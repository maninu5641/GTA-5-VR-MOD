#pragma once
// Camera stabilisation (0.4.1). Plain logic, unit tested in tests/camera_anchor_test.cpp.
//
// Up to 0.4.0 the VR camera was built on GTA's own first-person camera:
//  - its pitch and roll were applied on top of the tracked head, so a game camera
//    looking down tilted the whole world in the headset;
//  - its position bobs with the walk animation, so the VR view bobbed too;
//  - any brief loss of "player control"/falling switched to the flat cinema screen.
// Now only the game camera's HEADING turns the view, the eye is anchored to the
// character's body with an offset measured from the game camera, and soft
// interruptions must last before stereo is left.
#include "core.hpp"

namespace handvr {
// GTA world: X east, Y north, Z up; entity heading in degrees, counter-clockwise from north.
inline Vec3 headingRight(float degrees){float h=rad(degrees);return {std::cos(h),std::sin(h),0};}
inline Vec3 headingForward(float degrees){float h=rad(degrees);return {-std::sin(h),std::cos(h),0};}
inline Vec3 toPedLocal(Vec3 v,float heading){return {dot(v,headingRight(heading)),dot(v,headingForward(heading)),v.z};}
inline Vec3 fromPedLocal(Vec3 local,float heading){return headingRight(heading)*local.x+headingForward(heading)*local.y+Vec3{0,0,local.z};}
// VR comfort: keep the camera's heading (z), drop pitch (x) and roll (y). Rotation order 2 angles.
inline Vec3 levelRotation(Vec3 rotation){return {0,0,rotation.z};}

// 0.16.2: on foot (a person), where the eye may sit on the body. GTA's animation leans the head up to 50 cm forward
// (the character looking at the floor after the SteamVR menu, GTA's aim) or turns it aside, and an offset measured then
// put the view in front of the body and the controllers out of the arms' reach (the developer's 0.16.1 log: the eye
// 0.37-0.48 m in front of the body, or 0.10 m aside, for minutes). Now only upright moments are measured, and on foot
// the offset stays within an upright person's (a few cm aside at most, 0-14 cm forward, 45-85 cm above the root).
inline bool uprightEye(Vec3 local){return std::abs(local.x)<=.08f&&local.y>=-.06f&&local.y<=.20f&&local.z>=.40f&&local.z<=.95f;}
inline Vec3 onFootEye(Vec3 local){return {std::clamp(local.x,-.04f,.04f),std::clamp(local.y,0.0f,.14f),std::clamp(local.z,.45f,.85f)};}

class EyeAnchor {
    static constexpr unsigned CalibrationTicks=20,OnFootPatience=160;
    Vec3 sum{},offset{0,.08f,.62f};unsigned samples=0,waited=0;bool calibrated=false;std::uint64_t driftSince=0;
public:
    float lastDrift=0;unsigned recalibrations=0,leaningSkipped=0;
    bool ready()const{return calibrated;}
    Vec3 localOffset()const{return offset;}
    void reset(){sum={};samples=0;waited=0;calibrated=false;driftSince=0;lastDrift=0;}
    // pedPos: GET_ENTITY_COORDS of the player (root, moves smoothly with the body or vehicle).
    // gameCam: GTA's first-person camera position (bobs with the walk animation).
    // hold (0.10.0): the player's own crouch put the character in GTA's crouch stance; keep the standing
    // eye offset (the camera already goes down with the real head), no re-measure.
    // onFoot (0.16.2): a person standing / walking: upright samples only, the offset limited (above), and the view stays
    // on the body while it is measured (it followed GTA's animated head bone for those frames).
    Vec3 update(Vec3 pedPos,float heading,Vec3 gameCam,std::uint64_t nowMs,bool hold=false,bool onFoot=false){
        bool pedOk=finite(pedPos)&&std::isfinite(heading);
        bool camOk=pedOk&&finite(gameCam)&&length(gameCam-pedPos)<3;
        if(!pedOk)return gameCam;
        Vec3 local=camOk?toPedLocal(gameCam-pedPos,heading):Vec3{};
        bool sample=camOk&&(!onFoot||uprightEye(local));
        if(onFoot&&camOk&&!sample)++leaningSkipped;
        if(!calibrated){
            // Average the eye offset over ~20 frames so a walk-cycle extreme is not frozen in.
            if(sample){sum=sum+local;++samples;}
            ++waited;
            if(samples>=CalibrationTicks){offset=sum*(1.0f/float(samples));if(onFoot)offset=onFootEye(offset);calibrated=true;driftSince=0;}
            else if(onFoot&&waited>=OnFootPatience){calibrated=true;driftSince=0;}   // no upright moment for ~2.5 s: the last offset stays
            if(onFoot)return pedPos+fromPedLocal(onFootEye(offset),heading);
            return camOk?gameCam:pedPos+fromPedLocal(offset,heading);
        }
        lastDrift=camOk?length(local-offset):0;
        // A lasting change of the real eye position (crouch, cover, climbing, a seat): re-measure.
        // 0.16.2: on foot only an upright one (a lean is GTA's animation, not your head).
        if(sample&&lastDrift>.30f&&!hold){if(!driftSince)driftSince=nowMs;else if(nowMs-driftSince>=400){reset();++recalibrations;
            return onFoot?pedPos+fromPedLocal(onFootEye(offset),heading):gameCam;}}
        else driftSince=0;
        return pedPos+fromPedLocal(onFoot?onFootEye(offset):offset,heading);
    }
};

// GTA's first-person camera heading wobbles with the walk/idle animation. The image
// is rendered with that heading, but the pose sent to SteamVR only contains the real
// head, so every wobble shook the whole world in the headset. Small, slow changes
// are smoothed heavily; deliberate turns (snap turn, fast stick) pass through.
inline float wrapDegrees(float a){if(!std::isfinite(a))return 0;a=std::fmod(a+180.0f,360.0f);if(a<0)a+=360;return a-180;}
class YawStabilizer {
    float value=0;bool primed=false;
public:
    void reset(){primed=false;}
    float update(float heading,float dt){
        if(!std::isfinite(heading))return value;
        if(!primed||!(dt>0)||dt>.25f){value=heading;primed=true;return value;}
        float delta=wrapDegrees(heading-value);float size=std::abs(delta);
        if(size>12){value=heading;return value;}                 // snap turn / teleport: follow at once
        float tau=size<1.5f?.45f:size<6?.45f-(size-1.5f)/4.5f*.38f:.07f;   // wobble: 0.45 s .. turning: 0.07 s
        value=wrapDegrees(value+delta*(dt/(tau+dt)));return value;
    }
};
// 0.16.2: the view's heading on foot (a person). Up to 0.16.1 it was GTA's camera heading, smoothed. GTA's first-person
// character faces that camera only when GTA turns it, so when you turned for real the body stayed behind (the
// developer: "the head does not turn with the character's torso"), and a body turn that turned GTA's camera had to
// turn the view back once GTA showed it (one update late - or never: "GTA's camera did not take the body turn").
// Now the view keeps its own heading: your head and the snap turns turn it. GTA's camera and the character are turned
// to your body (TorsoYaw) and never move the view.
class ViewYaw {
    bool active=false,synced=false;float yaw=0;std::uint16_t lastTotal=0;
public:
    bool on()const{return active;}
    float value()const{return yaw;}
    // The view starts looking where the character faces: heading = yaw + your head's turn from the origin (degrees).
    void start(float characterHeading,float headFromOrigin){
        if(!std::isfinite(characterHeading)){active=false;return;}
        yaw=wrapDegrees(characterHeading-(std::isfinite(headFromOrigin)?headFromOrigin:0.0f));active=true;}
    void stop(){active=false;}
    void turn(float degrees){if(active&&std::isfinite(degrees))yaw=wrapDegrees(yaw+degrees);}
    // The motion add-on's snap turns: a running total in degrees (16 bits, wrapping; the first value read is the
    // start). Returns the degrees turned now.
    float snapTotal(std::uint16_t total){
        if(!synced){synced=true;lastTotal=total;return 0;}
        auto d=std::int16_t(std::uint16_t(total-lastTotal));lastTotal=total;
        if(!active||!d)return 0;
        yaw=wrapDegrees(yaw+float(d));return float(d);}
    void unsync(){synced=false;}
};
// The character's body heading in GTA's world (degrees): the view's heading + your body's turn from the origin
// (tracking yaw, radians, + = left like GTA headings).
inline float bodyHeading(float viewYaw,float torsoYaw,float originYaw){return wrapDegrees(viewYaw+(torsoYaw-originYaw)*180/pi);}

// Room-scale offset limited by a wall probe. Snapping the camera back to the body
// whenever the probe touched a wall made it flicker near walls; now the allowed
// fraction drops at once and grows back over ~0.25 s.
class OffsetLimiter {
    float allowed=1;
public:
    void reset(){allowed=1;}
    // hitFraction: probe contact along the offset (0..1), or >= 1 when clear.
    float update(float hitFraction,float dt){
        float target=!std::isfinite(hitFraction)||hitFraction>=1?1.0f:std::clamp(hitFraction-.15f,0.0f,1.0f);
        if(target<allowed)allowed=target;else if(dt>0&&std::isfinite(dt))allowed=std::min(target,allowed+std::min(dt,.1f)*4);
        return allowed;
    }
};

// Hard stops (cutscene, pause, fade, death, focus loss, Online) leave stereo at once.
// Soft stops (player control off, ragdoll) must last `graceMs` before the cinema screen,
// and never start stereo on their own.
class StereoGate {
    std::uint64_t softSince=0;bool active=false;
public:
    bool update(bool hardStop,bool softStop,std::uint64_t nowMs,std::uint64_t graceMs=300){
        if(hardStop){softSince=0;active=false;return false;}
        if(!softStop){softSince=0;active=true;return true;}
        if(!active)return false;
        if(!softSince)softSince=nowMs;
        if(nowMs-softSince>=graceMs)active=false;
        return active;
    }
    void reset(){softSince=0;active=false;}
};
}
