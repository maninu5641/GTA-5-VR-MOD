#pragma once
// 0.8.0: portable text parsing for game-folder detection (tested in tests/install_parse_test.cpp).
#include <string>
#include <vector>
namespace app {
// Values of "key": "value" (Epic .item JSON) and "key"  "value" (Steam libraryfolders.vdf), unescaped.
inline std::vector<std::string> quotedValuesUtf8(const std::string& text,const std::string& key){
    std::vector<std::string> out;std::size_t at=0;const std::string needle="\""+key+"\"";
    while((at=text.find(needle,at))!=std::string::npos){
        at+=needle.size();std::size_t q=text.find('"',at);if(q==std::string::npos)break;
        if(text.substr(at,q-at).find_first_not_of(" \t\r\n:")!=std::string::npos)continue;   // not a key: value pair
        std::string value;std::size_t i=q+1;
        for(;i<text.size()&&text[i]!='"';++i){
            if(text[i]=='\\'&&i+1<text.size()){++i;char c=text[i];value+=c=='/'?'/':c=='n'?'\n':c=='t'?'\t':c;}
            else value+=text[i];}
        if(i>=text.size())break;   // unterminated string
        out.push_back(value);at=i+1;
    }
    return out;
}
}
