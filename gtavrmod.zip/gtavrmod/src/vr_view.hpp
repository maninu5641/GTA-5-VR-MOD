#pragma once
// 0.7.0: what GTA really renders compared with what the headset needs.
// - viewProjection: the FOV to request from GTA and the per-eye texture crops, with an
//   optional image zoom (1 = exact) and a convergence depth for mono mode.
// - FovCalibrator: measures GTA's real image tangents from GET_SCREEN_COORD_FROM_WORLD_COORD
//   probes and corrects the request when GTA does not render the FOV it was asked for
//   (a too-narrow image is seen in the headset as "zoom").
// Plain logic, tested in tests/vr_view_test.cpp.
#include "stereo.hpp"
#include <algorithm>
#include <cmath>
#include <vector>

namespace handvr {

struct ViewSettings {
    float zoom=1;        // < 1: wider image squeezed into the headset (everything smaller); > 1: magnified
    float monoDepth=0;   // mono mode: metres where the flat image converges (0 = infinity)
};
// GTA's response to SET_CAM_FOV(f): image vertical half tangent = ratio * tan(f/2),
// horizontal = vertical * aspect. Unmeasured: ratio 1 (vertical FOV), aspect = backbuffer.
struct GtaFovModel { float ratio=1,aspect=0;bool measured=false; };
struct ViewProjection {
    float requestFov=0;            // degrees, for SET_CAM_FOV
    float tanV=0,tanH=0;           // expected half tangents of GTA's image
    Crop crop[2]{},monoCrop[2]{};  // texture bounds per eye (3D / mono)
    bool clamped=false;            // GTA's 130 degree limit reached
};
constexpr float MaxGtaFov=130,MinGtaFov=1;
inline float clampZoom(float z){return std::isfinite(z)?std::clamp(z,.6f,1.5f):1.0f;}

inline void validateEyes(const EyeTangents (&eyes)[2]){
    for(const auto& e:eyes)
        if(!std::isfinite(e.left)||!std::isfinite(e.right)||!std::isfinite(e.top)||!std::isfinite(e.bottom)
            ||e.left>=e.right||e.top>=e.bottom||e.left>=0||e.right<=0||e.top>=0||e.bottom<=0||-e.top>8||e.bottom>8||-e.left>8||e.right>8)
            throw std::runtime_error("Invalid headset projection tangents.");
}
inline void monoShift(const float (&eyeX)[2],const ViewSettings& settings,float (&shift)[2]){
    shift[0]=shift[1]=0;
    if(settings.monoDepth>0&&std::isfinite(settings.monoDepth))
        for(int i=0;i<2;++i)shift[i]=std::isfinite(eyeX[i])?std::clamp(-eyeX[i]/std::max(settings.monoDepth,.3f),-.2f,.2f):0.0f;
}
// Eye tangent t shows image tangent (t - shift) / zoom.
inline void fillCrops(ViewProjection& p,const EyeTangents (&eyes)[2],const float (&shift)[2],float zoom){
    for(int i=0;i<2;++i){const auto& e=eyes[i];
        p.crop[i]={.5f+(e.left/zoom)/(2*p.tanH),.5f+(e.top/zoom)/(2*p.tanV),.5f+(e.right/zoom)/(2*p.tanH),.5f+(e.bottom/zoom)/(2*p.tanV)};
        p.monoCrop[i]={.5f+((e.left-shift[i])/zoom)/(2*p.tanH),p.crop[i].vMin,.5f+((e.right-shift[i])/zoom)/(2*p.tanH),p.crop[i].vMax};}
}
// eyeX: eye-to-head X offsets (metres, left eye negative) for the mono convergence shift.
inline ViewProjection viewProjection(const EyeTangents (&eyes)[2],const float (&eyeX)[2],float backbufferAspect,const GtaFovModel& model,const ViewSettings& settings){
    if(!std::isfinite(backbufferAspect)||backbufferAspect<.25f||backbufferAspect>5)throw std::runtime_error("Unsupported backbuffer aspect ratio.");
    validateEyes(eyes);
    float zoom=clampZoom(settings.zoom);
    float aspect=model.aspect>.25f&&model.aspect<5&&std::isfinite(model.aspect)?model.aspect:backbufferAspect;
    float ratio=model.ratio>.2f&&model.ratio<5&&std::isfinite(model.ratio)?model.ratio:1.0f;
    float shift[2];monoShift(eyeX,settings,shift);
    // Image half tangents needed to cover both eyes (3D and mono crops).
    float needV=0,needH=0;
    for(int i=0;i<2;++i){const auto& e=eyes[i];
        needV=std::max({needV,-e.top/zoom,e.bottom/zoom});
        needH=std::max({needH,-e.left/zoom,e.right/zoom,std::abs(e.left-shift[i])/zoom,std::abs(e.right-shift[i])/zoom});}
    ViewProjection p;
    float tanV=std::max(needV,needH/aspect);
    float request=2*std::atan(tanV/ratio)*180/pi;
    if(request>MaxGtaFov){request=MaxGtaFov;p.clamped=true;tanV=ratio*std::tan(rad(MaxGtaFov/2));}
    if(request<MinGtaFov)throw std::runtime_error("Headset projection is below GTA's camera FOV range.");
    p.requestFov=request;p.tanV=tanV;p.tanH=tanV*aspect;
    fillCrops(p,eyes,shift,zoom);
    return p;
}
// A measured GTA image (request, tangents) used as it is, e.g. after the last calibration round.
inline ViewProjection viewProjectionAt(const EyeTangents (&eyes)[2],const float (&eyeX)[2],const ViewSettings& settings,float requestFov,float tanV,float tanH){
    validateEyes(eyes);
    if(!(tanV>.05f)||!(tanH>.05f)||!std::isfinite(tanV)||!std::isfinite(tanH)||!(requestFov>=MinGtaFov&&requestFov<=MaxGtaFov))throw std::runtime_error("Invalid measured GTA projection.");
    ViewProjection p;p.requestFov=requestFov;p.tanV=tanV;p.tanH=tanH;
    float shift[2];monoShift(eyeX,settings,shift);fillCrops(p,eyes,shift,clampZoom(settings.zoom));
    float needV=0,needH=0;for(const auto& e:eyes){needV=std::max({needV,-e.top,e.bottom});needH=std::max({needH,-e.left,e.right});}
    p.clamped=needV/clampZoom(settings.zoom)>tanV*1.001f||needH/clampZoom(settings.zoom)>tanH*1.001f;
    return p;
}

// ---------- Measuring GTA's real FOV ----------
struct FovSample { float tanV=0,tanH=0; };
// Screen coordinates (0..1, y down) of points at tangent +-tanA above / below / left / right of
// the rendered camera's axis, and of the axis itself (must be the screen centre).
inline bool fovSample(float tanA,float xLeft,float xRight,float yUp,float yDown,float xCentre,float yCentre,FovSample& out){
    for(float v:{tanA,xLeft,xRight,yUp,yDown,xCentre,yCentre})if(!std::isfinite(v))return false;
    if(std::abs(xCentre-.5f)>.015f||std::abs(yCentre-.5f)>.015f)return false;   // viewport and camera readback disagree
    float dx=xRight-xLeft,dy=yDown-yUp;
    if(dx<.02f||dy<.02f||dx>1.2f||dy>1.2f)return false;
    // Symmetric pairs cancel a small rotation between the readback and the viewport.
    if(std::abs((xRight+xLeft)*.5f-xCentre)>.02f||std::abs((yDown+yUp)*.5f-yCentre)>.02f)return false;
    out={tanA/dy,tanA/dx};
    return out.tanV>.05f&&out.tanV<6&&out.tanH>.05f&&out.tanH<12;
}
inline float medianOf(std::vector<float> v){if(v.empty())return 0;std::sort(v.begin(),v.end());std::size_t n=v.size();return n%2?v[n/2]:.5f*(v[n/2-1]+v[n/2]);}

// Rounds: measure at the current request; if GTA's image differs from what was assumed,
// correct the model (next request) and measure again; stop when consistent (max 3 rounds).
class FovCalibrator {
    std::vector<float> v,h;float request=0;int rounds=0;bool done=false;
public:
    static constexpr std::size_t Needed=24;
    struct Result { bool ready=false,changed=false,finished=false;GtaFovModel model{};float measuredV=0,measuredH=0;float request=0; };
    bool finished()const{return done;}
    int roundsDone()const{return rounds;}
    void restart(){v.clear();h.clear();request=0;rounds=0;done=false;}
    void stop(){done=true;v.clear();h.clear();}   // log-only mode: one measurement, no correction
    // assumed: the model the current request was computed with.
    Result add(const FovSample& s,float requestFov,const GtaFovModel& assumed,float backbufferAspect){
        Result r;if(done||!(requestFov>0))return r;
        if(std::abs(requestFov-request)>.01f){v.clear();h.clear();request=requestFov;}
        v.push_back(s.tanV);h.push_back(s.tanH);
        if(v.size()<Needed)return r;
        float mv=medianOf(v),mh=medianOf(h);
        // Reject a noisy round: most samples must agree within 3 %.
        std::size_t close=0;for(std::size_t i=0;i<v.size();++i)if(std::abs(v[i]/mv-1)<.03f&&std::abs(h[i]/mh-1)<.03f)++close;
        if(close*4<v.size()*3){v.clear();h.clear();return r;}
        v.clear();h.clear();++rounds;
        r.ready=true;r.measuredV=mv;r.measuredH=mh;r.request=requestFov;
        float t=std::tan(rad(requestFov/2));
        r.model.ratio=mv/t;r.model.aspect=mh/mv;r.model.measured=true;
        float assumedAspect=assumed.aspect>0?assumed.aspect:backbufferAspect,assumedRatio=assumed.ratio>0?assumed.ratio:1;
        bool consistent=std::abs(r.model.ratio/assumedRatio-1)<.02f&&std::abs(r.model.aspect/assumedAspect-1)<.02f;
        r.changed=!consistent;
        if(consistent||rounds>=3){done=true;r.finished=true;}
        return r;
    }
};
}
