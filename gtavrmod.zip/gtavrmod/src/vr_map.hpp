#pragma once
// 0.9.0: GTA's minimap in VR (GTA4VR has a wrist radar and a dashboard radar).
// GTA draws the minimap in the bottom-left corner of the whole rendered image. The VR camera
// renders much more than the headset shows, so that corner is never inside the eye crops (the
// 0.8.0 video: no map at all). The renderer copies that corner of each captured frame into a
// small texture and shows it on a SteamVR overlay: on the left wrist on foot (when the watch side
// faces the eyes), on the dashboard in vehicles.
// Plain logic, tested in tests/vr_map_test.cpp.
#include "core.hpp"
#include <algorithm>
#include <cmath>

namespace handvr {
// Normalised screen rectangle: x right, y down, 0..1.
struct ScreenRect { float x=0,y=0,w=0,h=0; };
// GTA's minimap (FiveM GetMinimapAnchor): 1/(4*aspect) wide, 1/5.674 high, moved in from the
// bottom-left corner by the HUD safe zone (GET_SAFE_ZONE_SIZE: 1.0 = no margin, 0.9 = 5 %).
inline ScreenRect minimapRect(float safeZone,float aspect){
    if(!std::isfinite(safeZone)||safeZone<.5f||safeZone>1.2f)safeZone=1;
    if(!std::isfinite(aspect)||aspect<.5f||aspect>4.5f)aspect=16.0f/9.0f;
    float margin=.5f*std::abs(1-safeZone);
    ScreenRect r;r.w=1/(4*aspect);r.h=1/5.674f;r.x=margin;r.y=1-margin-r.h;return r;
}
// What is captured: the minimap with a small margin plus a status strip above it (wanted level,
// clock) that the renderer draws itself, clamped to the screen.
inline ScreenRect radarCapture(const ScreenRect& map,float stripHeight){
    float mx=map.w*.04f,my=map.h*.04f;
    float left=std::max(0.0f,map.x-mx),right=std::min(1.0f,map.x+map.w+mx);
    float top=std::max(0.0f,map.y-my-std::max(0.0f,stripHeight)),bottom=std::min(1.0f,map.y+map.h+my);
    return {left,top,right-left,bottom-top};
}
// The status strip, just above the minimap (inside radarCapture).
inline ScreenRect radarStrip(const ScreenRect& map,float stripHeight){return {map.x,map.y-map.h*.04f-stripHeight,map.w,stripHeight};}
struct PixelBox { unsigned left=0,top=0,right=0,bottom=0; unsigned width()const{return right-left;} unsigned height()const{return bottom-top;} };
inline PixelBox toPixels(const ScreenRect& r,unsigned width,unsigned height){
    PixelBox b;if(!width||!height)return b;
    auto clampTo=[](float v,unsigned limit){if(!std::isfinite(v))v=0;return unsigned(std::clamp(std::lround(v*float(limit)),0L,long(limit)));};
    b.left=clampTo(r.x,width);b.right=clampTo(r.x+r.w,width);b.top=clampTo(r.y,height);b.bottom=clampTo(r.y+r.h,height);
    if(b.right<=b.left||b.bottom<=b.top)return {};
    return b;
}

// ---------- Overlay placement ----------
// A pose from three axes and a position (columns = the overlay's X / Y / Z; the image faces +Z).
inline Pose poseFromAxes(Vec3 x,Vec3 y,Vec3 z,Vec3 p){
    Pose r{};Vec3 c[4]={x,y,z,p};for(int i=0;i<4;++i){r.m[0][i]=c[i].x;r.m[1][i]=c[i].y;r.m[2][i]=c[i].z;}return r;
}
inline Pose composePoses(const Pose& a,const Pose& b){Pose r{};
    for(int i=0;i<3;++i)for(int j=0;j<4;++j){float s=0;for(int k=0;k<3;++k)s+=a.m[i][k]*b.m[k][j];r.m[i][j]=s+(j==3?a.m[i][3]:0);}return r;}
// Rotation about the pose's own X axis; positive turns the face (+Z) toward its +Y (up).
inline Pose tiltX(const Pose& p,float degrees){float a=rad(degrees),c=std::cos(a),s=std::sin(a);
    Vec3 y=p.col(1)*c-p.col(2)*s,z=p.col(2)*c+p.col(1)*s;return poseFromAxes(p.col(0),y,z,p.pos());}
// Watch face on the back of the wrist, in the controller's own (raw) space: the image's right
// points along the forearm toward the hand on the left wrist (toward the elbow on the right one),
// its top away from the body when the back of the hand faces the eyes.
// offset: metres in controller space (x right, y up, z back toward the wrist); mirrored for the right hand.
inline Pose wristOverlayLocal(bool leftHand,Vec3 offset,float tiltDegrees=0){
    Pose p=leftHand?poseFromAxes({0,0,-1},{0,-1,0},{-1,0,0},{-std::abs(offset.x),offset.y,offset.z})
                   :poseFromAxes({0,0,1},{0,-1,0},{1,0,0},{std::abs(offset.x),offset.y,offset.z});
    return tiltX(p,tiltDegrees);
}
// Dashboard radar: in front of the seated player, below eye level, tilted to face the eyes.
// origin: the recentred (yaw-only) head pose; offset: x right, y up, z forward (metres).
inline Pose dashboardOverlay(const Pose& origin,Vec3 offset,float tiltDegrees=35){
    Vec3 x=origin.col(0),y=origin.col(1),z=origin.col(2);   // z = back toward the player
    Vec3 p=origin.pos()+x*offset.x+y*offset.y-z*offset.z;
    return tiltX(poseFromAxes(x,y,z,p),tiltDegrees);
}
// The overlay's front (+Z) faces the eyes, within `maxDistance`.
inline float facingAmount(const Pose& overlay,Vec3 eye){
    Vec3 to=eye-overlay.pos();float d=length(to);if(!(d>1e-4f))return 0;
    return dot(overlay.col(2),to*(1/d));
}
class Hysteresis {
    bool on=false;
public:
    bool value()const{return on;}
    void reset(){on=false;}
    bool update(float v,float onAbove,float offBelow){if(!std::isfinite(v))v=-1;on=on?v>offBelow:v>onAbove;return on;}
};
}
