// GTA 5 VR launcher (GTA5 VR.exe, in the GTA V Legacy folder).
// 0.16.0, the release launcher: four options and Play. The built-in OpenVR renderer is the only renderer (the
// R.E.A.L. / OpenXR options and their input companion are gone) and physical driving was taken out. The options are
// saved as soon as they change; the panel at the top says in plain words whether everything needed is there.
#include "install_tools.hpp"
#include "expected_files.hpp"
using namespace app;
namespace {
HWND window=nullptr,firstPerson=nullptr,manual=nullptr,support=nullptr,laser=nullptr;
HFONT titleFont=nullptr,normal=nullptr,bold=nullptr,optionFont=nullptr,smallFont=nullptr,playFont=nullptr;
HBRUSH background=nullptr,panelBrush=nullptr;
fs::path game;bool xbox=false;   // the Xbox app (PC Game Pass) version: GTA V is started from the Xbox app
enum class State { Ready,NotReady,Starting,Running };
State state=State::NotReady;std::wstring problem,note;ULONGLONG checkedAt=0,startedAt=0;
enum { Play=101,FirstPerson=201,ManualReload=202,SupportGrip=203,Laser=204 };
constexpr const wchar_t* VersionText=L"0.16.3";
constexpr COLORREF warn=RGB(240,190,70);
constexpr int Width=640,Height=676,Left=32,Right=Width-32;

bool checked(HWND h){return SendMessageW(h,BM_GETCHECK,0,0)==BST_CHECKED;}
void checkmark(HWND h,bool value){SendMessageW(h,BM_SETCHECK,value?BST_CHECKED:BST_UNCHECKED,0);}
void redraw(){InvalidateRect(window,nullptr,FALSE);}
// What stops GTA 5 VR from working, in plain words ("" = nothing).
std::wstring findProblem(){
    if(!legacyGame(game))return L"This launcher is not in a GTA V Legacy folder. Run gta5vrmod setup.exe and install GTA 5 VR into your GTA V folder.";
    if(!pe64(game/L"ScriptHookV.dll"))return L"Script Hook V is missing. Download it from dev-c.com and copy ScriptHookV.dll into your GTA V folder.";
    if(!pe64(game/L"dinput8.dll"))return L"The ASI Loader is missing. Copy dinput8.dll (it comes with Script Hook V) into your GTA V folder.";
    if(app::exists(game/L"RealVR.asi"))return L"Another VR mod (RealVR.asi) is in your GTA V folder. Remove it: two VR mods cannot run at the same time.";
    for(const auto& f:expectedFiles){bool ok=false;try{ok=sha256(read(game/fs::path(f.path),200*1024*1024))==f.hash;}catch(...){}
        if(!ok)return L"A GTA 5 VR file is missing or damaged ("+fs::path(f.path).filename().wstring()+L"). Run gta5vrmod setup.exe again to repair it.";}
    if(!steamVRKnown())return L"SteamVR was not found. Install SteamVR (free on Steam) before playing.";
    return L"";
}
void recheck(bool force){
    auto now=GetTickCount64();if(!force&&now-checkedAt<1500)return;checkedAt=now;
    if(state==State::Starting&&!processRunning(L"GTA5.exe")&&now-startedAt<60000)return;   // GTA is still on its way (its launcher first)
    problem=findProblem();
    state=!problem.empty()?State::NotReady:processRunning(L"GTA5.exe")?State::Running:State::Ready;
    redraw();
}
// The four options, straight into GTAHandVR.ini (the add-on reads its file again when it changes).
void saveSettings(bool announce){
    auto config=game/L"GTAHandVR.ini";
    put(config,L"Renderer",L"FirstPerson",checked(firstPerson)?L"1":L"0");
    put(config,L"Motion",L"ManualReload",checked(manual)?L"1":L"0");
    put(config,L"Motion",L"RequireSupportGrip",checked(support)?L"1":L"0");
    put(config,L"Motion",L"Laser",checked(laser)?L"1":L"0");
    if(announce){note=processRunning(L"GTA5.exe")?L"Saved. GTA V is running: the weapon options change now, first-person gameplay when GTA V starts again.":L"Saved.";redraw();}
}
void play(){
    if(processRunning(L"GTA5.exe")){state=State::Running;note=L"";redraw();return;}
    saveSettings(false);
    problem=findProblem();if(!problem.empty()){state=State::NotReady;note=L"";redraw();return;}
    // The Xbox app version starts only from the Xbox app: its Store page (GTA V Legacy (PC)) has the Play button.
    if(xbox){try{open(window,L"ms-windows-store://pdp/?productid=9N9RSV4F7ZR0");note=L"Press Play on GTA V Legacy in the page that opens, then choose Story Mode.";}
        catch(...){note=L"Start GTA V Legacy from the Xbox app, then choose Story Mode.";}
        redraw();return;}
    auto p=spawn(game/L"PlayGTAV.exe");CloseHandle(p);
    state=State::Starting;startedAt=GetTickCount64();note=L"";redraw();
}
const wchar_t* headline(){
    switch(state){
        case State::Ready:return L"Ready to play";
        case State::Starting:return L"GTA V is starting";
        case State::Running:return L"GTA V is running";
        default:return L"Not ready yet";
    }
}
std::wstring detail(){
    switch(state){
        case State::Ready:return xbox?L"Start SteamVR, then GTA V Legacy from the Xbox app. The VR view starts once Story Mode has loaded."
            :L"Start SteamVR and press Play (or start GTA V from Epic, Steam or Rockstar). The VR view starts once Story Mode has loaded.";
        case State::Starting:return L"Choose Story Mode and put on your headset: the VR view starts once Story Mode has loaded.";
        case State::Running:return L"Have fun! Changes to the options below are saved right away.";
        default:return problem;
    }
}
struct Option { HWND* handle;int id;const wchar_t* label;const wchar_t* help;const wchar_t* section;const wchar_t* key;const wchar_t* fallback; };
const Option options[]={
    {&firstPerson,FirstPerson,L"First-person gameplay",L"You see through the character's eyes. Off: GTA on a big screen in VR.",L"Renderer",L"FirstPerson",L"1"},
    {&manual,ManualReload,L"Physical magazine reload",L"Drop the magazine, grab a new one at your shoulder or belt, push it in.",L"Motion",L"ManualReload",L"1"},
    {&support,SupportGrip,L"Support grip for heavier weapons",L"Rifles and shotguns need your other hand on them to shoot.",L"Motion",L"RequireSupportGrip",L"0"},
    {&laser,Laser,L"Show aiming laser",L"A laser from the barrel shows where your shots go.",L"Motion",L"Laser",L"0"},
};
constexpr int OptionsTop=246,OptionStep=62,PlayTop=OptionsTop+4*OptionStep+12;
LRESULT CALLBACK procedure(HWND h,UINT m,WPARAM w,LPARAM l) {
    try {
        switch(m) {
            case WM_CREATE: {
                window=h;titleFont=font(34,FW_BOLD);normal=font(16);bold=font(17,FW_SEMIBOLD);optionFont=font(17,FW_SEMIBOLD);smallFont=font(15);playFont=font(21,FW_BOLD);
                background=CreateSolidBrush(bg);panelBrush=CreateSolidBrush(panel);
                game=modulePath().parent_path();xbox=xboxAppFolder(game);auto config=game/L"GTAHandVR.ini";
                int y=OptionsTop;
                for(const auto& o:options){*o.handle=control(h,L"BUTTON",o.label,BS_AUTOCHECKBOX|WS_TABSTOP,o.id,Left,y,Right-Left,26,optionFont);
                    checkmark(*o.handle,ini(config,o.section,o.key,o.fallback)==L"1");y+=OptionStep;}
                control(h,L"BUTTON",L"PLAY GTA 5 IN VR",BS_OWNERDRAW|WS_TABSTOP,Play,Left,PlayTop,Right-Left,58,playFont);
                recheck(true);return 0;
            }
            case WM_ACTIVATE: if(LOWORD(w)!=WA_INACTIVE)recheck(false);break;   // back from installing Script Hook V, SteamVR... (focus: DefWindowProc)
            case WM_COMMAND:
                if(LOWORD(w)==Play){play();return 0;}
                if(LOWORD(w)>=FirstPerson&&LOWORD(w)<=Laser&&HIWORD(w)==BN_CLICKED){saveSettings(true);return 0;}
                return 0;
            case WM_CTLCOLORSTATIC: case WM_CTLCOLORBTN: SetTextColor(reinterpret_cast<HDC>(w),ink);SetBkColor(reinterpret_cast<HDC>(w),bg);return reinterpret_cast<LRESULT>(background);
            case WM_DRAWITEM: drawButton(reinterpret_cast<DRAWITEMSTRUCT*>(l),playFont,true);return TRUE;
            case WM_PAINT: {
                PAINTSTRUCT ps;auto dc=BeginPaint(h,&ps);RECT r;GetClientRect(h,&r);FillRect(dc,&r,background);
                drawText(dc,L"GTA 5 VR",{Left,22,Right,68},titleFont,ink,DT_LEFT|DT_TOP|DT_SINGLELINE);
                drawText(dc,(std::wstring(L"Version ")+VersionText+L"   ·   GTA V Legacy   ·   Story Mode").c_str(),{Left+2,70,Right,94},normal,accent,DT_LEFT|DT_TOP|DT_SINGLELINE);
                // The status card: is everything there?
                RECT card{Left,110,Right,198};FillRect(dc,&card,panelBrush);
                COLORREF dot=state==State::NotReady?warn:accent;auto brush=CreateSolidBrush(dot);auto pen=CreatePen(PS_SOLID,1,dot);auto oldBrush=SelectObject(dc,brush);auto oldPen=SelectObject(dc,pen);
                Ellipse(dc,Left+16,127,Left+30,141);SelectObject(dc,oldBrush);SelectObject(dc,oldPen);DeleteObject(brush);DeleteObject(pen);
                drawText(dc,headline(),{Left+42,121,Right-16,145},bold,state==State::NotReady?warn:ink,DT_LEFT|DT_TOP|DT_SINGLELINE|DT_END_ELLIPSIS);
                drawText(dc,detail().c_str(),{Left+42,148,Right-16,196},smallFont,muted);
                drawText(dc,L"OPTIONS",{Left,216,Right,236},smallFont,muted,DT_LEFT|DT_TOP|DT_SINGLELINE);
                int y=OptionsTop;
                for(const auto& o:options){drawText(dc,o.help,{Left+22,y+27,Right,y+50},smallFont,muted,DT_LEFT|DT_TOP|DT_SINGLELINE|DT_END_ELLIPSIS);y+=OptionStep;}
                if(!note.empty())drawText(dc,note.c_str(),{Left,PlayTop+66,Right,PlayTop+106},smallFont,accent);
                // 0.16.3: A is GTA's E (the developer: "the gun shop person says press E - make it the A button").
                drawText(dc,L"In game: A is GTA's E key (shops, people). F10 recenters the view. Hold both thumbsticks for 1 second to turn VR off or on. "
                    L"Stand in a T-pose and hold both triggers for 2 seconds to fit the body to your size.",{Left,Height-72,Right,Height-12},smallFont,muted);
                EndPaint(h,&ps);return 0;
            }
            case WM_DESTROY:
                for(auto f:{titleFont,normal,bold,optionFont,smallFont,playFont})DeleteObject(f);
                DeleteObject(background);DeleteObject(panelBrush);PostQuitMessage(0);return 0;
        }
    } catch(const std::exception& e){error(h,e);}
    return DefWindowProcW(h,m,w,l);
}
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int show) {
    CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);SetProcessDPIAware();
    WNDCLASSW c{};c.lpfnWndProc=procedure;c.hInstance=instance;c.lpszClassName=L"GTA5VRLauncher16";c.hCursor=LoadCursorW(nullptr,IDC_ARROW);RegisterClassW(&c);
    constexpr DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;RECT r{0,0,Width,Height};AdjustWindowRect(&r,style,FALSE);
    auto h=CreateWindowExW(0,c.lpszClassName,L"GTA 5 VR",style,CW_USEDEFAULT,CW_USEDEFAULT,r.right-r.left,r.bottom-r.top,nullptr,nullptr,instance,nullptr);if(!h)return 1;
    ShowWindow(h,show);MSG m;while(GetMessageW(&m,nullptr,0,0)>0){if(!IsDialogMessageW(h,&m)){TranslateMessage(&m);DispatchMessageW(&m);}}CoUninitialize();return int(m.wParam);
}
