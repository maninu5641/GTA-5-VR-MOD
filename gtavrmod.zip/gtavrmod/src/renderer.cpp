#include "openvr_input.hpp"
#include "native.hpp"
#include "native_ids.hpp"
#include "stereo.hpp"
#include "frame_sync.hpp"
#include "hand_overlay.hpp"
#include "camera_anchor.hpp"
#include "weapons_vr.hpp"
#include "vr_body.hpp"
#include "vr_view.hpp"
#include "vr_arms.hpp"
#include "vr_calib.hpp"
#include "vr_map.hpp"
#include "vr_play.hpp"
#include "vr_follow.hpp"
#include "vr_grip.hpp"
#include "vr_shot.hpp"
#include "vr_menu.hpp"
#include "vr_aim.hpp"
#define GTA5VR_CAMERA_API_BUILD
#include "camera_bridge.hpp"
#include <d3d11.h>
#include <dxgi.h>
#include <array>
#include <atomic>
#include <memory>
#include <mutex>

using namespace native;
using gta::call;
namespace {
constexpr const char* Version="0.16.3";
HMODULE moduleHandle=nullptr;
CameraBridge cameraBridge;
using PresentCallback=void(__cdecl*)(void*);
using CallbackRegistration=void(__cdecl*)(PresentCallback);
CallbackRegistration unregisterPresent=nullptr;
bool presentRegistered=false;
std::atomic<std::uint64_t> callbackCount{0},stageTime{0};
std::atomic<bool> startupStopped{false};
std::atomic<const char*> startupStage{"ASI loading"};
template<class T> struct Com {
    T* p=nullptr;
    ~Com(){reset();}
    void reset(){if(p)p->Release();p=nullptr;}
    T** put(){reset();return &p;}
    T* operator->()const{return p;}
};
std::wstring directory(){wchar_t path[32768]{};GetModuleFileNameW(moduleHandle,path,32768);std::wstring p(path);return p.substr(0,p.find_last_of(L"\\/"));}
void log(const std::string& message){auto path=directory()+L"\\GTA5VRRenderer.log";FILE* f=_wfopen(path.c_str(),L"a");if(f){std::fprintf(f,"[%llu] %s\n",static_cast<unsigned long long>(GetTickCount64()),message.c_str());std::fclose(f);}}
void stage(const char* message){stageTime.store(GetTickCount64());startupStage.store(message);log(message);}
void requireHR(HRESULT result,const char* operation){if(FAILED(result))throw std::runtime_error(std::string(operation)+" failed (HRESULT "+std::to_string(static_cast<unsigned long>(result))+").");}
void requireOverlay(EVROverlayError error,const char* operation){if(error!=EVROverlayError_VROverlayError_None)throw std::runtime_error(std::string(operation)+" failed (OpenVR overlay "+std::to_string(int(error))+").");}
std::uint64_t nowUs(){LARGE_INTEGER f{},c{};QueryPerformanceFrequency(&f);QueryPerformanceCounter(&c);
    auto q=std::uint64_t(c.QuadPart),hz=std::uint64_t(f.QuadPart);return q/hz*1000000+q%hz*1000000/hz;}
std::string fixed(double value,int digits=1){char text[32];std::snprintf(text,sizeof(text),"%.*f",digits,value);return text;}
// CameraLag: -1 automatic (measured), 0 same update, 1 one update late.
int parseCameraLag(const wchar_t* value){if(!_wcsicmp(value,L"0"))return 0;if(!_wcsicmp(value,L"1"))return 1;return -1;}
const char* cameraLagName(int value){return value<0?"Auto":value==0?"0":"1";}
// SubmitDevice: which D3D11 device hands textures to SteamVR.
// Bridge: a separate DXGI 1.1 device on GTA's GPU, fed through shared textures.
// GTA V Legacy creates its device through DXGI 1.0; SteamVR then rejects GTA's own
// textures with error 106 (SharedTexturesNotSupported) because it cannot create its
// keyed-mutex sync texture on that device. Game: submit GTA's textures directly.
enum class SubmitMode { Auto,Bridge,Game };
SubmitMode parseSubmitMode(const wchar_t* value){if(!_wcsicmp(value,L"Bridge"))return SubmitMode::Bridge;if(!_wcsicmp(value,L"Game"))return SubmitMode::Game;return SubmitMode::Auto;}
const char* submitModeName(SubmitMode m){return m==SubmitMode::Bridge?"Bridge":m==SubmitMode::Game?"Game":"Auto";}
// "r,g,b" (0-255) -> linear colour; false for Auto/Skin/invalid.
bool parseColor(const wchar_t* text,Vec3& out){int r=-1,g=-1,b=-1;if(swscanf(text,L"%d , %d , %d",&r,&g,&b)!=3||r<0||g<0||b<0||r>255||g>255||b>255)return false;out=srgb(r,g,b);return true;}
// "x,y,z" metres; false (out unchanged) when invalid or out of range.
bool parseOffset(const wchar_t* text,Vec3& out,float limit){float x=NAN,y=NAN,z=NAN;if(swscanf(text,L"%f , %f , %f",&x,&y,&z)!=3)return false;Vec3 v{x,y,z};
    if(!finite(v)||std::abs(x)>limit||std::abs(y)>limit||std::abs(z)>limit)return false;out=v;return true;}
float iniFloat(const wchar_t* section,const wchar_t* key,float fallback,float lo,float hi,const std::wstring& path){wchar_t value[64]{};
    GetPrivateProfileStringW(section,key,L"",value,64,path.c_str());if(!value[0])return fallback;wchar_t* end=nullptr;float v=std::wcstof(value,&end);
    return end==value||!std::isfinite(v)?fallback:std::clamp(v,lo,hi);}
std::uint32_t floatBits(float v){std::uint32_t b=0;std::memcpy(&b,&v,4);return b;}
// 0.15.5: a key like a keyboard (scan code; extended = arrows / Page Up / Down, not the number pad's).
bool sendScanKey(std::uint16_t code,bool extended,bool up){INPUT in{};in.type=INPUT_KEYBOARD;in.ki.wScan=code;
    in.ki.dwFlags=KEYEVENTF_SCANCODE|(extended?KEYEVENTF_EXTENDEDKEY:0)|(up?KEYEVENTF_KEYUP:0);return SendInput(1,&in,sizeof(in))==1;}
struct Config {
    bool builtin=true,oldExternal=false,oldOpenXR=false,firstPerson=true,hideBody=true,frameTag=true;float scale=1;unsigned frameOffset=0;int cameraLag=-1;SubmitMode submitDevice=SubmitMode::Auto;
    // [Hands] 0.4.0
    bool levelHorizon=true,stableCamera=true,stabilizeTurn=true,mono=false;   // 0.4.1
    bool stereoAuto=true,characterBody=true;   // 0.6.0 (0.8.0: the 0.6.0 renderer behaviour is the default again)
    float zoom=1,monoDepth=0;int fovCheck=1,overlayMode=0,armIkMode=0;bool armPose=true;   // 0.7.0 / 0.8.0: FovCheck 0 Off / 1 Log / 2 Fix; overlay 0 Auto / 1 On / 2 Off; arm IK 0 Auto / 1 Position / 2 Off
    // 0.9.0: ArmPose 1 = typing (hands in front, palms down), 2 = box (0.8.0, palms up), 0 = off.
    // 0.10.0: 3 = grip (fists, thumbs up). 0.11.0: typing is the default again (the grip animation is
    // multiplayer-only: it never loaded in Story Mode).
    int armPoseKind=1;
    // 0.11.0 [Hands]: IK blend-in in ms (0 = full strength at once); GTA's own first-person arm IK (off by default).
    int ikBlendIn=0;bool gameFpsArmIk=false;
    // 0.11.0 [Body]: GTA's own camera pitch held level on foot (it bent the character over; the view ignores it).
    bool levelGameCam=true;
    // 0.13.0 [Hands]: the fingers - GTA's own hand poses per arm, an empty hand closed by the grip button
    // (Fingers=Off: the 0.12.0 still pose). 0.14.0: the hand check picks the clips and the filter.
    bool fingers=true;
    PistolGrip pistolGrip=PistolGrip::Auto;   // 0.15.8 [Hands] PistolGrip=Auto / Rifle
    // 0.10.0 [Body]: the character follows real steps (room scale) and a real crouch; GTA leg IK.
    bool roomScale=true,physicalCrouch=true,legIk=true,turnBody=true;float crouchRatio=.78f;
    // 0.9.0 [Body]: eye height saved by the T-pose calibration (0 = not calibrated).
    float playerEye=0;bool calibrationGesture=true;
    // 0.9.0 [Map]: GTA's minimap on the wrist (-1 off, 0 left, 1 right) and on the dashboard.
    int wristMap=0;bool dashboardMap=true,mapStrip=true;float wristSize=.11f,dashboardSize=.22f,wristTilt=0,dashboardTilt=35;
    Vec3 wristOffset{.035f,-.015f,.10f},dashboardOffset{.15f,-.33f,.48f};
    // 0.9.0 [Motion] CharacterWheelView=Flat: the flat game view while GTA's character wheel is held.
    bool wheelFlat=false;
    // 0.15.0 [Renderer] VrButton=Sticks: both thumbstick clicks held VrButtonHold seconds = VR on / off (Off: F11 only).
    bool vrButton=true;int vrButtonMs=1000;
    // 0.15.5 [Controls]: what each of the six buttons does (vr_menu.hpp; chosen in the VR menu). [Menu] Controllers=1:
    // GTA's pause menu played with the controllers; PauseOnDashboard=1: the SteamVR menu button pauses GTA.
    ButtonMap buttons=ButtonMap::defaults();bool menuControls=true,pauseOnDashboard=true;
    // Drawn capsule hands: by default only when the character body is hidden (Body=Hidden).
    bool overlay()const{return showHands&&(overlayMode==1||(overlayMode==0&&!characterBody));}
    bool showHands=true,showArms=true,fingerCombo=true,skinAuto=true,sleeveSkin=true;float armLength=1,handBrightness=1;Vec3 skin{},sleeve{};
    void load(){auto path=directory()+L"\\GTAHandVR.ini";wchar_t value[64]{};
        GetPrivateProfileStringW(L"Hands",L"ArmPose",L"Typing",value,64,path.c_str());
        armPoseKind=!_wcsicmp(value,L"0")||!_wcsicmp(value,L"Off")?0:!_wcsicmp(value,L"Box")||!_wcsicmp(value,L"2")?2:!_wcsicmp(value,L"Grip")||!_wcsicmp(value,L"3")?3:1;
        ikBlendIn=int(iniFloat(L"Hands",L"IkBlendIn",0,0,500,path));
        GetPrivateProfileStringW(L"Hands",L"GameFpsArmIk",L"Off",value,64,path.c_str());gameFpsArmIk=!_wcsicmp(value,L"On")||!_wcsicmp(value,L"1");
        levelGameCam=GetPrivateProfileIntW(L"Body",L"LevelGameCamera",1,path.c_str())!=0;
        GetPrivateProfileStringW(L"Hands",L"Fingers",L"On",value,64,path.c_str());fingers=_wcsicmp(value,L"Off")!=0&&_wcsicmp(value,L"0")!=0;
        GetPrivateProfileStringW(L"Hands",L"PistolGrip",L"Auto",value,64,path.c_str());pistolGrip=!_wcsicmp(value,L"Rifle")?PistolGrip::Rifle:PistolGrip::Auto;   // 0.15.8
        roomScale=GetPrivateProfileIntW(L"Body",L"RoomScale",1,path.c_str())!=0;physicalCrouch=GetPrivateProfileIntW(L"Body",L"PhysicalCrouch",1,path.c_str())!=0;
        legIk=GetPrivateProfileIntW(L"Body",L"LegIk",1,path.c_str())!=0;turnBody=GetPrivateProfileIntW(L"Body",L"TurnBody",1,path.c_str())!=0;crouchRatio=iniFloat(L"Body",L"CrouchHeight",.78f,.50f,.92f,path);
        playerEye=iniFloat(L"Body",L"PlayerEyeHeight",0,0,2.3f,path);if(playerEye<.9f)playerEye=0;
        calibrationGesture=GetPrivateProfileIntW(L"Body",L"Calibration",1,path.c_str())!=0;
        GetPrivateProfileStringW(L"Map",L"Wrist",L"Left",value,64,path.c_str());wristMap=!_wcsicmp(value,L"Right")?1:!_wcsicmp(value,L"Off")||!_wcsicmp(value,L"0")?-1:0;
        dashboardMap=GetPrivateProfileIntW(L"Map",L"Dashboard",1,path.c_str())!=0;mapStrip=GetPrivateProfileIntW(L"Map",L"StatusStrip",1,path.c_str())!=0;
        wristSize=iniFloat(L"Map",L"WristSize",.11f,.05f,.40f,path);dashboardSize=iniFloat(L"Map",L"DashboardSize",.22f,.08f,.80f,path);
        wristTilt=iniFloat(L"Map",L"WristTilt",0,-90,90,path);dashboardTilt=iniFloat(L"Map",L"DashboardTilt",35,-90,90,path);
        GetPrivateProfileStringW(L"Map",L"WristOffset",L"",value,64,path.c_str());parseOffset(value,wristOffset,.4f);
        GetPrivateProfileStringW(L"Map",L"DashboardOffset",L"",value,64,path.c_str());parseOffset(value,dashboardOffset,1.5f);
        GetPrivateProfileStringW(L"Motion",L"CharacterWheelView",L"Flat",value,64,path.c_str());wheelFlat=_wcsicmp(value,L"VR")!=0;   // 0.14.0: Flat by default
        GetPrivateProfileStringW(L"Renderer",L"VrButton",L"Sticks",value,64,path.c_str());vrButton=_wcsicmp(value,L"Off")!=0&&_wcsicmp(value,L"0")!=0;   // 0.15.0
        vrButtonMs=int(iniFloat(L"Renderer",L"VrButtonHold",1.0f,.3f,3.0f,path)*1000);
        // 0.16.0: the built-in OpenVR renderer is the only one (the R.E.A.L. and OpenXR options are gone): an older INI's
        // Mode=External / Backend=OpenXR are ignored (logged at the start).
        GetPrivateProfileStringW(L"Renderer",L"Mode",L"Builtin",value,64,path.c_str());oldExternal=!_wcsicmp(value,L"External");builtin=true;
        GetPrivateProfileStringW(L"Renderer",L"Backend",L"OpenVR",value,64,path.c_str());oldOpenXR=!_wcsicmp(value,L"OpenXR");
        firstPerson=GetPrivateProfileIntW(L"Renderer",L"FirstPerson",1,path.c_str())!=0;
        hideBody=GetPrivateProfileIntW(L"Renderer",L"HideBody",1,path.c_str())!=0;
        // 0.3.3+ keys. Older INIs are preserved by Setup, so every key has a safe default.
        frameTag=GetPrivateProfileIntW(L"Renderer",L"FrameTag",1,path.c_str())!=0;
        frameOffset=unsigned(std::clamp(int(GetPrivateProfileIntW(L"Renderer",L"FrameOffset",0,path.c_str())),0,3));
        GetPrivateProfileStringW(L"Renderer",L"CameraLag",L"Auto",value,64,path.c_str());cameraLag=parseCameraLag(value);
        GetPrivateProfileStringW(L"Renderer",L"SubmitDevice",L"Auto",value,64,path.c_str());submitDevice=parseSubmitMode(value);
        levelHorizon=GetPrivateProfileIntW(L"Renderer",L"LevelHorizon",1,path.c_str())!=0;stableCamera=GetPrivateProfileIntW(L"Renderer",L"StableCamera",1,path.c_str())!=0;
        stabilizeTurn=GetPrivateProfileIntW(L"Renderer",L"StabilizeTurn",1,path.c_str())!=0;
        // 0.8.0: back to the 0.6.0 renderer: Auto = mono below ~50 game fps, 3D above ~62 (Shift+F10 switches).
        GetPrivateProfileStringW(L"Renderer",L"StereoMode",L"Auto",value,64,path.c_str());mono=_wcsicmp(value,L"Mono")==0;stereoAuto=_wcsicmp(value,L"Auto")==0;
        GetPrivateProfileStringW(L"Renderer",L"Zoom",L"1",value,64,path.c_str());zoom=clampZoom(std::wcstof(value,nullptr));
        GetPrivateProfileStringW(L"Renderer",L"MonoDepth",L"0",value,64,path.c_str());{float v=std::wcstof(value,nullptr);monoDepth=std::isfinite(v)?std::clamp(v,0.0f,50.0f):0.0f;}
        // FovCheck: Log (default) measures GTA's real FOV and only writes it to the log; Fix also corrects it; Off.
        GetPrivateProfileStringW(L"Renderer",L"FovCheck",L"Log",value,64,path.c_str());fovCheck=!_wcsicmp(value,L"Fix")||!_wcsicmp(value,L"2")?2:!_wcsicmp(value,L"Off")||!_wcsicmp(value,L"0")?0:1;
        armPose=armPoseKind!=0;
        GetPrivateProfileStringW(L"Hands",L"Overlay",L"Auto",value,64,path.c_str());overlayMode=!_wcsicmp(value,L"On")||!_wcsicmp(value,L"1")?1:!_wcsicmp(value,L"Off")||!_wcsicmp(value,L"0")?2:0;
        GetPrivateProfileStringW(L"Hands",L"ArmIk",L"Auto",value,64,path.c_str());armIkMode=!_wcsicmp(value,L"Position")?1:!_wcsicmp(value,L"Off")||!_wcsicmp(value,L"0")?2:0;
        // 0.6.0: the real character body (Franklin / Michael / Trevor / Chop) with the head hidden. Overrides HideBody.
        GetPrivateProfileStringW(L"Hands",L"Body",L"Character",value,64,path.c_str());characterBody=_wcsicmp(value,L"Hidden")!=0;
        showHands=GetPrivateProfileIntW(L"Hands",L"Show",1,path.c_str())!=0;showArms=GetPrivateProfileIntW(L"Hands",L"Arms",1,path.c_str())!=0;
        fingerCombo=GetPrivateProfileIntW(L"Hands",L"MiddleFingerCombo",1,path.c_str())!=0;
        GetPrivateProfileStringW(L"Hands",L"ArmLength",L"1",value,64,path.c_str());{float v=std::wcstof(value,nullptr);armLength=std::isfinite(v)?std::clamp(v,.6f,1.5f):1;}
        GetPrivateProfileStringW(L"Hands",L"Brightness",L"1",value,64,path.c_str());{float v=std::wcstof(value,nullptr);handBrightness=std::isfinite(v)?std::clamp(v,.2f,2.0f):1;}
        GetPrivateProfileStringW(L"Hands",L"SkinColor",L"Auto",value,64,path.c_str());skinAuto=!parseColor(value,skin);
        GetPrivateProfileStringW(L"Hands",L"SleeveColor",L"Skin",value,64,path.c_str());sleeveSkin=!parseColor(value,sleeve);
        GetPrivateProfileStringW(L"Motion",L"WorldScale",L"1",value,64,path.c_str());float s=std::wcstof(value,nullptr);scale=std::isfinite(s)?std::clamp(s,.1f,3.0f):1;
        // 0.15.5: the buttons ([Controls]; a missing or unknown word = that button's default) and GTA's menus.
        for(int i=0;i<physCount;++i){PhysButton b=PhysButton(i);GetPrivateProfileStringW(L"Controls",buttonKey(b),L"",value,64,path.c_str());
            ButtonFunction f=ButtonMap::defaults().of(b);if(value[0]&&!parseFunction(value,f))f=ButtonMap::defaults().of(b);buttons.set(b,f);}
        menuControls=GetPrivateProfileIntW(L"Menu",L"Controllers",1,path.c_str())!=0;
        pauseOnDashboard=GetPrivateProfileIntW(L"Menu",L"PauseOnDashboard",1,path.c_str())!=0;
    }
};
template<class T> void share(Com<T>& target,T* value){if(value)value->AddRef();target.reset();target.p=value;}
// One captured backbuffer. `capture` lives on GTA's device; `shared` is the same
// texture opened on the submit device (or `capture` itself in Game mode). The
// staging copy of the tag strip doubles as a GPU-completion signal: once it can be
// mapped, GTA's copy into `capture` has finished and the submit device may read it.
enum class SlotKind { Cinema,Tagged,Legacy };
struct CaptureSlot { Com<ID3D11Texture2D> capture,staging,shared;bool busy=false;SlotKind kind=SlotKind::Cinema;std::uint32_t latestPlan=0,legacyPlan=0; };
constexpr unsigned SlotCount=4;
struct State {
    std::mutex mutex;Config config;OpenVR vr;std::unique_ptr<Actions> actions;Ipc ipc;
    VR_IVRCompositor_FnTable* compositor=nullptr;VROverlayHandle_t cinema=0;
    // 0.9.0: GTA's minimap on a wrist / dashboard overlay. The script tick decides what is shown
    // (radarWanted, placement, pixel box); Present copies that corner of each captured frame.
    VROverlayHandle_t radar=0;Com<ID3D11Texture2D> radarTex;PixelBox radarBox{},radarTexBox{};bool radarWanted=false,radarShown=false,radarFresh=false,radarDeviceRelative=false;
    TrackedDeviceIndex_t radarDevice=k_unTrackedDeviceIndexInvalid;HmdMatrix34_t radarTransform{};float radarWidth=.11f;std::uint64_t radarSetAt=0;bool radarLogged=false;
    Com<ID3D11Device> device;Com<ID3D11DeviceContext> context;Com<IDXGISwapChain> chain;   // GTA's
    Com<ID3D11Device> vrDevice;Com<ID3D11DeviceContext> vrContext;bool bridge=false;         // submit side
    Com<ID3D11Texture2D> eye[2],screen,black;Com<ID3D11RenderTargetView> blackView;          // on vrDevice
    EyeTangents tangents[2]{};Pose eyeOffsets[2]{};HmdMatrix34_t eyePoses[2]{};
    InputFrame input{};
    // 0.7.0: projection = what GTA is asked to render and how each eye crops it.
    ViewProjection projection{};GtaFovModel fovModel{};ViewSettings view{};FovCalibrator fovCal;bool viewInitialized=false,eyeMono[2]{};float backAspect=0;
    bool fixedProjection=false;float fixedRequest=0,fixedTanV=0,fixedTanH=0;
    void rebuildProjection(){float ex[2]={eyeOffsets[0].m[0][3],eyeOffsets[1].m[0][3]};
        projection=fixedProjection?viewProjectionAt(tangents,ex,view,fixedRequest,fixedTanV,fixedTanH):viewProjection(tangents,ex,backAspect,fovModel,view);}
    std::string describeProjection()const{return "SET_CAM_FOV "+fixed(projection.requestFov)+" deg (GTA image "+fixed(2*std::atan(projection.tanV)*180/pi)+" x "+fixed(2*std::atan(projection.tanH)*180/pi)
        +" deg), zoom "+fixed(view.zoom,2)+(projection.clamped?", GTA's 130 deg limit reached":"");}
    bool ready=false,failed=false,stereo=false,cinemaVisible=false,repositionCinema=true,cinemaReady=false;
    bool previousStereo=false;unsigned width=0,height=0;std::uint32_t hapticSerial=0;unsigned submitErrors=0,poseErrors=0;int firstSubmitError=0;
    DXGI_FORMAT textureFormat=DXGI_FORMAT_UNKNOWN;unsigned sourceSamples=0,sourceQuality=0;
    bool firstSubmission=true,firstWait=true,posesStarted=false;
    // Render-thread pose from WaitGetPoses: places the cinema screen during loading.
    Pose renderHead{};bool renderHeadValid=false;
    float displayHz=90,vsyncToPhotons=0;
    // Frame synchronisation (frame_sync.hpp).
    PlanRing plans;CameraLagEstimator cameraLag;FrameSyncStats stats;LatencyFilter pipeline;
    // 0.16.2: frame timing for the log - GTA's frames apart in headset frames, SteamVR's own counts (once a second).
    std::uint64_t lastPresentUs=0;unsigned presentCount=0;Compositor_CumulativeStats steamStats{};bool steamStatsValid=false;
    // Hands: skeletons captured with each eye request, drawn when that eye image arrives.
    struct HandFrame { std::uint32_t id=0;HandSkeleton hand[2];HandColors colors;float brightness=1; };
    std::array<HandFrame,TagIdMask+1> handPlans{};HandOverlay hands;bool handsInitialized=false;unsigned handDraws=0;std::vector<Capsule> capsules;
    CaptureSlot slots[SlotCount];unsigned slotRead=0,slotWrite=0;bool eyeValid[2]{};
    bool tagMode=true,tagCapable=false;unsigned tagFailures=0,tagSuccesses=0,tagFailureLogs=0;int cameraLagOverride=-1;
    unsigned effectiveLag()const{return cameraLagOverride<0?cameraLag.lag():unsigned(cameraLagOverride);}
    // 0.15.5: GTA's pause menu with the controllers while the script fiber does not run (GTA holds the scripts in its
    // pause menu and loading screens): from the render thread, like the script fiber's menu controls (Camera).
    std::atomic<std::uint64_t> scriptTickMs{0};std::atomic<bool> menuRequest{false};
    StickRepeat rtStick;KeyTaps rtTaps;std::uint32_t rtPhysical=0;float rtGrip[2]{},rtTrigger[2]{};bool rtLogged=false,rtActive=false;
    void pausedMenuControls(std::uint64_t now){
        rtTaps.release(now,[](const KeyTap& t){sendScanKey(t.code,t.extended,true);});
        std::uint64_t last=scriptTickMs.load();
        bool paused=ready&&!failed&&actions&&config.menuControls&&last&&now>=last+250;
        DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
        if(!paused||pid!=GetCurrentProcessId()||vr.overlay->IsDashboardVisible()){rtStick.reset();rtActive=false;return;}
        InputFrame in{};if(!actions->read(in))return;
        std::uint32_t physical=in.buttons&physicalMask;
        if(!rtActive){rtActive=true;rtPhysical=physical;rtGrip[0]=in.leftGrip;rtGrip[1]=in.rightGrip;rtTrigger[0]=in.leftTrigger;rtTrigger[1]=in.trigger;return;}   // what is held now waits to be let go
        auto pressed=[&](PhysButton b){std::uint32_t bit=physicalBit(b);return (physical&bit)&&!(rtPhysical&bit);};
        auto tap=[&](std::uint16_t c,bool e){if(rtTaps.press(c,e,now))sendScanKey(c,e,false);};
        float x=in.stickX,y=in.stickY;if(in.moveX*in.moveX+in.moveY*in.moveY>x*x+y*y){x=in.moveX;y=in.moveY;}
        StickDir d=rtStick.update(x,y,now);if(d!=StickDir::None)tap(arrowScan(d),true);
        if(pressed(PhysButton::A))tap(scan::Enter,false);
        if(pressed(PhysButton::B))tap(scan::Esc,false);
        if(pressed(PhysButton::X))tap(scan::Space,false);
        if(pressed(PhysButton::Y)){tap(scan::Esc,false);menuRequest=true;}   // the VR menu once GTA runs again
        if(in.leftGrip>.7f&&rtGrip[0]<=.7f)tap(scan::Q,false);
        if(in.rightGrip>.7f&&rtGrip[1]<=.7f)tap(scan::E,false);
        if(in.leftTrigger>.7f&&rtTrigger[0]<=.7f)tap(scan::PageDown,true);
        if(in.trigger>.7f&&rtTrigger[1]<=.7f)tap(scan::PageUp,true);
        bool any=d!=StickDir::None||(physical&~rtPhysical);
        rtGrip[0]=in.leftGrip;rtGrip[1]=in.rightGrip;rtTrigger[0]=in.leftTrigger;rtTrigger[1]=in.trigger;rtPhysical=physical;
        if(!rtLogged&&any){rtLogged=true;log("GTA's menu while the game is paused (its scripts wait): the controllers play it from the render thread - a stick = arrow keys, A = Enter, B = Esc, X = Space, grips = Q / E, triggers = Page Down / Up, Y = the VR menu.");}
    }
    void fail(const std::string& reason){if(!failed)log("DISABLED: "+reason+" Normal camera will be restored on the next script tick.");failed=true;startupStopped.store(true);cameraBridge.enable(false,GetTickCount64());
        if(compositor)compositor->ClearLastSubmittedFrame();if(cinema&&vr.overlay)vr.overlay->HideOverlay(cinema);
        if(radar&&vr.overlay)vr.overlay->HideOverlay(radar);radarShown=false;
    }
    // ---------- 0.9.0: minimap overlay (render thread, mutex held) ----------
    void ensureRadarTexture(){
        if(!radar||!width||!radarBox.width()||!radarBox.height()){return;}
        if(radarTex.p&&radarTexBox.width()==radarBox.width()&&radarTexBox.height()==radarBox.height())return;
        radarTex.reset();radarFresh=false;
        D3D11_TEXTURE2D_DESC desc{};desc.Width=radarBox.width();desc.Height=radarBox.height();desc.MipLevels=1;desc.ArraySize=1;desc.Format=textureFormat;
        desc.SampleDesc={1,0};desc.Usage=D3D11_USAGE_DEFAULT;desc.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;
        if(FAILED(vrDevice->CreateTexture2D(&desc,nullptr,radarTex.put()))){radarTex.reset();log("Map: the minimap texture could not be created; no wrist / dashboard map.");radar=0;return;}
        radarTexBox=radarBox;
    }
    // The minimap corner of a captured frame (GTA draws it in every frame, both eyes).
    void copyRadar(ID3D11Texture2D* frame){
        if(!radarWanted||!radarTex.p||radarTexBox.width()!=radarBox.width()||radarTexBox.height()!=radarBox.height()||radarBox.right>width||radarBox.bottom>height)return;
        D3D11_BOX box{radarBox.left,radarBox.top,0,radarBox.right,radarBox.bottom,1};vrContext->CopySubresourceRegion(radarTex.p,0,0,0,0,frame,0,&box);radarFresh=true;
    }
    void updateRadar(){
        if(!radar||!vr.overlay)return;
        bool show=radarWanted&&stereo&&radarTex.p&&radarFresh;
        if(!show){if(radarShown){vr.overlay->HideOverlay(radar);radarShown=false;}return;}
        std::uint64_t now=GetTickCount64();if(radarShown&&now-radarSetAt<33)return;   // ~30 Hz is plenty for a map
        radarSetAt=now;
        Texture_t texture{radarTex.p,ETextureType_TextureType_DirectX,EColorSpace_ColorSpace_Gamma};
        bool ok=vr.overlay->SetOverlayWidthInMeters(radar,radarWidth)==EVROverlayError_VROverlayError_None&&vr.overlay->SetOverlayTexture(radar,&texture)==EVROverlayError_VROverlayError_None;
        if(ok)ok=radarDeviceRelative?vr.overlay->SetOverlayTransformTrackedDeviceRelative(radar,radarDevice,&radarTransform)==EVROverlayError_VROverlayError_None
                                    :vr.overlay->SetOverlayTransformAbsolute(radar,ETrackingUniverseOrigin_TrackingUniverseStanding,&radarTransform)==EVROverlayError_VROverlayError_None;
        if(ok&&!radarShown)ok=vr.overlay->ShowOverlay(radar)==EVROverlayError_VROverlayError_None;
        if(!ok){log("Map: SteamVR refused the minimap overlay; no wrist / dashboard map this session.");vr.overlay->HideOverlay(radar);radar=0;radarShown=false;return;}
        if(!radarLogged){radarLogged=true;log(std::string("Map: GTA's minimap shown on the ")+(radarDeviceRelative?"wrist":"dashboard")+" ("+std::to_string(radarBox.width())+"x"+std::to_string(radarBox.height())+" px corner of the game image).");}
        radarShown=true;
    }
    void clearStereoFrames(){for(auto& s:slots){s.busy=false;s.latestPlan=s.legacyPlan=0;}slotRead=slotWrite=0;eyeValid[0]=eyeValid[1]=false;tagFailures=0;tagSuccesses=0;}
    // Called by the script fiber whenever earlier eye requests no longer describe the view.
    void invalidateStereo(){plans.newSession();clearStereoFrames();cameraLag.reset();}
    void releaseTextures(){if(cinema&&vr.overlay)vr.overlay->ClearOverlayTexture(cinema);
        if(radar&&vr.overlay){vr.overlay->HideOverlay(radar);vr.overlay->ClearOverlayTexture(radar);}radarShown=false;radarFresh=false;radarTex.reset();radarTexBox={};
        eye[0].reset();eye[1].reset();screen.reset();blackView.reset();black.reset();cinemaReady=false;
        hands.detach();for(auto& s:slots){s.shared.reset();s.capture.reset();s.staging.reset();}clearStereoFrames();tagCapable=false;
        width=height=0;textureFormat=DXGI_FORMAT_UNKNOWN;sourceSamples=sourceQuality=0;
    }
    // A DXGI 1.1 device on the same adapter (LUID) as GTA, used only to submit to SteamVR.
    void createBridge(const LUID& luid){
        HMODULE dxgi=GetModuleHandleW(L"dxgi.dll");if(!dxgi)dxgi=LoadLibraryW(L"dxgi.dll");
        using CreateFactory1=HRESULT(WINAPI*)(REFIID,void**);
        auto createFactory=dxgi?reinterpret_cast<CreateFactory1>(GetProcAddress(dxgi,"CreateDXGIFactory1")):nullptr;
        if(!createFactory)throw std::runtime_error("dxgi.dll lacks CreateDXGIFactory1.");
        Com<IDXGIFactory1> factory;requireHR(createFactory(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(factory.put())),"Create DXGI 1.1 factory");
        Com<IDXGIAdapter1> adapter;std::wstring name;
        for(UINT i=0;;++i){Com<IDXGIAdapter1> candidate;HRESULT r=factory->EnumAdapters1(i,candidate.put());if(r==DXGI_ERROR_NOT_FOUND)break;requireHR(r,"Enumerate DXGI 1.1 adapters");
            DXGI_ADAPTER_DESC1 d{};requireHR(candidate->GetDesc1(&d),"Read DXGI 1.1 adapter");
            if(d.AdapterLuid.HighPart==luid.HighPart&&d.AdapterLuid.LowPart==luid.LowPart){share(adapter,candidate.p);name=d.Description;break;}}
        if(!adapter.p)throw std::runtime_error("GTA's GPU was not found through DXGI 1.1.");
        HMODULE d3d=GetModuleHandleW(L"d3d11.dll");if(!d3d)d3d=LoadLibraryW(L"d3d11.dll");
        auto create=d3d?reinterpret_cast<PFN_D3D11_CREATE_DEVICE>(GetProcAddress(d3d,"D3D11CreateDevice")):nullptr;
        if(!create)throw std::runtime_error("d3d11.dll lacks D3D11CreateDevice.");
        D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_1,D3D_FEATURE_LEVEL_11_0},level{};
        HRESULT r=create(adapter.p,D3D_DRIVER_TYPE_UNKNOWN,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,2,D3D11_SDK_VERSION,vrDevice.put(),&level,vrContext.put());
        if(r==E_INVALIDARG)r=create(adapter.p,D3D_DRIVER_TYPE_UNKNOWN,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels+1,1,D3D11_SDK_VERSION,vrDevice.put(),&level,vrContext.put());
        requireHR(r,"Create the VR submit device (D3D11 on DXGI 1.1)");
        log("Submit device: bridge D3D11 device (DXGI 1.1) on "+utf8(name)+"; GTA frames arrive through shared textures.");
    }
    void start(IDXGISwapChain* swap){
        stage("Capture: Script Hook V delivered the game swapchain; acquiring D3D11 device");
        requireHR(swap->GetDevice(__uuidof(ID3D11Device),reinterpret_cast<void**>(device.put())),"Get D3D11 device");device->GetImmediateContext(context.put());
        swap->AddRef();chain.p=swap;vr.start(directory()+L"\\GTAHandVR",true,stage);
        stage("OpenVR: requesting compositor and checking GPU adapter");
        compositor=vr.table<VR_IVRCompositor_FnTable>(IVRCompositor_Version);compositor->SetTrackingSpace(ETrackingUniverseOrigin_TrackingUniverseStanding);
        // Textures must be on the adapter used by SteamVR.
        Com<IDXGIDevice> dxDevice;Com<IDXGIAdapter> actual,expected;Com<IDXGIFactory> factory;
        requireHR(device->QueryInterface(__uuidof(IDXGIDevice),reinterpret_cast<void**>(dxDevice.put())),"Get DXGI device");
        requireHR(dxDevice->GetAdapter(actual.put()),"Get GTA adapter");requireHR(actual->GetParent(__uuidof(IDXGIFactory),reinterpret_cast<void**>(factory.put())),"Get DXGI factory");
        int adapterIndex=-1;vr.system->GetDXGIOutputInfo(&adapterIndex);
        if(adapterIndex<0)throw std::runtime_error("SteamVR did not provide its GPU adapter.");
        requireHR(factory->EnumAdapters(UINT(adapterIndex),expected.put()),"Get SteamVR adapter");
        DXGI_ADAPTER_DESC a{},b{};requireHR(actual->GetDesc(&a),"Read GTA adapter");requireHR(expected->GetDesc(&b),"Read SteamVR adapter");
        if(a.AdapterLuid.HighPart!=b.AdapterLuid.HighPart||a.AdapterLuid.LowPart!=b.AdapterLuid.LowPart)throw std::runtime_error("GTA and SteamVR are on different GPUs. Select the same GPU for both.");
        {Com<IDXGIFactory1> gtaFactory1;bool gtaDxgi11=SUCCEEDED(factory->QueryInterface(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(gtaFactory1.put())));
            log(std::string("GTA's DXGI factory ")+(gtaDxgi11?"exposes":"does not expose")+" IDXGIFactory1 (informational; a factory created as DXGI 1.0 can still expose it). SubmitDevice="+submitModeName(config.submitDevice)+".");}
        if(config.submitDevice!=SubmitMode::Game){
            try{createBridge(a.AdapterLuid);bridge=true;}
            catch(const std::exception& e){if(config.submitDevice==SubmitMode::Bridge)throw;vrDevice.reset();vrContext.reset();
                log(std::string("Submit device: bridge unavailable (")+e.what()+"); submitting GTA's own textures. SteamVR may reject them with error 106.");}
        }
        if(!bridge){share(vrDevice,device.p);share(vrContext,context.p);if(config.submitDevice==SubmitMode::Game)log("Submit device: GTA's own D3D11 device (SubmitDevice=Game).");}
        for(int i=0;i<2;++i){auto& t=tangents[i];vr.system->GetProjectionRaw(EVREye(i),&t.left,&t.right,&t.top,&t.bottom);
            auto matrix=vr.system->GetEyeToHeadTransform(EVREye(i));std::memcpy(eyeOffsets[i].m,matrix.m,sizeof(matrix.m));
            if(!validPose(eyeOffsets[i]))throw std::runtime_error("Invalid headset eye transform.");}
        ETrackedPropertyError propertyError=ETrackedPropertyError_TrackedProp_Success;
        float hz=vr.system->GetFloatTrackedDeviceProperty(0,ETrackedDeviceProperty_Prop_DisplayFrequency_Float,&propertyError);
        if(propertyError==ETrackedPropertyError_TrackedProp_Success&&hz>=20&&hz<=1000)displayHz=hz;
        float photons=vr.system->GetFloatTrackedDeviceProperty(0,ETrackedDeviceProperty_Prop_SecondsFromVsyncToPhotons_Float,&propertyError);
        if(propertyError==ETrackedPropertyError_TrackedProp_Success&&photons>=0&&photons<=.1f)vsyncToPhotons=photons;
        log("Headset display "+fixed(displayHz)+" Hz, vsync-to-photons "+fixed(vsyncToPhotons*1000,2)+" ms.");
        stage("OpenVR: binding actions and motion-input shared memory");
        actions=std::make_unique<Actions>(vr.input);if(!ipc.open(true))throw std::runtime_error("Cannot create motion-input shared memory.");
        char key[]="local.gta5vr.cinema",name[]="GTA 5 VR - cinema";requireOverlay(vr.overlay->CreateOverlay(key,name,&cinema),"Create cinema screen");
        requireOverlay(vr.overlay->SetOverlayWidthInMeters(cinema,4.0f),"Set cinema width");
        requireOverlay(vr.overlay->SetOverlayTextureColorSpace(cinema,EColorSpace_ColorSpace_Gamma),"Set cinema color space");
        // 0.9.0: the minimap overlay is optional; without it the game still runs.
        if(config.wristMap>=0||config.dashboardMap){char radarKey[]="local.gta5vr.radar",radarName[]="GTA 5 VR - map";
            if(vr.overlay->CreateOverlay(radarKey,radarName,&radar)!=EVROverlayError_VROverlayError_None){radar=0;log("Map: SteamVR did not create the minimap overlay; no wrist / dashboard map.");}
            else{vr.overlay->SetOverlayWidthInMeters(radar,config.wristSize);vr.overlay->SetOverlayTextureColorSpace(radar,EColorSpace_ColorSpace_Gamma);}}
        tagMode=config.frameTag;cameraLagOverride=config.cameraLag;
        log(std::string("Frame sync: ")+(tagMode?"frame tags enabled":"frame tags disabled in INI; untagged FrameOffset="+std::to_string(config.frameOffset))+", CameraLag="+cameraLagName(cameraLagOverride)+".");
        ready=true;stage("OpenVR scene initialized on GTA's D3D11 adapter. Waiting for a backbuffer.");
    }
    void textures(ID3D11Texture2D* source){D3D11_TEXTURE2D_DESC desc{};source->GetDesc(&desc);
        if(width==desc.Width&&height==desc.Height&&textureFormat==desc.Format&&sourceSamples==desc.SampleDesc.Count&&sourceQuality==desc.SampleDesc.Quality&&eye[0].p)return;
        releaseTextures();
        stage("Capture: creating textures from the game backbuffer");
        if(desc.Format!=DXGI_FORMAT_R8G8B8A8_UNORM&&desc.Format!=DXGI_FORMAT_B8G8R8A8_UNORM
            &&desc.Format!=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB&&desc.Format!=DXGI_FORMAT_B8G8R8A8_UNORM_SRGB)
            throw std::runtime_error("Unsupported backbuffer format "+std::to_string(int(desc.Format))+". Use Legacy DX11 with SDR output.");
        if(!desc.Width||!desc.Height)throw std::runtime_error("Empty game backbuffer.");
        if(desc.Width<TagWidth*4||desc.Height<TagHeight*8)throw std::runtime_error("Game backbuffer too small for VR capture.");
        if(!viewInitialized){view.zoom=config.zoom;view.monoDepth=config.monoDepth;viewInitialized=true;}
        backAspect=float(desc.Width)/desc.Height;fovModel={};fixedProjection=false;fovCal.restart();rebuildProjection();
        sourceSamples=desc.SampleDesc.Count;sourceQuality=desc.SampleDesc.Quality;textureFormat=desc.Format;
        desc.MipLevels=1;desc.ArraySize=1;desc.SampleDesc={1,0};desc.Usage=D3D11_USAGE_DEFAULT;
        desc.BindFlags=D3D11_BIND_SHADER_RESOURCE|D3D11_BIND_RENDER_TARGET;desc.CPUAccessFlags=0;desc.MiscFlags=0;
        // Submit-side textures (bridge device, or GTA's device in Game mode).
        for(auto& e:eye)requireHR(vrDevice->CreateTexture2D(&desc,nullptr,e.put()),"Create eye texture");
        requireHR(vrDevice->CreateTexture2D(&desc,nullptr,screen.put()),"Create cinema texture");
        // A black scene behind the flat overlay, independent of game pixels.
        D3D11_TEXTURE2D_DESC blackDesc=desc;blackDesc.Width=blackDesc.Height=16;
        requireHR(vrDevice->CreateTexture2D(&blackDesc,nullptr,black.put()),"Create cinema background");
        requireHR(vrDevice->CreateRenderTargetView(black.p,nullptr,blackView.put()),"Create background view");
        float color[4]={0,0,0,1};vrContext->ClearRenderTargetView(blackView.p,color);
        // Capture ring on GTA's device. Legacy (DXGI 1.0 compatible) sharing, no keyed mutex:
        // ordering comes from the staging readback (see CaptureSlot).
        D3D11_TEXTURE2D_DESC captureDesc=desc;if(bridge)captureDesc.MiscFlags=D3D11_RESOURCE_MISC_SHARED;
        D3D11_TEXTURE2D_DESC stagingDesc=desc;stagingDesc.Width=TagWidth;stagingDesc.Height=TagHeight;
        stagingDesc.Usage=D3D11_USAGE_STAGING;stagingDesc.BindFlags=0;stagingDesc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;stagingDesc.MiscFlags=0;
        for(auto& s:slots){requireHR(device->CreateTexture2D(&captureDesc,nullptr,s.capture.put()),bridge?"Create shared capture texture":"Create capture texture");
            requireHR(device->CreateTexture2D(&stagingDesc,nullptr,s.staging.put()),"Create frame-tag readback texture");
            if(bridge){Com<IDXGIResource> resource;requireHR(s.capture->QueryInterface(__uuidof(IDXGIResource),reinterpret_cast<void**>(resource.put())),"Get shared capture resource");
                HANDLE handle=nullptr;requireHR(resource->GetSharedHandle(&handle),"Get shared capture handle");
                requireHR(vrDevice->OpenSharedResource(handle,__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(s.shared.put())),"Open shared capture on the VR submit device");}
            else share(s.shared,s.capture.p);}
        tagCapable=true;
        if(config.showHands){
            if(!bridge)log("Hands: not drawn with SubmitDevice=Game (they are drawn on the bridge device). Use SubmitDevice=Auto.");
            else{if(!handsInitialized){handsInitialized=true;if(hands.init(vrDevice.p))log("Hands: overlay ready (HLSL compiled with d3dcompiler_47).");else log("Hands: disabled - "+hands.error);}
                if(hands.ready&&!hands.attach(vrDevice.p,eye[0].p,eye[1].p))log("Hands: disabled - "+hands.error);}
        }
        width=desc.Width;height=desc.Height;log("Backbuffer "+std::to_string(width)+"x"+std::to_string(height)+" format "+std::to_string(int(textureFormat))+" samples "+std::to_string(sourceSamples)+"; "+describeProjection()+".");
        stage("Capture: backbuffer ready; waiting for the script camera frame");
    }
    void copy(ID3D11Texture2D* destination,ID3D11Texture2D* source){D3D11_TEXTURE2D_DESC desc{};source->GetDesc(&desc);
        if(desc.SampleDesc.Count>1)context->ResolveSubresource(destination,0,source,0,desc.Format);else context->CopyResource(destination,source);
    }
    void updateCinema(const Pose& head){if(!cinemaVisible||repositionCinema){Pose p=yawPose(head);Vec3 pos=p.pos()-p.col(2)*3;
            p.m[0][3]=pos.x;p.m[1][3]=pos.y;p.m[2][3]=pos.z;HmdMatrix34_t transform{};std::memcpy(transform.m,p.m,sizeof(p.m));
            requireOverlay(vr.overlay->SetOverlayTransformAbsolute(cinema,ETrackingUniverseOrigin_TrackingUniverseStanding,&transform),"Position cinema");repositionCinema=false;}
        Texture_t texture{screen.p,ETextureType_TextureType_DirectX,EColorSpace_ColorSpace_Gamma};
        requireOverlay(vr.overlay->SetOverlayTexture(cinema,&texture),"Update cinema");requireOverlay(vr.overlay->ShowOverlay(cinema),"Show cinema");cinemaVisible=true;
    }
    void acceptEye(const FramePlan& plan){
        double seconds=double(nowUs()-plan.timeUs)/1e6;pipeline.add(seconds);stats.latency(seconds*1000);
        if(plan.mono){   // stable mode: one centre image, hands drawn once, both eyes updated together
            drawHands(plan,plan.eye,plan.head);vrContext->CopyResource(eye[1-plan.eye].p,eye[plan.eye].p);
            for(int i=0;i<2;++i){std::memcpy(eyePoses[i].m,plan.head.m,sizeof(plan.head.m));eyeValid[i]=true;eyeMono[i]=true;}
            return;
        }
        std::memcpy(eyePoses[plan.eye].m,plan.head.m,sizeof(plan.head.m));eyeValid[plan.eye]=true;eyeMono[plan.eye]=false;
        drawHands(plan,plan.eye,compose(plan.head,eyeOffsets[plan.eye]));
    }
    // Hands/arms in tracking space, seen from this eye with the frustum GTA used for the image.
    void drawHands(const FramePlan& plan,unsigned target,const Pose& eyePose){
        if(!hands.ready||!width)return;const HandFrame& f=handPlans[plan.id&TagIdMask];if(f.id!=plan.id)return;
        ArmSettings arm;arm.arms=config.showArms&&!config.characterBody;arm.lengthScale=config.armLength;capsules.clear();   // real arms in Character body mode
        handCapsules(f.hand[0],plan.head,-1,arm,f.colors,capsules);handCapsules(f.hand[1],plan.head,1,arm,f.colors,capsules);
        if(capsules.empty())return;
        Mat4 viewProj=multiply(perspective(2*std::atan(projection.tanV)*180/pi,projection.tanH/projection.tanV,.02f,30),viewMatrix(eyePose));
        if(hands.draw(vrContext.p,target,viewProj,capsules,f.brightness))++handDraws;
    }
    std::string describe(const std::array<TagSample,TagCells>& samples){std::string text;
        for(auto& s:samples){text+=std::to_string(s.r)+"/"+std::to_string(s.g)+"/"+std::to_string(s.b)+" ";}return text;
    }
    void useLegacy(const std::string& reason){tagMode=false;clearStereoFrames();
        log("Frame sync: "+reason+" Falling back to untagged alternate-eye capture with FrameOffset="+std::to_string(config.frameOffset)
            +". Eye assignment is NOT verified in this mode; send this log. Restart GTA to retry frame tags.");
    }
    void handleTag(const CaptureSlot& slot,std::optional<std::uint32_t> tag,const std::array<TagSample,TagCells>& samples){
        if(!tag){++stats.untagged;++tagFailures;
            if(tagFailureLogs<3){++tagFailureLogs;log("Frame sync: no frame tag in a captured stereo frame; cell samples r/g/b: "+describe(samples));}
            if((tagSuccesses==0&&tagFailures>=180)||tagFailures>=900)useLegacy("frame tags were not found in "+std::to_string(tagFailures)+" consecutive captured frames.");
            return;
        }
        tagFailures=0;if(++tagSuccesses==1)log("Frame sync: frame tag found in a captured frame; each eye now uses the camera of the game update shown in that frame.");
        std::uint32_t depth=~0u;const FramePlan* plan=planForTaggedFrame(plans,*tag,slot.latestPlan,effectiveLag(),&depth);
        if(depth!=~0u)stats.depth(depth);
        if(!plan){++stats.unmatched;return;}
        vrContext->CopyResource(eye[plan->eye].p,slot.shared.p);
        // Cover the tag strip with the pixels just below it.
        D3D11_BOX below{0,TagHeight,0,TagWidth,2*TagHeight,1};vrContext->CopySubresourceRegion(eye[plan->eye].p,0,0,0,0,slot.shared.p,0,&below);
        acceptEye(*plan);++stats.tagged;
    }
    // The slot's GPU copy is complete once its staging texture maps; then hand it to the submit device.
    bool resolveSlot(unsigned index,bool wait){auto& slot=slots[index];D3D11_MAPPED_SUBRESOURCE mapped{};
        HRESULT result=context->Map(slot.staging.p,0,D3D11_MAP_READ,wait?0:D3D11_MAP_FLAG_DO_NOT_WAIT,&mapped);
        if(result==DXGI_ERROR_WAS_STILL_DRAWING)return false;
        requireHR(result,"Read frame tag");
        bool bgra=textureFormat==DXGI_FORMAT_B8G8R8A8_UNORM||textureFormat==DXGI_FORMAT_B8G8R8A8_UNORM_SRGB;
        std::array<TagSample,TagCells> samples{};
        for(unsigned c=0;c<TagCells;++c){auto* px=static_cast<const std::uint8_t*>(mapped.pData)+std::size_t(TagSampleY)*mapped.RowPitch+std::size_t(tagSampleX(c))*4;
            samples[c]=bgra?TagSample{px[2],px[1],px[0]}:TagSample{px[0],px[1],px[2]};}
        context->Unmap(slot.staging.p,0);slot.busy=false;
        if(slot.kind!=SlotKind::Cinema)copyRadar(slot.shared.p);
        if(slot.kind==SlotKind::Cinema){vrContext->CopyResource(screen.p,slot.shared.p);cinemaReady=true;}
        else if(slot.kind==SlotKind::Tagged)handleTag(slot,decodeTag(samples),samples);
        else if(const FramePlan* plan=plans.find(slot.legacyPlan)){vrContext->CopyResource(eye[plan->eye].p,slot.shared.p);acceptEye(*plan);++stats.legacy;}
        return true;
    }
    void capture(ID3D11Texture2D* source,SlotKind kind){
        if(slots[slotWrite].busy){++stats.dropped;resolveSlot(slotRead,true);slotRead=(slotRead+1)%SlotCount;}
        if(kind==SlotKind::Tagged&&!tagMode)kind=SlotKind::Legacy;   // a fallback may have happened while resolving
        auto& slot=slots[slotWrite];copy(slot.capture.p,source);
        D3D11_BOX strip{0,0,0,TagWidth,TagHeight,1};context->CopySubresourceRegion(slot.staging.p,0,0,0,0,slot.capture.p,0,&strip);
        std::uint32_t latest=plans.latestId();
        slot.busy=true;slot.kind=kind;slot.latestPlan=latest;slot.legacyPlan=latest>config.frameOffset?latest-config.frameOffset:0;
        slotWrite=(slotWrite+1)%SlotCount;
        while(slots[slotRead].busy&&resolveSlot(slotRead,false))slotRead=(slotRead+1)%SlotCount;
    }
    void present(IDXGISwapChain* swap){
        if(failed)return;
        if(!swap)throw std::runtime_error("Script Hook V supplied a null swapchain.");
        // 0.16.2: how far apart GTA's frames come (in headset frames), its GPU time, and SteamVR's counts.
        {std::uint64_t t=nowUs();if(lastPresentUs&&stereo)stats.gaps.add(double(t-lastPresentUs)/1000,1000.0/double(displayHz));lastPresentUs=t;
            if(compositor&&ready&&++presentCount%15==0){Compositor_FrameTiming timing{};timing.m_nSize=sizeof(timing);
                if(compositor->GetFrameTiming(&timing,0)&&timing.m_flTotalRenderGpuMs>0)stats.gpu.add(timing.m_flTotalRenderGpuMs);}
            if(compositor&&ready&&presentCount%60==0){Compositor_CumulativeStats c{};compositor->GetCumulativeStats(&c,sizeof(c));steamStats=c;steamStatsValid=true;}}
        // The SDK callback supplies GTA's real swapchain; no probe-window address
        // guess or window-size filter is involved in selecting it.
        if(!ready)start(swap);
        if(swap!=chain.p){
            Com<ID3D11Device> nextDevice;requireHR(swap->GetDevice(__uuidof(ID3D11Device),reinterpret_cast<void**>(nextDevice.put())),"Get replacement D3D11 device");
            if(nextDevice.p!=device.p)throw std::runtime_error("Game graphics device changed. Restart GTA to reconnect VR.");
            releaseTextures();chain.reset();swap->AddRef();chain.p=swap;log("Capture: game swapchain replaced; rebuilding eye textures.");
        }
        Com<ID3D11Texture2D> source;requireHR(swap->GetBuffer(0,__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(source.put())),"Get game backbuffer");
        textures(source.p);
        if(stereo!=previousStereo){clearStereoFrames();previousStereo=stereo;log(stereo?"Tracked stereo first-person camera active.":"Native game camera on flat VR cinema screen.");}
        // The script pose is preferred; during loading screens (no script tick) the render pose places the screen.
        bool scriptHead=(input.flags&HeadValid)&&validPose(input.head);
        const Pose& head=scriptHead?input.head:renderHead;bool headValid=scriptHead||renderHeadValid;
        if(stereo){if(cinemaVisible){requireOverlay(vr.overlay->HideOverlay(cinema),"Hide cinema");cinemaVisible=false;}ensureRadarTexture();capture(source.p,tagMode?SlotKind::Tagged:SlotKind::Legacy);}
        else{capture(source.p,SlotKind::Cinema);if(cinemaReady&&headValid)updateCinema(head);}
        updateRadar();
        if(bridge)vrContext->Flush();
        if(!posesStarted){context->Flush();return;}   // Submit only after SteamVR issued a render pose.
        bool readyEyes=stereo&&eyeValid[0]&&eyeValid[1];bool frameError=false,submitted=true;
        for(int i=0;i<2;++i){VRTextureWithPose_t texture{};texture.handle=readyEyes?eye[i].p:black.p;texture.eType=ETextureType_TextureType_DirectX;texture.eColorSpace=EColorSpace_ColorSpace_Gamma;
            if(readyEyes)texture.mDeviceToAbsoluteTracking=eyePoses[i];else std::memcpy(texture.mDeviceToAbsoluteTracking.m,head.m,sizeof(head.m));
            auto c=eyeMono[i]?projection.monoCrop[i]:projection.crop[i];VRTextureBounds_t bounds{c.uMin,c.vMin,c.uMax,c.vMax};
            EVRSubmitFlags flags=(readyEyes||(headValid&&validPose(head)))?EVRSubmitFlags_Submit_TextureWithPose:EVRSubmitFlags_Submit_Default;
            auto error=compositor->Submit(EVREye(i),reinterpret_cast<Texture_t*>(&texture),readyEyes?&bounds:nullptr,flags);
            if(error!=EVRCompositorError_VRCompositorError_None)submitted=false;
            if(error!=EVRCompositorError_VRCompositorError_None&&error!=EVRCompositorError_VRCompositorError_DoNotHaveFocus){
                frameError=true;if(!firstSubmitError){firstSubmitError=int(error);log("Submit error "+std::to_string(int(error))+(bridge?" (bridge device)":" (GTA's device)"));}
            }
        }
        if(frameError){if(++submitErrors>10){
                if(firstSubmitError==EVRCompositorError_VRCompositorError_SharedTexturesNotSupported)
                    throw std::runtime_error(bridge?"SteamVR rejected the bridge device's textures with error 106 (SharedTexturesNotSupported). Send Steam\\logs\\vrclient_GTA5.txt and this log."
                        :"SteamVR cannot share GTA's own textures (error 106, SharedTexturesNotSupported). Set [Renderer] SubmitDevice=Auto in GTAHandVR.ini.");
                throw std::runtime_error("Repeated OpenVR Submit failure "+std::to_string(firstSubmitError)+". See the first error above.");}}
        else submitErrors=0;
        context->Flush();
        if(firstSubmission&&submitted){firstSubmission=false;stage("Capture: first eye textures accepted by SteamVR");startupStopped.store(true);}
    }
    // Render thread, after WaitGetPoses returned (called without the mutex held during the wait).
    void posesReturned(EVRCompositorError error,const TrackedDevicePose_t& pose){
        if(failed)return;
        if(firstWait){firstWait=false;stage("OpenVR: first render pose returned on the game render thread");}
        if(error!=EVRCompositorError_VRCompositorError_None&&error!=EVRCompositorError_VRCompositorError_DoNotHaveFocus){
            if(poseErrors++==0)log("WaitGetPoses error "+std::to_string(int(error)));
            if(poseErrors>30)throw std::runtime_error("Repeated WaitGetPoses failure "+std::to_string(int(error))+".");
            return;
        }
        poseErrors=0;posesStarted=true;
        Pose head{};std::memcpy(head.m,pose.mDeviceToAbsoluteTracking.m,sizeof(head.m));
        renderHeadValid=pose.bPoseIsValid&&pose.bDeviceIsConnected&&validPose(head);if(renderHeadValid)renderHead=head;
    }
};
// Process-lifetime state. ASI hot unloading is unsupported; avoid COM / VR shutdown
// under the Windows loader lock when GTA is exiting.
State* state=nullptr;
std::atomic<State*> publishedState{nullptr};
void __cdecl onGamePresent(void* swapchain){
    callbackCount.fetch_add(1);
    auto* current=publishedState.load();if(!current||!current->config.builtin)return;
    thread_local bool entered=false;if(entered)return;
    struct Guard{bool& value;explicit Guard(bool& v):value(v){value=true;}~Guard(){value=false;}} guard(entered);
    VR_IVRCompositor_FnTable* compositor=nullptr;
    std::uint64_t waitFrom=nowUs();
    {std::lock_guard<std::mutex> lock(current->mutex);
        current->stats.lockWait.add(double(nowUs()-waitFrom)/1000);   // 0.16.2: GTA's render thread waiting for the script update
        try{current->present(static_cast<IDXGISwapChain*>(swapchain));}catch(const std::exception& e){current->fail(e.what());}
        try{current->pausedMenuControls(GetTickCount64());}catch(const std::exception& e){current->fail(e.what());}   // 0.15.5
        if(current->ready&&!current->failed){compositor=current->compositor;if(current->firstWait)stage("OpenVR: waiting for the first render pose");}
    }
    if(!compositor)return;
    // OpenVR frame pacing on the thread that submits: Submit, then WaitGetPoses.
    // The mutex is released so the script fiber is never blocked by this wait.
    TrackedDevicePose_t pose{};auto error=compositor->WaitGetPoses(&pose,1,nullptr,0);
    std::lock_guard<std::mutex> lock(current->mutex);
    try{current->posesReturned(error,pose);}catch(const std::exception& e){current->fail(e.what());}
}
class Camera {
    int camera=0,hiddenPed=0,lastPed=0;bool wasVisible=false,savedModes=false,centered=false,flat=false,previousF10=false,previousF11=false,wasStereo=false;
    int pedMode=0,vehicleMode=0;Pose origin{},lastHead{};
    const char* lastWarnedStage=nullptr;
    std::uint64_t cameraFrame=0,lastCameraLog=0,lastSyncLog=0;std::uint32_t poseSource=GTA5VR_POSE_STEAMVR,lastCameraFlags=~0u;
    const char* cameraStatus=nullptr;float lastPrediction=0;
    StereoAuto autoStereo{50,62};float autoHz=0;std::uint64_t fpsWindowStart=0;unsigned fpsFrames=0;int savedContexts[7]{};bool savedContextModes=false;int armIkPed=0;const char* eyeSource=nullptr;
    // 0.7.0: FOV check, zoom keys, model-arm IK.
    std::uint64_t stereoSince=0,noticeUntil=0;std::string notice;bool previousPageUp=false,previousPageDown=false,previousHome=false;
    // 0.11.0 corrected the target from the hand bone's measured miss (ReachLoop) and learned the rotation
    // (HandTurn). 0.12.0: open loop. GTA gives scripts the arm bones from the animation, before its arm IK (0.11.0 video:
    // the hands moved, but the bone positions never came closer however far the target was pushed), so
    // nothing is corrected from them. The rig relation (hand bone axes vs knuckles) is the same in any
    // pose, so it is still measured from them (RigCalibration). An invisible marker attached to the hand
    // bone shows whether the game exposes the IK result anywhere (log "Arm IK check").
    struct ArmIk { int proxy=0,marker=0;RigCalibration rig;TargetReadback readback;
        Rot sentRot{},lastWant{};Vec3 lastGoal{};bool sentOrient=false,haveGoal=false,checkLogged=false,markerLogged=false,onGun=false,gunLogged=false;
        float goalSpeed=0,markerMiss=NAN,boneMiss=NAN,markerTurn=NAN,boneTurn=NAN,checkTime=0;std::uint64_t lastTick=0,nextReport=0; };
    ArmIk arms[2];std::uint32_t proxyModel=0;bool ikAnnounced=false;
    // 0.8.0: still upper-body pose so walking / running does not swing the arms (IK alone moves them).
    // 0.9.0: "typing" pose (hands in front, palms down, frozen frame) instead of carrying a box (palms up).
    bool poseOn=false,poseLogged=false,poseFrozen=false;std::uint64_t poseCheck=0,poseRequestedAt=0;int poseKind=-1;
    struct PoseAnim { const char* dict;const char* clip;float time; };
    static PoseAnim poseAnim(int kind){return kind==2?PoseAnim{"anim@heists@box_carry@","idle",-1.0f}
        :kind==3?PoseAnim{"anim@mp_player_intupperthumbs_up","idle_a",.5f}:PoseAnim{"anim@heists@prison_heistig1_p1_guard_checks_bus","loop",.25f};}
    static const char* poseName(int kind){return kind==2?"box carry (palms up)":kind==3?"grip (fists, thumbs up)":kind==1?"typing (palms down)":"off";}
    PoseAnim poseOverride{nullptr,nullptr,-1.0f},posePlaying{nullptr,nullptr,-1.0f};   // 0.13.0: whole-hand grips when the finger animation fails
    // 0.13.0: what the motion add-on says about the hands (what each one holds; where the right hand bone
    // goes so the gun sits in it like GTA holds it, relative to the right controller).
    HandShare handShare{};bool shareFresh=false;
    // 0.13.0 / 0.14.0: fingers. TASK_SCRIPTED_ANIMATION with one three-clip blend per arm (low priority = left
    // arm, medium = right arm), frozen (rate 0): open hand / fist / what the hand holds or the player's gesture.
    // 0.14.0: a hand check first (FingerSurvey: every candidate pose on both hands, finger bones read) decides
    // which clips really bend the character's fingers and which filter reaches them.
    struct HandFingers { int slot[3]{-1,-1,-1},issued[3]{-1,-1,-1};FingerWeights sent{};bool sentValid=false;SqueezeFilter squeeze;GripClass hold=GripNone;
        GestureHold gesture;int special=-1;FingerCurls curls{}; };
    HandFingers fingerHand[2];SurveyPose surveyList[MaxSurveyPoses];int surveyCount=surveyPoses(surveyList);FingerSurvey survey;HandChoice choice[2];
    bool fingersOn=false,fingersFailed=false,fingersLogged=false,fallbackFist=false,trustTask=false,surveyDone=false;
    static constexpr const char* FallbackGunDict="weapons@rifle@lo@shotgun_assault";bool fallbackGunFailed=false;   // 0.15.8
    int fingerFailures=0,unreported=0,fingerPed=0,surveyIssued=-1,surveyRuns=0,fingerFilter=0;ClipRef playingClip[2]{};
    std::uint64_t fingerIssuedAt=0,fingerBackoff=0,lastFingerUs=0,surveyWaitSince=0;
    struct ClipStatus { ClipRef clip;int state=0;std::uint64_t since=0; };std::vector<ClipStatus> clipStatus;
    // 0.9.0: height calibration, body scale, character wheel view, minimap placement, on-screen notes.
    HeightCalibration calib;TriggerMute triggerMute[2];CharacterEyeHeight charEye;float worldScale=1,appliedBody=1;
    BothClicksToggle vrToggle{1000};std::uint64_t vrHintUntil=0;   // 0.15.0: the VR on / off button
    PressHold wheelHold{350};Hysteresis wristFacing;std::string handNote;std::uint64_t handNoteUntil=0,mapHiddenSince=0;bool mapHiddenLogged=false,mapNoHandLogged=false;
    TrackedDevicePose_t devicePoses[k_unMaxTrackedDeviceCount]{};
    // 0.10.0: the body follows the player (real steps, real crouch) + GTA leg IK; diagnostics panel (Shift+End).
    CrouchDetector crouch;Vec3 prevAnchor{};bool havePrevAnchor=false,crouchSet=false,diagPanel=false,previousEnd=false;float standRef=0,followed=0;int legIkPed=0;std::uint64_t diagUntil=0;
    // 0.10.0 body turn: GTA's first-person character faces GTA's camera heading, which did not move when you
    // turned for real, so the body (and the arms reaching for your hands) stayed behind.
    // 0.16.2: the view keeps its own heading on foot (ViewYaw); your body (TorsoYaw) is the character's - GTA's camera and
    // the character are turned to it every update (bodyStep), and the motion add-on's holsters sit on it.
    TorsoYaw torsoYaw;ViewYaw viewYaw;bool stickWalking=false,viewLogged=false,bodyDriven=false,bodyLogged=false;
    unsigned bodySets=0,bodySamples=0;double bodyOffSum=0;float bodyOffMax=0;Compositor_CumulativeStats steamLogged{};bool steamLoggedValid=false;
    bool pitchLogged=false;   // 0.11.0
    EyeAnchor eyeAnchor;StereoGate gate;YawStabilizer yawFilter;OffsetLimiter offsetLimiter;int monoOverride=-1;bool lastInVehicle=false;float lastGamePitch=0,lastGameRoll=0;
    GestureCombo combo[2];std::uint64_t lastTickUs=0,lastGestureLog[2]{};int lastLevel[2]={-2,-2};Gesture lastGesture[2]{};bool firstHands=true;
    // ---------- 0.15.5 ----------
    // The buttons as chosen in the VR menu (Config::buttons); the VR menu (vr_menu.hpp, drawn on the flat screen);
    // GTA's pause menu played with the controllers (key taps); the SteamVR menu button pauses GTA.
    VrMenu vrMenu;MenuSettings menuSettings;StickRepeat menuStick,pauseStick;KeyTaps keyTaps;
    std::uint32_t lastPhysical=0,lastFunctions=0,swallowPhysical=0;bool pauseNavLogged=false,dashboardWas=false,buttonsLogged=false;float gripWas[2]{},triggerWas[2]{};std::uint64_t menuInputAfter=0,escRetryAt=0;int escTries=0;
    // GTA's own aim (the motion add-on turns GTA's camera to the person the VR gun points at): the view keeps the
    // heading it sends; the eye is placed with the character's heading from before (vr_aim.hpp).
    AnchorHeading anchorHeading;bool aimViewLogged=false;
    // Why the view is the flat screen (a note on it for a few seconds).
    const char* flatReason=nullptr;std::uint64_t flatNoteUntil=0;
    void tapKey(std::uint16_t code,bool extended,std::uint64_t now){if(keyTaps.press(code,extended,now))sendScanKey(code,extended,false);}
    void releaseTaps(std::uint64_t now,bool all=false){keyTaps.release(now,[](const KeyTap& t){sendScanKey(t.code,t.extended,true);},all);}
    void pulseHaptic(float seconds,float amplitude){state->vr.input->TriggerHapticVibrationAction(state->actions->haptic,0,seconds,150.0f,amplitude,0);}
    std::wstring iniPath(){return directory()+L"\\GTAHandVR.ini";}
    void iniWrite(const wchar_t* section,const wchar_t* key,const std::wstring& value){WritePrivateProfileStringW(section,key,value.c_str(),iniPath().c_str());}
    std::string buttonsLine(const ButtonMap& m){std::string t;for(int i=0;i<physCount;++i){if(i)t+=", ";t+=std::string(buttonName(PhysButton(i)))+" = "+functionName(m.of(PhysButton(i)));}return t;}
    void openVrMenu(std::uint64_t now,const char* how){
        auto path=iniPath();wchar_t value[64]{};
        menuSettings.buttons=state->config.buttons;menuSettings.wheelFlat=state->config.wheelFlat;menuSettings.pauseOnDashboard=state->config.pauseOnDashboard;
        menuSettings.snapOn=GetPrivateProfileIntW(L"Motion",L"SnapTurning",1,path.c_str())!=0;
        menuSettings.snapDegrees=int(iniFloat(L"Motion",L"SnapTurnDegrees",30,15,90,path));
        menuSettings.gtaAim=GetPrivateProfileIntW(L"Weapons",L"GtaAim",1,path.c_str())!=0;
        (void)value;vrMenu.open();menuStick.reset();menuInputAfter=now+300;escRetryAt=now+300;escTries=0;pulseHaptic(.03f,.4f);
        log(std::string("VR menu: open (")+how+"). Sticks: choose / change, A: change, B: close; every change is saved in GTAHandVR.ini at once.");
    }
    void saveMenuItem(MenuItem item){
        const MenuSettings& m=menuSettings;std::string what;
        if(isButtonItem(item)||item==MenuItem::ResetButtons){
            for(int i=0;i<physCount;++i){std::string t=functionToken(m.buttons.of(PhysButton(i)));iniWrite(L"Controls",buttonKey(PhysButton(i)),std::wstring(t.begin(),t.end()));}
            state->config.buttons=m.buttons;
            what=item==MenuItem::ResetButtons?"buttons back to the defaults: "+buttonsLine(m.buttons):std::string(menuLabel(item))+" = "+menuValue(item,m);}
        else if(item==MenuItem::SnapTurn){iniWrite(L"Motion",L"SnapTurning",m.snapOn?L"1":L"0");iniWrite(L"Motion",L"SnapTurnDegrees",std::to_wstring(m.snapDegrees));what="turn = "+menuValue(item,m);}
        else if(item==MenuItem::GtaAim){iniWrite(L"Weapons",L"GtaAim",m.gtaAim?L"1":L"0");what=std::string("GTA's aim = ")+(m.gtaAim?"on":"off");}
        else if(item==MenuItem::PauseOnDashboard){iniWrite(L"Menu",L"PauseOnDashboard",m.pauseOnDashboard?L"1":L"0");state->config.pauseOnDashboard=m.pauseOnDashboard;what=std::string("SteamVR menu button pauses GTA = ")+(m.pauseOnDashboard?"on":"off");}
        else if(item==MenuItem::WheelView){iniWrite(L"Motion",L"CharacterWheelView",m.wheelFlat?L"Flat":L"VR");state->config.wheelFlat=m.wheelFlat;what=std::string("character wheel view = ")+(m.wheelFlat?"Flat":"VR");}
        if(!what.empty())log("VR menu: "+what+" (saved in GTAHandVR.ini).");
    }
    void drawVrMenu(){
        call(DRAW_RECT,.5f,.5f,.66f,.84f,8,12,20,235,false);
        screenText("GTA 5 VR  -  VR SETTINGS",.5f,.105f,.56f,true,255,230,140);
        screenText("Stick up / down: choose     Stick left / right or A: change     B: close     (saved at once)",.5f,.158f,.30f,true,200,210,225);
        for(int i=0;i<menuItemCount;++i){MenuItem it=MenuItem(i);bool on=vrMenu.selected()==it;float y=.205f+float(i)*.047f;
            if(on)call(DRAW_RECT,.5f,y+.018f,.64f,.044f,30,110,140,240,false);
            screenText(menuLabel(it),.195f,y,.37f,false,255,255,on?255:225);
            std::string v=menuValue(it,menuSettings);if(!v.empty())screenText(v,.575f,y,.37f,false,on?255:160,on?235:215,on?140:255);}
        screenText("Open this menu: Y in GTA's pause menu (the SteamVR menu button pauses GTA). Also in GTAHandVR.ini: [Controls].",.5f,.795f,.27f,true,170,180,195);
        screenText("A button and B button always work in this menu and in GTA's pause menu, whatever they do in the game.",.5f,.83f,.27f,true,170,180,195);
    }
    // The VR menu, or GTA's pause menu, played with the physical buttons and sticks (the same whatever the buttons do in the game).
    void menuControls(const InputFrame& in,std::uint32_t physical,bool frontend,bool pauseReady){
        std::uint64_t now=in.timeMs;
        auto pressed=[&](PhysButton b){std::uint32_t bit=physicalBit(b);return (physical&bit)&&!(lastPhysical&bit);};
        float x=in.stickX,y=in.stickY;if(in.moveX*in.moveX+in.moveY*in.moveY>x*x+y*y){x=in.moveX;y=in.moveY;}   // the stick pushed further
        bool leftGrip=in.leftGrip>.7f&&gripWas[0]<=.7f,rightGrip=in.rightGrip>.7f&&gripWas[1]<=.7f;
        bool leftTrigger=in.leftTrigger>.7f&&triggerWas[0]<=.7f,rightTrigger=in.trigger>.7f&&triggerWas[1]<=.7f;
        gripWas[0]=in.leftGrip;gripWas[1]=in.rightGrip;triggerWas[0]=in.leftTrigger;triggerWas[1]=in.trigger;
        if(vrMenu.opened()){pauseStick.reset();
            // GTA's pause menu still up (Esc only went back one page): Esc again until it is closed (the VR menu is drawn under it).
            // Only while it is fully open (not while it closes: an Esc then would open it again).
            if(pauseReady&&now>=escRetryAt&&escTries<8){tapKey(scan::Esc,false,now);escRetryAt=now+300;++escTries;}
            if(now<menuInputAfter){menuStick.update(0,0,now);return;}   // the press that opened it does nothing in it
            StickDir d=menuStick.update(x,y,now);
            auto o=vrMenu.input(d,pressed(PhysButton::A)||rightTrigger,pressed(PhysButton::B),menuSettings);
            if(o.result==VrMenu::Result::Moved)pulseHaptic(.01f,.15f);
            if(o.result==VrMenu::Result::Changed||o.result==VrMenu::Result::Reset){saveMenuItem(o.item);pulseHaptic(.02f,.3f);}
            if(o.result==VrMenu::Result::Close){pulseHaptic(.03f,.3f);log("VR menu: closed.");}
            return;}
        menuStick.reset();
        if(!frontend||!state->config.menuControls){pauseStick.reset();return;}
        // Y: the VR menu (GTA's pause menu closes first: Esc).
        if(pressed(PhysButton::Y)){pauseStick.reset();tapKey(scan::Esc,false,now);openVrMenu(now,"Y in GTA's pause menu");return;}
        StickDir d=pauseStick.update(x,y,now);
        if(d!=StickDir::None)tapKey(arrowScan(d),true,now);
        if(pressed(PhysButton::A))tapKey(scan::Enter,false,now);
        if(pressed(PhysButton::B))tapKey(scan::Esc,false,now);
        if(pressed(PhysButton::X))tapKey(scan::Space,false,now);
        if(leftGrip)tapKey(scan::Q,false,now);
        if(rightGrip)tapKey(scan::E,false,now);
        if(leftTrigger)tapKey(scan::PageDown,true,now);
        if(rightTrigger)tapKey(scan::PageUp,true,now);
        if(!pauseNavLogged&&(d!=StickDir::None||(physical&~lastPhysical)||leftGrip||rightGrip)){pauseNavLogged=true;
            log("GTA's pause menu with the controllers: a stick = arrow keys, A = Enter, B = Esc (back / resume), X = Space, grips = Q / E (tabs), triggers = Page Down / Up, Y = the VR menu.");}
    }
    void reportHands(const HandSkeleton (&h)[2],std::uint64_t nowMs){
        const char* names[2]={"left","right"};
        for(int i=0;i<2;++i){int level=h[i].valid?h[i].trackingLevel:-1;
            if(level!=lastLevel[i]){lastLevel[i]=level;log(std::string("Hands: ")+names[i]+" hand finger tracking "+trackingLevelName(level)+".");}
            if(!h[i].valid)continue;Gesture g=classifyGesture(h[i].curl);
            if(g!=lastGesture[i]&&g!=Gesture::Unknown&&nowMs-lastGestureLog[i]>1500){lastGesture[i]=g;lastGestureLog[i]=nowMs;log(std::string("Hands: ")+names[i]+" gesture "+gestureName(g)+".");}
        }
    }
    void reportCamera(const char* message){if(cameraStatus!=message){log(message);cameraStatus=message;}}
    bool firstPerson(){if(!state->config.firstPerson)return false;
        if(!savedModes){pedMode=call<int>(GET_FOLLOW_PED_CAM_VIEW_MODE);vehicleMode=call<int>(GET_FOLLOW_VEHICLE_CAM_VIEW_MODE);savedModes=true;}
        // 0.6.0: every view context (on foot, car, bike, boat, aircraft, sub, heli) in first person.
        if(!savedContextModes){for(int c=0;c<7;++c)savedContexts[c]=call<int>(GET_CAM_VIEW_MODE_FOR_CONTEXT,c);savedContextModes=true;}
        for(int c=0;c<7;++c)call(SET_CAM_VIEW_MODE_FOR_CONTEXT,c,4);
        call(SET_FOLLOW_PED_CAM_VIEW_MODE,4);call(SET_FOLLOW_VEHICLE_CAM_VIEW_MODE,4);return true;
    }
    // Real character body: visible with the head hidden (the camera sits in it).
    void characterBody(int ped){if(hiddenPed==ped)showBody();call(SET_PED_RESET_FLAG,ped,166,true);}   // CPED_RESET_FLAG_MakeHeadInvisible
    // ---------- 0.7.0: the character's own arms follow the real hands ----------
    // GTA bone ids, index 0 = left, 1 = right.
    static constexpr int handBone[2]={18905,57005},indexBone[2]={26611,58867},middleBone[2]={26612,58868},pinkyBone[2]={26614,58870},
        upperArmBone[2]={45509,40269},forearmBone[2]={61163,28252};
    Vec3 bone(int ped,int id,float x=0,float y=0,float z=0){return call<Vec3>(GET_PED_BONE_COORDS,ped,id,x,y,z);}
    void deleteProxies(){for(auto& a:arms){for(int* e:{&a.proxy,&a.marker}){if(*e&&call<bool>(DOES_ENTITY_EXIST,*e))call(DELETE_ENTITY,e);*e=0;}a.sentOrient=false;}}
    void resetArms(){deleteProxies();for(auto& a:arms){a.rig.reset();a.readback.reset();a.sentOrient=a.haveGoal=a.checkLogged=a.markerLogged=false;
        a.goalSpeed=0;a.markerMiss=a.boneMiss=a.markerTurn=a.boneTurn=NAN;a.checkTime=0;a.lastTick=0;a.nextReport=0;}}
    // On-screen notes (bottom of the view) so a video shows what the hands / calibration are doing.
    void handNotice(const std::string& text,std::uint64_t ms){handNote=text;handNoteUntil=GetTickCount64()+ms;}
    void notify(const std::string& text,std::uint64_t ms){notice=text;noticeUntil=GetTickCount64()+ms;}
    void screenText(const std::string& text,float x,float y,float size,bool centre=true,int r=255,int g=255,int b=255){
        call(SET_TEXT_FONT,0);call(SET_TEXT_SCALE,0.0f,size);call(SET_TEXT_COLOUR,r,g,b,255);call(SET_TEXT_CENTRE,centre);call(SET_TEXT_OUTLINE);
        call(BEGIN_TEXT_COMMAND_DISPLAY_TEXT,"STRING");call(ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME,text.c_str());call(END_TEXT_COMMAND_DISPLAY_TEXT,x,y,0);}
    std::string cm(float metres){return std::isfinite(metres)?fixed(metres*100)+" cm":std::string("?");}
    void reportReadback(int i,ArmIk& a){const char* side=i?"right":"left";
        switch(a.readback.state()){
            case TargetReadback::State::Direct:log(std::string("Arm IK (")+side+"): the target entity takes the rotation exactly as sent (quaternion check OK).");break;
            case TargetReadback::State::Transposed:log(std::string("Arm IK (")+side+"): the game reads the target rotation inverted; corrected (earlier versions sent every hand rotation backwards).");break;
            case TargetReadback::State::Stuck:log(std::string("Arm IK (")+side+"): the target entity does not take the rotation that is sent; hand rotation off, position only.");
                handNotice("Hands: rotation unavailable (target entity does not turn) - position only",6000);break;
            default:break;}
    }
    // 0.12.0: what the marker on the hand bone and GTA's bone positions say about the last IK target.
    std::string checkLine(int i,const ArmIk& a){
        std::string t=std::string("Arm IK check (")+(i?"right":"left")+"): marker on the hand bone "+cm(a.markerMiss)+" from the target";
        if(std::isfinite(a.markerTurn))t+=", turned "+fixed(a.markerTurn)+" deg from it";
        t+="; GTA's bone position (as scripts read it) "+cm(a.boneMiss);
        if(std::isfinite(a.boneTurn))t+=", "+fixed(a.boneTurn)+" deg";
        return t;}
    std::string checkVerdict(const ArmIk& a){
        if(!std::isfinite(a.markerMiss)||!std::isfinite(a.boneMiss))return "";
        if(a.markerMiss<.06f&&a.boneMiss>.12f)return " -> the marker follows the IK target: GTA's IK reaches the controller; the bone positions scripts read are the animation before the IK.";
        if(a.markerMiss<.06f&&a.boneMiss<.06f)return " -> both at the target: the IK result is visible to scripts.";
        if(std::abs(a.markerMiss-a.boneMiss)<.03f)return " -> the marker shows the same as the bone reads: the IK result is not visible to scripts.";
        return " -> unclear.";}
    // The entity's axes as the game has them (GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS).
    bool entityAxes(int e,Rot& out){Vec3 o=call<Vec3>(GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS,e,0.0f,0.0f,0.0f);
        out={call<Vec3>(GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS,e,1.0f,0.0f,0.0f)-o,call<Vec3>(GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS,e,0.0f,1.0f,0.0f)-o,call<Vec3>(GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS,e,0.0f,0.0f,1.0f)-o};
        return orthonormalRot(out,.05f);}
    // Invisible entity whose position / orientation is the hand target.
    bool proxyModelReady(){
        if(!proxyModel){for(const char* name:{"prop_golf_ball","prop_tennis_ball"}){std::uint32_t m=joaat(name);if(call<bool>(IS_MODEL_VALID,m)){proxyModel=m;break;}}if(!proxyModel)return false;}
        call(REQUEST_MODEL,proxyModel);return call<bool>(HAS_MODEL_LOADED,proxyModel);}
    bool ensureProxy(ArmIk& a,Vec3 at){
        if(a.proxy&&call<bool>(DOES_ENTITY_EXIST,a.proxy))return true;a.proxy=0;
        if(!proxyModelReady())return false;
        a.proxy=call<int>(CREATE_OBJECT,proxyModel,at.x,at.y,at.z,false,false,false);if(!a.proxy)return false;
        call(SET_ENTITY_VISIBLE,a.proxy,false,false);call(SET_ENTITY_COLLISION,a.proxy,false,false);call(FREEZE_ENTITY_POSITION,a.proxy,true);return true;
    }
    // 0.12.0: invisible marker attached to the character's hand bone (rotation follows the bone).
    bool ensureMarker(ArmIk& a,int ped,int i){
        if(a.marker&&call<bool>(DOES_ENTITY_EXIST,a.marker)&&call<bool>(IS_ENTITY_ATTACHED_TO_ENTITY,a.marker,ped))return true;
        if(a.marker&&call<bool>(DOES_ENTITY_EXIST,a.marker))call(DELETE_ENTITY,&a.marker);a.marker=0;
        if(!proxyModelReady())return false;
        Vec3 p=bone(ped,handBone[i]);int index=call<int>(GET_PED_BONE_INDEX,ped,handBone[i]);if(index<0||!finite(p))return false;
        a.marker=call<int>(CREATE_OBJECT,proxyModel,p.x,p.y,p.z,false,false,false);if(!a.marker)return false;
        call(SET_ENTITY_VISIBLE,a.marker,false,false);call(SET_ENTITY_COLLISION,a.marker,false,false);
        call(ATTACH_ENTITY_TO_ENTITY,a.marker,ped,index,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,false,false,false,false,2,true,false);
        if(!a.markerLogged){a.markerLogged=true;log(std::string("Arm IK check (")+(i?"right":"left")+"): marker attached to the hand bone (index "+std::to_string(index)+").");}
        return true;
    }
    // Hands: GTA's arm IK, every update (an IK target lasts one update). The wrist goes where the real
    // wrist is (SteamVR skeleton, else the controller).
    // 0.12.0: open loop. The target is the real wrist itself (within the character's reach); with
    // ArmIk=Auto the target also has your hand's rotation: an invisible entity turned like your hand, in
    // the hand bone's axes (RigCalibration), with ITF_ARM_TARGET_WRT_HANDBONE | ITF_ARM_USE_ORIENTATION (65).
    // Blend-in at once and GTA's own first-person arm IK off (0.11.0). Nothing is corrected from GTA's bone
    // positions: scripts get them from the animation, before the IK (0.11.0's correction pushed the hands
    // up to 40 cm past the controllers). The marker check logs what the game shows of the IK result.
    void armIk(int ped,const InputFrame& in,const HandSkeleton (&hands)[2],const WorldCamera& head){
        if(armIkPed!=ped){resetArms();armIkPed=ped;}
        int mode=state->config.armIkMode;if(mode==2)return;
        call(SET_PED_CAN_ARM_IK,ped,true);
        if(!state->config.gameFpsArmIk)call(SET_PED_RESET_FLAG,ped,408,true);   // CPED_RESET_FLAG_DisableFPSArmIK
        int blendIn=state->config.ikBlendIn;
        if(!ikAnnounced){ikAnnounced=true;
            log("Arm IK: open loop - the target is your wrist itself (0.11.0 corrected it from GTA's bone positions, which scripts get from the animation before the IK,"
                " and pushed the hands up to 40 cm past the controllers). Blend-in "+std::to_string(blendIn)+" ms,"
                +(state->config.gameFpsArmIk?std::string(" GTA's own first-person arm IK left on."):std::string(" GTA's own first-person arm IK off."))
                +(mode==1?" Hand rotation off ([Hands] ArmIk=Position).":" Hand rotation on: the target turns like your hand (flags 65)."));}
        std::uint64_t now=GetTickCount64();
        for(int i=0;i<2;++i){ArmIk& a=arms[i];
            float dt=a.lastTick?float(now-a.lastTick)*.001f:0;a.lastTick=now;
            const Pose& controller=i?in.right:in.left;bool controllerOk=(in.flags&(i?RightValid:LeftValid))&&validPose(controller);
            // The real wrist and how the real hand is turned (tracking space).
            Vec3 wristT{};Rot anatomyT{};bool anatomyOk=false;
            if(hands[i].valid){wristT=hands[i].world(BoneWrist);
                anatomyOk=anatomicalFrame(wristT,hands[i].world(BoneIndex1),hands[i].world(BoneMiddle1),hands[i].world(fingerBase(4)+1),anatomyT);}
            else if(controllerOk){wristT=controller.pos();anatomyT=controllerAnatomy(controller);anatomyOk=orthonormalRot(anatomyT,.05f);}
            else{a.sentOrient=false;a.haveGoal=false;a.onGun=false;continue;}
            // 0.13.0: the right hand on the gun. The motion add-on sends where the hand bone must be for the gun
            // to sit in it like GTA holds it, relative to the controller; rebuilt from this update's controller.
            Frame3 gunHand{};a.onGun=false;
            if(i==1&&controllerOk&&shareFresh){Frame3 rel{};   // ArmIk=Position: its position only
                if(unpackRight(handShare,rel)){gunHand=compose(controllerWorld(controller,in.head,head.position,head.basis,worldScale),rel);a.onGun=finiteFrame(gunHand);}}
            if(a.onGun&&!a.gunLogged){a.gunLogged=true;log("Arm IK (right): the hand holds the gun the way GTA holds it (target from the motion add-on, rebuilt from the controller every update).");}
            Vec3 wrist=trackingToWorld(wristT,in.head,head.position,head.basis,worldScale);if(!finite(wrist)){a.sentOrient=false;a.haveGoal=false;continue;}
            Rot anatomy{};
            if(anatomyOk){anatomy={trackingVectorToWorld(anatomyT.x,in.head,head.basis),trackingVectorToWorld(anatomyT.y,in.head,head.basis),trackingVectorToWorld(anatomyT.z,in.head,head.basis)};
                anatomyOk=orthonormalRot(anatomy,.05f);}
            // The character's own arm (animation pose: fine for the shoulder and the arm's length).
            Vec3 shoulder=bone(ped,upperArmBone[i]),elbow=bone(ped,forearmBone[i]),hand=bone(ped,handBone[i]);
            float armLength=length(elbow-shoulder)+length(hand-elbow);bool armOk=finite(shoulder)&&armLength>.3f&&armLength<1.2f;
            Vec3 aim=a.onGun?gunHand.pos:wrist;
            Vec3 goal=armOk?clampReach(aim,shoulder,armLength):aim;
            // The hand bone's axes vs its knuckles: the same in every pose, so the animation gives it.
            Rot boneAxes{},knuckles{};const float s=.1f;
            bool boneAxesOk=boneFrame(hand,bone(ped,handBone[i],s,0,0),bone(ped,handBone[i],0,s,0),bone(ped,handBone[i],0,0,s),s,boneAxes);
            bool knucklesOk=anatomicalFrame(hand,bone(ped,indexBone[i]),bone(ped,middleBone[i]),bone(ped,pinkyBone[i]),knuckles);
            if(mode==0&&boneAxesOk&&knucklesOk&&!a.rig.ready()){a.rig.add(boneAxes,knuckles);
                if(a.rig.ready())log(std::string("Arm IK (")+(i?"right":"left")+"): hand bone axes measured (consistent within "+fixed(a.rig.spreadDegrees())+" deg); the hand target now turns like your hand.");}
            // What the game shows of the last request (before this one is sent).
            checkIk(i,a,ped,hand,boneAxesOk?&boneAxes:nullptr,dt,now);
            bool orient=mode==0&&(a.onGun||(anatomyOk&&a.rig.ready()))&&ensureProxy(a,goal);
            if(orient&&a.sentOrient){Rot actual{};if(entityAxes(a.proxy,actual)&&a.readback.observe(a.sentRot,actual))reportReadback(i,a);
                if(a.readback.state()==TargetReadback::State::Stuck)orient=false;}
            if(orient){Rot want=a.onGun?gunHand.rot:a.rig.boneFor(anatomy),cmd=a.readback.command(want);auto q=quaternion(cmd.x,cmd.y,cmd.z);
                call(SET_ENTITY_COORDS_NO_OFFSET,a.proxy,goal.x,goal.y,goal.z,false,false,false);call(SET_ENTITY_QUATERNION,a.proxy,q.x,q.y,q.z,q.w);
                call(SET_IK_TARGET,ped,i?4:3,a.proxy,-1,0.0f,0.0f,0.0f,65,blendIn,120);   // IK_PART_ARM_LEFT = 3, RIGHT = 4
                a.sentRot=cmd;a.lastWant=want;a.sentOrient=true;}
            else{call(SET_IK_TARGET,ped,i?4:3,0,-1,goal.x,goal.y,goal.z,1,blendIn,120);   // world position, ITF_ARM_TARGET_WRT_HANDBONE
                a.sentOrient=false;}
            a.goalSpeed=a.haveGoal&&dt>0?length(goal-a.lastGoal)/dt:0;a.lastGoal=goal;a.haveGoal=true;
            if(now>=a.nextReport){if(a.nextReport&&std::isfinite(a.markerMiss))log(checkLine(i,a)+".");a.nextReport=now+15000;}
        }
    }
    // Marker (attached to the hand bone) and GTA's bone read against the previous target, while the target
    // moves slowly (lag is not error). Logged once after 4 s, then every 15 s.
    void checkIk(int i,ArmIk& a,int ped,Vec3 hand,const Rot* boneAxes,float dt,std::uint64_t){
        if(!a.haveGoal||!ensureMarker(a,ped,i))return;
        if(a.goalSpeed>.30f)return;
        Vec3 m=call<Vec3>(GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS,a.marker,0.0f,0.0f,0.0f);if(!finite(m)||!finite(hand))return;
        auto ema=[](float& v,float x){v=std::isfinite(v)?v*.9f+x*.1f:x;};
        ema(a.markerMiss,length(m-a.lastGoal));ema(a.boneMiss,length(hand-a.lastGoal));
        Rot markerAxes{};if(a.sentOrient&&entityAxes(a.marker,markerAxes))ema(a.markerTurn,rotAngleDegrees(a.lastWant,markerAxes));
        if(a.sentOrient&&boneAxes)ema(a.boneTurn,rotAngleDegrees(a.lastWant,*boneAxes));
        a.checkTime+=dt;
        if(!a.checkLogged&&a.checkTime>4){a.checkLogged=true;log(checkLine(i,a)+checkVerdict(a));}
    }
    std::string rotationStatus(const ArmIk& a){
        if(state->config.armIkMode==1)return "off (ArmIk=Position)";
        if(a.readback.state()==TargetReadback::State::Stuck)return "off (target entity does not turn)";
        if(!a.rig.ready()&&!a.onGun)return "measuring the hand bone";
        return a.sentOrient?"ON (flags 65)":"waiting";}
    // 0.8.0: no walk / run arm swing. A still upper-body pose (hands in front) plays on top of the
    // locomotion while the VR arms are active; GTA's arm IK then moves the hands from there.
    // 0.9.0: the typing pose (palms down, frozen) by default; the 0.8.0 box-carry pose had the palms up.
    void stopPose(int ped){
        if(poseOn&&posePlaying.dict&&ped&&call<bool>(DOES_ENTITY_EXIST,ped)&&call<bool>(IS_ENTITY_PLAYING_ANIM,ped,posePlaying.dict,posePlaying.clip,3))
            call(STOP_ANIM_TASK,ped,posePlaying.dict,posePlaying.clip,4.0f);
        poseOn=false;poseFrozen=false;posePlaying={nullptr,nullptr,-1.0f};
    }
    // 0.13.0: poseOverride (whole-hand grips when the finger animation does not play) replaces the pose's clip.
    void armPose(int ped,bool want){
        if(!want){stopPose(ped);return;}
        std::uint64_t now=GetTickCount64();
        if(poseKind<0)poseKind=state->config.armPoseKind>0?state->config.armPoseKind:1;
        PoseAnim a=poseOverride.dict?poseOverride:poseAnim(poseKind);
        bool switching=posePlaying.dict&&(std::strcmp(posePlaying.dict,a.dict)!=0||std::strcmp(posePlaying.clip,a.clip)!=0);
        if(!switching&&now<poseCheck)return;poseCheck=now+400;
        call(REQUEST_ANIM_DICT,a.dict);
        if(!call<bool>(HAS_ANIM_DICT_LOADED,a.dict)){if(!poseRequestedAt)poseRequestedAt=now;
            // 0.10.0: grip -> typing -> box carry, 4 s each, if a dictionary does not load in Story Mode.
            if(!poseOverride.dict&&poseKind!=2&&now-poseRequestedAt>4000){int next=poseKind==3?1:2;log(std::string("Arms: the ")+poseName(poseKind)+" pose did not load; using "+poseName(next)+".");poseKind=next;poseRequestedAt=0;}
            if(poseOverride.dict==FallbackGunDict&&!fallbackGunFailed&&now-poseRequestedAt>4000){fallbackGunFailed=true;poseRequestedAt=0;   // 0.15.8
                log("Fingers: GTA's rifle grip (whole-hand pose for a gun) did not load in 4 s; a gun takes nm@hands grab (the claw) like 0.15.7.");}
            return;}
        poseRequestedAt=0;
        if(switching||!call<bool>(IS_ENTITY_PLAYING_ANIM,ped,a.dict,a.clip,3)){
            if(switching&&call<bool>(IS_ENTITY_PLAYING_ANIM,ped,posePlaying.dict,posePlaying.clip,3))call(STOP_ANIM_TASK,ped,posePlaying.dict,posePlaying.clip,8.0f);
            float blend=switching?8.0f:4.0f;
            call(TASK_PLAY_ANIM,ped,a.dict,a.clip,blend,-blend,-1,49,0.0f,false,false,false);poseFrozen=false;posePlaying=a;   // 49 = loop | upper body | player keeps control
            if(!poseLogged){poseLogged=true;log(std::string("Arms: still upper-body pose active (")+(poseOverride.dict?std::string(a.dict)+" / "+a.clip:std::string(poseName(poseKind)))
                +", frozen); no walk / run arm swing, IK moves the hands. [Hands] ArmPose=Grip / Typing / Box / Off.");}}
        else if(a.time>=0&&!poseFrozen){call(SET_ENTITY_ANIM_CURRENT_TIME,ped,a.dict,a.clip,a.time);call(SET_ENTITY_ANIM_SPEED,ped,a.dict,a.clip,0.0f);poseFrozen=true;}   // still frame: no typing fingers
        poseOn=true;
    }
    // Leave the pose to GTA where the body needs its own arm animation (0.13.0: also the phone).
    bool poseAllowed(int ped){
        return !call<bool>(GET_IS_TASK_ACTIVE,ped,160)&&!call<bool>(IS_PED_GETTING_INTO_A_VEHICLE,ped)&&!call<bool>(IS_PED_SWIMMING,ped)&&!call<bool>(IS_PED_CLIMBING,ped)
            &&!call<bool>(IS_PED_VAULTING,ped)&&!call<bool>(IS_PED_IN_COVER,ped,false)&&!call<bool>(IS_PED_RAGDOLL,ped)&&!call<bool>(IS_PED_FALLING,ped)
            &&!call<bool>(IS_PED_RUNNING_MOBILE_PHONE_TASK,ped);
    }
    // ---------- 0.13.0 / 0.14.0: fingers ----------
    // 1 = the clip's dictionary is loaded, 0 = loading, -1 = not in this game (or it never loads).
    int clipState(const ClipRef& c){
        ClipStatus* s=nullptr;for(auto& x:clipStatus)if(sameClip(x.clip,c)){s=&x;break;}
        if(!s){clipStatus.push_back({c,0,GetTickCount64()});s=&clipStatus.back();}
        if(s->state!=0)return s->state;
        if(!call<bool>(DOES_ANIM_DICT_EXIST,c.dict)){s->state=-1;log(std::string("Fingers: animation dictionary ")+c.dict+" is not in this game; skipped.");return -1;}
        call(REQUEST_ANIM_DICT,c.dict);
        if(!call<bool>(HAS_ANIM_DICT_LOADED,c.dict)){if(GetTickCount64()-s->since>6000){s->state=-1;log(std::string("Fingers: ")+c.dict+" did not load within 6 s; skipped.");}return s->state;}
        s->state=1;float d=call<float>(GET_ANIM_DURATION,c.dict,c.clip);
        log(std::string("Fingers: ")+c.dict+" / "+c.clip+" loaded ("+(std::isfinite(d)&&d>0?fixed(d,2)+" s":std::string("single frame or not found: ")+fixed(d,2))+").");
        return 1;
    }
    // 0 = each arm (BONEMASK_ARMONLY_L / R), 1 = GTA's hand grip filters, 2 = none (upper body, both hands alike).
    std::int32_t filterHash(int hand,int filter){
        if(filter==2)return 0;
        if(filter==1)return std::int32_t(joaat(hand?"Grip_R_Only_filter":"Grip_L_Only_filter"));
        return std::int32_t(joaat(hand?"BONEMASK_ARMONLY_R":"BONEMASK_ARMONLY_L"));
    }
    static const char* filterName(int filter){return filter==2?"no filter (both hands alike)":filter==1?"GTA's hand grip filters":"arm filters";}
    // Ours still playing: the clip with the most weight on either arm (a clip at weight 0 may not count).
    bool ourFingersPlaying(int ped){for(const auto& c:playingClip)if(c.dict&&c.dict[0]&&call<bool>(IS_ENTITY_PLAYING_ANIM,ped,c.dict,c.clip,3))return true;return false;}
    // If GTA does not report blended clips as playing, the task itself (CTaskScriptedAnimation = 134) is checked.
    bool fingersAlive(int ped){return trustTask?call<bool>(GET_IS_TASK_ACTIVE,ped,134):ourFingersPlaying(ped);}
    std::string poseText(int pose)const{return pose>=0&&pose<surveyCount?std::string(surveyList[pose].clip.dict)+" / "+surveyList[pose].clip.clip:std::string("none");}
    void issueSurveyPose(int ped,int pose){
        const SurveyPose& p=surveyList[pose];
        ScriptedAnimData low=armSingle(p.clip,p.phase,filterHash(0,p.filter),FingerAnimFlags),mid=armSingle(p.clip,p.phase,filterHash(1,p.filter),FingerAnimFlags),high;
        if(p.filter==2)low=ScriptedAnimData{};   // no filter: one slot is the whole upper body
        call(TASK_SCRIPTED_ANIMATION,ped,&low,&mid,&high,.125f,.125f);
        playingClip[0]=playingClip[1]=p.clip;fingersOn=true;fingerIssuedAt=GetTickCount64();for(auto& h:fingerHand)h.sentValid=false;
    }
    void issueFingers(int ped,const FingerWeights (&w)[2]){
        ClipRef clips[2][3];float phases[2][3];
        for(int i=0;i<2;++i)for(int k=0;k<3;++k){int pose=fingerHand[i].slot[k];clips[i][k]=surveyList[pose].clip;phases[i][k]=surveyList[pose].phase;fingerHand[i].issued[k]=pose;}
        ScriptedAnimData low=armBlend(clips[0],phases[0],w[0],filterHash(0,fingerFilter),FingerAnimFlags),mid=armBlend(clips[1],phases[1],w[1],filterHash(1,fingerFilter),FingerAnimFlags),high;
        if(fingerFilter==2)low=ScriptedAnimData{};
        call(TASK_SCRIPTED_ANIMATION,ped,&low,&mid,&high,.125f,.125f);
        for(int i=0;i<2;++i){fingerHand[i].sent=w[i];fingerHand[i].sentValid=true;playingClip[i]=clips[i][w[i].grip>=w[i].fist&&w[i].grip>=w[i].open?2:w[i].fist>w[i].open?1:0];}
        fingersOn=true;fingerIssuedAt=GetTickCount64();
    }
    void stopFingers(int ped){
        if(fingersOn&&ped&&call<bool>(DOES_ENTITY_EXIST,ped)&&(ourFingersPlaying(ped)||call<bool>(GET_IS_TASK_ACTIVE,ped,134)))call(CLEAR_PED_SECONDARY_TASK,ped);
        fingersOn=false;for(auto& h:fingerHand){h.sentValid=false;for(int& k:h.issued)k=-1;}
        if(!surveyDone){survey.reset();surveyIssued=-1;}   // the hand check starts over next time
    }
    // How bent the character's fingers are in the animation (finger bones are not moved by the arm IK).
    FingerCurls handCurls(int ped,int i){
        static constexpr int thumb[2][3]={{26610,4089,4090},{58866,64016,64017}};
        // Bone tags (alt:V's ped bone list): SKEL_x_Finger10-12 index, 20-22 middle, 30-32 ring.
        static constexpr int fingers[2][3][3]={{{26611,4169,4170},{26612,4185,4186},{26613,4137,4138}},{{58867,64096,64097},{58868,64112,64113},{58869,64064,64065}}};
        FingerCurls c;Vec3 wrist=bone(ped,handBone[i]);
        c.f[0]=chainBend(bone(ped,thumb[i][0]),bone(ped,thumb[i][1]),bone(ped,thumb[i][2]));
        for(int k=0;k<3;++k)c.f[k+1]=fingerCurl(wrist,bone(ped,fingers[i][k][0]),bone(ped,fingers[i][k][1]),bone(ped,fingers[i][k][2]));
        return c;
    }
    static std::string curlText(const FingerCurls& c){std::string t;for(int k=0;k<4;++k){if(k)t+="/";t+=std::isfinite(c.f[k])?fixed(c.f[k],2):std::string("?");}return t;}
    int surveyIndex(const char* dict,const char* clip,int filter=0)const{for(int i=0;i<surveyCount;++i)if(surveyList[i].filter==filter&&sameClip(surveyList[i].clip,ClipRef{dict,clip}))return i;return -1;}
    void finishSurvey(){
        surveyDone=true;surveyIssued=-1;
        std::string table="Fingers: hand check done (bend of thumb / index / middle / ring, 0 = straight; left | right):";
        for(int k=0;k<surveyCount;++k)table+="\n    "+poseText(k)+(surveyList[k].filter?std::string(" [")+filterName(surveyList[k].filter)+"]":std::string())+": "+curlText(survey.result(k,0))+" | "+curlText(survey.result(k,1));
        log(table);
        for(int i=0;i<2;++i)choice[i]=chooseHand(surveyList,surveyCount,survey,i,state->config.pistolGrip);
        float g1=NAN,g2=NAN;
        for(int i=0;i<2;++i){float a=filterGain(surveyList,surveyCount,survey,i,1,choice[i].open),b=filterGain(surveyList,surveyCount,survey,i,2,choice[i].open);
            if(std::isfinite(a)&&!(a<=g1))g1=a;if(std::isfinite(b)&&!(b<=g2))g2=b;}
        if(choice[0].anyChange||choice[1].anyChange)fingerFilter=0;
        else if(g1>=CloseNeeded||g2>=CloseNeeded){
            fingerFilter=g1>=CloseNeeded?1:2;int open=surveyIndex("nm@hands","natural"),fist=surveyIndex("nm@hands","fist"),grab=surveyIndex("nm@hands","grab");
            for(auto& c:choice){c=HandChoice{};c.open=open;c.fist=fist;c.grab=grab;for(int& g:c.grip)g=grab;c.anyChange=true;}
            log(std::string("Fingers: the arm filters do not reach the fingers; ")+filterName(fingerFilter)+" do (+"+fixed(fingerFilter==1?g1:g2,2)+").");}
        else{fingersFailed=true;
            log("Fingers: no pose changed the character's fingers (+"+(std::isfinite(g2)?fixed(g2,2):std::string("?"))+" without a filter). Whole-hand poses with GTA's ordinary animation task are used instead.");return;}
        if(choice[0].open<0&&choice[1].open<0){fingersFailed=true;log("Fingers: no open-hand pose plays; whole-hand poses are used instead.");return;}
        for(int i=0;i<2;++i){const HandChoice& c=choice[i];
            auto gripText=[&](GripClass g){return std::string(gripName(g))+" = "+(c.grip[g]>=0?poseText(c.grip[g]):std::string("none"))
                +(c.borrowed[g]>=0?std::string(" (the ")+gripName(GripClass(c.borrowed[g]))+"'s"+(g==GripPistol&&state->config.pistolGrip==PistolGrip::Rifle?": PistolGrip=Rifle)":": its own did not close the hand)"):std::string());};
            log(std::string("Fingers: ")+(i?"right":"left")+" hand ("+filterName(fingerFilter)+"): open = "+poseText(c.open)+", fist = "+poseText(c.fist)+", holding = "+poseText(c.grab)
                +"; "+gripText(GripPistol)+", "+gripText(GripSmg)+", "+gripText(GripRifle)+", "+gripText(GripSniper)+", "+gripText(GripThrown)
                +"; gestures: thumbs up "+(c.thumbs>=0?"yes":"no")+", point "+(c.point>=0?"yes":"no")+", middle finger "+(c.middle>=0?"yes":"no")+".");}
    }
    // SteamVR's finger curls -> 0 none, 1 thumbs up, 2 point / finger gun, 3 middle finger.
    static int gestureCode(const HandSkeleton& h){
        if(!h.valid)return 0;
        switch(classifyGesture(h.curl)){case Gesture::ThumbsUp:return 1;case Gesture::Point:case Gesture::Gun:return 2;case Gesture::MiddleFinger:return 3;default:return 0;}
    }
    static const char* gestureText(int g){return g==1?"thumbs up":g==2?"point":g==3?"middle finger":"";}
    // Every update while the VR arms are on (the pose rules of poseAllowed apply).
    void fingersUpdate(int ped,const InputFrame& in,const HandSkeleton (&skeletons)[2],bool allowed){
        std::uint64_t us=nowUs();float dt=lastFingerUs?float(double(us-lastFingerUs)/1e6):0;lastFingerUs=us;
        std::uint64_t now=GetTickCount64();
        if(ped!=fingerPed){fingerPed=ped;fingersOn=false;for(auto& h:fingerHand){h.sentValid=false;for(int& k:h.issued)k=-1;}if(!surveyDone){survey.reset();surveyIssued=-1;}}
        if(!allowed){stopFingers(ped);return;}
        // Ours still playing? Another secondary task (a mission animation, GTA's weapon switch) wins: wait.
        bool settling=fingersOn&&now-fingerIssuedAt<400;
        if(fingersOn&&!settling&&!fingersAlive(ped)){fingersOn=false;for(auto& h:fingerHand){h.sentValid=false;for(int& k:h.issued)k=-1;}
            if(!surveyDone){survey.reset();surveyIssued=-1;}
            if(call<bool>(IS_PED_SWITCHING_WEAPON,ped))fingerBackoff=now+1500;
            else if(call<bool>(GET_IS_TASK_ACTIVE,ped,134)){   // a scripted animation plays: another script's, or ours unreported
                if(++unreported>=2){trustTask=true;fingersOn=true;log("Fingers: GTA does not report the blended clips as playing; the animation task itself is checked from now on.");}
                else fingerBackoff=now+1500;}
            else if(++fingerFailures>=3){fingersFailed=true;log("Fingers: GTA does not play the per-arm finger animation (3 tries); whole-hand poses with GTA's ordinary animation task are used instead. [Hands] Fingers=Off turns this off.");return;}
            else fingerBackoff=now+1000;}
        if(fingersOn&&!settling&&now-fingerIssuedAt>2000){fingerFailures=0;if(!trustTask)unreported=0;}
        if(!fingersOn&&(now<fingerBackoff||call<bool>(IS_PED_SWITCHING_WEAPON,ped)))return;
        // ---- 0.14.0: the hand check, once ----
        if(!surveyDone){
            if(!survey.running()){
                bool loading=false;for(int i=0;i<surveyCount;++i)if(clipState(surveyList[i].clip)==0)loading=true;
                if(!surveyWaitSince)surveyWaitSince=now;
                if(loading&&now-surveyWaitSince<9000)return;
                if(++surveyRuns>4){surveyDone=true;fingersFailed=true;log("Fingers: the hand check was interrupted 4 times; whole-hand poses are used instead.");return;}
                survey.start(surveyCount);surveyIssued=-1;
                log("Fingers: hand check - both hands show "+std::to_string(surveyCount)+" poses (about "+fixed(surveyCount*FingerSurvey::Hold,0)+" s); the finger bones tell which ones GTA really plays.");}
            int pose=survey.current();
            while(pose>=0&&clipState(surveyList[pose].clip)<0){survey.skip();pose=survey.current();}
            if(pose<0){finishSurvey();return;}
            if(pose!=surveyIssued){issueSurveyPose(ped,pose);surveyIssued=pose;return;}
            FingerCurls c[2]={handCurls(ped,0),handCurls(ped,1)};fingerHand[0].curls=c[0];fingerHand[1].curls=c[1];
            if(survey.update(dt,c)==2)finishSurvey();
            return;
        }
        // ---- the chosen poses ----
        GripClass hold[2]={shareFresh?GripClass(handShare.leftGrip):GripNone,shareFresh?GripClass(handShare.rightGrip):GripNone};
        const float grip[2]={in.leftGrip,in.rightGrip};
        FingerWeights w[2];bool changed=false;
        for(int i=0;i<2;++i){HandFingers& h=fingerHand[i];const HandChoice& c=choice[i].open>=0?choice[i]:choice[1-i];
            if(hold[i]>GripFist)hold[i]=GripNone;h.hold=hold[i];
            float g=h.squeeze.update(grip[i],dt);int gesture=h.gesture.update(gestureCode(skeletons[i]),dt);
            int open=c.open,fist=c.fist>=0?c.fist:open;h.special=specialPose(c,hold[i],gesture);
            h.slot[0]=open;h.slot[1]=fist;h.slot[2]=h.special>=0?h.special:fist;
            w[i]=h.special>=0?FingerWeights{0,0,1}:FingerWeights{1-g,g,0};
            for(int k=0;k<3;++k)if(h.slot[k]!=h.issued[k])changed=true;}
        if(!fingersOn||changed){
            issueFingers(ped,w);
            if(!fingersLogged){fingersLogged=true;log(std::string("Fingers: on (")+filterName(fingerFilter)+") - an empty hand closes with the grip; a held weapon takes its grip; "
                "SteamVR's finger gestures (thumbs up, point, middle finger) show where the hand check found a pose. [Hands] Fingers=Off: the 0.12.0 still pose.");}
            return;}
        for(int i=0;i<2;++i){HandFingers& h=fingerHand[i];
            if(h.sentValid&&std::abs(w[i].open-h.sent.open)<=.02f&&std::abs(w[i].fist-h.sent.fist)<=.02f&&std::abs(w[i].grip-h.sent.grip)<=.02f)continue;
            if(fingerFilter==2&&i==0)continue;   // no filter: the right hand's blend shows on both
            const float v[3]={w[i].open,w[i].fist,w[i].grip};
            for(int k=0;k<3;++k)call(SET_ANIM_WEIGHT,ped,v[k],i,k,true);   // priority 0 = low (left arm), 1 = medium (right arm); secondary task
            h.sent=w[i];h.sentValid=true;playingClip[i]=surveyList[h.slot[w[i].grip>=w[i].fist&&w[i].grip>=w[i].open?2:w[i].fist>w[i].open?1:0]].clip;}
        if(diagPanel||now<diagUntil)for(int i=0;i<2;++i)fingerHand[i].curls=handCurls(ped,i);   // 20 bone reads: only for the panel
    }
    // Fallback (the finger animation does not play): whole-hand poses with GTA's ordinary animation task.
    void fallbackGrips(const InputFrame& in){
        GripClass hold=shareFresh?GripClass(handShare.rightGrip):GripNone;if(hold>GripFist)hold=GripNone;
        float g=std::max(in.rightGrip,in.leftGrip);fallbackFist=fallbackFist?g>.35f:g>.6f;
        // 0.15.8: a gun takes GTA's rifle grip (the hand around a pistol grip, the index finger at the trigger) - not the
        // claw - unless that clip does not load (4 s, armPose).
        bool gun=hold==GripPistol||hold==GripSmg||hold==GripRifle||hold==GripSniper;
        if(gun&&!fallbackGunFailed)poseOverride={FallbackGunDict,"grip",0.0f};
        else if(hold!=GripNone)poseOverride={"nm@hands","grab",0.0f};
        else if(fallbackFist)poseOverride={"nm@hands","fist",0.0f};
        else poseOverride={"nm@hands","natural",0.0f};
    }
    std::string fingerLine(){
        if(!state->config.fingers)return std::string("Arm pose: ")+(poseOn?poseName(poseKind):"none")+" (Fingers=Off)";
        if(fingersFailed)return std::string("Fingers: whole-hand poses (")+(posePlaying.dict?std::string(posePlaying.dict)+" / "+posePlaying.clip:std::string("none"))+")";
        if(!surveyDone)return survey.running()?"Fingers: hand check "+std::to_string(survey.current()+1)+" / "+std::to_string(surveyCount)+" ("+poseText(survey.current())+") L "+curlText(fingerHand[0].curls)+" R "+curlText(fingerHand[1].curls):std::string("Fingers: loading the hand poses");
        if(!fingersOn)return "Fingers: waiting";
        auto hand=[&](int i){const HandFingers& h=fingerHand[i];std::string t=i?"R ":"L ";
            int gesture=h.gesture.value();
            if(h.hold!=GripNone)t+=gripName(h.hold);
            else if(h.special>=0)t+=gestureText(gesture);
            else t+=std::to_string(int(std::lround(h.sent.fist*100)))+"% closed";
            if(h.curls.valid())t+=" ("+curlText(h.curls)+")";return t;};
        return "Fingers: "+hand(0)+" | "+hand(1);
    }
    // ---------- 0.7.0: what GTA really renders (the headset "zoom" check) ----------
    // Projects four points 20 degrees off the rendered camera's axis and measures GTA's image.
    void probeFov(){
        if(state->config.fovCheck==0||state->fovCal.finished()||!camera||!stereoSince||GetTickCount64()-stereoSince<1000)return;
        float fov=call<float>(GET_FINAL_RENDERED_CAM_FOV);if(!std::isfinite(fov)||std::abs(fov-state->projection.requestFov)>.3f)return;   // not our camera (yet)
        Vec3 c=call<Vec3>(GET_FINAL_RENDERED_CAM_COORD),r=call<Vec3>(GET_FINAL_RENDERED_CAM_ROT,2);if(!finite(c)||!finite(r))return;
        Basis b=cameraBasis(r);const float tanA=std::tan(rad(20)),distance=30;
        auto screen=[&](Vec3 direction,float& x,float& y){Vec3 p=c+direction*distance;x=y=-1;return call<bool>(GET_SCREEN_COORD_FROM_WORLD_COORD,p.x,p.y,p.z,&x,&y);};
        float xc,yc,xl,yl,xr,yr,xu,yu,xd,yd;
        if(!screen(b.forward,xc,yc)||!screen(b.forward-b.right*tanA,xl,yl)||!screen(b.forward+b.right*tanA,xr,yr)||!screen(b.forward+b.up*tanA,xu,yu)||!screen(b.forward-b.up*tanA,xd,yd))return;
        FovSample sample;if(!fovSample(tanA,xl,xr,yu,yd,xc,yc,sample))return;
        auto result=state->fovCal.add(sample,state->projection.requestFov,state->fovModel,state->backAspect);if(!result.ready)return;
        float expectedV=state->projection.tanV,expectedH=state->projection.tanH;
        log("FOV check round "+std::to_string(state->fovCal.roundsDone())+": SET_CAM_FOV "+fixed(result.request)+" deg gave a GTA image of "+fixed(2*std::atan(result.measuredV)*180/pi)
            +" x "+fixed(2*std::atan(result.measuredH)*180/pi)+" deg (vertical x horizontal); expected "+fixed(2*std::atan(expectedV)*180/pi)+" x "+fixed(2*std::atan(expectedH)*180/pi)+" deg.");
        if(!result.changed){log("FOV check: GTA's image matches the headset projection (no zoom). "+state->describeProjection()+".");return;}
        if(state->config.fovCheck==1){state->fovCal.stop();log("FOV check: GTA's image differs from the headset projection; FovCheck=Log leaves it unchanged (FovCheck=Fix corrects it).");return;}
        state->fovModel=result.model;state->fixedProjection=false;state->rebuildProjection();
        if(result.finished&&std::abs(state->projection.requestFov-result.request)>.5f){
            // Out of rounds: use what was measured as it is rather than an unverified new request.
            state->fixedProjection=true;state->fixedRequest=result.request;state->fixedTanV=result.measuredV;state->fixedTanH=result.measuredH;state->rebuildProjection();}
        state->invalidateStereo();
        log(std::string("FOV check: ")+(result.finished?"final correction":"corrected")+"; "+state->describeProjection()+(result.finished?".":"; measuring again."));
    }
    // Shift+PageUp / PageDown: image zoom in 2 % steps, Shift+Home: exact (1.00). Saved to the INI.
    void zoomKeys(bool focused,bool shift,std::uint64_t now){
        bool up=(GetAsyncKeyState(VK_PRIOR)&0x8000)!=0,down=(GetAsyncKeyState(VK_NEXT)&0x8000)!=0,home=(GetAsyncKeyState(VK_HOME)&0x8000)!=0;
        float zoom=state->view.zoom;bool changed=false;
        if(focused&&shift){if(up&&!previousPageUp){zoom+=.02f;changed=true;}if(down&&!previousPageDown){zoom-=.02f;changed=true;}if(home&&!previousHome){zoom=1;changed=true;}}
        previousPageUp=up;previousPageDown=down;previousHome=home;
        if(changed){state->view.zoom=clampZoom(std::round(zoom*50)/50);state->fixedProjection=false;state->fovCal.restart();state->rebuildProjection();state->invalidateStereo();
            wchar_t text[32];swprintf(text,32,L"%.2f",double(state->view.zoom));WritePrivateProfileStringW(L"Renderer",L"Zoom",text,(directory()+L"\\GTAHandVR.ini").c_str());
            notice="VR zoom "+fixed(state->view.zoom,2)+(std::abs(state->view.zoom-1)<.001f?" (exact)":state->view.zoom<1?" (smaller / wider)":" (bigger)")+" | Shift+PgUp / PgDn, Shift+Home = 1.00";
            noticeUntil=now+3500;log("Camera: "+notice+"; "+state->describeProjection()+".");}
        if(now<noticeUntil)screenText(notice,.5f,.80f,.40f);
        if(now<handNoteUntil)screenText(handNote,.5f,.76f,.34f,true,170,230,255);
        // 0.10.0: Shift+End shows / hides the diagnostics panel (it also shows for 15 s when the 3D view starts).
        bool end=focused&&shift&&(GetAsyncKeyState(VK_END)&0x8000)!=0;
        if(end&&!previousEnd){diagPanel=!diagPanel;diagUntil=0;log(std::string("Diagnostics panel ")+(diagPanel?"on":"off")+" (Shift+End).");}
        previousEnd=end;
    }
    bool monoNow()const{return monoOverride>=0?monoOverride==1:state->config.stereoAuto?autoStereo.monoSelected():state->config.mono;}
    // 0.16.2: how far your head is turned from the origin (degrees, + = left like GTA headings).
    float headTurnDegrees(const Pose& head){return wrapAngle(headYaw(head)-headYaw(origin))*180/pi;}
    // 0.16.2: GTA's camera and the character face your body. Standing, GTA leaves a first-person character as it is when
    // its camera turns (the 0.16.1 log: the character 42-85 deg from GTA's camera), so the character is turned itself;
    // walking, GTA's walk faces its camera (and a turn of more than 30 deg is done at once). The view depends on neither.
    void bodyStep(int ped,float pedHeading,float body,bool drive,bool walking){
        if(!drive||!std::isfinite(body)||!std::isfinite(pedHeading)){bodyDriven=false;return;}
        float off=wrapDegrees(body-pedHeading);
        bodyOffSum+=std::abs(off);++bodySamples;bodyOffMax=std::max(bodyOffMax,std::abs(off));
        bool moving=walking&&call<float>(GET_ENTITY_SPEED,ped)>.5f;
        if(!moving||std::abs(off)>30){if(std::abs(off)>.5f){call(SET_ENTITY_HEADING,ped,body);++bodySets;}off=0;}
        call(SET_GAMEPLAY_CAM_RELATIVE_HEADING,off);
        call(SET_PED_DESIRED_HEADING,ped,body);
        if(!bodyLogged){bodyLogged=true;log("Body: the character faces your body (it turns with you: past 40 deg at once, all the way after 0.5 s looking aside, "
            "and where you walk); GTA's camera points there too. [Body] TurnBody=0 turns this off.");}
        bodyDriven=true;
    }
    // ---------- 0.10.0: real crouch -> GTA crouch stance ----------
    void physicalCrouch(int ped,float headHeight,bool allowed,float dt){
        float stand=state->config.playerEye>0?state->config.playerEye:standRef;
        bool ok=allowed&&state->config.physicalCrouch&&(crouchSet||!call<bool>(GET_PED_STEALTH_MOVEMENT,ped));   // a crouch you toggled with the keyboard is yours
        int e=crouch.update(headHeight,stand,state->config.crouchRatio,std::min(.95f,state->config.crouchRatio+.08f),dt,ok);
        if(e==1){call(SET_PED_STEALTH_MOVEMENT,ped,true,"DEFAULT_ACTION");crouchSet=true;
            log("Body: you crouched (head "+fixed(headHeight,2)+" m, standing "+fixed(stand,2)+" m): character in GTA's crouch stance.");}
        if(e==-1&&crouchSet){call(SET_PED_STEALTH_MOVEMENT,ped,false,"DEFAULT_ACTION");crouchSet=false;log("Body: you stood up: character standing.");}
    }
    // ---------- 0.10.0: diagnostics panel, readable in the headset and in a video of the monitor ----------
    std::string armLine(int i){const ArmIk& a=arms[i];std::string t=i?"Right arm: ":"Left arm: ";
        if(state->config.armIkMode==2)return t+"IK off (ArmIk=Off)";
        t+=std::string("target = ")+(a.onGun?"the gun (GTA's grip)":"controller")+" | rotation: "+rotationStatus(a)+" | marker "+cm(a.markerMiss);
        if(std::isfinite(a.markerTurn))t+=" "+fixed(a.markerTurn,0)+" deg";
        return t+" | anim "+cm(a.boneMiss);}
    void drawDiagnostics(std::uint64_t now,bool onFoot){
        if(!diagPanel&&now>=diagUntil)return;
        bool mono=monoOverride<0?(state->config.stereoAuto?autoStereo.monoSelected():state->config.mono):monoOverride==1;
        std::string l1=std::string("GTA 5 VR ")+Version+" | "+(mono?"mono":"3D")+" "+fixed(autoStereo.framesPerSecond())+" fps | world x"+fixed(worldScale,2)
            +(state->config.playerEye>0?" (your eyes "+fixed(state->config.playerEye,2)+" m)":" (height not calibrated: T-pose + both triggers 2 s)");
        std::string l4=fingerLine(),l5=std::string("Crouch: ")+(crouch.crouched()?"crouched":"standing")+" | steps: "
            +(state->config.roomScale?fixed(followed,1)+" m":"off")+" | body: "+(!state->config.turnBody?std::string("off"):bodyDriven?"follows you":"waits")
            +" | map: "+(state->radarShown?"shown":state->radar?(onFoot?"turn the wrist to see it":"dashboard"):"off");
        call(DRAW_RECT,.5f,.233f,.80f,.166f,0,0,0,150,false);
        screenText(l1,.5f,.156f,.28f);screenText(armLine(0),.5f,.182f,.28f);screenText(armLine(1),.5f,.208f,.28f);screenText(l4,.5f,.234f,.28f);screenText(l5,.5f,.260f,.28f);
        screenText(diagPanel?"Shift+End hides this panel":"Shift+End keeps this panel on",.5f,.288f,.22f,true,180,180,180);
    }
    // ---------- 0.9.0: the body at the player's height ----------
    // T-pose + both triggers for 2 s: the eye height above the real floor, saved to [Body] PlayerEyeHeight.
    void heightCalibration(InputFrame& input,bool allowed,float dt){
        TPoseInput t;t.head=input.head;t.left=input.left.pos();t.right=input.right.pos();t.leftValid=(input.flags&LeftValid)!=0;t.rightValid=(input.flags&RightValid)!=0;
        t.leftTrigger=input.leftTrigger;t.rightTrigger=input.trigger;t.allowed=allowed&&state->config.calibrationGesture&&(input.flags&HeadValid);
        CalibrationResult r;auto e=calib.update(t,dt,r);
        // Triggers used for the gesture never reach the weapons (also not when the arms come down still squeezing).
        bool mute=calib.posing();input.trigger=triggerMute[1].update(input.trigger,mute);input.leftTrigger=triggerMute[0].update(input.leftTrigger,mute);
        if(e==HeightCalibration::Started)log("Body calibration: T-pose with both triggers held; keep still for 2 seconds.");
        if(e==HeightCalibration::Cancelled){notify("Height calibration cancelled (keep the T-pose and both triggers for 2 s)",2500);
            log("Body calibration cancelled: the T-pose or a trigger was released before 2 seconds.");}
        if(calib.holding())notify("Height calibration: keep the T-pose... "+std::to_string(int(calib.progress()*100))+" %",500);
        if(e!=HeightCalibration::Done)return;
        if(!plausibleCalibration(r)){log("Body calibration rejected: eye height "+fixed(r.eyeHeight,2)+" m, hands "+fixed(r.span,2)+" m apart. SteamVR's floor height may be wrong (Room Setup).");
            notify("Height calibration failed: stand straight, arms out to the sides (check SteamVR's floor)",6000);return;}
        state->config.playerEye=r.eyeHeight;
        wchar_t text[32];swprintf(text,32,L"%.3f",double(r.eyeHeight));WritePrivateProfileStringW(L"Body",L"PlayerEyeHeight",text,(directory()+L"\\GTAHandVR.ini").c_str());
        float s=bodyScale(charEye.value(),r.eyeHeight);
        log("Body calibration: your eyes are "+fixed(r.eyeHeight,2)+" m above the floor, hands "+fixed(r.span,2)+" m apart; the character's eyes "+fixed(charEye.value(),2)
            +" m"+(charEye.ready()?"":" (estimate)")+" -> body scale "+fixed(s,3)+" (world scale "+fixed(state->config.scale*s,3)+"). Saved to [Body] PlayerEyeHeight.");
        notify("Height calibrated: your eyes "+fixed(r.eyeHeight,2)+" m -> body scale "+fixed(s,2),6000);
        if(state->actions)state->vr.input->TriggerHapticVibrationAction(state->actions->haptic,0,.12f,150.0f,.7f,0);
    }
    // How high the current character's eyes are above its feet (standing still on foot).
    void measureCharacter(int ped,bool onFoot,bool eyesOk,Vec3 eye){
        std::uint32_t model=call<std::uint32_t>(GET_ENTITY_MODEL,ped);if(model!=charEye.model())charEye.reset(model);
        if(charEye.ready()||!onFoot||!eyesOk||!finite(eye))return;
        if(call<float>(GET_ENTITY_SPEED,ped)>.3f||call<bool>(GET_PED_STEALTH_MOVEMENT,ped)||call<bool>(IS_PED_RAGDOLL,ped)||call<bool>(IS_PED_FALLING,ped)
            ||call<bool>(IS_PED_CLIMBING,ped)||call<bool>(IS_PED_SWIMMING,ped)||call<bool>(IS_PED_IN_COVER,ped,false))return;
        Vec3 l=bone(ped,20781),r=bone(ped,24806);if(!finite(l)||!finite(r))return;   // SKEL_L_Toe0, SKEL_R_Toe0
        charEye.add(eye.z,std::min(l.z,r.z));
        if(charEye.ready())log("Body: this character's eyes are "+fixed(charEye.value(),2)+" m above its feet"+(state->config.playerEye>0?"; body scale "+fixed(bodyScale(charEye.value(),state->config.playerEye),3)+".":" (no height calibration yet: T-pose + both triggers 2 s)."));
    }
    // World scale = WorldScale x (character eyes / your eyes) once calibrated.
    void updateWorldScale(){
        float body=state->config.playerEye>0?bodyScale(charEye.value(),state->config.playerEye):1.0f;
        if(std::abs(body-appliedBody)>.005f){appliedBody=body;state->invalidateStereo();log("Body: world scale "+fixed(state->config.scale*body,3)+" (WorldScale "+fixed(state->config.scale,2)+" x body "+fixed(body,3)+").");}
        worldScale=state->config.scale*appliedBody;
    }
    // ---------- 0.9.0: GTA's minimap on the wrist (on foot) or the dashboard (vehicles) ----------
    void drawMapStrip(const ScreenRect& r,int player){
        call(DRAW_RECT,r.x+r.w*.5f,r.y+r.h*.5f,r.w,r.h,0,0,0,175,false);
        char clock[16];std::snprintf(clock,sizeof(clock),"%02d:%02d",call<int>(GET_CLOCK_HOURS),call<int>(GET_CLOCK_MINUTES));
        screenText(clock,r.x+r.w*.04f,r.y+r.h*.02f,.40f,false);
        int wanted=std::clamp(call<int>(GET_PLAYER_WANTED_LEVEL,player),0,5);
        for(int k=0;k<5;++k){bool on=k<wanted;float cx=r.x+r.w*(.47f+.105f*float(k)),cy=r.y+r.h*.5f;
            call(DRAW_RECT,cx,cy,r.w*.075f,r.h*.55f,on?255:70,on?205:70,on?40:70,on?255:200,false);}
    }
    void mapOverlay(bool stereo,bool inVehicle,int player,const Pose& eyeHead){
        auto& s=*state;
        bool wanted=s.radar&&stereo&&(inVehicle?s.config.dashboardMap:s.config.wristMap>=0);
        bool rendering=wanted&&call<bool>(IS_MINIMAP_RENDERING);
        // Diagnostics for the log: GTA not drawing its minimap, or no controller in the wrist's hand role.
        std::uint64_t nowMs=GetTickCount64();
        if(wanted&&!rendering){if(!mapHiddenSince)mapHiddenSince=nowMs;if(!mapHiddenLogged&&nowMs-mapHiddenSince>5000){mapHiddenLogged=true;
            log("Map: GTA is not drawing its minimap (radar off in GTA's display settings, or hidden by a mission); nothing to show on the wrist / dashboard.");}}
        else{mapHiddenSince=0;if(rendering)mapHiddenLogged=false;}
        bool dash=rendering&&inVehicle,wrist=rendering&&!inVehicle;
        if(!dash&&!wrist){s.radarWanted=false;wristFacing.reset();return;}
        ScreenRect map=minimapRect(call<float>(GET_SAFE_ZONE_SIZE),call<float>(GET_ASPECT_RATIO,false));
        float strip=s.config.mapStrip?map.h*.22f:0;
        if(s.config.mapStrip)drawMapStrip(radarStrip(map,strip),player);
        s.radarBox=toPixels(radarCapture(map,strip),s.width,s.height);
        if(dash){wristFacing.reset();Pose p=dashboardOverlay(origin,s.config.dashboardOffset,s.config.dashboardTilt);
            s.radarWanted=true;s.radarDeviceRelative=false;std::memcpy(s.radarTransform.m,p.m,sizeof(p.m));s.radarWidth=s.config.dashboardSize;return;}
        bool left=s.config.wristMap==0;
        TrackedDeviceIndex_t device=s.vr.system->GetTrackedDeviceIndexForControllerRole(left?ETrackedControllerRole_TrackedControllerRole_LeftHand:ETrackedControllerRole_TrackedControllerRole_RightHand);
        Pose local=wristOverlayLocal(left,s.config.wristOffset,s.config.wristTilt);bool visible=false;
        if(device<k_unMaxTrackedDeviceCount&&devicePoses[device].bPoseIsValid){Pose controller{};std::memcpy(controller.m,devicePoses[device].mDeviceToAbsoluteTracking.m,sizeof(controller.m));
            // Shown while the watch side of the wrist faces the eyes (hysteresis against flicker).
            if(validPose(controller)&&validPose(eyeHead))visible=wristFacing.update(facingAmount(composePoses(controller,local),eyeHead.pos()),.45f,.25f);}
        else{wristFacing.reset();if(!mapNoHandLogged){mapNoHandLogged=true;log(std::string("Map: SteamVR reports no ")+(left?"left":"right")+"-hand controller pose; no wrist map ([Map] Wrist=Left / Right).");}}
        s.radarWanted=visible;s.radarDeviceRelative=true;s.radarDevice=device;std::memcpy(s.radarTransform.m,local.m,sizeof(local.m));s.radarWidth=s.config.wristSize;
    }
    void showBody(){if(hiddenPed&&call<bool>(DOES_ENTITY_EXIST,hiddenPed))call(SET_ENTITY_VISIBLE,hiddenPed,wasVisible,false);hiddenPed=0;}
    void hideBody(int ped){if(!state->config.hideBody){showBody();return;}if(hiddenPed!=ped){showBody();hiddenPed=ped;wasVisible=call<bool>(IS_ENTITY_VISIBLE,ped);}call(SET_ENTITY_VISIBLE,ped,false,false);}
    // Draw this update's frame tag; script draws render with the same update as the world.
    void drawTag(std::uint32_t id){auto cells=encodeTag(id);
        call(SET_SCRIPT_GFX_DRAW_ORDER,7);call(RESET_SCRIPT_GFX_ALIGN);
        for(unsigned c=0;c<TagCells;++c){auto r=tagRect(c,state->width,state->height);int v=cells[c]?255:0;call(DRAW_RECT,r.x,r.y,r.w,r.h,v,v,v,255,false);}
    }
    void logSync(std::uint64_t now){if(now-lastSyncLog<10000)return;lastSyncLog=now;auto& s=state->stats;auto& lag=state->cameraLag;
        std::string depth=s.depthSamples?(std::to_string(s.depthMin)+"/"+fixed(double(s.depthSum)/s.depthSamples)+"/"+std::to_string(s.depthMax)):"n/a";
        log(std::string("Frame sync: mode=")+(state->tagMode?"tagged":"untagged")+" tagged="+std::to_string(s.tagged)+" untagged="+std::to_string(s.untagged)
            +" unmatched="+std::to_string(s.unmatched)+" ring_full="+std::to_string(s.dropped)+" legacy="+std::to_string(s.legacy)
            +" capture_depth_min/avg/max="+depth+" camera_lag="+std::to_string(state->effectiveLag())+"("+cameraLagName(state->cameraLagOverride)
            +", votes same="+std::to_string(lag.votesFor(0))+" late="+std::to_string(lag.votesFor(1))+" unclear="+std::to_string(lag.ambiguousSamples())+")"
            +" plan_to_submit_ms="+(s.latencySamples?fixed(s.latencyMsSum/s.latencySamples):std::string("n/a"))+" prediction_ms="+fixed(lastPrediction*1000)+" hands_drawn="+std::to_string(state->handDraws)
            +" game_cam_pitch_roll_ignored="+fixed(lastGamePitch)+"/"+fixed(lastGameRoll)+" anchor_offset="+fixed(eyeAnchor.localOffset().x,2)+","+fixed(eyeAnchor.localOffset().y,2)+","+fixed(eyeAnchor.localOffset().z,2)
            +" anchor_drift_m="+fixed(eyeAnchor.lastDrift,2)+" anchor_remeasured="+std::to_string(eyeAnchor.recalibrations)
            +" anchor_lean_skipped="+std::to_string(eyeAnchor.leaningSkipped));
        // 0.16.2 (the developer: "very juddery"): where the time goes, and whether the character keeps facing your body.
        auto ms=[](const MsSpan& m){return m.count?fixed(m.average(),1)+"/"+fixed(m.max,1):std::string("n/a");};
        std::string steam="n/a";
        if(state->steamStatsValid){const auto& c=state->steamStats;
            if(steamLoggedValid&&c.m_nPid==steamLogged.m_nPid&&c.m_nNumFramePresents>=steamLogged.m_nNumFramePresents)
                steam=std::to_string(c.m_nNumFramePresents-steamLogged.m_nNumFramePresents)+" shown / "+std::to_string(c.m_nNumDroppedFrames-steamLogged.m_nNumDroppedFrames)
                    +" dropped / "+std::to_string(c.m_nNumReprojectedFrames-steamLogged.m_nNumReprojectedFrames)+" reprojected";
            steamLogged=c;steamLoggedValid=true;}
        log("Frame timing: GTA's frames 1 / 2 / 3+ headset frames apart="+std::to_string(s.gaps.one)+"/"+std::to_string(s.gaps.two)+"/"+std::to_string(s.gaps.more)
            +" ("+fixed(state->displayHz)+" Hz) gpu_ms_avg/max="+ms(s.gpu)+" render_thread_lock_wait_ms="+ms(s.lockWait)+" script_update_ms="+ms(s.scriptTick)
            +" steamvr="+steam+" | view: "+(monoNow()?"mono":"3D")
            +" | body: "+(bodySamples?"off_avg/max_deg="+fixed(bodyOffSum/bodySamples,1)+"/"+fixed(bodyOffMax,1)+" turned_by_mod="+std::to_string(bodySets)+"/"+std::to_string(bodySamples):std::string("not driven")));
        bodyOffSum=0;bodyOffMax=0;bodySets=0;bodySamples=0;
        s.clear();state->handDraws=0;
    }
public:
    void restore(){if(camera){if(call<bool>(DOES_CAM_EXIST,camera)){call(RENDER_SCRIPT_CAMS,false,false,0,true,false,0);call(SET_CAM_ACTIVE,camera,false);call(DESTROY_CAM,camera,false);}camera=0;}
        showBody();if(savedModes){call(SET_FOLLOW_PED_CAM_VIEW_MODE,pedMode);call(SET_FOLLOW_VEHICLE_CAM_VIEW_MODE,vehicleMode);savedModes=false;}
        if(savedContextModes){for(int c=0;c<7;++c)call(SET_CAM_VIEW_MODE_FOR_CONTEXT,c,savedContexts[c]);savedContextModes=false;}
        centered=false;wasStereo=false;stereoSince=0;deleteProxies();{int p=call<int>(PLAYER_PED_ID);armPose(p,false);stopFingers(p);}state->radarWanted=false;wristFacing.reset();
        if(crouchSet){int p=call<int>(PLAYER_PED_ID);if(p&&call<bool>(DOES_ENTITY_EXIST,p))call(SET_PED_STEALTH_MOVEMENT,p,false,"DEFAULT_ACTION");crouchSet=false;}crouch.reset();havePrevAnchor=false;
        cameraBridge.suspend(GetTickCount64(),poseSource);lastCameraFlags=~0u;
    }
    void tick(){
        // Report a startup stall without waiting on the render thread's mutex.
        const char* currentStage=startupStage.load();auto since=stageTime.load();
        if(state->config.builtin&&!startupStopped.load()&&since&&GetTickCount64()-since>15000&&lastWarnedStage!=currentStage){
            log(std::string("Startup status unchanged for 15 seconds: ")+currentStage+"; Script Hook present callbacks="+std::to_string(callbackCount.load())+". If no callback arrived, check Legacy DX11 / Script Hook V. Otherwise send this log's last initialization stage.");lastWarnedStage=currentStage;
        }
        // Blocking lock: Present only holds it for copy commands (never during WaitGetPoses),
        // and a skipped tick would leave one game update without an eye request / frame tag.
        std::unique_lock<std::mutex> lock(state->mutex);
        // 0.16.2: how long this update holds the lock (GTA's render thread waits for it).
        struct HoldTimer{FrameSyncStats& s;std::uint64_t from=nowUs();~HoldTimer(){s.scriptTick.add(double(nowUs()-from)/1000);}} holdTimer{state->stats};
        releaseTaps(GetTickCount64());   // 0.15.5: menu key taps end on time, whatever this update does
        std::uint64_t lastScript=state->scriptTickMs.exchange(GetTickCount64());bool resumed=lastScript&&GetTickCount64()>lastScript+250;   // GTA held the scripts (pause menu)
        int player=call<int>(PLAYER_ID),ped=call<int>(PLAYER_PED_ID);
        bool online=call<bool>(NETWORK_IS_SESSION_ACTIVE)||call<bool>(NETWORK_IS_SESSION_STARTED);
        DWORD focusedPID=0;GetWindowThreadProcessId(GetForegroundWindow(),&focusedPID);
        // Hard stops leave stereo at once; brief control loss / ragdoll must last 300 ms.
        // Jumping and falling stay in stereo (the body anchor follows the character).
        // 0.15.5: a cutscene that PLAYS (IS_CUTSCENE_ACTIVE is also true while a mission only loads its next one: the
        // prologue's "Go to the guard" was on the flat screen for a minute although the character could walk).
        bool noFocus=focusedPID!=GetCurrentProcessId(),cutscene=call<bool>(IS_CUTSCENE_PLAYING),pauseMenu=call<bool>(IS_PAUSE_MENU_ACTIVE);
        bool hardStop=online||noFocus||cutscene||pauseMenu
            ||call<bool>(IS_SCREEN_FADED_OUT)||!ped||!call<bool>(DOES_ENTITY_EXIST,ped)||call<bool>(IS_ENTITY_DEAD,ped,false);
        bool controlOff=!hardStop&&!call<bool>(IS_PLAYER_CONTROL_ON,player);
        bool softStop=!hardStop&&(controlOff||call<bool>(IS_PED_RAGDOLL,ped));
        const char* stopWhy=online?nullptr:noFocus?"GTA's window is not in front (click it once): flat screen meanwhile"
            :cutscene?"Cutscene: flat screen until it ends":controlOff?"GTA plays a scene (no control): flat screen until you can move again":nullptr;
        bool playing=gate.update(hardStop,softStop,GetTickCount64());
        if(online&&state->config.builtin)state->fail("Story Mode only.");
        if(state->failed){restore();return;}
        if(!state->config.builtin){if(playing)firstPerson();else restore();return;}
        if(!state->ready||!state->width){restore();reportCamera("Camera: waiting for VR initialization and a game backbuffer.");return;}
        bool f10=(GetAsyncKeyState(VK_F10)&0x8000)!=0,f11=(GetAsyncKeyState(VK_F11)&0x8000)!=0,shift=(GetAsyncKeyState(VK_SHIFT)&0x8000)!=0;
        if(f10&&!previousF10){
            if(shift){bool mono=!(monoOverride<0?state->config.mono:monoOverride==1);monoOverride=mono?1:0;state->invalidateStereo();
                log(std::string("Camera: Shift+F10 selected ")+(mono?"MONO stable mode (same centre image in both eyes, no alternating-eye judder, no world depth).":"ALTERNATING stereo 3D."));}
            else{centered=false;state->repositionCinema=true;eyeAnchor.reset();yawFilter.reset();offsetLimiter.reset();}
        }
        if(f11&&!previousF11){
            if(shift){// Shift+F11 cycles the camera-lag override for in-headset comparison.
                state->cameraLagOverride=state->cameraLagOverride<0?0:state->cameraLagOverride==0?1:-1;state->invalidateStereo();
                log(std::string("Frame sync: CameraLag override set to ")+cameraLagName(state->cameraLagOverride)+" with Shift+F11.");
            }else{flat=!flat;state->repositionCinema=true;log(flat?"VR mode: off (F11) - GTA's own view on the flat screen.":"VR mode: on (F11).");}
        }
        previousF10=f10;previousF11=f11;
        VREvent_t event{};while(state->vr.system->PollNextEvent(&event,sizeof(event)))if(event.eventType==EVREventType_VREvent_Quit){state->fail("SteamVR requested shutdown. Restart GTA after restarting SteamVR.");restore();return;}
        if(!state->posesStarted){restore();reportCamera("Camera: waiting for SteamVR's first render pose on the game render thread.");return;}
        // Non-blocking predicted pose. WaitGetPoses runs on the render thread after Submit.
        float sinceVsync=0;std::uint64_t vsyncCounter=0;if(!state->vr.system->GetTimeSinceLastVsync(&sinceVsync,&vsyncCounter))sinceVsync=0;
        lastPrediction=predictionSeconds(sinceVsync,state->displayHz,state->vsyncToPhotons,state->pipeline.seconds());
        // 0.9.0: every device (the wrist map needs the controller's own pose).
        for(auto& d:devicePoses)d=TrackedDevicePose_t{};
        state->vr.system->GetDeviceToAbsoluteTrackingPose(ETrackingUniverseOrigin_TrackingUniverseStanding,lastPrediction,devicePoses,k_unMaxTrackedDeviceCount);
        const TrackedDevicePose_t& pose=devicePoses[0];
        InputFrame input{};input.timeMs=GetTickCount64();
        std::memcpy(input.head.m,pose.mDeviceToAbsoluteTracking.m,sizeof(input.head.m));
        bool runtimeTracked=pose.bPoseIsValid&&pose.bDeviceIsConnected&&validPose(input.head);
        auto tracking=cameraBridge.select(input.head,runtimeTracked,input.timeMs);bool tracked=tracking.valid;
        if(tracking.recenter||poseSource!=tracking.source){centered=false;state->invalidateStereo();state->repositionCinema=true;
            if(poseSource!=tracking.source)log(tracking.source==GTA5VR_POSE_PLUGIN?"Camera: external tracking provider selected.":"Camera: SteamVR tracking provider selected.");}
        poseSource=tracking.source;input.head=tracking.head;
        if(tracked){input.flags|=HeadValid;lastHead=input.head;}else input.head=lastHead;
        state->actions->read(input);
        // 0.15.0 (the friend: "a button to enter and exit VR mode"): both thumbstick clicks held for a second =
        // VR off: GTA's own view on the flat cinema screen (like F11; the motion controls pause, the keyboard /
        // gamepad play) - and the same button brings the VR view back. Neither click reaches anything else
        // while both are down (no run, no character wheel).
        if(state->config.vrButton){vrToggle.setHold(std::uint64_t(state->config.vrButtonMs));
            bool clicks[2]={(input.buttons&SprintHeld)!=0,(input.buttons&InteractHeld)!=0};
            if(vrToggle.update(clicks[0],clicks[1],input.timeMs)){
                flat=!flat;state->repositionCinema=true;vrHintUntil=input.timeMs+(flat?8000:2500);
                state->vr.input->TriggerHapticVibrationAction(state->actions->haptic,0,flat?.12f:.06f,120.0f,.8f,0);
                log(flat?"VR mode: off (both stick clicks) - GTA's own view on the flat screen; the motion controls pause. The same button (or F11) brings VR back."
                    :"VR mode: on (both stick clicks).");}
            if(vrToggle.swallowing())input.buttons&=~(SprintHeld|InteractHeld);
        }
        if(vrToggle.holding()&&vrToggle.progress(input.timeMs)>.2f)
            screenText(std::string(flat?"Keep holding both sticks: VR on":"Keep holding both sticks: VR off (flat screen)")+" "+std::to_string(int(vrToggle.progress(input.timeMs)*100))+"%",.5f,.70f,.42f,true,255,230,140);
        else if(input.timeMs<vrHintUntil)
            screenText(flat?"VR off (flat screen) | hold both stick clicks 1 s or F11: VR on":"VR on",.5f,.70f,.42f,true,255,230,140);
        // Fingers: skeletons predicted like the head. Touch combo grip+trigger+stick click raises the middle finger.
        std::uint64_t tickUs=nowUs();float dt=lastTickUs?float(double(tickUs-lastTickUs)/1e6):0;lastTickUs=tickUs;
        bool inVehicle=ped&&call<bool>(IS_PED_IN_ANY_VEHICLE,ped,false);bool comboAllowed=state->config.fingerCombo&&!inVehicle&&playing;
        if(combo[1].update(input.rightGrip,input.trigger,(input.buttons&InteractHeld)!=0,comboAllowed,dt))input.buttons&=~InteractHeld;
        if(combo[0].update(input.leftGrip,input.leftTrigger,(input.buttons&SprintHeld)!=0,comboAllowed,dt))input.buttons&=~SprintHeld;
        // 0.15.5: the six buttons -> what each one does ([Controls], the VR menu). While the VR menu or GTA's pause menu is
        // up, the physical A / B / sticks play it and nothing reaches the game as a VR button.
        std::uint32_t physical=input.buttons&physicalMask;
        // GTA's pause menu (ready) or a warning screen ("quit?"); not its brief start / close states (the buttons stay the game's).
        bool frontend=!noFocus&&!online&&(pauseMenu||call<bool>(IS_WARNING_MESSAGE_ACTIVE));
        bool menuInput=vrMenu.opened()||(frontend&&state->config.menuControls);
        if(!buttonsLogged){buttonsLogged=true;log("Buttons: "+buttonsLine(state->config.buttons)+" ([Controls]; change them in the VR menu: Y in GTA's pause menu).");}
        // A button still held when a menu closes (B that resumed GTA, A that chose) does nothing in the game until let go.
        if(menuInput||resumed)swallowPhysical=physical;else swallowPhysical&=physical;
        if(state->menuRequest.exchange(false)&&!vrMenu.opened())openVrMenu(input.timeMs,"Y in GTA's pause menu");
        if(menuInput)input.buttons&=~physicalMask;
        else input.buttons=(input.buttons&~physicalMask)|state->config.buttons.apply(physical&~swallowPhysical);
        menuControls(input,physical,frontend,pauseMenu);
        if(!menuInput&&!noFocus){std::uint32_t fresh=input.buttons&~lastFunctions;
            if(fresh&PauseHeld){tapKey(scan::P,false,input.timeMs);log("Buttons: GTA's pause menu (P).");}
            if((fresh&MenuHeld)&&!vrMenu.opened())openVrMenu(input.timeMs,"its button");}
        lastPhysical=physical;lastFunctions=menuInput?0:input.buttons;
        if(menuInput)input.buttons&=~(PauseHeld|MenuHeld);
        HandSkeleton handSkeletons[2];
        bool human=!ped||call<bool>(IS_PED_HUMAN,ped);   // Chop and other animals: no hands, no weapons
        // 0.7.0: skeletons also drive the character's own arms (Body=Character), with or without drawn hands.
        bool overlay=state->config.overlay()&&state->hands.ready;
        bool armSkeleton=state->config.characterBody&&state->config.armIkMode!=2&&state->actions->leftSkeleton&&state->actions->rightSkeleton;
        if(human&&(overlay||armSkeleton)){
            state->actions->skeleton(state->actions->leftSkeleton,state->actions->left,lastPrediction,handSkeletons[0]);
            state->actions->skeleton(state->actions->rightSkeleton,state->actions->right,lastPrediction,handSkeletons[1]);
            for(int i=0;i<2;++i)if(handSkeletons[i].valid)straightenFinger(handSkeletons[i],2,combo[i].blend());
            if(firstHands){firstHands=false;if(!state->actions->leftSkeleton||!state->actions->rightSkeleton)log("Hands: the SteamVR action manifest has no skeleton actions; update all package files together.");}
            reportHands(handSkeletons,input.timeMs);
        }
        bool dashboard=state->vr.overlay->IsDashboardVisible();
        // 0.15.5: the SteamVR menu button pauses GTA (its own pause menu - the sticks / A / B play it once the SteamVR
        // menu is closed; B or P resumes). [Menu] PauseOnDashboard=0 turns this off.
        if(dashboard&&!dashboardWas&&state->config.pauseOnDashboard&&!noFocus&&!online&&!frontend&&!vrMenu.opened()&&ped&&!call<bool>(IS_ENTITY_DEAD,ped,false)){
            tapKey(scan::P,false,input.timeMs);log("SteamVR menu opened: GTA paused (its pause menu - close the SteamVR menu, then the sticks / A / B play it; B resumes). [Menu] PauseOnDashboard=0 turns this off.");}
        dashboardWas=dashboard;
        // 0.9.0: CharacterWheelView=Flat shows GTA's own view (cinema) while the right stick click is held.
        // 0.14.0: also while the motion add-on holds GTA's character wheel open (the Y button).
        bool shareRead=state->ipc.readHands(handShare);shareFresh=shareRead&&freshShare(handShare,GetTickCount64());   // 0.13.0: what the hands hold, the hand on the gun
        if(shareRead)viewYaw.snapTotal(handShare.turnTotal);   // 0.16.2: the motion add-on's snap turns turn the view's own heading
        wheelHold.update((input.buttons&InteractHeld)!=0,input.timeMs);
        // 0.15.3: GTA's own wheel (Y) also in a vehicle - it is only on the flat view; the stick click stays on foot.
        bool modWheel=shareFresh&&(handShare.flags&CharacterWheel);
        bool wheelOpen=wheelHold.holding()||modWheel;bool wheelFlat=state->config.wheelFlat&&((wheelHold.holding()&&!inVehicle)||modWheel);
        bool stereo=playing&&tracked&&!dashboard&&!flat&&!wheelFlat&&state->config.firstPerson&&!vrMenu.opened();   // 0.15.5: the VR menu on the flat screen
        // 0.9.0: height calibration (on foot, in the headset view) and the resulting world scale.
        heightCalibration(input,stereo&&human&&!inVehicle,dt);
        updateWorldScale();
        zoomKeys(focusedPID==GetCurrentProcessId(),shift,GetTickCount64());
        if(stereo){if(!wasStereo){state->invalidateStereo();wasStereo=true;eyeAnchor.reset();yawFilter.reset();offsetLimiter.reset();stereoSince=GetTickCount64();}   // 0.16.1: no automatic numbers panel (Shift+End only)
            firstPerson();if(ped!=lastPed){centered=false;lastPed=ped;eyeAnchor.reset();yawFilter.reset();}
            if(inVehicle!=lastInVehicle){lastInVehicle=inVehicle;eyeAnchor.reset();yawFilter.reset();}
            bool recentred=!centered;
            if(!centered){origin=yawPose(input.head);centered=true;state->invalidateStereo();standRef=input.head.pos().y;havePrevAnchor=false;torsoYaw.reset();}
            // Before this update's camera is set: which earlier request did GTA render last?
            std::uint32_t latest=state->plans.latestId();
            if(camera&&latest>1){const FramePlan* previous=state->plans.find(latest);const FramePlan* before=state->plans.find(latest-1);
                if(previous&&before&&state->cameraLag.observe(CameraLagEstimator::classify(call<Vec3>(GET_FINAL_RENDERED_CAM_COORD),*previous,*before)))
                    log(std::string("Frame sync: measured scripted-camera application ")+(state->cameraLag.lag()?"ONE game update late":"in the same game update")
                        +(state->cameraLagOverride<0?"; eye labels follow this measurement.":"; INI/Shift+F11 override remains in effect."));
            }
            probeFov();   // what GTA rendered last frame, before this update's camera is set
            Vec3 gameCam=call<Vec3>(GET_GAMEPLAY_CAM_COORD),rotation=call<Vec3>(GET_GAMEPLAY_CAM_ROT,2);
            // 0.15.5: while GTA aims at the person the VR gun points at, GTA's camera looks at him (the motion add-on turns
            // it); the view keeps the heading the add-on sends and is not levelled / body-turned meanwhile.
            float aimYaw=NAN;bool aimView=shareFresh&&(handShare.flags&AimHeading);
            if(aimView){std::memcpy(&aimYaw,&handShare.viewYawBits,4);aimView=std::isfinite(aimYaw)&&human&&!inVehicle;}
            if(aimView){rotation.z=aimYaw;rotation.x=0;rotation.y=0;
                if(!aimViewLogged){aimViewLogged=true;log("View: GTA aims at the person the VR gun points at - GTA's camera looks at him, the view keeps its own heading.");}}
            lastGamePitch=rotation.x;lastGameRoll=rotation.y;
            // 0.11.0: GTA's own camera pitch bends the first-person character (head and upper body look there;
            // the 0.10.0 log had it at -70 deg after a SteamVR dashboard visit). The view ignores it, so on foot
            // it is held level; the arms then reach from an upright body.
            if(state->config.levelGameCam&&human&&!inVehicle&&!wheelOpen&&!aimView){
                if(std::abs(rotation.x)>25&&!pitchLogged){pitchLogged=true;log("Body: GTA's own camera was pitched "+fixed(rotation.x)+" deg (the character looked "+(rotation.x<0?"down at the floor":"up")
                    +" and bent over); it is now held level on foot. [Body] LevelGameCamera=0 turns this off.");}
                call(SET_GAMEPLAY_CAM_RELATIVE_PITCH,0.0f,1.0f);}
            // Only the game camera's heading turns the view (no inherited pitch/roll), and the
            // eye rides on the body instead of the bobbing first-person camera.
            // 0.6.0: in a vehicle the view is locked to the vehicle's heading (GTA's vehicle camera may be third
            // person or free-look); on foot the game camera heading is smoothed.
            // 0.16.2 (the developer: "it is very juddery and the head does not turn with the character's torso"): on foot
            // (a person) the view has its own heading (ViewYaw): your head and the snap turns turn it - not GTA's camera,
            // which is turned to your body below (bodyStep). Up to 0.16.1 a body turn turned GTA's camera and then the view
            // back, once GTA showed it: one update late, or never ("GTA's camera did not take the body turn").
            int vehicle=inVehicle?call<int>(GET_VEHICLE_PED_IS_IN,ped,false):0;
            float pedHeading=call<float>(GET_ENTITY_HEADING,ped);
            bool ownView=state->config.turnBody&&state->config.levelHorizon&&human&&!vehicle&&std::isfinite(pedHeading);
            if(!ownView)viewYaw.stop();
            else if(!viewYaw.on()||recentred){viewYaw.start(pedHeading,headTurnDegrees(input.head));torsoYaw.reset();   // you look where the character faces
                if(!viewLogged){viewLogged=true;log("View: on foot the view keeps its own heading - your head and the snap turns turn it; GTA's camera and the character turn to your body ([Body] TurnBody=0: 0.16.1).");}}
            if(ownView)rotation=Vec3{0,0,viewYaw.value()};
            else if(state->config.levelHorizon){rotation=levelRotation(rotation);
                if(vehicle)rotation.z=call<float>(GET_ENTITY_HEADING,vehicle);
                else if(state->config.stabilizeTurn)rotation.z=yawFilter.update(rotation.z,dt);}
            // 0.6.0: eye from the character's head bone (not GTA's camera, which can be third person
            // in vehicles or for Chop, and was measured up to 40 cm in front of the body).
            Vec3 root=call<Vec3>(GET_ENTITY_COORDS,ped,true);
            Vec3 headBone=call<Vec3>(GET_PED_BONE_COORDS,ped,31086,0.0f,0.0f,0.0f);
            bool headOk=headBoneUsable(headBone,root);Vec3 eyeL{},eyeR{};
            if(human&&headOk){eyeL=call<Vec3>(GET_PED_BONE_COORDS,ped,25260,0.0f,0.0f,0.0f);eyeR=call<Vec3>(GET_PED_BONE_COORDS,ped,27474,0.0f,0.0f,0.0f);}
            bool eyesOk=human&&headOk&&eyeBonesUsable(eyeL,eyeR,headBone);
            Vec3 eyeEstimate=eyesOk?eyeFromEyeBones(eyeL,eyeR,pedHeading):headOk?eyeFromHeadBone(headBone,pedHeading,!human):(human?gameCam:root+headingForward(pedHeading)*.35f+Vec3{0,0,.45f});
            const char* source=eyesOk?"Camera: eye position from the character's eye bones.":headOk?(human?"Camera: eye position from the character's head bone.":"Camera: animal first person from the head bone."):(human?"Camera: eye position from GTA's camera (no head bone).":"Camera: animal first person (no head bone).");
            if(source!=eyeSource){eyeSource=source;log(source);}
            if(human)measureCharacter(ped,!inVehicle,eyesOk,eyeEstimate);
            // 0.10.0: legs. A real crouch puts the character in GTA's crouch stance; GTA's leg IK keeps the feet on the ground.
            bool bodyFollows=human&&!inVehicle&&poseAllowed(ped);
            if(state->config.legIk&&human&&ped!=legIkPed){call(SET_PED_CAN_LEG_IK,ped,true);call(SET_PED_LEG_IK_MODE,ped,2);legIkPed=ped;log("Body: GTA leg IK set to full (the feet follow the ground).");}
            physicalCrouch(ped,input.head.pos().y,bodyFollows,dt);
            // 0.15.5: GTA turns the character to where it aims; the eye (25 cm in front of the body) keeps the heading from before.
            float anchorYaw=anchorHeading.update(aimView,aimYaw,pedHeading,dt);
            Vec3 anchor=state->config.stableCamera?eyeAnchor.update(root,anchorYaw,eyeEstimate,GetTickCount64(),crouch.crouched()||anchorHeading.hold(),bodyFollows):eyeEstimate;   // 0.16.2: on foot the eye stays on the body
            if(!finite(anchor)||!finite(rotation))throw std::runtime_error("Invalid native first-person camera.");
            Basis base=cameraBasis(rotation);
            // 0.10.0: when the character walks toward where your head went (a real step, see the motion add-on),
            // the origin moves with it, so the camera stays exactly at your real head and the body comes under it.
            if(state->config.roomScale&&bodyFollows&&havePrevAnchor){
                Vec3 used=consumeOffset(trackedOffset(input.head,origin,base,worldScale),anchor-prevAnchor);
                if(length(used)>0){Vec3 t=worldToTracking(used,origin,base,worldScale);if(finite(t)){origin.m[0][3]+=t.x;origin.m[2][3]+=t.z;followed+=length(used);}}}
            prevAnchor=anchor;havePrevAnchor=bodyFollows&&!anchorHeading.hold();   // 0.15.5: the eye's heading held / blending: no room-scale step
            auto head=trackedCamera(input.head,origin,anchor,base,worldScale,.75f*worldScale);
            // Prevent room-scale translation from putting the camera through nearby walls.
            if(length(head.position-anchor)>.02f){auto end=head.position;int ray=call<int>(START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE,anchor.x,anchor.y,anchor.z,end.x,end.y,end.z,511,ped,7);
                int hit=0,entity=0;gta::NativeVector contact{},normal{};int result=call<int>(GET_SHAPE_TEST_RESULT,ray,&hit,&contact,&normal,&entity);
                // Pull back to just before the wall, and ease out again (no flicker at walls).
                float fraction=result==2&&hit?length(Vec3{contact.x,contact.y,contact.z}-anchor)/std::max(length(end-anchor),1e-3f):1.0f;
                head.position=anchor+(end-anchor)*offsetLimiter.update(fraction,dt);}
            else offsetLimiter.update(1,dt);
            input.gameHead=head.position;input.gameBasis=head.basis;input.flags|=CameraKnown;
            if(camera&&!call<bool>(DOES_CAM_EXIST,camera)){camera=0;state->invalidateStereo();}
            unsigned eyeIndex=eyeForPlan(state->plans.latestId()+1);
            // Frame rate decides Auto mode: mono when each alternating eye would get < ~15 fps.
            ++fpsFrames;std::uint64_t nowMs=GetTickCount64();if(!fpsWindowStart)fpsWindowStart=nowMs;
            if(autoHz!=state->displayHz){autoHz=state->displayHz;auto r=StereoAuto::rangeFor(autoHz);autoStereo.setRange(r.first,r.second);   // 0.16.1
                autoStereo.startMono(true);   // 0.16.2: Auto starts smooth (mono) and goes to 3D once GTA holds the 3D rate for 5 s
                if(state->config.stereoAuto)log("Camera: StereoMode=Auto for a "+fixed(autoHz)+" Hz headset: "+(StereoAuto::monoOnly(autoHz)
                    ?"Mono (the same image in both eyes every frame); 3D would give each eye "+fixed(autoHz/2)+" images a second at most - juddery (90 / 120 Hz and GTA at that rate: 3D)"
                    :"3D above "+fixed(r.second)+" game fps ("+fixed(r.second/2)+"+ images per eye), mono below "+fixed(r.first)+"; it starts in mono")
                    +". Shift+F10 switches.");}
            if(nowMs-fpsWindowStart>=1000){if(autoStereo.update(fpsFrames,double(nowMs-fpsWindowStart)/1000,nowMs)&&state->config.stereoAuto&&monoOverride<0)
                    log(std::string("Camera: StereoMode=Auto selected ")+(autoStereo.monoSelected()?"MONO":"3D")+" at "+fixed(autoStereo.framesPerSecond())+" game fps.");
                fpsFrames=0;fpsWindowStart=nowMs;}
            bool mono=monoNow();
            auto eye=mono?head:eyeCamera(head,state->eyeOffsets[eyeIndex],worldScale);auto angles=cameraAngles(eye.basis);
            if(!camera){camera=call<int>(CREATE_CAM,"DEFAULT_SCRIPTED_CAMERA",false);if(!camera)throw std::runtime_error("GTA did not create the VR camera.");}
            call(SET_CAM_COORD,camera,eye.position.x,eye.position.y,eye.position.z);call(SET_CAM_ROT,camera,angles.x,angles.y,angles.z,2);
            call(SET_CAM_FOV,camera,state->projection.requestFov);call(SET_CAM_NEAR_CLIP,camera,.03f);call(SET_CAM_ACTIVE,camera,true);call(RENDER_SCRIPT_CAMS,true,false,0,true,false,0);
            // Arms reach for the controllers on foot; in a vehicle GTA keeps the hands on the wheel / bars.
            bool vrArms=(state->config.characterBody||!human)&&human&&!inVehicle&&state->config.armIkMode!=2;
            bool posing=vrArms&&poseAllowed(ped);
            if(state->config.fingers&&!fingersFailed){stopPose(ped);fingersUpdate(ped,input,handSkeletons,posing);}
            else{stopFingers(ped);if(state->config.fingers)fallbackGrips(input);else poseOverride={nullptr,nullptr,-1.0f};armPose(ped,posing&&state->config.armPose);}
            if(state->config.characterBody||!human){characterBody(ped);if(vrArms)armIk(ped,input,handSkeletons,head);else for(auto& a:arms){a.sentOrient=false;a.haveGoal=false;}}else hideBody(ped);
            mapOverlay(true,inVehicle,player,input.head);
            // 0.16.2: your body - pulled along past 40 deg, all the way after 0.5 s looking aside, at once while walking,
            // kept while you look down at it - is the character's: GTA's camera and the character are turned to it, and the
            // motion add-on puts the holsters on it (bodyYawBits).
            {float stick=std::hypot(input.moveX,input.moveY);bool touched=!(input.buttons&TouchKnown)||(input.buttons&MoveTouched);
                stickWalking=touched&&std::isfinite(stick)&&stick>(stickWalking?.18f:.28f);}
            float torso=torsoYaw.update(headYaw(input.head),dt,stickWalking,lookingDown(input.head));
            if(ownView){input.flags|=ViewHeading;input.bodyYawBits=floatBits(torso);
                bodyStep(ped,pedHeading,bodyHeading(viewYaw.value(),torso,headYaw(origin)),bodyFollows&&!aimView&&!wheelOpen&&validPose(input.head),stickWalking);}
            else bodyDriven=false;
            drawDiagnostics(GetTickCount64(),human&&!inVehicle);
            const FramePlan& plan=state->plans.create(input.head,eye.position,nowUs(),mono);
            if(overlay&&human){auto& f=state->handPlans[plan.id&TagIdMask];f.id=plan.id;f.hand[0]=handSkeletons[0];f.hand[1]=handSkeletons[1];
                std::uint32_t model=call<std::uint32_t>(GET_ENTITY_MODEL,ped);f.colors.skin=state->config.skinAuto?defaultSkin(model):state->config.skin;
                f.colors.sleeve=state->config.sleeveSkin?f.colors.skin:state->config.sleeve;f.brightness=daylightFactor(call<int>(GET_CLOCK_HOURS))*state->config.handBrightness;}
            if(plan.eye!=eyeIndex)state->invalidateStereo();   // 32-bit id wrap: discard this one request
            else if(state->tagMode&&state->tagCapable)drawTag(plan.id);
            Vec3 actualPosition=call<Vec3>(GET_CAM_COORD,camera),actualAngles=call<Vec3>(GET_CAM_ROT,camera,2);
            float actualFov=call<float>(GET_CAM_FOV,camera);
            if(!finite(actualPosition)||!finite(actualAngles)||!std::isfinite(actualFov))throw std::runtime_error("Non-finite native camera readback.");
            auto snapshot=cameraSnapshot(eye,{actualPosition,cameraBasis(actualAngles)},state->projection.requestFov,actualFov,
                camera,call<bool>(IS_CAM_ACTIVE,camera),GetTickCount64(),++cameraFrame,poseSource);
            cameraBridge.publish(snapshot);
            reportCamera("Camera: scripted first-person tracking is active; native properties are available.");
            if(snapshot.timeMs-lastCameraLog>=30000){
                log("Camera native readback: frame="+std::to_string(snapshot.frame)+" source="+(poseSource==GTA5VR_POSE_PLUGIN?"plugin":"SteamVR")
                    +" active="+std::to_string(bool(snapshot.flags&GTA5VR_CAMERA_NATIVE_ACTIVE))+" matches="+std::to_string(bool(snapshot.flags&GTA5VR_CAMERA_READBACK_MATCHES))
                    +" position_error="+std::to_string(snapshot.positionError)+" angle_error_deg="+std::to_string(snapshot.orientationErrorDegrees)
                    +". Camera properties; captured-eye timing is reported by the Frame sync lines.");
                lastCameraFlags=snapshot.flags;lastCameraLog=snapshot.timeMs;
            }
            logSync(snapshot.timeMs);
        }else{restore();state->radarWanted=false;wristFacing.reset();anchorHeading.reset();
            // The flat character-wheel view keeps the controllers live: the motion add-on still feeds GTA's wheel.
            bool wheelView=wheelFlat&&playing&&tracked&&!dashboard&&!vrMenu.opened();
            // 0.16.3: so does a flat view while GTA takes the character's control (a shop's menu after E): the motion
            // add-on plays that menu with the controllers (a stick = arrow keys, A = Enter, B = Backspace).
            bool menuView=controlOff&&tracked&&!dashboard&&!vrMenu.opened();
            if(!wheelView&&!menuView){input.flags|=DashboardOpen;input.flags&=~InputReady;}
            // 0.15.5: why the view is flat, on it for a few seconds (the friend: "sometimes the game leaves VR mode").
            std::uint64_t nowMs=GetTickCount64();
            if(!playing&&stopWhy&&stopWhy!=flatReason){flatReason=stopWhy;flatNoteUntil=nowMs+6000;log(std::string("Flat screen: ")+stopWhy+".");}
            if(playing)flatReason=nullptr;
            if(!playing&&stopWhy&&nowMs<flatNoteUntil&&!pauseMenu)screenText(std::string(stopWhy)+" - VR comes back by itself",.5f,.035f,.34f,true,255,230,140);
            if(vrMenu.opened()){drawVrMenu();reportCamera("Camera: flat game view while the VR menu is open.");}
            else if(wheelView)reportCamera("Camera: flat game view while the character menu is open (CharacterWheelView=Flat).");
            else if(!playing)reportCamera("Camera paused: waiting for controllable Story Mode / game focus.");
            else if(!runtimeTracked)reportCamera("Camera paused: SteamVR HMD tracking is unavailable.");
            else if(!tracked)reportCamera("Camera paused: external head pose is stale; send a fresh sample or clear the provider.");
            else if(dashboard)reportCamera("Camera paused: SteamVR dashboard is open.");
            else if(flat)reportCamera("Camera paused: VR is off - flat screen (F11 or both stick clicks: VR on).");
            else reportCamera("Camera paused: First-person gameplay is disabled in settings.");
        }
        input.reserved=floatBits(worldScale);   // 0.9.0: the motion mod maps hands with the same (calibrated) world scale
        std::uint32_t feedback=state->hapticSerial;std::uint64_t consumer=0;
        if(state->ipc.publish(input,feedback,consumer)&&feedback!=state->hapticSerial&&stereo&&fresh(consumer,input.timeMs,500))
            {float amplitude=.45f,seconds=.025f;decodeHaptic(state->ipc.lastHapticCode,amplitude,seconds);state->vr.input->TriggerHapticVibrationAction(state->actions->haptic,0,seconds,amplitude>.8f?110.0f:150.0f,amplitude,0);}
        state->hapticSerial=feedback;state->input=input;state->stereo=stereo;
    }
};
void scriptMain(){state=new State;Camera camera;
    MoveFileExW((directory()+L"\\GTA5VRRenderer.log").c_str(),(directory()+L"\\GTA5VRRenderer.previous.log").c_str(),MOVEFILE_REPLACE_EXISTING);
    try{state->config.load();log(std::string("GTA 5 VR ")+Version+". Capture uses Script Hook V's game Present callback; frame tags identify which game update each captured eye shows.");
        if(state->config.oldExternal||state->config.oldOpenXR)log("Renderer: GTAHandVR.ini still has an older build's renderer option (Mode=External / Backend=OpenXR) - ignored, the built-in OpenVR renderer runs.");
        if(state->config.builtin){
            if(GetModuleHandleW(L"RealVR.asi")||GetFileAttributesW((directory()+L"\\RealVR.asi").c_str())!=INVALID_FILE_ATTRIBUTES){
                throw std::runtime_error("RealVR.asi (another VR mod) is in the game folder. Remove it: two VR mods cannot run together.");
            }
            if(!presentRegistered)throw std::runtime_error("Script Hook V lacks presentCallbackRegister/Unregister. Install a compatible Script Hook V; the renderer cannot receive game frames.");
            stage("Capture: Script Hook V Present callback registered; waiting for a game frame");
        }
        else log("External renderer selected. Built-in capture and OpenVR scene remain disabled.");
    }catch(const std::exception& e){std::lock_guard<std::mutex> lock(state->mutex);state->fail(e.what());}
    cameraBridge.enable(state->config.builtin&&state->config.firstPerson&&!state->failed,GetTickCount64());
    log("Camera API v1 loaded: queued tracking input and native camera readback, applied on the Script Hook V script fiber.");
    publishedState.store(state);
    for(;;){try{camera.tick();}catch(const std::exception& e){std::lock_guard<std::mutex> lock(state->mutex);state->fail(e.what());camera.restore();}scriptWait(0);}
}
}
extern "C" GTA5VR_CAMERA_PUBLIC uint32_t GTA5VR_GetCameraApiVersion(void){return GTA5VR_CAMERA_API_VERSION;}
extern "C" GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_SubmitHeadPose(const Gta5VrHeadPose* pose,uint32_t bytes){
    if(!pose||bytes!=sizeof(Gta5VrHeadPose))return GTA5VR_CAMERA_BAD_ARGUMENT;
    try{return cameraBridge.submit(*pose,GetTickCount64());}catch(...){return GTA5VR_CAMERA_UNAVAILABLE;}
}
extern "C" GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_ClearHeadPose(void){
    try{return cameraBridge.clear();}catch(...){return GTA5VR_CAMERA_UNAVAILABLE;}
}
extern "C" GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_RequestRecenter(void){
    try{return cameraBridge.recenter();}catch(...){return GTA5VR_CAMERA_UNAVAILABLE;}
}
extern "C" GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_ReadCamera(Gta5VrCameraSnapshot* snapshot,uint32_t bytes){
    if(!snapshot||bytes!=sizeof(Gta5VrCameraSnapshot))return GTA5VR_CAMERA_BAD_ARGUMENT;
    try{*snapshot=cameraBridge.read();return GTA5VR_CAMERA_OK;}catch(...){return GTA5VR_CAMERA_UNAVAILABLE;}
}
BOOL APIENTRY DllMain(HMODULE instance,DWORD reason,LPVOID){
    if(reason==DLL_PROCESS_ATTACH){
        moduleHandle=instance;DisableThreadLibraryCalls(instance);
        auto hook=GetModuleHandleW(L"ScriptHookV.dll");
        auto registerPresent=hook?reinterpret_cast<CallbackRegistration>(GetProcAddress(hook,"?presentCallbackRegister@@YAXP6AXPEAX@Z@Z")):nullptr;
        unregisterPresent=hook?reinterpret_cast<CallbackRegistration>(GetProcAddress(hook,"?presentCallbackUnregister@@YAXP6AXPEAX@Z@Z")):nullptr;
        // SDK contract: register/unregister callbacks in DllMain. No graphics or
        // runtime initialization occurs under the loader lock.
        if(registerPresent&&unregisterPresent){registerPresent(onGamePresent);presentRegistered=true;}
        scriptRegister(instance,scriptMain);
    }else if(reason==DLL_PROCESS_DETACH){publishedState.store(nullptr);if(presentRegistered&&unregisterPresent)unregisterPresent(onGamePresent);scriptUnregister(instance);}
    return TRUE;
}
