#pragma once
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "protocol.hpp"
namespace handvr {
class Ipc {
    HANDLE mapping=nullptr,mutex=nullptr;
    SharedMemory* memory=nullptr;
public:
    std::uint32_t lastHapticCode=0;   // strength of the latest requested pulse
private:
    bool lock() {
        if(!mutex) return false;
        DWORD r=WaitForSingleObject(mutex,0);
        return r==WAIT_OBJECT_0||r==WAIT_ABANDONED;
    }
public:
    ~Ipc() { close(); }
    void close() {
        if(memory) UnmapViewOfFile(memory);
        if(mapping) CloseHandle(mapping);
        if(mutex) CloseHandle(mutex);
        memory=nullptr;mapping=nullptr;mutex=nullptr;
    }
    bool open(bool producer) {
        if(memory) return true;
        constexpr auto mapName=L"Local\\GTAHandVR.Input.v4";
        constexpr auto mutexName=L"Local\\GTAHandVR.InputLock.v4";
        mutex=producer?CreateMutexW(nullptr,FALSE,mutexName):OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,mutexName);
        if(!mutex) return false;
        mapping=producer?CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(SharedMemory),mapName):OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,mapName);
        if(!mapping) { close();return false; }
        memory=static_cast<SharedMemory*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(SharedMemory)));
        if(!memory) { close();return false; }
        return true;
    }
    bool publish(const InputFrame& f,std::uint32_t& feedback,std::uint64_t& consumer) {
        if(!memory||!lock()) return false;
        memory->input=f;feedback=memory->hapticSerial;consumer=memory->consumerTimeMs;lastHapticCode=memory->hapticCode;
        ReleaseMutex(mutex);return true;
    }
    bool read(InputFrame& f,std::uint64_t now) {
        if(!memory||!lock()) return false;
        f=memory->input;memory->consumerTimeMs=now;
        ReleaseMutex(mutex);return true;
    }
    void haptic(std::uint32_t code=0) { if(memory&&lock()) { memory->hapticCode=code;++memory->hapticSerial;ReleaseMutex(mutex); } }
    // 0.13.0: hand information from the motion add-on to the renderer.
    bool writeHands(const HandShare& h) { if(!memory||!lock()) return false;memory->hands=h;ReleaseMutex(mutex);return true; }
    bool readHands(HandShare& h) { if(!memory||!lock()) return false;h=memory->hands;ReleaseMutex(mutex);return true; }
};
}
