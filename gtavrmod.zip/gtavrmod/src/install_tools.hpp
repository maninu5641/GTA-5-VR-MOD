#pragma once
// 0.8.0: shared by the installer (gta5vrmod setup.exe, GTA5_VR_Setup.exe until 0.16.2) and the menu (GTA5 VR.exe):
// finding GTA V Legacy, checking a folder before installing, and removing the add-on.
#include "win_app.hpp"
#include "install_parse.hpp"
#include <set>
#include <cwctype>

namespace app {

// GTA V Legacy (Enhanced uses GTA5_Enhanced.exe and has no PlayGTAV.exe).
inline bool looksLikeLegacy(const fs::path& p){return app::exists(p/L"GTA5.exe")&&app::exists(p/L"PlayGTAV.exe");}
inline bool looksLikeEnhanced(const fs::path& p){return app::exists(p/L"GTA5_Enhanced.exe");}
inline std::wstring lowerPath(const fs::path& p);
// 0.16.0: the Xbox app (PC Game Pass / Microsoft Store) puts games in <drive>:\XboxGames\<game>\Content, next to a
// MicrosoftGame.config. 0.15.8's setup could not read GTA5.exe there (the developer's PC) and refused the folder.
// 0.16.1: tested there - Script Hook V v3889.0 loads the add-on in it (VER_1_0_3889_0).
inline bool xboxAppFolder(const fs::path& p){
    if(app::exists(p/L"MicrosoftGame.config"))return true;
    auto s=lowerPath(p)+L"\\";return s.find(L"\\xboxgames\\")!=std::wstring::npos||s.find(L"\\windowsapps\\")!=std::wstring::npos;
}
// GTA V Legacy that GTA 5 VR can go into: GTA5.exe a 64-bit program (or the Xbox app's, which cannot be read).
inline bool legacyGame(const fs::path& p){return looksLikeLegacy(p)&&(pe64(p/L"GTA5.exe")||xboxAppFolder(p));}

inline std::wstring lowerPath(const fs::path& p){std::wstring s=p.lexically_normal().wstring();while(s.size()>3&&(s.back()==L'\\'||s.back()==L'/'))s.pop_back();
    for(auto& c:s)c=wchar_t(towlower(c));return s;}
// JSON / VDF string values (install_parse.hpp), as paths.
inline std::vector<std::wstring> quotedValues(const std::string& text,const std::string& key){
    std::vector<std::wstring> out;for(auto& v:quotedValuesUtf8(text,key))out.push_back(wide(v));return out;
}
inline fs::path knownFolder(REFKNOWNFOLDERID id){PWSTR p=nullptr;if(FAILED(SHGetKnownFolderPath(id,0,nullptr,&p)))return {};fs::path r(p);CoTaskMemFree(p);return r;}
// Epic, Steam and Rockstar Games Launcher installs plus the usual default folders.
inline std::vector<fs::path> detectGameFolders(){
    std::vector<fs::path> candidates;
    auto add=[&](const fs::path& p){if(!p.empty()){candidates.push_back(p);candidates.push_back(p/L"GTAV");}};
    // Epic Games: one manifest per game with its InstallLocation.
    std::error_code e;fs::path manifests=knownFolder(FOLDERID_ProgramData)/L"Epic/EpicGamesLauncher/Data/Manifests";
    if(fs::is_directory(manifests,e))for(auto& entry:fs::directory_iterator(manifests,e)){
        if(entry.path().extension()!=L".item")continue;
        try{auto text=read(entry.path(),4*1024*1024);for(auto& v:quotedValues(text,"InstallLocation"))add(fs::path(v));}catch(...){}}
    // Steam: every library folder.
    auto steam=registryString(HKEY_CURRENT_USER,L"Software\\Valve\\Steam",L"SteamPath");
    if(!steam.empty()){std::vector<fs::path> libraries{fs::path(steam)};
        try{auto vdf=read(fs::path(steam)/L"steamapps/libraryfolders.vdf",4*1024*1024);for(auto& v:quotedValues(vdf,"path"))libraries.push_back(fs::path(v));}catch(...){}
        for(auto& l:libraries)add(l/L"steamapps/common/Grand Theft Auto V");}
    // Rockstar Games Launcher / retail.
    for(const wchar_t* key:{L"SOFTWARE\\WOW6432Node\\Rockstar Games\\Grand Theft Auto V",L"SOFTWARE\\Rockstar Games\\Grand Theft Auto V",L"SOFTWARE\\WOW6432Node\\Rockstar Games\\GTAV"}){
        auto v=registryString(HKEY_LOCAL_MACHINE,key,L"InstallFolder");if(!v.empty())add(fs::path(v));}
    for(const wchar_t* p:{L"C:\\Program Files\\Rockstar Games\\Grand Theft Auto V",L"C:\\Program Files\\Epic Games\\GTAV",L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Grand Theft Auto V"})add(fs::path(p));
    // 0.16.0: the Xbox app (PC Game Pass / Microsoft Store), on any drive.
    DWORD drives=GetLogicalDrives();
    for(int d=0;d<26;++d)if(drives&(1u<<d)){std::wstring root{wchar_t(L'A'+d),L':',L'\\'};if(GetDriveTypeW(root.c_str())!=DRIVE_FIXED)continue;   // no "insert a disk" prompts
        for(const wchar_t* game:{L"Grand Theft Auto V Legacy",L"Grand Theft Auto V"})candidates.push_back(fs::path(root)/L"XboxGames"/game/L"Content");}
    std::vector<fs::path> found;std::set<std::wstring> seen;
    for(auto& c:candidates){if(!looksLikeLegacy(c))continue;if(seen.insert(lowerPath(c)).second)found.push_back(c.lexically_normal());}
    return found;
}

// ---------- Folder checks ----------
enum class CheckState { Ok,Warning,Missing };
struct Check { CheckState state;std::wstring text; };
// First line of GTAHandVR/Installed-files.txt, e.g. "GTA 5 VR 0.16.0" (older builds: "GTA 5 VR 0.7.0 development build").
inline std::wstring installedVersion(const fs::path& root){
    try{auto t=read(root/L"GTAHandVR/Installed-files.txt",1024*1024);auto end=t.find_first_of("\r\n");return wide(t.substr(0,end));}catch(...){}
    return app::exists(root/L"GTAHandVR.asi")||app::exists(root/L"GTA5VRRenderer.asi")?L"an older GTA 5 VR build":L"";
}
inline std::vector<Check> folderChecks(const fs::path& root){
    std::vector<Check> c;
    if(root.empty()){c.push_back({CheckState::Missing,L"Choose the folder that contains GTA5.exe and PlayGTAV.exe."});return c;}
    if(looksLikeLegacy(root)){
        if(!legacyGame(root)){c.push_back({CheckState::Missing,L"GTA5.exe could not be read: close GTA V and check again"});return c;}
        c.push_back({CheckState::Ok,L"GTA V Legacy found"});
        if(xboxAppFolder(root))c.push_back({CheckState::Ok,L"Xbox app (Game Pass) version: start GTA V from the Xbox app"});}
    else if(looksLikeEnhanced(root))c.push_back({CheckState::Missing,L"This is GTA V Enhanced: GTA 5 VR needs GTA V Legacy (DirectX 11)"});
    else{c.push_back({CheckState::Missing,L"GTA5.exe and PlayGTAV.exe are not in this folder"});return c;}
    c.push_back(app::exists(root/L"ScriptHookV.dll")?Check{CheckState::Ok,L"Script Hook V installed (update it whenever GTA V updates)"}
        :Check{CheckState::Missing,L"Script Hook V missing: get it, copy ScriptHookV.dll into this folder"});
    c.push_back(app::exists(root/L"dinput8.dll")?Check{CheckState::Ok,L"ASI Loader installed (dinput8.dll)"}
        :Check{CheckState::Missing,L"ASI Loader missing: copy dinput8.dll (from Script Hook V) here"});
    c.push_back(steamVRKnown()?Check{CheckState::Ok,L"SteamVR found"}:Check{CheckState::Warning,L"SteamVR not found: install it (free on Steam) before playing"});
    if(app::exists(root/L"RealVR.asi"))c.push_back({CheckState::Warning,L"RealVR.asi found: remove it - two VR mods cannot run together"});
    auto installed=installedVersion(root);
    c.push_back(installed.empty()?Check{CheckState::Ok,L"GTA 5 VR is not installed yet"}:Check{CheckState::Ok,L"Installed now: "+installed});
    return c;
}
inline bool checksAllowInstall(const std::vector<Check>& c){return !c.empty()&&c.front().state==CheckState::Ok;}

// ---------- Uninstall ----------
// Everything the add-on puts in the game folder; GTA, Script Hook V and the ASI loader stay.
inline const std::vector<std::wstring>& addonRootFiles(){
    static const std::vector<std::wstring> f={L"GTAHandVR.asi",L"GTA5VRRenderer.asi",L"GTAHandVR.ini",L"GTAHandVR-launcher.ini",
        L"GTAHandVR.log",L"GTAHandVR.previous.log",L"GTA5VRRenderer.log",L"GTA5VRRenderer.previous.log",L"GTA5 VR.exe"};
    return f;
}
struct UninstallResult { std::vector<std::wstring> removed,failed;bool selfScheduled=false; };
// A running program cannot delete its own .exe: a hidden cmd waits for it to close, then deletes it.
inline bool scheduleDelete(const fs::path& file){
    std::wstring command=L"cmd.exe /c ping 127.0.0.1 -n 3 > nul & del /f /q \""+file.wstring()+L"\"";
    std::vector<wchar_t> buffer(command.begin(),command.end());buffer.push_back(0);
    STARTUPINFOW si{};si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;PROCESS_INFORMATION pi{};
    if(!CreateProcessW(nullptr,buffer.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,nullptr,&si,&pi))return false;
    CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return true;
}
inline UninstallResult uninstallAddon(const fs::path& root,bool removeBackups){
    if(!app::exists(root/L"GTA5.exe"))throw std::runtime_error("This is not a GTA V folder; nothing was removed.");
    if(processRunning(L"GTA5.exe")||processRunning(L"GTAHandVR-Bridge.exe"))throw std::runtime_error("Close GTA V first; nothing was removed.");
    UninstallResult r;std::error_code e;fs::path self;try{self=modulePath();}catch(...){}
    for(const auto& name:addonRootFiles()){
        fs::path p=root/name;if(!app::exists(p))continue;
        if(!self.empty()&&fs::equivalent(p,self,e)){r.selfScheduled=scheduleDelete(p);if(r.selfScheduled)r.removed.push_back(name+L" (when this window closes)");else r.failed.push_back(name);continue;}
        e.clear();fs::remove(p,e);(e?r.failed:r.removed).push_back(name);
    }
    for(const wchar_t* folder:{L"GTAHandVR",L"GTA5VR-Backups"}){
        if(std::wstring(folder)==L"GTA5VR-Backups"&&!removeBackups)continue;
        fs::path d=root/folder;if(!fs::is_directory(d,e))continue;
        e.clear();fs::remove_all(d,e);(e?r.failed:r.removed).push_back(std::wstring(folder)+L"\\");
    }
    try{fs::path diag=localFolder();if(fs::is_directory(diag,e)){e.clear();fs::remove_all(diag,e);if(!e)r.removed.push_back(L"%LOCALAPPDATA%\\GTA5VR\\");}}catch(...){}
    return r;
}
inline std::wstring describe(const UninstallResult& r){
    std::wstring t=std::to_wstring(r.removed.size())+L" item(s) removed.";
    if(!r.failed.empty()){t+=L" Could not remove:";for(auto& f:r.failed)t+=L" "+f;t+=L" (close the programs that use them and try again).";}
    return t;
}
}
