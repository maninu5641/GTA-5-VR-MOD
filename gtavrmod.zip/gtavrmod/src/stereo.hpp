#pragma once
#include "core.hpp"
#include <stdexcept>

namespace handvr {
inline bool validBasis(const Basis& b) {
    return finite(b.right)&&finite(b.forward)&&finite(b.up)
        &&std::abs(length(b.right)-1)<.03f&&std::abs(length(b.forward)-1)<.03f
        &&std::abs(length(b.up)-1)<.03f&&std::abs(dot(b.right,b.forward))<.03f
        &&dot(cross(b.right,b.forward),b.up)>.97f;
}
inline Vec3 cameraAngles(const Basis& b) {
    float pitch=std::asin(std::clamp(b.forward.z,-1.0f,1.0f));
    float yaw=std::atan2(-b.forward.x,b.forward.y);
    // At the poles choose zero roll; heading absorbs the remaining rotation.
    if(std::abs(std::cos(pitch))<.00001f)
        return {pitch*180/pi,0,std::atan2(b.right.y,b.right.x)*180/pi};
    Vec3 right{std::cos(yaw),std::sin(yaw),0};
    Vec3 up=cross(right,b.forward);
    float roll=std::atan2(-dot(b.right,up),dot(b.right,right));
    return {pitch*180/pi,roll*180/pi,yaw*180/pi};
}
inline Pose yawPose(const Pose& pose) {
    Vec3 forward=-pose.col(2);forward.y=0;forward=unit(forward,{0,0,-1});
    Vec3 right=cross(forward,{0,1,0});
    Pose result{};Vec3 columns[]={right,{0,1,0},-forward,pose.pos()};
    for(int c=0;c<4;++c){result.m[0][c]=columns[c].x;result.m[1][c]=columns[c].y;result.m[2][c]=columns[c].z;}
    return result;
}
struct WorldCamera { Vec3 position{};Basis basis{}; };
inline WorldCamera trackedCamera(const Pose& head,const Pose& origin,Vec3 anchor,const Basis& base,float scale,float limit) {
    auto vector=[&](Vec3 v){return headLocalToWorld(origin.inverseRotate(v),base);};
    Vec3 offset=vector(head.pos()-origin.pos())*scale;
    float distance=length(offset);if(distance>limit&&distance>0)offset=offset*(limit/distance);
    return {anchor+offset,{vector(head.col(0)),vector(-head.col(2)),vector(head.col(1))}};
}
// 0.10.0: the head's offset from the recentred origin in the world (unclamped), and a world
// vector back in tracking space (to move the origin with the character when it follows the head).
inline Vec3 trackedOffset(const Pose& head,const Pose& origin,const Basis& base,float scale){
    return headLocalToWorld(origin.inverseRotate(head.pos()-origin.pos()),base)*scale;
}
inline Vec3 worldToTracking(Vec3 world,const Pose& origin,const Basis& base,float scale){
    Vec3 local{dot(world,base.right),dot(world,base.up),-dot(world,base.forward)};
    Vec3 r{origin.m[0][0]*local.x+origin.m[0][1]*local.y+origin.m[0][2]*local.z,
           origin.m[1][0]*local.x+origin.m[1][1]*local.y+origin.m[1][2]*local.z,
           origin.m[2][0]*local.x+origin.m[2][1]*local.y+origin.m[2][2]*local.z};
    return scale>0?r*(1/scale):Vec3{};
}
inline WorldCamera eyeCamera(const WorldCamera& head,const Pose& eyeToHead,float scale) {
    return {head.position+headLocalToWorld(eyeToHead.pos(),head.basis)*scale,
        {headLocalToWorld(eyeToHead.col(0),head.basis),headLocalToWorld(-eyeToHead.col(2),head.basis),headLocalToWorld(eyeToHead.col(1),head.basis)}};
}
struct EyeTangents { float left,right,top,bottom; };
struct Crop { float uMin,vMin,uMax,vMax; };
struct StereoProjection { float verticalFov=0;Crop crop[2]{}; };
// Cover each asymmetric headset frustum with GTA's symmetric camera, then crop.
// The SET_CAM_FOV vertical-FOV assumption needs verification in the target game.
inline StereoProjection projection(const EyeTangents (&eyes)[2],float aspect) {
    if(!std::isfinite(aspect)||aspect<.25f||aspect>5)throw std::runtime_error("Unsupported backbuffer aspect ratio.");
    float vertical=0;
    for(const auto& e:eyes){
        if(!std::isfinite(e.left)||!std::isfinite(e.right)||!std::isfinite(e.top)||!std::isfinite(e.bottom)
            ||e.left>=e.right||e.top>=e.bottom||e.left>=0||e.right<=0||e.top>=0||e.bottom<=0)
            throw std::runtime_error("Invalid headset projection tangents.");
        vertical=std::max({vertical,-e.top,e.bottom,-e.left/aspect,e.right/aspect});
    }
    StereoProjection result;result.verticalFov=2*std::atan(vertical)*180/pi;
    if(result.verticalFov<1||result.verticalFov>130)throw std::runtime_error("Headset projection exceeds GTA's camera FOV range.");
    float horizontal=vertical*aspect;
    for(int i=0;i<2;++i){const auto& e=eyes[i];result.crop[i]={.5f+e.left/(2*horizontal),.5f+e.top/(2*vertical),.5f+e.right/(2*horizontal),.5f+e.bottom/(2*vertical)};}
    return result;
}
// Advance only after Present consumes a planned game-camera frame.
class EyeSequence {
    unsigned nextEye=0;bool valid[2]{};
public:
    unsigned next() const{return nextEye;}
    bool ready() const{return valid[0]&&valid[1];}
    void consumed(){valid[nextEye]=true;nextEye^=1;}
    void reset(){nextEye=0;valid[0]=valid[1]=false;}
};
}
