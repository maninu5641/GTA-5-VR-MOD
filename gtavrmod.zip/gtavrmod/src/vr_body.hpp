#pragma once
// 0.6.0: character body, vehicles and frame-rate-aware stereo. Plain logic,
// tested in tests/vr_body_test.cpp.
#include "core.hpp"
#include <array>
#include <cstdint>

namespace handvr {

// ---------- Eye position from the character's head bone ----------
// GTA world axes (Z up). The head bone (SKEL_Head) sits at the base of the skull;
// the eyes are a little in front of and above it. Works on foot, in vehicles
// (where GTA's camera may be third person) and for animals (Chop).
inline Vec3 eyeFromHeadBone(Vec3 headBone,float headingDegrees,bool animal){
    float h=rad(headingDegrees);Vec3 forward{-std::sin(h),std::cos(h),0};
    return headBone+forward*(animal?.13f:.09f)+Vec3{0,0,animal?.04f:.07f};
}
// Facial eye bones (FB_L_Eye_000 25260, FB_R_Eye_000 27474) on rigs that have them (the main
// characters): their midpoint is the real eye position, 1 cm forward for the pupil.
inline bool eyeBonesUsable(Vec3 left,Vec3 right,Vec3 headBone){
    if(!finite(left)||!finite(right)||!finite(headBone))return false;
    float apart=length(left-right),fromHead=length((left+right)*.5f-headBone);
    return apart>.03f&&apart<.12f&&fromHead>.02f&&fromHead<.25f;
}
inline Vec3 eyeFromEyeBones(Vec3 left,Vec3 right,float headingDegrees){
    float h=rad(headingDegrees);return (left+right)*.5f+Vec3{-std::sin(h),std::cos(h),0}*.01f;
}
// GET_PED_BONE_COORDS returns the entity origin or zeros for a missing bone.
inline bool headBoneUsable(Vec3 headBone,Vec3 root){
    return finite(headBone)&&length(headBone)>1&&length(headBone-root)>.05f&&length(headBone-root)<1.6f;
}

// ---------- Tracking space -> GTA world ----------
// headTracking: SteamVR head pose; worldHead/worldBasis: the VR camera in GTA's world.
inline Vec3 trackingToWorld(Vec3 tracking,const Pose& headTracking,Vec3 worldHead,const Basis& worldBasis,float scale){
    return worldHead+trackingVectorToWorld(tracking-headTracking.pos(),headTracking,worldBasis)*scale;
}

// ---------- Stereo mode chosen by frame rate ----------
// Alternating eyes halve each eye's frame rate: at 36 game fps each eye gets 18.
// Auto uses mono (both eyes every frame) below `low` fps and returns to 3D above `high`.
// 0.7.0: 30 / 40 (was 50 / 62): mono looks flat and oversized, so it is a last resort.
class StereoAuto {
    double fps=0,low=30,high=40;bool mono=false,primed=false;std::uint64_t belowSince=0,aboveSince=0;
public:
    StereoAuto()=default;
    StereoAuto(double lowFps,double highFps):low(lowFps),high(std::max(highFps,lowFps+1)){}
    double framesPerSecond()const{return fps;}
    bool monoSelected()const{return mono;}
    double lowFps()const{return low;}
    double highFps()const{return high;}
    // 0.16.1: the thresholds for the headset's refresh rate. 3D gives each eye half of the game's frames, so a faster
    // display needs more of them (the developer's 120 Hz headset with GTA at 60 fps: 30 per eye - juddery, and each
    // eye from another moment, so the picture looked distorted).
    // 0.16.2 (the developer at 72 Hz, "very juddery": 3D at 45 and 72 game fps, 22 and 36 images per eye): 3D only when
    // each eye gets 40+ images a second and GTA holds about the headset's rate (90 % of it). 72 Hz: never (36 per eye at
    // most) - Mono, every frame in both eyes; 90 Hz: 3D above 81 game fps, mono below 72; 120 Hz: 108 / 96.
    static std::pair<double,double> rangeFor(double hz){
        if(!(hz>=20&&hz<=1000))hz=90;double high=std::max(80.0,hz*.9);return {std::min(high-6,std::max(60.0,hz*.8)),high};}
    // 3D out of reach at this refresh rate: the game cannot run faster than the headset (SteamVR paces it).
    static bool monoOnly(double hz){return std::isfinite(hz)&&hz>=20&&hz<=1000&&hz*1.02<rangeFor(hz).second;}
    void setRange(double lowFps,double highFps){if(!(lowFps>0)||!std::isfinite(lowFps))return;low=lowFps;high=std::max(highFps,lowFps+1);}
    // 0.16.2: Auto starts in mono (smooth) and goes to 3D once GTA has held the 3D rate for 5 s.
    void startMono(bool on){mono=on;belowSince=aboveSince=0;}
    void reset(){fps=0;primed=false;belowSince=aboveSince=0;}
    // Feed the number of game frames captured over `seconds`; returns true when the mode changes.
    bool update(unsigned frames,double seconds,std::uint64_t nowMs){
        if(!(seconds>.2)||seconds>5)return false;
        double sample=frames/seconds;fps=primed?fps*.6+sample*.4:sample;primed=true;
        bool previous=mono;
        if(fps<low){aboveSince=0;if(!belowSince)belowSince=nowMs;if(!mono&&nowMs-belowSince>=3000)mono=true;}
        else if(fps>high){belowSince=0;if(!aboveSince)aboveSince=nowMs;if(mono&&nowMs-aboveSince>=5000)mono=false;}
        else belowSince=aboveSince=0;
        return mono!=previous;
    }
};

// ---------- Short tap vs hold (Y: tap = enter / exit vehicle, hold = motion on/off) ----------
class TapHold {
    bool down=false,holdFired=false;std::uint64_t since=0;
public:
    enum Event { None,Tap,Hold };
    static constexpr std::uint64_t HoldMs=800;
    void reset(){down=false;holdFired=false;since=0;}
    Event update(bool pressed,std::uint64_t nowMs){
        if(pressed&&!down){down=true;holdFired=false;since=nowMs;return None;}
        if(pressed&&down&&!holdFired&&nowMs-since>=HoldMs){holdFired=true;return Hold;}
        if(!pressed&&down){down=false;bool tap=!holdFired;holdFired=false;return tap?Tap:None;}
        return None;
    }
};

// ---------- Driving with VR controllers ----------
enum class VehicleKind { Car,Bike,Bicycle,Boat,Heli,Plane,Other };
// GET_VEHICLE_CLASS: 8 motorcycles, 13 cycles, 14 boats, 15 helicopters, 16 planes, 21 trains.
inline VehicleKind vehicleKind(int vehicleClass){
    switch(vehicleClass){case 8:return VehicleKind::Bike;case 13:return VehicleKind::Bicycle;case 14:return VehicleKind::Boat;
        case 15:return VehicleKind::Heli;case 16:return VehicleKind::Plane;case 21:return VehicleKind::Other;default:return VehicleKind::Car;}
}
struct DriveInput { float throttle=0,brake=0,stickX=0,stickY=0,rightX=0,rightY=0;bool handbrake=false; };
struct ControlValue { int control=0;float value=0; };
struct DriveControls { std::array<ControlValue,8> items{};int count=0;void add(int c,float v){if(count<8)items[count++]={c,v};} };
inline float driveDeadzone(float v,float zone=.15f){if(!std::isfinite(v))return 0;float a=std::abs(v);if(a<zone)return 0;return std::copysign(std::min(1.0f,(a-zone)/(1-zone)),v);}
// GTA control IDs: 59 VEH_MOVE_LR, 60 VEH_MOVE_UD, 71 VEH_ACCELERATE, 72 VEH_BRAKE, 76 VEH_HANDBRAKE,
// 87/88 VEH_FLY_THROTTLE_UP/DOWN, 89/90 VEH_FLY_YAW_LEFT/RIGHT, 107 VEH_FLY_ROLL_LR, 108 VEH_FLY_PITCH_UD.
// Right trigger = throttle, left trigger = brake / reverse, left stick = steer, A = handbrake.
inline DriveControls driveControls(VehicleKind kind,const DriveInput& in){
    DriveControls c;float throttle=std::clamp(std::isfinite(in.throttle)?in.throttle:0.0f,0.0f,1.0f),brake=std::clamp(std::isfinite(in.brake)?in.brake:0.0f,0.0f,1.0f);
    float steer=driveDeadzone(in.stickX),lean=driveDeadzone(in.stickY),yaw=driveDeadzone(in.rightX);
    switch(kind){
        case VehicleKind::Heli:case VehicleKind::Plane:
            if(throttle>.05f)c.add(87,throttle);if(brake>.05f)c.add(88,brake);
            if(steer!=0)c.add(107,steer);if(lean!=0)c.add(108,-lean);   // stick forward = nose down
            if(yaw<0)c.add(89,-yaw);else if(yaw>0)c.add(90,yaw);
            break;
        case VehicleKind::Other:break;
        default:
            if(throttle>.05f)c.add(71,throttle);if(brake>.05f)c.add(72,brake);
            if(steer!=0)c.add(59,steer);
            if((kind==VehicleKind::Bike||kind==VehicleKind::Bicycle)&&lean!=0)c.add(60,-lean);   // lean forward / back
            if(in.handbrake&&kind!=VehicleKind::Boat)c.add(76,1);
            break;
    }
    return c;
}
}
