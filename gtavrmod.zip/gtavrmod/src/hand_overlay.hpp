#pragma once
// Draws hands/arms (capsules from hands.hpp) into an eye texture on the VR
// submit (bridge) device. It owns every piece of pipeline state it binds, on a
// device GTA never uses, so GTA's rendering state is untouched.
// Shaders are compiled at runtime with d3dcompiler_47.dll (part of Windows 8.1+);
// the HLSL text is validated at build time with DXC (see build.py --dxc).
#include "hands.hpp"
#include <d3d11.h>
#include <string>
#include <vector>

namespace handvr {
inline const char* handShaderSource(){return R"HLSL(
cbuffer Frame : register(b0) {
    row_major float4x4 viewProj;
    float4 light;    // xyz: direction towards the light (tracking space), w: ambient
    float4 params;   // x: 1 = encode sRGB in shader (UNORM target), y: brightness
};
struct VSIn {
    float3 n : POSITION;     // unit-sphere direction in the capsule frame (+Y = axis)
    float end : TEXCOORD0;   // 0 = end A, 1 = end B
    float4 a : TEXCOORD1;    // xyz end A, w radius A
    float4 b : TEXCOORD2;    // xyz end B, w radius B
    float4 color : COLOR0;   // linear RGB
};
struct VSOut {
    float4 position : SV_Position;
    float3 normal : NORMAL;
    float4 color : COLOR0;
};
VSOut VSMain(VSIn i) {
    float3 axis = i.b.xyz - i.a.xyz;
    float len = length(axis);
    float3 w = len > 1e-5 ? axis / len : float3(0, 1, 0);
    float3 t = abs(w.y) < 0.99 ? float3(0, 1, 0) : float3(1, 0, 0);
    float3 u = normalize(cross(t, w));
    float3 v = cross(w, u);
    float3 dir = u * i.n.x + w * i.n.y + v * i.n.z;
    float3 base = i.end > 0.5 ? i.b.xyz : i.a.xyz;
    float radius = i.end > 0.5 ? i.b.w : i.a.w;
    VSOut o;
    o.position = mul(viewProj, float4(base + dir * radius, 1));
    o.normal = dir;
    o.color = i.color;
    return o;
}
float4 PSMain(VSOut i) : SV_Target {
    float3 n = normalize(i.normal);
    float diffuse = saturate(dot(n, normalize(light.xyz)));
    float fill = saturate(dot(n, float3(0, -0.3, 0.95))) * 0.25;
    float3 color = i.color.rgb * (light.w + diffuse * 0.75 + fill) * params.y;
    color = saturate(color);
    if (params.x > 0.5) color = pow(color, 1.0 / 2.2);
    return float4(color, 1);
}
)HLSL";}

class HandOverlay {
    template<class T> struct Ref { T* p=nullptr;~Ref(){reset();}void reset(){if(p)p->Release();p=nullptr;}T** put(){reset();return &p;} };
    Ref<ID3D11VertexShader> vs;Ref<ID3D11PixelShader> ps;Ref<ID3D11InputLayout> layout;
    Ref<ID3D11Buffer> mesh,index,instances,constants;Ref<ID3D11RasterizerState> raster;Ref<ID3D11DepthStencilState> depthState;
    Ref<ID3D11Texture2D> depth;Ref<ID3D11DepthStencilView> depthView;Ref<ID3D11RenderTargetView> targets[2];ID3D11Texture2D* targetTextures[2]{};
    unsigned indexCount=0,width=0,height=0;bool encodeSrgb=true;
    static constexpr unsigned MaxInstances=96;
public:
    bool ready=false;std::string error;
    using CompileFn=HRESULT(WINAPI*)(LPCVOID,SIZE_T,LPCSTR,const D3D_SHADER_MACRO*,ID3DInclude*,LPCSTR,LPCSTR,UINT,UINT,ID3DBlob**,ID3DBlob**);
    // Returns false (with `error`) instead of throwing: hands are optional.
    bool init(ID3D11Device* device){
        ready=false;error.clear();
        HMODULE compiler=LoadLibraryW(L"d3dcompiler_47.dll");
        auto compile=compiler?reinterpret_cast<CompileFn>(GetProcAddress(compiler,"D3DCompile")):nullptr;
        if(!compile){error="d3dcompiler_47.dll / D3DCompile is unavailable";return false;}
        const char* source=handShaderSource();std::size_t size=std::strlen(source);
        ID3DBlob *vsCode=nullptr,*psCode=nullptr,*messages=nullptr;
        auto fail=[&](const std::string& what,HRESULT hr){error=what+" (HRESULT "+std::to_string(static_cast<unsigned long>(hr))+")";
            if(messages){error+=": "+std::string(static_cast<const char*>(messages->GetBufferPointer()),messages->GetBufferSize());messages->Release();messages=nullptr;}
            if(vsCode)vsCode->Release();if(psCode)psCode->Release();return false;};
        HRESULT hr=compile(source,size,"gta5vr_hands.hlsl",nullptr,nullptr,"VSMain","vs_5_0",0,0,&vsCode,&messages);
        if(FAILED(hr))return fail("Compile hand vertex shader",hr);if(messages){messages->Release();messages=nullptr;}
        hr=compile(source,size,"gta5vr_hands.hlsl",nullptr,nullptr,"PSMain","ps_5_0",0,0,&psCode,&messages);
        if(FAILED(hr))return fail("Compile hand pixel shader",hr);if(messages){messages->Release();messages=nullptr;}
        hr=device->CreateVertexShader(vsCode->GetBufferPointer(),vsCode->GetBufferSize(),nullptr,vs.put());
        if(SUCCEEDED(hr))hr=device->CreatePixelShader(psCode->GetBufferPointer(),psCode->GetBufferSize(),nullptr,ps.put());
        D3D11_INPUT_ELEMENT_DESC elements[]={
            {"POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},
            {"TEXCOORD",0,DXGI_FORMAT_R32_FLOAT,0,12,D3D11_INPUT_PER_VERTEX_DATA,0},
            {"TEXCOORD",1,DXGI_FORMAT_R32G32B32A32_FLOAT,1,0,D3D11_INPUT_PER_INSTANCE_DATA,1},
            {"TEXCOORD",2,DXGI_FORMAT_R32G32B32A32_FLOAT,1,16,D3D11_INPUT_PER_INSTANCE_DATA,1},
            {"COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,1,32,D3D11_INPUT_PER_INSTANCE_DATA,1}};
        if(SUCCEEDED(hr))hr=device->CreateInputLayout(elements,5,vsCode->GetBufferPointer(),vsCode->GetBufferSize(),layout.put());
        vsCode->Release();psCode->Release();
        if(FAILED(hr)){error="Create hand shaders / input layout (HRESULT "+std::to_string(static_cast<unsigned long>(hr))+")";return false;}
        std::vector<CapsuleVertex> vertices;std::vector<std::uint16_t> indices;capsuleMesh(vertices,indices);indexCount=unsigned(indices.size());
        D3D11_BUFFER_DESC d{};d.Usage=D3D11_USAGE_IMMUTABLE;d.BindFlags=D3D11_BIND_VERTEX_BUFFER;d.ByteWidth=UINT(vertices.size()*sizeof(CapsuleVertex));
        D3D11_SUBRESOURCE_DATA init{vertices.data(),0,0};hr=device->CreateBuffer(&d,&init,mesh.put());
        d.BindFlags=D3D11_BIND_INDEX_BUFFER;d.ByteWidth=UINT(indices.size()*sizeof(std::uint16_t));init.pSysMem=indices.data();
        if(SUCCEEDED(hr))hr=device->CreateBuffer(&d,&init,index.put());
        d={};d.Usage=D3D11_USAGE_DYNAMIC;d.CPUAccessFlags=D3D11_CPU_ACCESS_WRITE;d.BindFlags=D3D11_BIND_VERTEX_BUFFER;d.ByteWidth=MaxInstances*sizeof(CapsuleInstance);
        if(SUCCEEDED(hr))hr=device->CreateBuffer(&d,nullptr,instances.put());
        d.BindFlags=D3D11_BIND_CONSTANT_BUFFER;d.ByteWidth=96;
        if(SUCCEEDED(hr))hr=device->CreateBuffer(&d,nullptr,constants.put());
        D3D11_RASTERIZER_DESC r{};r.FillMode=D3D11_FILL_SOLID;r.CullMode=D3D11_CULL_NONE;r.DepthClipEnable=TRUE;
        if(SUCCEEDED(hr))hr=device->CreateRasterizerState(&r,raster.put());
        D3D11_DEPTH_STENCIL_DESC ds{};ds.DepthEnable=TRUE;ds.DepthWriteMask=D3D11_DEPTH_WRITE_MASK_ALL;ds.DepthFunc=D3D11_COMPARISON_LESS;
        if(SUCCEEDED(hr))hr=device->CreateDepthStencilState(&ds,depthState.put());
        if(FAILED(hr)){error="Create hand geometry / states (HRESULT "+std::to_string(static_cast<unsigned long>(hr))+")";return false;}
        ready=true;return true;
    }
    void detach(){targets[0].reset();targets[1].reset();targetTextures[0]=targetTextures[1]=nullptr;depthView.reset();depth.reset();width=height=0;}
    // Eye textures are (re)created with the backbuffer; bind render targets to them.
    bool attach(ID3D11Device* device,ID3D11Texture2D* left,ID3D11Texture2D* right){
        targets[0].reset();targets[1].reset();targetTextures[0]=targetTextures[1]=nullptr;depthView.reset();depth.reset();width=height=0;
        if(!ready)return false;
        D3D11_TEXTURE2D_DESC desc{};left->GetDesc(&desc);
        encodeSrgb=desc.Format!=DXGI_FORMAT_R8G8B8A8_UNORM_SRGB&&desc.Format!=DXGI_FORMAT_B8G8R8A8_UNORM_SRGB;
        ID3D11Texture2D* eyes[2]={left,right};
        for(int i=0;i<2;++i){if(FAILED(device->CreateRenderTargetView(eyes[i],nullptr,targets[i].put()))){error="Create hand render target";ready=false;return false;}targetTextures[i]=eyes[i];}
        D3D11_TEXTURE2D_DESC dd{};dd.Width=desc.Width;dd.Height=desc.Height;dd.MipLevels=1;dd.ArraySize=1;dd.Format=DXGI_FORMAT_D32_FLOAT;dd.SampleDesc={1,0};
        dd.Usage=D3D11_USAGE_DEFAULT;dd.BindFlags=D3D11_BIND_DEPTH_STENCIL;
        if(FAILED(device->CreateTexture2D(&dd,nullptr,depth.put()))||FAILED(device->CreateDepthStencilView(depth.p,nullptr,depthView.put()))){error="Create hand depth buffer";ready=false;return false;}
        width=desc.Width;height=desc.Height;return true;
    }
    // Draws `capsules` into eye `eyeIndex`. viewProj is row-major (column vectors).
    bool draw(ID3D11DeviceContext* context,unsigned eyeIndex,const Mat4& viewProj,const std::vector<Capsule>& capsules,float brightness){
        if(!ready||!width||eyeIndex>1||!targets[eyeIndex].p||capsules.empty())return false;
        unsigned count=unsigned(std::min<std::size_t>(capsules.size(),MaxInstances));
        D3D11_MAPPED_SUBRESOURCE mapped{};
        if(FAILED(context->Map(instances.p,0,D3D11_MAP_WRITE_DISCARD,0,&mapped)))return false;
        auto* out=static_cast<CapsuleInstance*>(mapped.pData);
        for(unsigned i=0;i<count;++i){auto& c=capsules[i];out[i]={{c.a.x,c.a.y,c.a.z,c.ra},{c.b.x,c.b.y,c.b.z,c.rb},{c.color.x,c.color.y,c.color.z,1}};}
        context->Unmap(instances.p,0);
        if(FAILED(context->Map(constants.p,0,D3D11_MAP_WRITE_DISCARD,0,&mapped)))return false;
        float* cb=static_cast<float*>(mapped.pData);std::memcpy(cb,viewProj.m,64);
        cb[16]=.35f;cb[17]=.85f;cb[18]=.40f;cb[19]=.38f;            // light from above / in front, ambient
        cb[20]=encodeSrgb?1.0f:0.0f;cb[21]=brightness;cb[22]=cb[23]=0;
        context->Unmap(constants.p,0);
        context->ClearDepthStencilView(depthView.p,D3D11_CLEAR_DEPTH,1,0);
        ID3D11RenderTargetView* rtv=targets[eyeIndex].p;context->OMSetRenderTargets(1,&rtv,depthView.p);
        context->OMSetDepthStencilState(depthState.p,0);context->OMSetBlendState(nullptr,nullptr,0xffffffff);
        D3D11_VIEWPORT viewport{0,0,float(width),float(height),0,1};context->RSSetViewports(1,&viewport);context->RSSetState(raster.p);
        ID3D11Buffer* buffers[2]={mesh.p,instances.p};UINT strides[2]={sizeof(CapsuleVertex),sizeof(CapsuleInstance)},offsets[2]={0,0};
        context->IASetVertexBuffers(0,2,buffers,strides,offsets);context->IASetIndexBuffer(index.p,DXGI_FORMAT_R16_UINT,0);
        context->IASetInputLayout(layout.p);context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        context->VSSetShader(vs.p,nullptr,0);context->VSSetConstantBuffers(0,1,&constants.p);
        context->PSSetShader(ps.p,nullptr,0);context->PSSetConstantBuffers(0,1,&constants.p);
        context->DrawIndexedInstanced(indexCount,count,0,0,0);
        context->OMSetRenderTargets(0,nullptr,nullptr);   // the eye texture is copied/submitted next
        return true;
    }
};
}
