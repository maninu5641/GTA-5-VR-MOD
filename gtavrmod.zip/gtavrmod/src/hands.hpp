#pragma once
// VR hands and arms (0.4.0): geometry built from SteamVR's hand skeleton.
//
// SteamVR's skeletal input gives 31 bone transforms per hand. Only bone
// POSITIONS are used here (model space, metres, relative to the skeleton root
// pose), so no bone-orientation conventions are involved. Each finger segment,
// the palm and the arm become tapered capsules that the renderer draws over the
// captured eye image. Arms come from a two-bone IK between an estimated
// shoulder and the tracked wrist, with the elbow swivel taken from the hand.
//
// Plain logic only (no Windows/D3D/GTA); unit tested in tests/hands_test.cpp.
#include "core.hpp"
#include <array>
#include <cstdint>
#include <vector>

namespace handvr {

// SteamVR hand skeleton (openvr wiki: Hand-Skeleton).
enum HandBone : unsigned {
    BoneRoot=0,BoneWrist=1,
    BoneThumb0=2,BoneThumb1=3,BoneThumb2=4,BoneThumb3=5,
    BoneIndex0=6,BoneIndex1=7,BoneIndex2=8,BoneIndex3=9,BoneIndex4=10,
    BoneMiddle0=11,BoneMiddle1=12,BoneMiddle2=13,BoneMiddle3=14,BoneMiddle4=15,
    BoneRing0=16,BoneRing1=17,BoneRing2=18,BoneRing3=19,BoneRing4=20,
    BonePinky0=21,BonePinky1=22,BonePinky2=23,BonePinky3=24,BonePinky4=25,
    HandBoneCount=31
};
inline unsigned fingerBase(unsigned finger){return 6+5*(finger-1);}   // finger 1..4 = index..pinky

struct HandSkeleton {
    bool valid=false;
    Pose root{};                               // skeleton root in standing tracking space
    std::array<Vec3,HandBoneCount> model{};    // bone positions in root space
    float curl[5]{};                           // thumb..pinky, 0 straight .. 1 curled
    int trackingLevel=-1;                      // 0 estimated, 1 partial, 2 full (EVRSkeletalTrackingLevel)
    Vec3 world(unsigned bone)const{return root.pos()+root.col(0)*model[bone].x+root.col(1)*model[bone].y+root.col(2)*model[bone].z;}
};
inline bool plausible(const HandSkeleton& h){
    if(!h.valid||!validPose(h.root))return false;
    for(auto& p:h.model)if(!finite(p)||length(p)>.5f)return false;
    float palm=length(h.model[BoneMiddle1]-h.model[BoneWrist]);
    return palm>.03f&&palm<.2f;
}

struct Capsule { Vec3 a{};float ra=0;Vec3 b{};float rb=0;Vec3 color{}; };   // colour in linear RGB

struct ArmSettings {
    float upperArm=.30f,forearm=.27f;          // metres; multiplied by `lengthScale`
    float lengthScale=1;
    float shoulderWidth=.36f,shoulderDrop=.24f,shoulderBack=.07f;
    bool arms=true;
};
struct ArmJoints { Vec3 shoulder{},elbow{},wrist{}; };

// Flattened (yaw-only) head axes in OpenVR space: +Y up, -Z forward.
inline void headYawAxes(const Pose& head,Vec3& forward,Vec3& right){
    forward=-head.col(2);forward.y=0;forward=unit(forward,{0,0,-1});
    right=cross(forward,{0,1,0});   // forward x up = right (right-handed, Y up)
}
// side: -1 left hand, +1 right hand.
inline Vec3 shoulderPosition(const Pose& head,float side,const ArmSettings& s){
    Vec3 forward,right;headYawAxes(head,forward,right);
    return head.pos()-Vec3{0,1,0}*s.shoulderDrop-forward*s.shoulderBack+right*(side*s.shoulderWidth*.5f);
}
// Two-bone IK. The elbow lies on the circle allowed by the bone lengths; its
// swivel points towards where the forearm would be if it continued the hand's
// own direction, nudged down and outwards like a relaxed arm.
inline ArmJoints solveArm(const Pose& head,Vec3 wrist,Vec3 handForward,float side,const ArmSettings& s){
    ArmJoints j;j.shoulder=shoulderPosition(head,side,s);j.wrist=wrist;
    float a=s.upperArm*s.lengthScale,b=s.forearm*s.lengthScale;
    Vec3 toWrist=wrist-j.shoulder;float d=length(toWrist);
    Vec3 dir=unit(toWrist,{0,-1,0});
    float reach=a+b-1e-3f;
    if(d>=reach){j.elbow=j.shoulder+dir*(a*reach/(a+b));return j;}   // fully stretched
    d=std::max(d,std::abs(a-b)+1e-3f);
    float x=(a*a-b*b+d*d)/(2*d);float r=std::sqrt(std::max(0.0f,a*a-x*x));
    Vec3 center=j.shoulder+dir*x;
    Vec3 forward,right;headYawAxes(head,forward,right);
    Vec3 hint=wrist-unit(handForward,dir)*b+Vec3{0,-1,0}*.12f+right*(side*.08f);
    Vec3 pole=hint-center;pole=pole-dir*dot(pole,dir);
    if(length(pole)<1e-4f){pole=Vec3{0,-1,0}-dir*dot(Vec3{0,-1,0},dir);if(length(pole)<1e-4f)pole=right*side;}
    j.elbow=center+unit(pole)*r;return j;
}

struct HandColors { Vec3 skin{},sleeve{},nail{}; };
inline float srgbToLinear(float c){c=std::clamp(c,0.0f,1.0f);return c<=.04045f?c/12.92f:std::pow((c+.055f)/1.055f,2.4f);}
inline Vec3 srgb(int r,int g,int b){return {srgbToLinear(r/255.0f),srgbToLinear(g/255.0f),srgbToLinear(b/255.0f)};}
// Story-mode protagonists by model hash; others get a neutral tone. Overridable in the INI.
inline Vec3 defaultSkin(std::uint32_t model){
    switch(model){
        case 0x0D7114C9u:return srgb(222,182,152);   // player_zero (Michael)
        case 0x9B22DBAFu:return srgb(124,84,62);     // player_one (Franklin)
        case 0x9B810FA2u:return srgb(214,168,138);   // player_two (Trevor)
        default:return srgb(200,160,130);
    }
}

// All capsules for one hand (+ arm). Radii follow an adult hand; `scale` = 1.
inline void handCapsules(const HandSkeleton& h,const Pose& head,float side,const ArmSettings& arm,const HandColors& colors,std::vector<Capsule>& out){
    if(!plausible(h))return;
    auto w=[&](unsigned bone){return h.world(bone);};
    auto add=[&](Vec3 a,float ra,Vec3 b,float rb,Vec3 c){out.push_back({a,ra,b,rb,c});};
    Vec3 skin=colors.skin;
    // Thumb: metacarpal, proximal, distal.
    add(w(BoneThumb0),.0145f,w(BoneThumb1),.0125f,skin);
    add(w(BoneThumb1),.0125f,w(BoneThumb2),.0110f,skin);
    add(w(BoneThumb2),.0110f,w(BoneThumb3),.0095f,skin);
    // Fingers: proximal, intermediate, distal (metacarpals are inside the palm).
    const float width[5]={0,1.0f,1.03f,.96f,.84f};
    for(unsigned f=1;f<=4;++f){unsigned b=fingerBase(f);float k=width[f];
        add(w(b+1),.0105f*k,w(b+2),.0098f*k,skin);
        add(w(b+2),.0098f*k,w(b+3),.0090f*k,skin);
        add(w(b+3),.0090f*k,w(b+4),.0080f*k,skin);
    }
    // Palm: wrist to each knuckle, across the knuckles, and a thick centre.
    Vec3 wrist=w(BoneWrist);
    for(unsigned f=1;f<=4;++f)add(wrist,.019f,w(fingerBase(f)+1),.0125f,skin);
    for(unsigned f=1;f<4;++f)add(w(fingerBase(f)+1),.0125f,w(fingerBase(f+1)+1),.0125f,skin);
    Vec3 knuckles=(w(BoneIndex1)+w(BonePinky1))*.5f;
    add(wrist,.022f,wrist+(knuckles-wrist)*.62f,.021f,skin);
    add(wrist,.019f,w(BoneThumb1),.0145f,skin);   // thenar (thumb base) pad
    if(!arm.arms)return;
    Vec3 handForward=w(BoneMiddle1)-wrist;
    auto joints=solveArm(head,wrist,handForward,side,arm);
    add(joints.wrist,.026f,joints.elbow,.039f,skin);
    add(joints.elbow,.041f,joints.shoulder,.050f,colors.sleeve);
}

// ---- Button gestures for Touch controllers ----
// Touch has ONE grip sensor for middle, ring and pinky, so they always move
// together. Like several VR games, a button combo raises a chosen finger: its
// joints are re-placed in a straight line along its metacarpal, keeping the
// tracked segment lengths. `amount` blends 0 (tracked) .. 1 (straight).
inline void straightenFinger(HandSkeleton& h,unsigned finger,float amount){
    if(finger<1||finger>4||!(amount>0))return;amount=std::min(amount,1.0f);
    unsigned b=fingerBase(finger);Vec3 original[5];for(unsigned k=0;k<5;++k)original[k]=h.model[b+k];
    Vec3 dir=unit(original[1]-original[0],unit(original[1]-h.model[BoneWrist],{0,0,-1}));
    Vec3 p=original[1];
    for(unsigned k=2;k<5;++k){p=p+dir*length(original[k]-original[k-1]);h.model[b+k]=original[k]+(p-original[k])*amount;}
    h.curl[finger]*=1-amount;
}
// Middle finger combo: grip + trigger (closed fist) + click the same hand's stick.
// While latched the stick click is consumed (no vehicle entry / sprint) until the
// stick is released, so letting go of grip first cannot fire the click.
class GestureCombo {
    bool latched=false;float amount=0;
public:
    static bool fist(float grip,float trigger){return grip>.8f&&trigger>.8f;}
    // Returns true while the stick click must be hidden from game controls.
    bool update(float grip,float trigger,bool stickClick,bool allowed,float dt){
        if(!allowed){latched=false;}
        else if(stickClick&&fist(grip,trigger))latched=true;
        if(!stickClick)latched=false;
        float step=std::isfinite(dt)?std::clamp(dt,0.0f,.1f)/.08f:0;
        amount=std::clamp(amount+(latched?step:-step),0.0f,1.0f);
        return latched;
    }
    float blend()const{return amount;}
    void reset(){latched=false;amount=0;}
};

// ---- Gestures (diagnostics / log; the drawn hand follows the bones directly) ----
enum class Gesture { Unknown,Open,Fist,ThumbsUp,Point,Gun,Peace,Three,MiddleFinger,Rock };
inline const char* gestureName(Gesture g){
    switch(g){case Gesture::Open:return "open hand";case Gesture::Fist:return "fist";case Gesture::ThumbsUp:return "thumbs up";
        case Gesture::Point:return "pointing";case Gesture::Gun:return "finger gun";case Gesture::Peace:return "two fingers";
        case Gesture::Three:return "three fingers";case Gesture::MiddleFinger:return "middle finger";case Gesture::Rock:return "rock";default:return "other";}
}
inline Gesture classifyGesture(const float (&curl)[5]){
    bool up[5],down[5];
    for(int i=0;i<5;++i){float c=std::isfinite(curl[i])?curl[i]:.5f;up[i]=c<(i==0?.40f:.35f);down[i]=c>(i==0?.45f:.62f);}
    auto is=[&](bool t,bool i,bool m,bool r,bool p){bool want[5]={t,i,m,r,p};for(int k=0;k<5;++k)if(want[k]?!up[k]:!down[k])return false;return true;};
    if(up[0]&&up[1]&&up[2]&&up[3]&&up[4])return Gesture::Open;
    if(is(false,false,false,false,false))return Gesture::Fist;
    if(is(true,false,false,false,false))return Gesture::ThumbsUp;
    if(is(false,true,false,false,false))return Gesture::Point;
    if(is(true,true,false,false,false))return Gesture::Gun;
    if(is(false,true,true,false,false))return Gesture::Peace;
    if(is(false,true,true,true,false))return Gesture::Three;
    if(is(false,false,true,false,false))return Gesture::MiddleFinger;
    if(is(false,true,false,false,true)||is(true,true,false,false,true))return Gesture::Rock;
    return Gesture::Unknown;
}
inline const char* trackingLevelName(int level){return level==2?"full (every finger)":level==1?"partial (Touch: middle/ring/pinky move together on grip)":level==0?"estimated":"unavailable";}

// ---- Overlay camera: the eye image is GTA's symmetric frustum around the eye ----
struct Mat4 { float m[4][4]{}; };
inline Mat4 multiply(const Mat4& a,const Mat4& b){Mat4 r;for(int i=0;i<4;++i)for(int j=0;j<4;++j){float s=0;for(int k=0;k<4;++k)s+=a.m[i][k]*b.m[k][j];r.m[i][j]=s;}return r;}
inline Pose compose(const Pose& a,const Pose& b){Pose r{};
    for(int i=0;i<3;++i){for(int j=0;j<4;++j){float s=0;for(int k=0;k<3;++k)s+=a.m[i][k]*b.m[k][j];r.m[i][j]=s+(j==3?a.m[i][3]:0);}}return r;}
// Rigid inverse as a 4x4 view matrix.
inline Mat4 viewMatrix(const Pose& eye){Mat4 v;
    for(int i=0;i<3;++i){for(int j=0;j<3;++j)v.m[i][j]=eye.m[j][i];v.m[i][3]=-(eye.m[0][i]*eye.m[0][3]+eye.m[1][i]*eye.m[1][3]+eye.m[2][i]*eye.m[2][3]);}
    v.m[3][3]=1;return v;}
// Right-handed (camera looks down -Z), D3D clip depth 0..1.
inline Mat4 perspective(float verticalFovDegrees,float aspect,float nearZ,float farZ){Mat4 p;
    float tanV=std::tan(verticalFovDegrees*pi/360),tanH=tanV*aspect;
    p.m[0][0]=1/tanH;p.m[1][1]=1/tanV;p.m[2][2]=farZ/(nearZ-farZ);p.m[2][3]=nearZ*farZ/(nearZ-farZ);p.m[3][2]=-1;return p;}
inline std::array<float,4> transformPoint(const Mat4& m,Vec3 p){std::array<float,4> r{};for(int i=0;i<4;++i)r[i]=m.m[i][0]*p.x+m.m[i][1]*p.y+m.m[i][2]*p.z+m.m[i][3];return r;}

// ---- GPU capsule mesh: unit sphere split at the equator (+Y = capsule axis) ----
struct CapsuleVertex { float n[3];float end; };
struct CapsuleInstance { float a[4],b[4],color[4]; };
inline void capsuleMesh(std::vector<CapsuleVertex>& vertices,std::vector<std::uint16_t>& indices,unsigned stacks=6,unsigned slices=14){
    vertices.clear();indices.clear();
    // Rows: bottom pole .. equator (end A), then equator .. top pole (end B).
    for(unsigned half=0;half<2;++half)for(unsigned k=0;k<=stacks;++k){
        float theta=half==0?-pi/2+pi/2*k/stacks:pi/2*k/stacks;
        float y=std::sin(theta),ring=std::cos(theta);
        for(unsigned s=0;s<slices;++s){float phi=2*pi*s/slices;vertices.push_back({{ring*std::cos(phi),y,ring*std::sin(phi)},float(half)});}
    }
    unsigned rows=2*(stacks+1);
    for(unsigned r=0;r+1<rows;++r)for(unsigned s=0;s<slices;++s){
        auto i0=std::uint16_t(r*slices+s),i1=std::uint16_t(r*slices+(s+1)%slices),i2=std::uint16_t((r+1)*slices+s),i3=std::uint16_t((r+1)*slices+(s+1)%slices);
        indices.insert(indices.end(),{i0,i2,i1,i1,i2,i3});
    }
}

// Brightness by in-game hour so hands do not glow at night.
inline float daylightFactor(int hour){
    if(hour<0||hour>23)return 1;
    float h=float(hour);
    if(h>=8&&h<=18)return 1;
    if(h>=21||h<=5)return .42f;
    if(h<8)return .42f+(h-5)/3*.58f;     // 05..08 sunrise
    return 1-(h-18)/3*.58f;              // 18..21 sunset
}
}
