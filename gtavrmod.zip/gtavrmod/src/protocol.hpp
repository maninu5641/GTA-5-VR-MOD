#pragma once
#include "stereo.hpp"
#include <cstddef>
namespace handvr {
constexpr std::uint32_t protocolMagic=0x48565233,protocolVersion=4;   // 0.13.0: 4 = HandShare added
// 0.16.2: ViewHeading = the renderer keeps the view's heading itself and turns GTA's camera and the character to your body
// (camera_anchor.hpp ViewYaw): bodyYawBits = that body's direction in tracking space (radians, float bits, the holsters sit
// there), and a snap turn goes to the renderer (HandShare::turnTotal) instead of to GTA's camera.
enum Flags:std::uint32_t { HeadValid=1,RightValid=2,LeftValid=4,InputReady=8,DashboardOpen=16,CameraKnown=32,ViewHeading=64 };
enum Buttons:std::uint32_t { WheelHeld=1,ReloadHeld=2,JumpHeld=4,SprintHeld=8,SupportGrip=16,ToggleHeld=32,WeaponGrip=64,InteractHeld=128,
    MoveTouched=256,TouchKnown=512,   // 0.7.0: left stick touch (TouchKnown = the touch action is bound and active)
    // 0.15.5: what a button can also be given in the VR menu (vr_menu.hpp): GTA's action key (E), cover (Q), the phone,
    // the special ability, GTA's pause menu, the VR menu. The renderer turns the six buttons into these bits.
    ContextHeld=1024,CoverHeld=2048,PhoneHeld=4096,SpecialHeld=8192,PauseHeld=16384,MenuHeld=32768 };
struct InputFrame {
    std::uint32_t magic=protocolMagic,version=protocolVersion;
    std::uint64_t timeMs=0;
    std::uint32_t flags=0,buttons=0;
    Pose head{},left{},right{};
    float trigger=0,moveX=0,moveY=0,stickX=0,stickY=0;
    float leftTrigger=0,rightGrip=0,leftGrip=0;
    std::uint32_t bodyYawBits=0,reserved=0;   // 0.16.2: was backend (1, never read)
    Vec3 gameHead{};Basis gameBasis{};
};
// 0.13.0: written by the motion add-on, read by the renderer. What each hand holds, and where the
// right hand bone must be so the gun sits in it like GTA holds it (relative to the right controller:
// world metres in the controller's mapped axes, rotation as a quaternion x y z w).
// 0.15.5: AimHeading = the motion add-on points GTA's camera at the person the VR gun points at (GTA's own aim);
// the view keeps the heading in viewYawBits (degrees, float bits) meanwhile, so it does not turn with GTA's camera.
enum HandShareFlags:std::uint32_t { RightTarget=1,CharacterWheel=2,AimHeading=4 };   // 0.14.0: GTA's character wheel is open (Y)
enum GripClass:std::uint8_t { GripNone=0,GripPistol=1,GripSmg=2,GripRifle=3,GripSniper=4,GripMelee1h=5,GripMelee2h=6,GripThrown=7,GripFist=8 };
struct HandShare {
    std::uint32_t serial=0,flags=0;
    std::uint64_t timeMs=0;
    float rightPos[3]{},rightRot[4]{0,0,0,1};
    std::uint8_t rightGrip=0,leftGrip=0;std::uint16_t turnTotal=0;std::uint32_t viewYawBits=0;   // 0.15.5: was spare2 (same layout)
    // 0.16.2: turnTotal (was spare) = every snap turn so far, degrees, wrapping at 16 bits (+ = left), for the renderer.
};
struct SharedMemory {
    InputFrame input{};
    std::uint32_t hapticSerial=0,hapticCode=0;   // 0.5.0: code = amplitude% << 16 | ms (0 = default click)
    std::uint64_t consumerTimeMs=0;
    HandShare hands{};   // 0.13.0
};
static_assert(std::is_trivially_copyable_v<SharedMemory>);
static_assert(sizeof(Pose)==48&&sizeof(InputFrame)==256&&sizeof(HandShare)==56&&sizeof(SharedMemory)==328);
inline bool usable(const InputFrame& f,std::uint64_t now) {
    constexpr auto needed=HeadValid|RightValid|InputReady;
    return f.magic==protocolMagic&&f.version==protocolVersion&&fresh(f.timeMs,now)
        &&(f.flags&needed)==needed&&!(f.flags&DashboardOpen)
        &&validPose(f.head)&&validPose(f.right)
        &&length(f.right.pos()-f.head.pos())<2.5f&&std::isfinite(f.trigger)
        &&std::isfinite(f.leftTrigger)&&std::isfinite(f.rightGrip)&&std::isfinite(f.leftGrip)
        &&(!(f.flags&CameraKnown)||(finite(f.gameHead)&&validBasis(f.gameBasis)));
}
// 0.15.8: why usable() says no (for the log): the first failing check; "" = usable.
inline const char* inputProblem(const InputFrame& f,std::uint64_t now) {
    if(f.magic!=protocolMagic||f.version!=protocolVersion)return "no input from the VR side";
    if(!fresh(f.timeMs,now))return "the input is late - older than 0.2 s (a slow game frame or the VR side paused)";
    if(f.flags&DashboardOpen)return "the SteamVR dashboard / VR off";
    if(!(f.flags&HeadValid)||!validPose(f.head))return "the headset's tracking";
    if(!(f.flags&RightValid)||!validPose(f.right))return "the right controller's tracking";
    if(!(f.flags&InputReady))return "the controller bindings are not ready";
    if(!(length(f.right.pos()-f.head.pos())<2.5f))return "the right controller 2.5 m or more from the headset (tracking)";
    if(!std::isfinite(f.trigger)||!std::isfinite(f.leftTrigger)||!std::isfinite(f.rightGrip)||!std::isfinite(f.leftGrip))return "an invalid trigger / grip reading";
    if((f.flags&CameraKnown)&&!(finite(f.gameHead)&&validBasis(f.gameBasis)))return "the game camera from the renderer";
    return "";
}
}
