#pragma once
// Frame synchronisation for alternating-eye capture (0.3.3).
//
// Problem: the script fiber sets the eye camera for update frame T, but the
// Present callback may receive a backbuffer from an earlier update because GTA's
// render thread runs behind the game thread. Labelling a frame by "the latest
// plan" can swap or mislabel eyes.
//
// Solution: every stereo tick creates a numbered FramePlan and draws a small
// black/white code (the frame tag) with DRAW_RECT in the top-left corner. Script
// draw commands are rendered with the same update frame as the world, so the
// tag read back from the captured backbuffer identifies the update that
// produced the image. A second, independent signal (GET_FINAL_RENDERED_CAM_COORD
// compared with the positions the previous plans requested) measures whether the
// scripted camera is applied in the same update or one update later.
//
// Everything here is plain logic without Windows or GTA calls, so it is unit
// tested on the build host (tests/frame_sync_test.cpp).
#include "core.hpp"
#include <array>
#include <cstdint>
#include <optional>

namespace handvr {

constexpr unsigned TagIdBits=7;
constexpr std::uint32_t TagIdMask=(1u<<TagIdBits)-1;
// Layout: [1][0] id(7 bits, MSB first) ~id(7 bits) => 16 square cells.
constexpr unsigned TagCells=2+2*TagIdBits;
constexpr unsigned TagCellPixels=6;
constexpr unsigned TagWidth=TagCells*TagCellPixels;   // 96 px
constexpr unsigned TagHeight=TagCellPixels;            // 6 px
// The newest plans that a tag may refer to. Older matches are rejected so a
// 7-bit id cannot alias a frame from more than ~1.5 s ago at 60 fps.
constexpr std::uint32_t TagMaxAge=100;

inline std::array<bool,TagCells> encodeTag(std::uint32_t id) {
    std::array<bool,TagCells> cells{};
    std::uint32_t value=id&TagIdMask;
    cells[0]=true;cells[1]=false;
    for(unsigned b=0;b<TagIdBits;++b){bool bit=((value>>(TagIdBits-1-b))&1u)!=0;cells[2+b]=bit;cells[2+TagIdBits+b]=!bit;}
    return cells;
}
// Normalised DRAW_RECT parameters (centre x/y, width, height) for one cell.
struct TagRect { float x,y,w,h; };
inline TagRect tagRect(unsigned cell,unsigned width,unsigned height) {
    float w=float(TagCellPixels)/float(width),h=float(TagCellPixels)/float(height);
    return {(float(cell)+.5f)*w,.5f*h,w,h};
}
// Pixel sampled for a cell: its centre, so +/-2 px of rasterisation snapping is tolerated.
inline unsigned tagSampleX(unsigned cell){return cell*TagCellPixels+TagCellPixels/2;}
constexpr unsigned TagSampleY=TagCellPixels/2;

struct TagSample { std::uint8_t r=0,g=0,b=0; };
// -1 = not a clean black/white cell (natural image content, blending, HUD).
inline int classifyTagCell(TagSample s) {
    int hi=std::max({int(s.r),int(s.g),int(s.b)}),lo=std::min({int(s.r),int(s.g),int(s.b)});
    if(hi-lo>48)return -1;
    if(lo>=170)return 1;
    if(hi<=85)return 0;
    return -1;
}
inline std::optional<std::uint32_t> decodeTag(const std::array<TagSample,TagCells>& samples) {
    int cells[TagCells];
    for(unsigned i=0;i<TagCells;++i){cells[i]=classifyTagCell(samples[i]);if(cells[i]<0)return std::nullopt;}
    if(cells[0]!=1||cells[1]!=0)return std::nullopt;
    std::uint32_t value=0;
    for(unsigned b=0;b<TagIdBits;++b){
        if(cells[2+b]==cells[2+TagIdBits+b])return std::nullopt;   // complement check
        value=(value<<1)|std::uint32_t(cells[2+b]);
    }
    return value;
}

// One scripted-camera request. Eye alternates with the plan id.
struct FramePlan {
    std::uint32_t id=0;unsigned eye=0;
    Pose head{};           // SteamVR standing-space head pose used for this request
    Vec3 eyePosition{};    // GTA world position requested for the eye camera
    std::uint64_t timeUs=0;
    bool mono=false;       // 0.4.1 stable mode: one centre image for both eyes
};
inline unsigned eyeForPlan(std::uint32_t id){return id&1u;}

class PlanRing {
    std::array<FramePlan,TagIdMask+1> plans{};
    std::uint32_t latest=0,sessionStart=1;
public:
    // Invalidates every earlier plan (recenter, camera recreation, stereo restart).
    void newSession(){sessionStart=latest+1;}
    std::uint32_t latestId()const{return latest;}
    std::uint32_t firstValidId()const{return sessionStart;}
    const FramePlan& create(const Pose& head,Vec3 eyePosition,std::uint64_t timeUs,bool mono=false){
        ++latest;if(latest==0){latest=1;sessionStart=1;}   // 32-bit wrap: start over
        auto& p=plans[latest&TagIdMask];p.id=latest;p.eye=eyeForPlan(latest);p.head=head;p.eyePosition=eyePosition;p.timeUs=timeUs;p.mono=mono;return p;
    }
    const FramePlan* find(std::uint32_t id)const{
        if(!id||id<sessionStart||id>latest||latest-id>TagIdMask)return nullptr;
        const auto& p=plans[id&TagIdMask];return p.id==id?&p:nullptr;
    }
    // Expand a 7-bit tag to the newest full id at or before `latestAtCapture`.
    std::optional<std::uint32_t> resolveTag(std::uint32_t tag,std::uint32_t latestAtCapture)const{
        if(latestAtCapture>latest||!latestAtCapture)return std::nullopt;
        std::uint32_t back=(latestAtCapture-tag)&TagIdMask;
        if(back>latestAtCapture)return std::nullopt;
        std::uint32_t id=latestAtCapture-back;
        if(!id||id<sessionStart||back>TagMaxAge)return std::nullopt;
        return id;
    }
};

// The plan whose camera produced a tagged frame: the tagged update, minus the
// measured camera-application lag. `depth` = updates between capture and tag.
inline const FramePlan* planForTaggedFrame(const PlanRing& ring,std::uint32_t tag,std::uint32_t latestAtCapture,unsigned lag,std::uint32_t* depth=nullptr) {
    auto id=ring.resolveTag(tag,latestAtCapture);if(!id)return nullptr;
    if(depth)*depth=latestAtCapture-*id;
    if(*id<=lag)return nullptr;
    return ring.find(*id-lag);
}

// Votes whether GTA rendered the camera requested by the previous plan (lag 0)
// or by the plan before it (lag 1). Read at the start of a tick, before the new
// camera is set, GET_FINAL_RENDERED_CAM_COORD describes the last rendered update.
class CameraLagEstimator {
    static constexpr unsigned Window=64,MinimumVotes=24;
    std::array<std::int8_t,Window> votes{};unsigned count=0,next=0;unsigned current=0;
    unsigned ambiguous=0;
public:
    enum Vote { None=-1,SameFrame=0,OneFrameLate=1 };
    unsigned lag()const{return current;}
    unsigned ambiguousSamples()const{return ambiguous;}
    unsigned votesFor(int value)const{unsigned n=0;for(unsigned i=0;i<count;++i)n+=votes[i]==value;return n;}
    void reset(){count=next=0;ambiguous=0;}   // keeps the last decided lag
    static Vote classify(Vec3 rendered,const FramePlan& previous,const FramePlan& beforePrevious){
        if(!finite(rendered))return None;
        float separation=length(previous.eyePosition-beforePrevious.eyePosition);
        if(!(separation>=.02f))return None;            // eyes too close to tell apart
        float d0=length(rendered-previous.eyePosition),d1=length(rendered-beforePrevious.eyePosition);
        if(d0<separation*.25f&&d1>separation*.75f)return SameFrame;
        if(d1<separation*.25f&&d0>separation*.75f)return OneFrameLate;
        return None;
    }
    // Returns true when the decided lag changed.
    bool observe(Vote vote){
        if(vote==None){++ambiguous;return false;}
        votes[next]=std::int8_t(vote);next=(next+1)%Window;if(count<Window)++count;
        if(count<MinimumVotes)return false;
        unsigned late=votesFor(OneFrameLate),same=votesFor(SameFrame);
        unsigned decided=current;
        if(late*4>=count*3)decided=1;else if(same*4>=count*3)decided=0;
        bool changed=decided!=current;current=decided;return changed;
    }
};

// A running sum / count / maximum of milliseconds (0.16.2 timing lines).
struct MsSpan {
    double sum=0,max=0;unsigned count=0;
    void add(double ms){if(!(ms>=0)||!(ms<1e6))return;sum+=ms;max=std::max(max,ms);++count;}
    double average()const{return count?sum/count:0;}
};
// 0.16.2 (the developer: "very juddery"): how far apart GTA's frames came, in headset frames - 1 is smooth, 2 or more
// is a frame the headset showed twice (SteamVR reprojects it).
struct FrameGaps {
    unsigned one=0,two=0,more=0;
    void add(double gapMs,double headsetFrameMs){if(!(gapMs>0)||!(headsetFrameMs>0))return;
        if(gapMs<=headsetFrameMs*1.4)++one;else if(gapMs<=headsetFrameMs*2.4)++two;else ++more;}
    unsigned total()const{return one+two+more;}
};
// Running numbers for the periodic "Frame sync:" log line.
struct FrameSyncStats {
    unsigned tagged=0,untagged=0,unmatched=0,dropped=0,legacy=0;
    std::uint32_t depthMin=~0u,depthMax=0;std::uint64_t depthSum=0;unsigned depthSamples=0;
    double latencyMsSum=0;unsigned latencySamples=0;
    FrameGaps gaps;MsSpan lockWait,scriptTick,gpu;   // 0.16.2
    void depth(std::uint32_t d){depthMin=std::min(depthMin,d);depthMax=std::max(depthMax,d);depthSum+=d;++depthSamples;}
    void latency(double ms){latencyMsSum+=ms;++latencySamples;}
    void clear(){*this=FrameSyncStats{};}
};

// Rendered-to-submitted latency, smoothed, for head-pose prediction.
class LatencyFilter {
    double value=0;bool primed=false;
public:
    void add(double seconds){if(!(seconds>=0&&seconds<.25))return;value=primed?value*.9+seconds*.1:seconds;primed=true;}
    double seconds()const{return primed?value:0;}
};
// Seconds to predict the head pose ahead from a script tick: rest of the current
// HMD frame + vsync-to-photons + the measured plan-to-submit pipeline delay.
inline float predictionSeconds(float sinceVsync,float displayHz,float vsyncToPhotons,double pipeline) {
    if(!(displayHz>=20&&displayHz<=1000))displayHz=90;
    if(!(vsyncToPhotons>=0&&vsyncToPhotons<=.1f))vsyncToPhotons=0;
    float frame=1/displayHz;float remaining=frame-(std::isfinite(sinceVsync)?std::clamp(sinceVsync,0.0f,frame):0.0f);
    float total=remaining+vsyncToPhotons+float(std::isfinite(pipeline)?pipeline:0);
    return std::clamp(total,0.0f,.06f);   // 0.4.1: longer extrapolation amplified tracking noise
}
}
