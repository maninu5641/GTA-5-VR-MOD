#pragma once
// 0.15.0: GTA's own gunshot, the VR on / off button and Pavlov magazines.
// Portable logic, tested in tests/vr_shot_test.cpp. The game side: mod.cpp / mod_interactions.inc
// (gunshot, magazines) and renderer.cpp (the VR button).
#include "core.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>
namespace handvr {

// ---------- the VR on / off button (renderer) ----------
// Both thumbstick clicks held together for holdMs: the VR view <-> GTA's own flat view on the
// cinema screen (what F11 does). While both are down - and until both are let go - neither click
// goes on to the game or the motion add-on (no run, no character wheel).
class BothClicksToggle {
    bool both=false,fired=false,swallow=false;std::uint64_t since=0,holdMs;
public:
    explicit BothClicksToggle(std::uint64_t ms=1000):holdMs(ms){}
    void reset(){both=fired=swallow=false;since=0;}
    void setHold(std::uint64_t ms){holdMs=ms<200?200:ms;}
    // True once per hold, when both clicks have been down for holdMs.
    bool update(bool left,bool right,std::uint64_t now){
        if(left&&right){
            if(!both){both=true;fired=false;since=now;}
            swallow=true;
            if(!fired&&now-since>=holdMs){fired=true;return true;}
            return false;
        }
        both=false;fired=false;
        if(!left&&!right)swallow=false;
        return false;
    }
    bool swallowing()const{return swallow;}
    bool holding()const{return both&&!fired;}
    float progress(std::uint64_t now)const{return both&&!fired&&holdMs?std::min(1.0f,float(now-since)/float(holdMs)):0.0f;}
};

// ---------- GTA's own gunshot (motion add-on) ----------
// The gun in the VR hand is also GTA's weapon in the character's hand (invisible). Each shot asks GTA
// to fire it (SET_PED_SHOOTS_AT_COORD): then GTA plays its own gunshot. Whether GTA does, is learned
// per weapon from GTA's ammunition:
//  Sync   = the round leaves during the request;
//  Late   = it leaves a few updates later (the mod waits for it);
//  Script = GTA never fires it: the mod fires the bullet itself (0.14.0; GTA plays no gunshot for it).
enum class ShotPath { Unknown,Sync,Late,Script };
inline const char* shotPathName(ShotPath p){
    return p==ShotPath::Sync?"GTA fires it":p==ShotPath::Late?"GTA fires it a moment later":p==ShotPath::Script?"the mod fires it":"not known yet";}
class ShotLearner {
    struct Entry { std::uint32_t hash=0;ShotPath path=ShotPath::Unknown;int misses=0,refusals=0; };
    std::vector<Entry> list;
    Entry& at(std::uint32_t h){for(auto& e:list)if(e.hash==h)return e;list.push_back(Entry{h});return list.back();}
public:
    static constexpr int MissesToScript=2;
    ShotPath path(std::uint32_t h)const{for(const auto& e:list)if(e.hash==h)return e.path;return ShotPath::Unknown;}
    int refusals(std::uint32_t h)const{for(const auto& e:list)if(e.hash==h)return e.refusals;return 0;}
    bool askGame(std::uint32_t h)const{return path(h)!=ShotPath::Script;}
    enum class After { Fired,Wait };
    // Right after the request. Fired = the round left during it; Wait = check GTA's ammunition over the
    // next updates (PendingRound) - GTA may fire it a moment later, or not at all.
    After afterRequest(std::uint32_t h,bool firedNow){
        Entry& e=at(h);
        if(firedNow){if(e.path!=ShotPath::Late)e.path=ShotPath::Sync;e.misses=0;return After::Fired;}
        return After::Wait;
    }
    // A round waited for: GTA fired it late (true) or not within the wait (false: the mod fires it).
    // A weapon GTA fired before keeps being asked; one it never fired goes to Script after two tries.
    ShotPath resolved(std::uint32_t h,bool fired){
        Entry& e=at(h);
        if(fired){if(e.path!=ShotPath::Sync)e.path=ShotPath::Late;e.misses=0;return e.path;}
        ++e.refusals;
        if(e.path!=ShotPath::Sync&&e.path!=ShotPath::Late&&++e.misses>=MissesToScript)e.path=ShotPath::Script;
        return e.path;
    }
    void forget(){list.clear();}
};
// One round GTA was asked for and has not fired yet. ammoLeft = GTA's ammunition when it was asked;
// GTA's own shot takes one round from it.
struct PendingRound {
    static constexpr int WaitUpdates=4;
    bool active=false;std::uint32_t hash=0;int ammoLeft=0,updates=0;
    void start(std::uint32_t h,int left){active=true;hash=h;ammoLeft=left;updates=0;}
    void clear(){active=false;hash=0;updates=0;}
    enum class State { Idle,Waiting,Fired,Missed };
    State update(int ammoNow){
        if(!active)return State::Idle;
        if(ammoNow<ammoLeft){active=false;return State::Fired;}
        if(++updates>=WaitUpdates){active=false;return State::Missed;}
        return State::Waiting;
    }
};

// ---------- Pavlov magazines ----------
// The magazine in the left hand lines up with the gun once it is near the magazine well: 0 = in the
// hand (farther than snap), 1 = at the well (seat distance or closer).
inline float wellSnap(float distance,float snap,float seat){
    if(!std::isfinite(distance)||!(snap>seat))return 0;
    return std::clamp((snap-distance)/(snap-seat),0.0f,1.0f);
}
inline Vec3 mixPoint(Vec3 a,Vec3 b,float t){return a+(b-a)*t;}
// Where the held magazine is drawn: from the hand (t = 0) to just under the gun's magazine attach
// point, in the gun's axes (t = 1). Below the attach point by `drop` metres times (1 - t).
inline Vec3 magazineDrawPoint(Vec3 hand,Vec3 attach,Vec3 gunUp,float t,float drop){
    t=std::clamp(t,0.0f,1.0f);return mixPoint(hand,attach-gunUp*(drop*(1-t)),t);
}

// Dry fire: one tick per trigger pull while the gun cannot fire.
class DryFire {
    bool down=false;
public:
    // True on the pull (trigger past .65 after being under .35) while the gun cannot fire.
    bool update(float trigger,bool canFire){
        if(!std::isfinite(trigger))trigger=0;
        if(down){if(trigger<.35f)down=false;return false;}
        if(trigger>=.65f){down=true;return !canFire;}
        return false;
    }
};
}
