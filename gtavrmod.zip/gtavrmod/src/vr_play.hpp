#pragma once
// 0.7.0 play logic, tested in tests/vr_play_test.cpp:
//  - TorsoYaw: a lazy body direction, so body holsters stay on the body when you look around.
//  - HandGrab: grab from a holster with the grip, hold while squeezed (or toggle), let go to
//    put the weapon back / throw a grenade.
//  - MoveFilter: left-stick locomotion with thumb-touch gating, deadzone hysteresis and a short
//    brake after release (the character no longer keeps walking), plus head-relative direction.
//  - Character switch with the right stick.
//  - ClipBook: magazine rounds per weapon (the character holds no GTA weapon, so GTA keeps none).
#include "core.hpp"
#include "weapons_vr.hpp"
#include <array>
#include <cstdint>
#include <cmath>

namespace handvr {

// ---------- Body yaw (tracking space; 0 = facing -Z, positive = turning left / counter-clockwise from above) ----------
inline float wrapAngle(float a){if(!std::isfinite(a))return 0;a=std::fmod(a+pi,2*pi);if(a<0)a+=2*pi;return a-pi;}
inline float headYaw(const Pose& head){
    Vec3 f=-head.col(2);Vec3 h{f.x,0,f.z};
    if(length(h)<.3f){Vec3 u=head.col(1);float s=f.y<0?1.0f:-1.0f;h={u.x*s,0,u.z*s};}   // looking straight down / up: the top of the head points forward / back
    if(length(h)<1e-4f)return 0;return std::atan2(-h.x,-h.z);
}
inline Vec3 yawForward(float yaw){return {-std::sin(yaw),0,-std::cos(yaw)};}
// The torso turns only when the head is turned far (beyond the deadband) or for a while.
// 0.16.2 (the developer: "the head does not turn with the character's torso"): this is now the character's body too
// (the renderer turns GTA's character to it, camera_anchor.hpp ViewYaw), so it follows sooner: pulled along past 40 deg (was
// 46), and looking 20+ deg aside for 0.5 s turns it all the way to where you look in about 0.4 s (was 10 deg for 1.5 s,
// at 0.8 / s, and it stopped 10 deg short). Walking it faces where you look (you walk there); looking down at your
// body (a holster, a magazine) it stays.
class TorsoYaw {
    float yaw=0,steady=0;bool primed=false,settling=false;
public:
    static constexpr float Deadband=.70f;      // 40 degrees: the head turns that far before the body is pulled along
    static constexpr float SettleAngle=.35f;   // 20 degrees aside...
    static constexpr float FollowAfter=.5f;    // ...for 0.5 s: the body turns to where you look...
    static constexpr float FollowRate=2.5f;    // ...in about 0.4 s (1 / rate)...
    static constexpr float Aligned=.05f;       // ...until it is within 3 degrees
    static constexpr float MoveRate=6.0f;      // walking: in about 0.17 s
    void reset(){primed=false;steady=0;settling=false;}
    float value()const{return yaw;}
    // 0.16.2: the motion add-on takes the renderer's body direction (the holsters sit on the character's body).
    void set(float v){if(std::isfinite(v)){yaw=wrapAngle(v);primed=true;steady=0;settling=false;}}
    // moving: walking with the stick. hold: looking down at the body - it stays (the 40 degree pull still works).
    float update(float head,float dt,bool moving=false,bool hold=false){
        if(!std::isfinite(head))return yaw;
        if(!primed){yaw=wrapAngle(head);primed=true;steady=0;settling=false;return yaw;}
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        float d=wrapAngle(head-yaw);
        if(moving){yaw=wrapAngle(yaw+d*std::min(1.0f,dt*MoveRate));steady=0;settling=false;return yaw;}
        if(d>Deadband){yaw=wrapAngle(yaw+d-Deadband);d=Deadband;}
        else if(d<-Deadband){yaw=wrapAngle(yaw+d+Deadband);d=-Deadband;}
        if(hold){steady=0;settling=false;return yaw;}
        if(settling){if(std::abs(d)<Aligned)settling=false;else yaw=wrapAngle(yaw+d*std::min(1.0f,dt*FollowRate));}
        else if(std::abs(d)>SettleAngle){steady+=dt;if(steady>=FollowAfter){settling=true;steady=0;}}
        else steady=0;
        return yaw;
    }
};
// 0.16.2: looking down at your own body (the face more than ~45 degrees below the horizon).
inline bool lookingDown(const Pose& head){Vec3 f=-head.col(2);return std::isfinite(f.y)&&f.y<-.70f;}
// Holster zones around the body (head position, torso yaw), tracking space.
// 0.9.0: size = the player's body relative to an average adult (from the height calibration).
inline float bodySizeOr1(float size){return std::isfinite(size)&&size>.4f&&size<2.0f?size:1.0f;}
inline HolsterZones holsterZonesAt(Vec3 headPos,float yaw,float heightOffset=0,float size=1){
    float k=bodySizeOr1(size);
    Vec3 f=yawForward(yaw),r=cross(f,{0,1,0}),up{0,1,0},h=headPos+up*heightOffset;
    HolsterZones z;
    z[int(Holster::RightHip)]={h-up*(.70f*k)+r*(.20f*k)+f*(.03f*k),.17f*k};
    z[int(Holster::LeftHip)]={h-up*(.70f*k)-r*(.20f*k)+f*(.03f*k),.17f*k};
    z[int(Holster::Chest)]={h-up*(.38f*k)+f*(.12f*k),.18f*k};   // 0.14.0: 14 -> 18 cm (grenades were hard to take)
    z[int(Holster::RightShoulder)]={h-up*(.12f*k)+r*(.19f*k)-f*(.10f*k),.16f*k};
    z[int(Holster::LeftShoulder)]={h-up*(.12f*k)-r*(.19f*k)-f*(.10f*k),.16f*k};
    return z;
}
inline Vec3 pouchCenterAt(Vec3 headPos,float yaw,float heightOffset=0,float size=1){float k=bodySizeOr1(size);
    Vec3 f=yawForward(yaw),r=cross(f,{0,1,0});return headPos+Vec3{0,heightOffset-.62f*k,0}-r*(.17f*k)+f*(.08f*k);}
inline bool atPouchAt(Vec3 headPos,float yaw,Vec3 hand,float heightOffset=0,float size=1){float k=bodySizeOr1(size);
    Vec3 f=yawForward(yaw),r=cross(f,{0,1,0}),h=headPos+Vec3{0,heightOffset,0};
    return length(hand-pouchCenterAt(headPos,yaw,heightOffset,k))<.20f*k||length(hand-(h-Vec3{0,.40f*k,0}-r*(.08f*k)+f*(.15f*k)))<.15f*k;
}
// 0.9.0: the belt pouch alone (shotgun shells: the chest belongs to the grenades).
inline bool atBeltPouchAt(Vec3 headPos,float yaw,Vec3 hand,float heightOffset=0,float size=1){float k=bodySizeOr1(size);
    return finite(hand)&&length(hand-pouchCenterAt(headPos,yaw,heightOffset,k))<.20f*k;}

// ---------- Grab / hold / let go (one hand) ----------
enum class GripMode { Hold,Toggle };
struct GrabInput { bool grip=false;Holster zone=Holster::None;bool zoneHasItem=false;bool valid=true;GripMode mode=GripMode::Hold;bool alwaysHold=false; };
struct GrabEvents { bool grabbed=false,released=false,inHolster=false,emptyHolster=false;Holster from=Holster::None; };
class HandGrab {
    bool previousGrip=true;   // a grip already squeezed when the hand becomes valid is not a press
public:
    bool holding=false;Holster source=Holster::None;
    void reset(){previousGrip=true;holding=false;source=Holster::None;}
    // alwaysHold: grenades are held while squeezed and thrown on release, whatever the mode.
    GrabEvents update(const GrabInput& in){
        GrabEvents e;
        if(!in.valid){if(holding){holding=false;e.released=true;e.inHolster=true;e.from=source;}previousGrip=true;return e;}   // lost tracking: back in the holster
        bool press=in.grip&&!previousGrip,release=!in.grip&&previousGrip;previousGrip=in.grip;
        if(!holding){
            if(press&&in.zone!=Holster::None){if(in.zoneHasItem){holding=true;source=in.zone;e.grabbed=true;e.from=in.zone;}else e.emptyHolster=true;}
            return e;
        }
        bool hold=in.mode==GripMode::Hold||in.alwaysHold;
        if((hold&&release)||(!hold&&press&&in.zone!=Holster::None)){
            holding=false;e.released=true;e.from=source;e.inHolster=in.zone!=Holster::None&&(in.zone==source||!hold);source=Holster::None;
        }
        return e;
    }
};

// ---------- Locomotion ----------
struct MoveOutput { float x=0,y=0;bool brake=false;bool moving=false; };
class MoveFilter {
    bool moving=false;int brakeFrames=0;
public:
    static constexpr float Start=.28f,Stop=.18f;static constexpr int BrakeFrames=6;
    void reset(){moving=false;brakeFrames=0;}
    // touchKnown: the stick's touch sensor is bound; untouched = no movement, whatever the stick reports.
    MoveOutput update(float x,float y,bool touchKnown,bool touched,bool blocked){
        MoveOutput o;
        if(!std::isfinite(x)||!std::isfinite(y)||blocked||(touchKnown&&!touched))x=y=0;
        float m=std::sqrt(x*x+y*y);bool was=moving;
        moving=moving?m>Stop:m>Start;
        if(moving){float scaled=std::min(1.0f,(m-Stop)/(1-Stop));o.x=x/m*scaled;o.y=y/m*scaled;o.moving=true;}
        if(was&&!moving)brakeFrames=BrakeFrames;
        if(brakeFrames>0&&!moving){--brakeFrames;o.brake=true;}
        if(moving)brakeFrames=0;
        return o;
    }
};
// GTA heading (degrees, counter-clockwise from north) of a world direction.
inline float gtaHeading(Vec3 forward){return std::atan2(-forward.x,forward.y)*180/pi;}
// A stick (x right, y forward) meant relative to heading `look` re-expressed relative to `camera`
// (GTA moves the character relative to its gameplay camera).
inline void stickRelativeTo(float& x,float& y,float lookHeading,float cameraHeading){
    float d=rad(lookHeading-cameraHeading);if(!std::isfinite(d))return;
    float c=std::cos(d),s=std::sin(d),nx=x*c-y*s,ny=x*s+y*c;x=nx;y=ny;
}

// ---------- Character switch ----------
enum class Character { None,Michael,Franklin,Trevor };
inline const char* characterName(Character c){switch(c){case Character::Michael:return "Michael";case Character::Franklin:return "Franklin";case Character::Trevor:return "Trevor";default:return "none";}}
// Right stick: left = Michael, up = Franklin, right = Trevor, down / centre = none.
inline Character characterForStick(float x,float y){
    if(!std::isfinite(x)||!std::isfinite(y)||x*x+y*y<.55f*.55f)return Character::None;
    if(y>std::abs(x))return Character::Franklin;
    if(x<-std::abs(y))return Character::Michael;
    if(x>std::abs(y))return Character::Trevor;
    return Character::None;
}
// INPUT_SELECT_CHARACTER_MICHAEL / FRANKLIN / TREVOR (F5 / F6 / F7 on PC).
inline int characterControl(Character c){switch(c){case Character::Michael:return 166;case Character::Franklin:return 167;case Character::Trevor:return 168;default:return 0;}}
// 0.15.1: the same keys as keyboard scan codes (set 1: F5 0x3F, F6 0x40, F7 0x41) for a real key press.
inline std::uint16_t characterScan(Character c){switch(c){case Character::Michael:return 0x3F;case Character::Franklin:return 0x40;case Character::Trevor:return 0x41;default:return 0;}}
inline const char* characterKey(Character c){switch(c){case Character::Michael:return "F5";case Character::Franklin:return "F6";case Character::Trevor:return "F7";default:return "-";}}
// 0.15.2: GTA's character selector (selector.c, story mode) opens its wheel on the key press and switches only when
// the key is let go after the wheel has been fully open: 300 ms after the press (state 1 -> 4; the release commits in
// state 4). 0.15.1 let go after 200 ms - too early, GTA never switched. The key is now held CharacterKeyHold seconds
// (0.65 by default; never less than 0.35 s).
constexpr std::uint64_t SelectorOpenMs=300;
inline std::uint64_t selectKeyHoldMs(float seconds){
    if(!std::isfinite(seconds))seconds=.65f;
    float ms=seconds*1000.0f;if(ms<float(SelectorOpenMs+50))ms=float(SelectorOpenMs+50);if(ms>2000.0f)ms=2000.0f;
    return std::uint64_t(ms);
}
// The control sequence after a pick: the character wheel (INPUT_CHARACTER_WHEEL 19) with the
// select key, then the select key alone (direct switch), whichever GTA accepts.
class SwitchSequence {
    int frame=-1,control=0;
public:
    struct Step { bool wheel=false;int select=0;bool done=false; };
    bool active()const{return frame>=0;}
    void start(int selectControl){if(selectControl){control=selectControl;frame=0;}}
    void cancel(){frame=-1;}
    Step next(){Step s;if(frame<0){s.done=true;return s;}
        if(frame<4){s.wheel=true;s.select=control;}else if(frame>=6&&frame<10)s.select=control;
        if(++frame>=10){frame=-1;s.done=true;}return s;}
};
// Hold detector with a configurable time (the right stick click: tap = enter vehicle, hold = character switch).
class PressHold {
    bool down=false,fired=false;std::uint64_t since=0;std::uint64_t holdMs;
public:
    explicit PressHold(std::uint64_t ms=350):holdMs(ms){}
    enum Event { None,Tap,HoldStart,HoldEnd };
    bool holding()const{return down&&fired;}
    void reset(){down=fired=false;since=0;}
    Event update(bool pressed,std::uint64_t now){
        if(pressed&&!down){down=true;fired=false;since=now;return None;}
        if(pressed&&down&&!fired&&now-since>=holdMs){fired=true;return HoldStart;}
        if(!pressed&&down){down=false;bool wasHold=fired;fired=false;return wasHold?HoldEnd:Tap;}
        return None;
    }
};

// ---------- Magazine rounds per weapon ----------
class ClipBook {
    struct Entry { std::uint32_t hash=0;int clip=0; };std::array<Entry,48> e{};
public:
    bool has(std::uint32_t hash)const{for(auto& x:e)if(x.hash==hash)return true;return false;}
    int get(std::uint32_t hash,int fallback)const{for(auto& x:e)if(x.hash==hash)return x.clip;return fallback;}
    void set(std::uint32_t hash,int clip){if(!hash)return;for(auto& x:e)if(x.hash==hash){x.clip=std::max(0,clip);return;}
        for(auto& x:e)if(!x.hash){x={hash,std::max(0,clip)};return;}e[0]={hash,std::max(0,clip)};}
    void clear(){e={};}
};
// Rounds a full magazine holds when GTA does not report it for a weapon that is not in hand.
inline int defaultCapacity(int group){static constexpr int c[8]={0,12,30,30,100,8,10,1};return c[group&7];}
}
