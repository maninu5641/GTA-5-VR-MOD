#pragma once
// 0.15.5 (the friend: "make the VR bindings and put them into the in-game settings, and make the menu usable -
// every time I get on the menu I can't do anything"):
//  - what each of the six controller buttons does is chosen in the game (the VR menu) and kept in GTAHandVR.ini;
//  - GTA's own pause menu is played with the controllers (the sticks are its arrow keys, A Enter, B Esc...);
//  - the VR menu itself (its items and values; the renderer draws it and saves the INI).
// Portable: tests/vr_menu_test.cpp.
#include "protocol.hpp"
#include <array>
#include <cmath>
#include <cstdint>
#include <cwctype>
#include <string>
namespace handvr {

// ---------- The six buttons and what each one does ----------
// The SteamVR actions keep their default binding (renderer_bindings_oculus_touch.json): each one is one
// physical button. The renderer reads them as "physical" bits and gives each button its function here.
enum class PhysButton:int { A,B,X,Y,LeftClick,RightClick };
constexpr int physCount=6;
constexpr std::uint32_t physicalBit(PhysButton b){
    return b==PhysButton::A?ReloadHeld:b==PhysButton::B?WheelHeld:b==PhysButton::X?JumpHeld:b==PhysButton::Y?ToggleHeld
        :b==PhysButton::LeftClick?SprintHeld:b==PhysButton::RightClick?InteractHeld:0u;}
constexpr std::uint32_t physicalMask=ReloadHeld|WheelHeld|JumpHeld|ToggleHeld|SprintHeld|InteractHeld;
inline const char* buttonName(PhysButton b){
    switch(b){case PhysButton::A:return "A button";case PhysButton::B:return "B button";case PhysButton::X:return "X button";
        case PhysButton::Y:return "Y button";case PhysButton::LeftClick:return "Left stick click";case PhysButton::RightClick:return "Right stick click";}
    return "?";}
inline const wchar_t* buttonKey(PhysButton b){   // [Controls] key in GTAHandVR.ini
    switch(b){case PhysButton::A:return L"ButtonA";case PhysButton::B:return L"ButtonB";case PhysButton::X:return L"ButtonX";
        case PhysButton::Y:return L"ButtonY";case PhysButton::LeftClick:return L"LeftStickClick";case PhysButton::RightClick:return L"RightStickClick";}
    return L"";}

// Reload .. Run, WheelHold: the functions of 0.15.4 (same bits, so the motion add-on does what it did).
// Context .. VrMenu: new in 0.15.5.
enum class ButtonFunction:int { None,Reload,Vehicle,Jump,CharacterWheel,Run,WheelHold,Context,Cover,Phone,Special,Pause,VrMenu };
constexpr int functionCount=13;
constexpr std::uint32_t functionBit(ButtonFunction f){
    switch(f){case ButtonFunction::Reload:return ReloadHeld;case ButtonFunction::Vehicle:return WheelHeld;case ButtonFunction::Jump:return JumpHeld;
        case ButtonFunction::CharacterWheel:return ToggleHeld;case ButtonFunction::Run:return SprintHeld;case ButtonFunction::WheelHold:return InteractHeld;
        case ButtonFunction::Context:return ContextHeld;case ButtonFunction::Cover:return CoverHeld;case ButtonFunction::Phone:return PhoneHeld;
        case ButtonFunction::Special:return SpecialHeld;case ButtonFunction::Pause:return PauseHeld;case ButtonFunction::VrMenu:return MenuHeld;
        default:return 0u;}}
inline const char* functionName(ButtonFunction f){   // what the VR menu shows
    switch(f){case ButtonFunction::None:return "Nothing";case ButtonFunction::Reload:return "Magazine / reload / E / phone OK";   // 0.16.3: also GTA's E (ReloadIsE)
        case ButtonFunction::Vehicle:return "Vehicle in / out, phone back";case ButtonFunction::Jump:return "Jump / climb";
        case ButtonFunction::CharacterWheel:return "GTA's character wheel";case ButtonFunction::Run:return "Run / sprint";
        case ButtonFunction::WheelHold:return "Character wheel (held, like 0.15.4)";case ButtonFunction::Context:return "GTA's action key (E)";
        case ButtonFunction::Cover:return "Cover (GTA's Q)";case ButtonFunction::Phone:return "Phone (take out / put away)";
        case ButtonFunction::Special:return "Special ability";case ButtonFunction::Pause:return "GTA's pause menu";case ButtonFunction::VrMenu:return "This VR menu";}
    return "?";}
inline const char* functionToken(ButtonFunction f){   // the value in GTAHandVR.ini
    switch(f){case ButtonFunction::None:return "None";case ButtonFunction::Reload:return "Reload";case ButtonFunction::Vehicle:return "Vehicle";
        case ButtonFunction::Jump:return "Jump";case ButtonFunction::CharacterWheel:return "CharacterWheel";case ButtonFunction::Run:return "Run";
        case ButtonFunction::WheelHold:return "WheelHold";case ButtonFunction::Context:return "Context";case ButtonFunction::Cover:return "Cover";
        case ButtonFunction::Phone:return "Phone";case ButtonFunction::Special:return "Special";case ButtonFunction::Pause:return "Pause";case ButtonFunction::VrMenu:return "VrMenu";}
    return "None";}
inline bool sameToken(const wchar_t* a,const char* b){
    if(!a||!b)return false;
    for(;*a&&*b;++a,++b)if(std::towlower(wint_t(*a))!=std::towlower(wint_t(static_cast<unsigned char>(*b))))return false;
    return !*a&&!*b;}
// INI text -> function (any letter case); false for an unknown word.
inline bool parseFunction(const wchar_t* text,ButtonFunction& out){
    if(!text)return false;
    while(*text==L' '||*text==L'\t')++text;
    std::wstring t(text);while(!t.empty()&&(t.back()==L' '||t.back()==L'\t'||t.back()==L'\r'))t.pop_back();
    for(int i=0;i<functionCount;++i)if(sameToken(t.c_str(),functionToken(ButtonFunction(i)))){out=ButtonFunction(i);return true;}
    if(sameToken(t.c_str(),"E")||sameToken(t.c_str(),"Action")){out=ButtonFunction::Context;return true;}
    if(sameToken(t.c_str(),"Off")||sameToken(t.c_str(),"Nothing")||sameToken(t.c_str(),"0")){out=ButtonFunction::None;return true;}
    return false;}
// 0.16.3: when the Reload button (A) is GTA's action key E too ([Controls] ReloadIsE): on foot while the right hand holds
// no gun (A has nothing else to do then), and whenever GTA shows a help message ("press E to browse"; with a gun, or in a
// vehicle, A still does its own thing as well). Never while the phone or a menu of the add-on has the press.
inline bool reloadIsActionKey(bool enabled,bool aDown,bool free,bool phone,bool inVehicle,bool handGun,bool helpShown){
    if(!enabled||!aDown||!free||phone)return false;
    return (!inVehicle&&!handGun)||helpShown;}
struct ButtonMap {
    std::array<ButtonFunction,physCount> f{};
    // 0.15.5 default: like 0.15.4, except the right stick click = GTA's action key E (it was the character wheel
    // when held - Y does that - so missions that ask for E can be played).
    static ButtonMap defaults(){ButtonMap m;m.f={ButtonFunction::Reload,ButtonFunction::Vehicle,ButtonFunction::Jump,ButtonFunction::CharacterWheel,ButtonFunction::Run,ButtonFunction::Context};return m;}
    ButtonFunction of(PhysButton b)const{return f[std::size_t(int(b))];}
    void set(PhysButton b,ButtonFunction v){f[std::size_t(int(b))]=v;}
    bool isDefault()const{return f==defaults().f;}
    // Physical bits (the six actions) -> the function bits the rest of the mod reads. Two buttons may share a function.
    std::uint32_t apply(std::uint32_t physical)const{std::uint32_t out=0;
        for(int i=0;i<physCount;++i)if(physical&physicalBit(PhysButton(i)))out|=functionBit(f[std::size_t(i)]);
        return out;}
    // The first button with this function (the VR menu and the hints name it), or -1.
    int buttonFor(ButtonFunction v)const{for(int i=0;i<physCount;++i)if(f[std::size_t(i)]==v)return i;return -1;}
};

// ---------- A stick used as arrow keys ----------
// Pushed one way: one step at once, again after 0.4 s, then every 0.11 s (like a held arrow key).
// Hysteresis: a push over 0.6 starts it, it holds down to 0.35; another direction over 0.6 takes over.
enum class StickDir { None,Up,Down,Left,Right };
class StickRepeat {
    StickDir held=StickDir::None;std::uint64_t next=0;
public:
    static constexpr float On=.6f,Off=.35f;
    static constexpr std::uint64_t FirstMs=400,RepeatMs=110;
    void reset(){held=StickDir::None;next=0;}
    StickDir holding()const{return held;}
    static StickDir direction(float x,float y,float threshold){
        if(!std::isfinite(x)||!std::isfinite(y))return StickDir::None;
        float ax=std::abs(x),ay=std::abs(y);if(ax<threshold&&ay<threshold)return StickDir::None;
        return ay>=ax?(y>0?StickDir::Up:StickDir::Down):(x>0?StickDir::Right:StickDir::Left);}
    // The step to take now (None most of the time).
    StickDir update(float x,float y,std::uint64_t now){
        StickDir strong=direction(x,y,On);
        if(held==StickDir::None){if(strong==StickDir::None)return StickDir::None;held=strong;next=now+FirstMs;return held;}
        if(strong!=StickDir::None&&strong!=held){held=strong;next=now+FirstMs;return held;}
        if(direction(x,y,Off)!=held){held=StickDir::None;return StickDir::None;}
        if(now>=next){next=now+RepeatMs;return held;}
        return StickDir::None;}
};

// ---------- Key taps for GTA's menus ----------
// A tap holds the key 60 ms (GTA reads the keyboard once per game update, a down+up in between could be lost).
// Scan codes (set 1); Ext = an extended key (arrows, Page Up / Down: not the number pad's).
namespace scan {
constexpr std::uint16_t Esc=0x01,Backspace=0x0E,Q=0x10,E=0x12,Enter=0x1C,P=0x19,Space=0x39,Up=0x48,Left=0x4B,Right=0x4D,Down=0x50,PageUp=0x49,PageDown=0x51;
}
struct KeyTap { std::uint16_t code=0;bool extended=false;std::uint64_t upAt=0; };
class KeyTaps {
    std::array<KeyTap,8> down{};int count=0;
public:
    static constexpr std::uint64_t HoldMs=60;
    int held()const{return count;}
    bool isDown(std::uint16_t code)const{for(int i=0;i<count;++i)if(down[std::size_t(i)].code==code)return true;return false;}
    // True when the key must go down now (false: already down - its tap is made longer - or no room).
    bool press(std::uint16_t code,bool extended,std::uint64_t now,std::uint64_t holdMs=HoldMs){
        for(int i=0;i<count;++i)if(down[std::size_t(i)].code==code){down[std::size_t(i)].upAt=now+holdMs;return false;}
        if(count>=int(down.size()))return false;
        down[std::size_t(count++)]={code,extended,now+holdMs};return true;}
    // Keys whose tap is over (or every key: all=true) go to `up`, oldest first; returns how many.
    template<class F> int release(std::uint64_t now,F&& up,bool all=false){
        int n=0;for(int i=0;i<count;){if(all||now>=down[std::size_t(i)].upAt){up(down[std::size_t(i)]);++n;
                for(int j=i;j+1<count;++j)down[std::size_t(j)]=down[std::size_t(j+1)];--count;}else ++i;}
        return n;}
};
// GTA's pause menu with the controllers: what each control is on the keyboard.
inline std::uint16_t arrowScan(StickDir d){return d==StickDir::Up?scan::Up:d==StickDir::Down?scan::Down:d==StickDir::Left?scan::Left:d==StickDir::Right?scan::Right:0;}

// ---------- The VR menu ----------
struct MenuSettings {
    ButtonMap buttons=ButtonMap::defaults();
    bool snapOn=true;int snapDegrees=30;     // [Motion] SnapTurning / SnapTurnDegrees (the motion add-on reads them)
    bool gtaAim=true;                        // [Weapons] GtaAim (motion add-on)
    bool pauseOnDashboard=true;              // [Menu] PauseOnDashboard (renderer)
    bool wheelFlat=true;                     // [Motion] CharacterWheelView (renderer)
};
enum class MenuItem:int { ButtonY,ButtonX,ButtonA,ButtonB,LeftClick,RightClick,SnapTurn,GtaAim,PauseOnDashboard,WheelView,ResetButtons,Close };
constexpr int menuItemCount=12;
inline PhysButton menuButton(MenuItem i){
    switch(i){case MenuItem::ButtonY:return PhysButton::Y;case MenuItem::ButtonX:return PhysButton::X;case MenuItem::ButtonA:return PhysButton::A;
        case MenuItem::ButtonB:return PhysButton::B;case MenuItem::LeftClick:return PhysButton::LeftClick;default:return PhysButton::RightClick;}}
inline bool isButtonItem(MenuItem i){return int(i)<=int(MenuItem::RightClick);}
constexpr int snapChoices[]={0,15,30,45,60,90};   // 0 = off
inline const char* menuLabel(MenuItem i){
    if(isButtonItem(i))return buttonName(menuButton(i));
    switch(i){case MenuItem::SnapTurn:return "Turn (right stick)";case MenuItem::GtaAim:return "People react to your gun (GTA's aim)";
        case MenuItem::PauseOnDashboard:return "SteamVR menu button pauses GTA";case MenuItem::WheelView:return "Character wheel view";
        case MenuItem::ResetButtons:return "Buttons back to the defaults";case MenuItem::Close:return "Close";default:return "";}}
inline std::string menuValue(MenuItem i,const MenuSettings& s){
    if(isButtonItem(i))return functionName(s.buttons.of(menuButton(i)));
    switch(i){case MenuItem::SnapTurn:return s.snapOn?"snap "+std::to_string(s.snapDegrees)+" degrees":"off";
        case MenuItem::GtaAim:return s.gtaAim?"on":"off";case MenuItem::PauseOnDashboard:return s.pauseOnDashboard?"on":"off";
        case MenuItem::WheelView:return s.wheelFlat?"flat screen":"VR";default:return "";}}
class VrMenu {
    bool isOpen=false;int sel=0;
    static int step(int value,int count,int by){return ((value+by)%count+count)%count;}
public:
    enum class Result { None,Moved,Changed,Reset,Close };
    struct Outcome { Result result=Result::None;MenuItem item=MenuItem::Close; };
    void open(){isOpen=true;sel=0;}
    void close(){isOpen=false;}
    bool opened()const{return isOpen;}
    MenuItem selected()const{return MenuItem(sel);}
    // One step of input: a stick step, A (accept: the value forward / the action), B (back: close).
    Outcome input(StickDir dir,bool accept,bool back,MenuSettings& s){
        Outcome o{};o.item=MenuItem(sel);if(!isOpen)return o;
        if(back){isOpen=false;o.result=Result::Close;return o;}
        if(dir==StickDir::Up||dir==StickDir::Down){sel=step(sel,menuItemCount,dir==StickDir::Up?-1:1);o.item=MenuItem(sel);o.result=Result::Moved;return o;}
        int by=dir==StickDir::Left?-1:(dir==StickDir::Right||accept)?1:0;
        if(!by)return o;
        MenuItem item=MenuItem(sel);
        if(isButtonItem(item)){PhysButton b=menuButton(item);s.buttons.set(b,ButtonFunction(step(int(s.buttons.of(b)),functionCount,by)));o.result=Result::Changed;return o;}
        switch(item){
            case MenuItem::SnapTurn:{int n=int(sizeof(snapChoices)/sizeof(snapChoices[0])),at=0;int cur=s.snapOn?s.snapDegrees:0;
                for(int i=0;i<n;++i)if(snapChoices[i]==cur)at=i;
                int v=snapChoices[step(at,n,by)];s.snapOn=v!=0;if(v)s.snapDegrees=v;o.result=Result::Changed;return o;}
            case MenuItem::GtaAim:s.gtaAim=!s.gtaAim;o.result=Result::Changed;return o;
            case MenuItem::PauseOnDashboard:s.pauseOnDashboard=!s.pauseOnDashboard;o.result=Result::Changed;return o;
            case MenuItem::WheelView:s.wheelFlat=!s.wheelFlat;o.result=Result::Changed;return o;
            case MenuItem::ResetButtons:if(!accept)return o;s.buttons=ButtonMap::defaults();o.result=Result::Reset;return o;
            case MenuItem::Close:if(!accept)return o;isOpen=false;o.result=Result::Close;return o;
            default:return o;}
    }
};
}
