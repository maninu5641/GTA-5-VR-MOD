#pragma once
// 0.13.0: the hand on the gun and the fingers, Pavlov style.
//  - The motion add-on knows the gun; it measures how GTA itself holds that weapon in the
//    character's hand (GTA's weapon object vs a marker on the hand bone, both attachments, read in
//    the same update) and sends the renderer where the hand bone must be so the gun sits in it,
//    relative to the right controller (HandShare). The renderer turns that into the arm IK target.
//  - Fingers: GTA's own per-weapon "grip" poses, blended per arm with an open hand and a fist by
//    the controller's grip value.
//  - Pavlov holsters: the weapons rest on the body where the hand takes them.
// Plain logic, tested in tests/vr_grip_test.cpp.
#include "vr_arms.hpp"
#include "protocol.hpp"
#include <algorithm>
#include <cmath>
#include <cstddef>

namespace handvr {
// A rigid frame: origin and axes (columns) in its parent's space.
struct Frame3 { Vec3 pos{};Rot rot{}; };
inline Frame3 compose(const Frame3& a,const Frame3& b){return {a.pos+apply(a.rot,b.pos),mul(a.rot,b.rot)};}
inline Frame3 inverse(const Frame3& t){Rot r=transpose(t.rot);return {apply(r,t.pos)*-1.0f,r};}
// child expressed in parent's frame (parent * result = child).
inline Frame3 relativeTo(const Frame3& parent,const Frame3& child){return {applyT(parent.rot,child.pos-parent.pos),mul(transpose(parent.rot),child.rot)};}
inline bool finiteFrame(const Frame3& f){return finite(f.pos)&&orthonormalRot(f.rot,.05f);}
// The controller's frame in the world, mapped exactly like the hands and weapons (renderer and motion add-on).
inline Frame3 controllerWorld(const Pose& hand,const Pose& head,Vec3 cameraPosition,const Basis& camera,float scale){
    return {cameraPosition+trackingVectorToWorld(hand.pos()-head.pos(),head,camera)*scale,
            {trackingVectorToWorld(hand.col(0),head,camera),trackingVectorToWorld(hand.col(1),head,camera),trackingVectorToWorld(hand.col(2),head,camera)}};
}
inline Rot rotFromQuaternion(float x,float y,float z,float w){
    float l=std::sqrt(x*x+y*y+z*z+w*w);if(!(l>1e-6f)||!std::isfinite(l))return {};
    x/=l;y/=l;z/=l;w/=l;
    return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};
}
// HandShare <-> the right hand bone target relative to the right controller.
inline void packRight(HandShare& s,const Frame3& rel){
    s.rightPos[0]=rel.pos.x;s.rightPos[1]=rel.pos.y;s.rightPos[2]=rel.pos.z;
    Quaternion q=quaternion(rel.rot.x,rel.rot.y,rel.rot.z);s.rightRot[0]=q.x;s.rightRot[1]=q.y;s.rightRot[2]=q.z;s.rightRot[3]=q.w;
}
inline bool unpackRight(const HandShare& s,Frame3& rel){
    if(!(s.flags&RightTarget))return false;
    rel.pos={s.rightPos[0],s.rightPos[1],s.rightPos[2]};rel.rot=rotFromQuaternion(s.rightRot[0],s.rightRot[1],s.rightRot[2],s.rightRot[3]);
    return finite(rel.pos)&&length(rel.pos)<.6f&&orthonormalRot(rel.rot,.02f);
}
// Fresh = written by the motion add-on within the last 250 ms.
inline bool freshShare(const HandShare& s,std::uint64_t now){return s.timeMs&&now>=s.timeMs&&now-s.timeMs<250;}

// ---------- 0.15.7: the weapon in the character's hand ----------
// The weapon object's axes as the add-on sets them from a weapon pose (x = the barrel turned by ModelYawDegrees,
// y = the gun's left, z = its top), and back: the pose of a weapon object that sits in the character's hand.
inline Frame3 objectFromPose(const WeaponPose& p,float modelYawDegrees){
    float a=rad(modelYawDegrees),c=std::cos(a),s=std::sin(a);
    return {p.grip,{p.forward*c+p.right*s,p.right*-c+p.forward*s,p.up}};
}
inline WeaponPose poseFromObject(const Frame3& o,float modelYawDegrees){
    float a=rad(modelYawDegrees),c=std::cos(a),s=std::sin(a);
    return {o.pos,unit(o.rot.x*c+o.rot.y*s),unit(o.rot.x*s-o.rot.y*c),unit(o.rot.z)};
}
// How far the weapon in the hand is from where the controller points it: metres (grip) and degrees (barrel).
struct HoldMiss { float metres=NAN,degrees=NAN; };
inline HoldMiss holdMiss(const WeaponPose& seen,const WeaponPose& wanted){
    HoldMiss m;if(!finite(seen.grip)||!finite(wanted.grip)||!finite(seen.forward)||!finite(wanted.forward))return m;
    m.metres=length(seen.grip-wanted.grip);
    m.degrees=std::acos(std::clamp(dot(unit(seen.forward),unit(wanted.forward)),-1.0f,1.0f))*180/pi;return m;
}
// The arm IK takes the hand (and the weapon in it) where the controller points the weapon. Far off for a while (the
// arm is GTA's: an animation, out of reach for long, the IK off) -> the weapon floats at the controller again
// (0.15.6) for a while. Smoothed (fast moves lag a frame); not judged in the first 1.2 s after it was put in the hand.
class HoldWatch {
    std::uint64_t since=0,badSince=0;float ePos=NAN,eDeg=NAN;
public:
    static constexpr float FarMetres=.20f,FarDegrees=50;
    static constexpr std::uint64_t SettleMs=1200,BadMs=1500;
    void reset(std::uint64_t now){since=now;badSince=0;ePos=eDeg=NAN;}
    float metres()const{return ePos;}
    float degrees()const{return eDeg;}
    // turn: the barrel's direction counts (guns, melee); a grenade only by its place. true = give up for now.
    bool update(const HoldMiss& m,bool turn,std::uint64_t now){
        if(!std::isfinite(m.metres))return false;
        auto ema=[](float& v,float x){v=std::isfinite(v)?v*.85f+x*.15f:x;};
        ema(ePos,m.metres);if(std::isfinite(m.degrees))ema(eDeg,m.degrees);
        if(now<since+SettleMs){badSince=0;return false;}
        bool off=ePos>FarMetres||(turn&&std::isfinite(eDeg)&&eDeg>FarDegrees);
        if(!off){badSince=0;return false;}
        if(!badSince)badSince=now;
        return now-badSince>=BadMs;
    }
};

// ---------- 0.15.8: the gun in the hand the way GTA holds it ----------
// GTA's rotation order 2 (EULER_YXZ: the camera's, and ATTACH_ENTITY_TO_ENTITY's last argument): (x, y, z) degrees
// = Rz(z) * Rx(x) * Ry(y), what cameraBasis builds (right, forward, up). eulerYXZ: the angles of a rotation
// (r.x = right, r.y = forward, r.z = up); rotYXZ: back.
inline Rot rotYXZ(Vec3 e){Basis b=cameraBasis(e);return {b.right,b.forward,b.up};}
inline Vec3 eulerYXZ(const Rot& r){
    float sp=std::clamp(r.y.z,-1.0f,1.0f),pitch=std::asin(sp),yaw,roll;
    if(std::abs(sp)<.99999f){yaw=std::atan2(-r.y.x,r.y.y);roll=std::atan2(-r.x.z,r.z.z);}
    else{roll=0;yaw=std::atan2(r.x.y,r.x.x);}   // forward straight up / down: the whole turn is the yaw
    constexpr float d=180.0f/pi;return {pitch*d,roll*d,yaw*d};
}
// The gun attached GTA's way, checked once against GTA's grip as read (the attachment as measured, after 0.5 s):
// 8 updates within 2.5 cm / 12 deg = it matches; 8 outside = it does not (then the prop bone again, 0.15.7).
class GripMatch {
    std::uint64_t since=0;int good=0,bad=0;bool done=false;
public:
    static constexpr std::uint64_t WaitMs=500;static constexpr float Metres=.025f,Degrees=12;static constexpr int Needed=8;
    void reset(std::uint64_t now){since=now;good=bad=0;done=false;}
    // 1 = it matches, -1 = it does not (each once), 0 = not decided (yet).
    int update(float metres,float degrees,std::uint64_t now){
        if(done||now<since+WaitMs||!std::isfinite(metres)||!std::isfinite(degrees))return 0;
        if(metres<=Metres&&degrees<=Degrees)++good;else ++bad;
        if(good>=Needed){done=true;return 1;}
        if(bad>=Needed){done=true;return -1;}
        return 0;
    }
};

// Average of a rigid transform measured several times; samples must agree (1.5 cm / 4 deg) with the first.
class FrameAverage {
    Vec3 sum{};RotAverage rot;Frame3 first{};unsigned n=0;
public:
    static constexpr unsigned Needed=4;
    void reset(){sum={};rot.reset();n=0;}
    unsigned count()const{return n;}
    bool ready()const{return n>=Needed;}
    bool add(const Frame3& f){
        if(!finiteFrame(f))return false;
        if(n&&(length(f.pos-first.pos)>.015f||rotAngleDegrees(first.rot,f.rot)>4)){reset();}
        if(!n)first=f;
        sum=sum+f.pos;rot.add(f.rot);++n;return true;
    }
    Frame3 mean()const{return n?Frame3{sum*(1.0f/float(n)),rot.mean()}:Frame3{};}
};

// Which of GTA's grip poses the hand needs for a weapon (groups: 0 melee, 1 pistols, 2 SMGs, 3 rifles,
// 4 machine guns, 5 shotguns, 6 snipers, 7 heavy / thrown).
inline GripClass gripClassFor(int group,bool melee,bool thrown,bool utility,bool twoHandedMelee,bool unarmed){
    if(unarmed||utility)return GripNone;
    if(thrown)return GripThrown;
    if(melee)return twoHandedMelee?GripMelee2h:GripMelee1h;
    switch(group){case 1:return GripPistol;case 2:return GripSmg;case 6:return GripSniper;default:return GripRifle;}
}
// Blend weights of a hand's three clips: open hand, fist, grip pose of what it holds.
struct FingerWeights { float open=1,fist=0,grip=0; };
inline FingerWeights fingerWeights(GripClass hold,float squeeze){
    if(hold==GripFist)return {0,1,0};
    if(hold!=GripNone)return {0,0,1};
    float g=std::clamp(std::isfinite(squeeze)?squeeze:0.0f,0.0f,1.0f);
    return {1-g,g,0};
}
// The grip value, smoothed: fingers close quickly (60 ms) and open a little slower (100 ms).
class SqueezeFilter {
    float v=0;bool primed=false;
public:
    void reset(){v=0;primed=false;}
    float value()const{return v;}
    float update(float raw,float dt){
        if(!std::isfinite(raw))raw=0;raw=std::clamp(raw,0.0f,1.0f);
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        if(!primed){v=raw;primed=true;return v;}
        float tau=raw>v?.06f:.10f;v+=(raw-v)*std::min(1.0f,dt/tau);return v;
    }
};
// Animation clips (dictionary, clip) for each pose, first choice first; all base-game Story Mode
// dictionaries (names checked against DurtyFree's animDictsCompact dump).
struct ClipRef { const char* dict;const char* clip; };
inline bool sameClip(const ClipRef& a,const ClipRef& b){auto eq=[](const char* x,const char* y){if(!x||!y)return x==y;for(;*x&&*x==*y;++x,++y){}return *x==*y;};return eq(a.dict,b.dict)&&eq(a.clip,b.clip);}
inline int clipCandidates(GripClass c,ClipRef* out){
    int n=0;auto add=[&](const char* d,const char* a){out[n++]={d,a};};
    switch(c){
        case GripNone:add("anim@heists@box_carry@","idle");add("anim@heists@prison_heistig1_p1_guard_checks_bus","loop");break;   // open hand
        case GripFist:add("weapons@melee_1h","grip_idle");add("weapons@projectile@","grip_idle");break;
        case GripPistol:add("weapons@pistol@","grip");add("move_jump@weapons@pistol","hand_grip");break;
        case GripSmg:add("weapons@rifle@lo@smg","grip");add("weapons@pistol@","grip");break;
        case GripRifle:add("weapons@rifle@lo@shotgun_assault","grip");add("weapons@rifle@lo@smg","grip");add("weapons@pistol@","grip");break;
        case GripSniper:add("weapons@rifle@hi@sniper_rifle","grip");add("weapons@rifle@lo@shotgun_assault","grip");add("weapons@pistol@","grip");break;
        case GripMelee1h:add("weapons@melee_1h","grip_idle");break;
        case GripMelee2h:add("weapons@melee_2h","grip_idle");add("weapons@melee_1h","grip_idle");break;
        case GripThrown:add("weapons@projectile@","grip_idle");add("move_jump@weapons@projectile@grenade","hand_grip");add("weapons@melee_1h","grip_idle");break;
    }
    return n;
}
inline const char* gripName(GripClass c){
    switch(c){case GripPistol:return "pistol grip";case GripSmg:return "SMG grip";case GripRifle:return "rifle grip";case GripSniper:return "sniper grip";
        case GripMelee1h:return "melee grip";case GripMelee2h:return "two-handed melee grip";case GripThrown:return "grenade grip";case GripFist:return "fist";default:return "open hand";}
}
// TASK_SCRIPTED_ANIMATION's data for one priority level: 22 script slots of 8 bytes. The dictionary and
// clip names are string pointers (GTA 1.0.3889's own scripts fill .f_1 / .f_2 with string constants and
// compare them with ARE_STRINGS_EQUAL; Script Hook V mods pass the same layout). type 0 = empty slot,
// 1 = one clip, 2 = a blend of three clips (a weight per clip, changed later with SET_ANIM_WEIGHT).
struct ScriptedAnimData {
    std::int32_t type=0,pad0=0;                                                  // slot 0
    struct Clip { const char* dict="";const char* anim="";float phase=0;std::int32_t pad1=0;float rate=1;std::int32_t pad2=0;float weight=1;std::int32_t pad3=0; } clip[3];   // slots 1-15
    std::int32_t filter=0,pad4=0;float blendIn=.125f;std::int32_t pad5=0;float blendOut=.125f;std::int32_t pad6=0;   // slots 16-18
    std::int32_t timeToPlay=-1,pad7=0,flags=0,pad8=0,ikFlags=0,pad9=0;           // slots 19-21
};
static_assert(sizeof(void*)!=8||sizeof(ScriptedAnimData)==176,"TASK_SCRIPTED_ANIMATION data must be 22 script slots");
static_assert(sizeof(void*)!=8||(offsetof(ScriptedAnimData,clip)==8&&offsetof(ScriptedAnimData,filter)==128&&offsetof(ScriptedAnimData,flags)==160&&offsetof(ScriptedAnimData,ikFlags)==168),"slot layout");
// One arm: three frozen clips (rate 0) blended with the given weights, filtered to that arm.
// The clip names must outlive the call (string literals).
inline ScriptedAnimData armBlend(const ClipRef (&clips)[3],const float (&phases)[3],const FingerWeights& w,std::int32_t filterHash,std::int32_t flags){
    ScriptedAnimData d;d.type=2;d.filter=filterHash;d.flags=flags;
    const float weights[3]={w.open,w.fist,w.grip};
    for(int i=0;i<3;++i){d.clip[i].dict=clips[i].dict?clips[i].dict:"";d.clip[i].anim=clips[i].clip?clips[i].clip:"";
        d.clip[i].phase=std::isfinite(phases[i])?std::clamp(phases[i],0.0f,1.0f):0.0f;d.clip[i].rate=0;d.clip[i].weight=weights[i];}
    return d;
}
inline ScriptedAnimData armBlend(const ClipRef (&clips)[3],const FingerWeights& w,std::int32_t filterHash,std::int32_t flags){
    const float zero[3]={0,0,0};return armBlend(clips,zero,w,filterHash,flags);
}
// 0.14.0: one frozen clip on one arm (the hand check).
inline ScriptedAnimData armSingle(const ClipRef& clip,float phase,std::int32_t filterHash,std::int32_t flags){
    ScriptedAnimData d;d.type=1;d.filter=filterHash;d.flags=flags;
    d.clip[0].dict=clip.dict?clip.dict:"";d.clip[0].anim=clip.clip?clip.clip:"";d.clip[0].phase=std::isfinite(phase)?std::clamp(phase,0.0f,1.0f):0.0f;d.clip[0].rate=0;d.clip[0].weight=1;
    return d;
}
// The scripted-animation flags used for the fingers: loop | not interruptable | upper body | secondary
// (the player keeps control of the legs). No AF_HIDE_WEAPON: the motion add-on's weapons are objects.
constexpr std::int32_t FingerAnimFlags=1|8|16|32;
// How far a finger is bent: 0 = straight (its joints in a line), larger = curled. Joints from the
// knuckle (b0) to the last joint (b2) and the hand bone (wrist).
inline float fingerCurl(Vec3 wrist,Vec3 b0,Vec3 b1,Vec3 b2){
    if(!finite(wrist)||!finite(b0)||!finite(b1)||!finite(b2))return NAN;
    float chain=length(b0-wrist)+length(b1-b0)+length(b2-b1);if(!(chain>.02f))return NAN;
    return std::clamp(1-length(b2-wrist)/chain,0.0f,1.0f);
}
// The finger check: does a clip really move a hand's fingers? Open pose, then fist pose, a few frames
// each; the mean curl of the fingers must change by Needed.
class FingerCheck {
public:
    enum class Stage { Idle,Open,Fist,Done };
    static constexpr float Settle=.35f,Needed=.06f;
private:
    Stage s=Stage::Idle;float t=0,open[2]{},fist[2]{};int nOpen[2]{},nFist[2]{};
public:
    void start(){s=Stage::Open;t=0;for(int i=0;i<2;++i){open[i]=fist[i]=0;nOpen[i]=nFist[i]=0;}}
    void reset(){s=Stage::Idle;t=0;}
    Stage stage()const{return s;}
    bool running()const{return s==Stage::Open||s==Stage::Fist;}
    // The pose this frame should show: true = fist.
    bool wantFist()const{return s==Stage::Fist;}
    // curl[hand] measured this frame (NaN = not readable). Returns true when it finished this frame.
    bool update(float dt,const float (&curl)[2]){
        if(!running())return false;if(!(dt>=0)||!std::isfinite(dt))dt=0;t+=std::min(dt,.1f);
        bool sampling=t>Settle*.6f;
        for(int i=0;i<2;++i)if(sampling&&std::isfinite(curl[i])){if(s==Stage::Open){open[i]+=curl[i];++nOpen[i];}else{fist[i]+=curl[i];++nFist[i];}}
        if(t<Settle)return false;
        t=0;if(s==Stage::Open){s=Stage::Fist;return false;}
        s=Stage::Done;return true;
    }
    float openCurl(int i)const{return nOpen[i]?open[i]/nOpen[i]:NAN;}
    float fistCurl(int i)const{return nFist[i]?fist[i]/nFist[i]:NAN;}
    // The fist clip closes this hand (unknown = not measurable counts as working).
    bool closes(int i)const{float a=openCurl(i),b=fistCurl(i);return !std::isfinite(a)||!std::isfinite(b)||b-a>=Needed;}
    bool measured(int i)const{return std::isfinite(openCurl(i))&&std::isfinite(fistCurl(i));}
};
// Fist poses for each hand, first choice first (the left hand needs a clip with left-hand fingers:
// two-handed grips first).
inline int fistCandidates(int hand,ClipRef* out){
    int n=0;auto add=[&](const char* d,const char* a){out[n++]={d,a};};
    if(hand==0){add("weapons@melee_2h","grip_idle");add("weapons@rifle@lo@shotgun_assault","grip");add("weapons@melee_1h","grip_idle");}
    else{add("weapons@melee_1h","grip_idle");add("weapons@melee_2h","grip_idle");add("weapons@projectile@","grip_idle");}
    return n;
}

// ---------- 0.14.0: fingers v2 - GTA's own hand shapes, checked on the character ----------
// The 0.13.0 video: the hands stayed open with every clip. 0.14.0 first plays a short hand check
// (both hands, one pose after another, ~5 s) and reads the finger bones of each pose; only poses
// that really bend the fingers are used. nm@hands are the hand shapes GTA's ragdoll (Natural
// Motion) uses: natural, fist, grab, middle finger...
enum class PoseRole : std::uint8_t { Open,Fist,Grab,WeaponGrip,MiddleFinger,ThumbsUp,Point };
// filter: 0 = each arm (BONEMASK_ARMONLY_L / R), 1 = GTA's hand grip filters (Grip_L / R_Only_filter),
// 2 = none (the upper body: both hands the same). The last two poses check the filters themselves.
struct SurveyPose { ClipRef clip;float phase;PoseRole role;GripClass grip;int filter; };
constexpr int MaxSurveyPoses=20;
inline int surveyPoses(SurveyPose* out){
    int n=0;auto add=[&](const char* d,const char* c,float phase,PoseRole r,GripClass g=GripNone,int filter=0){out[n++]={{d,c},phase,r,g,filter};};
    add("anim@heists@box_carry@","idle",0,PoseRole::Open);   // first: it also holds the arms still (no walk swing, as 0.12.0)
    add("nm@hands","natural",0,PoseRole::Open);
    add("nm@hands","flat_floor",0,PoseRole::Open);
    add("nm@hands","fist",0,PoseRole::Fist);
    add("weapons@melee_1h","grip_idle",0,PoseRole::Fist);
    add("weapons@melee_2h","grip_idle",0,PoseRole::Fist);
    add("nm@hands","grab",0,PoseRole::Grab);
    add("weapons@pistol@","grip",0,PoseRole::WeaponGrip,GripPistol);
    add("weapons@rifle@lo@smg","grip",0,PoseRole::WeaponGrip,GripSmg);
    add("weapons@rifle@lo@shotgun_assault","grip",0,PoseRole::WeaponGrip,GripRifle);
    add("weapons@rifle@hi@sniper_rifle","grip",0,PoseRole::WeaponGrip,GripSniper);
    add("weapons@projectile@","grip_idle",0,PoseRole::WeaponGrip,GripThrown);
    add("nm@hands","middle_finger",0,PoseRole::MiddleFinger);
    add("timetable@mime@ig_2","thumbs_up",.5f,PoseRole::ThumbsUp);
    add("cellphone@self@michael@","finger_point",.5f,PoseRole::Point);
    add("nm@hands","fist",0,PoseRole::Fist,GripNone,1);
    add("nm@hands","fist",0,PoseRole::Fist,GripNone,2);
    return n;
}
// How bent a two-joint chain is (the thumb): 0 = straight.
inline float chainBend(Vec3 a,Vec3 b,Vec3 c){
    if(!finite(a)||!finite(b)||!finite(c))return NAN;float l=length(b-a)+length(c-b);if(!(l>.01f))return NAN;
    return std::clamp(1-length(c-a)/l,0.0f,1.0f);
}
// Finger bends of one hand: thumb, index, middle, ring.
struct FingerCurls { float f[4]{NAN,NAN,NAN,NAN};
    float closed()const{float s=0;int n=0;for(int k=1;k<4;++k)if(std::isfinite(f[k])){s+=f[k];++n;}return n?s/n:NAN;}
    bool valid()const{return std::isfinite(closed());} };
// The hand check: each pose is held Hold seconds; the fingers are read in the last part.
class FingerSurvey {
public:
    static constexpr float Hold=.40f,SampleFrom=.24f;
private:
    int n=0,at=-1;float t=0;
    struct Acc { float sum[4]{};int count[4]{}; };Acc acc[MaxSurveyPoses][2];
public:
    void start(int poses){n=std::clamp(poses,0,MaxSurveyPoses);at=n?0:-1;t=0;for(auto& p:acc)for(auto& h:p)h=Acc{};}
    void reset(){at=-1;t=0;}
    bool running()const{return at>=0&&at<n;}
    int current()const{return running()?at:-1;}
    int poses()const{return n;}
    void skip(){if(running()){++at;t=0;if(at>=n)at=n;}}   // a pose whose clip does not load
    // 0 = same pose, 1 = next pose (play it), 2 = finished.
    int update(float dt,const FingerCurls (&c)[2]){
        if(!running())return 0;if(!(dt>=0)||!std::isfinite(dt))dt=0;t+=std::min(dt,.1f);
        if(t>=SampleFrom)for(int h=0;h<2;++h)for(int k=0;k<4;++k)if(std::isfinite(c[h].f[k])){acc[at][h].sum[k]+=c[h].f[k];++acc[at][h].count[k];}
        if(t<Hold)return 0;
        t=0;++at;return at>=n?2:1;
    }
    FingerCurls result(int pose,int hand)const{FingerCurls r;if(pose<0||pose>=n||hand<0||hand>1)return r;
        for(int k=0;k<4;++k)if(acc[pose][hand].count[k])r.f[k]=acc[pose][hand].sum[k]/acc[pose][hand].count[k];return r;}
};
// What the check found for one hand: the clip (and phase) for each use, -1 = none works.
struct HandChoice {
    int open=-1,fist=-1,grab=-1,middle=-1,thumbs=-1,point=-1;int grip[9]{-1,-1,-1,-1,-1,-1,-1,-1,-1};
    float openClosed=NAN;bool anyChange=false;
    int borrowed[9]{-1,-1,-1,-1,-1,-1,-1,-1,-1};   // 0.15.8: the gun whose grip clip this one uses (its own did not close the hand)
};
// 0.15.8 [Hands] PistolGrip: Auto = the pistol's own grip clip when it closes the hand; Rifle = always the rifle's.
enum class PistolGrip : std::uint8_t { Auto,Rifle };
constexpr float CloseNeeded=.06f,GripNeeded=.04f;
inline HandChoice chooseHand(const SurveyPose* poses,int n,const FingerSurvey& s,int hand,PistolGrip pistol=PistolGrip::Auto){
    HandChoice c;FingerCurls open;
    for(int i=0;i<n&&c.open<0;++i)if(poses[i].role==PoseRole::Open&&poses[i].filter==0){auto r=s.result(i,hand);if(r.valid()){c.open=i;open=r;}}   // the first that plays (the list order is the preference)
    if(c.open<0)return c;c.openClosed=open.closed();
    float bestFist=CloseNeeded,bestGrab=GripNeeded;
    for(int i=0;i<n;++i){if(poses[i].filter!=0)continue;auto r=s.result(i,hand);if(!r.valid())continue;float gain=r.closed()-open.closed();if(std::abs(gain)>=GripNeeded)c.anyChange=true;
        switch(poses[i].role){
            case PoseRole::Fist:if(gain>=bestFist){bestFist=gain;c.fist=i;}break;
            case PoseRole::Grab:if(gain>=bestGrab){bestGrab=gain;c.grab=i;}break;
            case PoseRole::WeaponGrip:if(gain>=GripNeeded&&poses[i].grip<9&&c.grip[poses[i].grip]<0)c.grip[poses[i].grip]=i;break;
            case PoseRole::MiddleFinger:{float mid=r.f[2]-open.f[2],others=(r.f[1]+r.f[3])*.5f-(open.f[1]+open.f[3])*.5f;
                if(std::isfinite(mid)&&std::isfinite(others)&&mid<=.04f&&others>=.08f)c.middle=i;break;}
            case PoseRole::ThumbsUp:{float thumb=r.f[0]-open.f[0];if(std::isfinite(thumb)&&thumb<=.03f&&gain>=.08f)c.thumbs=i;break;}
            case PoseRole::Point:{float index=r.f[1]-open.f[1],others=(r.f[2]+r.f[3])*.5f-(open.f[2]+open.f[3])*.5f;
                if(std::isfinite(index)&&std::isfinite(others)&&index<=.04f&&others>=.08f)c.point=i;break;}
            default:break;
        }
    }
    if(c.grab<0)c.grab=c.fist;   // something that closes the hand around a handle
    if(c.fist<0)c.fist=c.grab;
    // 0.15.8 (the friend's 0.15.7 video: a claw on the pistol, the rifles held right): a gun whose own grip clip did not
    // close the hand takes another gun's (the rifle's first: the hand around a pistol grip, the index finger at the
    // trigger) - not the claw (nm@hands grab). PistolGrip=Rifle: the pistol takes the rifle's in any case.
    constexpr GripClass guns[]={GripRifle,GripSmg,GripPistol,GripSniper};
    if(pistol==PistolGrip::Rifle&&c.grip[GripRifle]>=0&&c.grip[GripPistol]!=c.grip[GripRifle]){c.grip[GripPistol]=c.grip[GripRifle];c.borrowed[GripPistol]=GripRifle;}
    for(GripClass g:guns)if(c.grip[g]<0)for(GripClass from:guns)if(from!=g&&c.grip[from]>=0&&c.borrowed[from]<0){c.grip[g]=c.grip[from];c.borrowed[g]=from;break;}
    for(int g=0;g<9;++g)if(c.grip[g]<0)c.grip[g]=c.grab;
    return c;
}
// How much a filter-check pose (filter 1 or 2) closes a hand compared with its open pose.
inline float filterGain(const SurveyPose* poses,int n,const FingerSurvey& s,int hand,int filter,int openPose){
    if(openPose<0)return NAN;auto open=s.result(openPose,hand);
    for(int i=0;i<n;++i)if(poses[i].filter==filter){auto r=s.result(i,hand);if(r.valid()&&open.valid())return r.closed()-open.closed();}
    return NAN;
}
// The clip a hand shows besides open / fist: what it holds, else a gesture of the player's fingers.
// Gestures (from SteamVR's finger curls): 0 none, 1 thumbs up, 2 point (finger gun too), 3 middle finger.
inline int specialPose(const HandChoice& c,GripClass hold,int gesture){
    if(hold==GripFist)return c.grab>=0?c.grab:c.fist;
    if(hold!=GripNone&&hold<9)return c.grip[hold];
    switch(gesture){case 1:return c.thumbs;case 2:return c.point;case 3:return c.middle;default:return -1;}
}
// A gesture must be seen for a short while before the hand changes (SteamVR's estimates flicker).
class GestureHold {
    int shown=0,candidate=0;float t=0;
public:
    static constexpr float Settle=.15f;
    void reset(){shown=candidate=0;t=0;}
    int value()const{return shown;}
    int update(int g,float dt){if(!(dt>=0)||!std::isfinite(dt))dt=0;
        if(g==shown){candidate=g;t=0;return shown;}
        if(g!=candidate){candidate=g;t=0;}
        t+=dt;if(t>=Settle){shown=candidate;t=0;}
        return shown;}
};

// Pavlov holsters: axes of a weapon resting in a holster (x = barrel, y = the gun's left, z = its top),
// from the body's right / forward / up. Pistol and melee: barrel down, grip backwards (hip holster);
// grenade on the chest; long guns on the back, barrel down across it, the grip at the shoulder.
inline Rot holsterAxes(int holster,Vec3 right,Vec3 forward,Vec3 up){
    Vec3 x,z;
    switch(holster){
        case 0:case 1:x=up*-1.0f;z=forward;break;                               // right / left hip
        case 2:x=forward;z=up;break;                                              // chest
        case 3:x=unit(up*-.8f-right*.6f);z=forward*-1.0f;break;                   // right shoulder (back)
        case 4:x=unit(up*-.8f+right*.6f);z=forward*-1.0f;break;                   // left shoulder (back)
        default:return {};
    }
    z=unit(z-x*dot(z,x));return {x,cross(z,x),z};
}
}
