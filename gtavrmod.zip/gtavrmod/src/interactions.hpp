#pragma once
#include "core.hpp"
#include <deque>
#include <string>

namespace handvr {
// 0.5.0: the magazine reload lives in weapons_vr.hpp (MagazineReload).
class HandMotion {
    struct Sample { std::uint64_t time;Vec3 p; };
    std::deque<Sample> samples;
public:
    void reset() { samples.clear(); }
    Vec3 update(Vec3 position,std::uint64_t time) {
        if(!finite(position)) { reset();return {}; }
        if(!samples.empty()) {
            auto last=samples.back();
            if(time<=last.time) return velocity();
            float dt=float(time-last.time)*.001f;
            if(dt>.2f||length(position-last.p)>std::max(.12f,dt*18)) reset();
        }
        samples.push_back({time,position});
        while(samples.size()>2&&time-samples.front().time>90) samples.pop_front();
        return velocity();
    }
    Vec3 velocity() const {
        if(samples.size()<2) return {};
        float dt=float(samples.back().time-samples.front().time)*.001f;
        if(dt<.008f) return {};
        Vec3 v=(samples.back().p-samples.front().p)*(1/dt);
        return length(v)>12?unit(v)*12:v;
    }
};
class SwingGate {
    bool armed=false;
    std::uint64_t next=0;
public:
    void reset() { armed=false;next=0; }
    bool update(float speed,bool contact,std::uint64_t now,float threshold=1.1f) {
        if(!std::isfinite(speed)) { reset();return false; }
        if(speed<.45f) armed=true;
        if(armed&&speed>=threshold&&contact&&now>=next) { armed=false;next=now+400;return true; }
        return false;
    }
};
// ---- Localized punches (0.4.0) ----
// The fist's capsule sweep hits the target's ragdoll bounds; the nearest skeleton
// bone to the contact point decides the body region, damage and reaction.
enum class HitRegion { Head,Neck,Torso,Arm,Leg };
struct BodyBone { int id;HitRegion region; };
// GTA ped bone IDs (alloc8or nativedb, GET_PED_BONE_INDEX).
constexpr BodyBone bodyBones[]={
    {31086,HitRegion::Head},{39317,HitRegion::Neck},
    {24818,HitRegion::Torso},{24817,HitRegion::Torso},{24816,HitRegion::Torso},{23553,HitRegion::Torso},{11816,HitRegion::Torso},
    {64729,HitRegion::Torso},{10706,HitRegion::Torso},
    {45509,HitRegion::Arm},{40269,HitRegion::Arm},{61163,HitRegion::Arm},{28252,HitRegion::Arm},{18905,HitRegion::Arm},{57005,HitRegion::Arm},
    {58271,HitRegion::Leg},{51826,HitRegion::Leg},{63931,HitRegion::Leg},{36864,HitRegion::Leg}};
constexpr std::size_t bodyBoneCount=sizeof(bodyBones)/sizeof(bodyBones[0]);
inline const char* regionName(HitRegion r){switch(r){case HitRegion::Head:return "head";case HitRegion::Neck:return "neck";case HitRegion::Torso:return "torso";case HitRegion::Arm:return "arm";default:return "leg";}}
// Index of the bone closest to `hit`, or -1 when no position is usable.
inline int nearestBone(const Vec3* positions,std::size_t count,Vec3 hit){
    int best=-1;float bestDistance=1e9f;if(!finite(hit))return -1;
    for(std::size_t i=0;i<count;++i){if(!finite(positions[i])||length(positions[i])<1e-3f)continue;float d=length(positions[i]-hit);if(d<bestDistance){bestDistance=d;best=int(i);}}
    return bestDistance<1.5f?best:-1;
}
struct PunchOutcome { HitRegion region=HitRegion::Torso;int damage=0;bool ragdoll=false;int ragdollType=0,ragdollMs=0;float impulse=0; };
// speed: fist speed in m/s at contact (swing threshold 1.1 m/s, full power 4 m/s).
inline PunchOutcome punchOutcome(float speed,HitRegion region,int baseDamage,float forceScale=1){
    PunchOutcome o;o.region=region;if(!std::isfinite(speed)||speed<0)speed=0;
    float power=std::clamp((speed-1.1f)/(4.0f-1.1f),0.0f,1.0f);
    float multiplier=region==HitRegion::Head?2.2f:region==HitRegion::Neck?1.7f:region==HitRegion::Torso?1.0f:region==HitRegion::Arm?.55f:.7f;
    o.damage=std::clamp(int(std::lround(float(std::max(baseDamage,1))*(.55f+.9f*power)*multiplier)),1,150);
    bool high=region==HitRegion::Head||region==HitRegion::Neck;
    if(high&&speed>=2.3f){o.ragdoll=true;o.ragdollType=0;o.ragdollMs=1400+int(1200*power);}          // knock down
    else if(region==HitRegion::Torso&&speed>=3.2f){o.ragdoll=true;o.ragdollType=0;o.ragdollMs=900+int(600*power);}
    else if(speed>=2.4f){o.ragdoll=true;o.ragdollType=3;o.ragdollMs=450;}                               // stumble, may stay up
    float regionForce=high?1.2f:region==HitRegion::Arm?.6f:region==HitRegion::Leg?.8f:1.0f;
    o.impulse=o.ragdoll?std::clamp(forceScale,0.0f,3.0f)*(4+10*power)*regionForce:0;
    return o;
}
struct ThrowResult { bool released=false;Vec3 velocity{}; };
class ThrowGesture {
    bool previousGrip=false,primed=false,blocked=true;
public:
    bool held=false;
    void reset() { previousGrip=false;primed=false;held=false;blocked=true; }
    ThrowResult update(bool grip,bool trigger,bool valid,bool hasAmmo,Vec3 velocity) {
        if(!valid) { reset();return {}; }
        if(!grip&&!trigger) blocked=false;
        bool press=grip&&!previousGrip,release=!grip&&previousGrip;previousGrip=grip;
        if(blocked) return {};
        if(press&&hasAmmo) { held=true;primed=false; }
        if(held&&trigger) primed=true;
        if(release&&held) {
            held=false;bool throwNow=primed;primed=false;
            if(throwNow&&finite(velocity)) return {true,length(velocity)>12?unit(velocity)*12:velocity};
        }
        return {};
    }
};
inline bool oneHandAllowed(int group) { return group==1||group==3; }
inline float wrapRadians(float a) { while(a>pi)a-=2*pi;while(a< -pi)a+=2*pi;return a; }
class WheelSteering {
    bool active=false;
    float previousAngle=0,accumulated=0;
public:
    void reset() { active=false;previousAngle=0;accumulated=0; }
    float update(float x,float y,bool gripping,float lockDegrees=90) {
        if(!gripping||!std::isfinite(x)||!std::isfinite(y)||x*x+y*y<.0025f) { reset();return 0; }
        float angle=std::atan2(y,x);
        if(!active) { active=true;previousAngle=angle;accumulated=0;return 0; }
        accumulated+=wrapRadians(angle-previousAngle);previousAngle=angle;
        accumulated=std::clamp(accumulated,-rad(lockDegrees),rad(lockDegrees));
        return std::clamp(-accumulated/rad(lockDegrees),-1.0f,1.0f);
    }
};
}
