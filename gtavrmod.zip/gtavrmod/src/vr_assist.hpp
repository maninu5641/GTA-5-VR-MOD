#pragma once
// 0.15.7: the friend's requests after the 0.15.6 videos.
//  - "Pull the right stick up: the phone comes up - everywhere in the game" (PhoneStickUp).
//  - The prologue's shoot-out by the crates: "make the character take cover next to the boxes, in this mission only"
//    (prologueCover, AutoCover).
//  - "When you kill a person the character gets a little health back" (healAfterKill).
// Plain logic, tested in tests/vr_assist_test.cpp; the GTA calls are in mod_assist.inc.
#include "core.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace handvr {
// ---------- the phone on the right stick ----------
// Phone away: a flick up (from the centre) takes it out (GTA's INPUT_PHONE). Phone up: a flick up is GTA's arrow up
// in it (the phone's own navigation, mod_interactions.inc), and the stick held up 0.7 s puts it away (GTA's "back"
// until the phone is gone). Sideways and diagonal pushes do nothing here (snap turn).
class PhoneStickUp {
    bool armed=false,holding=false,done=false;std::uint64_t upSince=0;
public:
    static constexpr float On=.75f,Centre=.35f;
    static constexpr std::uint64_t HoldMs=700;
    enum class Act { None,TakeOut,PutAway };
    void reset(){armed=false;holding=false;done=false;upSince=0;}
    static bool up(float x,float y){return std::isfinite(x)&&std::isfinite(y)&&y>On&&y>1.5f*std::abs(x);}
    // phoneUp: GTA's phone is in the hand (its task runs). allowed: no wheel / menu uses the stick now.
    Act update(float x,float y,bool phoneUp,bool allowed,std::uint64_t now){
        if(!std::isfinite(x)||!std::isfinite(y)||!allowed){reset();return Act::None;}
        if(std::abs(y)<Centre&&std::abs(x)<.5f){armed=true;holding=false;done=false;return Act::None;}
        if(!up(x,y)){if(y<.5f)holding=false;return Act::None;}   // a little below the line still counts as held
        if(!holding){holding=true;upSince=now;done=false;
            bool fresh=armed;armed=false;
            if(fresh&&!phoneUp){done=true;return Act::TakeOut;}
            return Act::None;}
        if(phoneUp&&!done&&now-upSince>=HoldMs){done=true;return Act::PutAway;}
        return Act::None;
    }
};

// ---------- the prologue's shoot-out at the crates ----------
// prologue1.c (stageShootOut) adds these cover points by the crates (ADD_COVER_POINT) and waits for Trevor in cover
// at one of them with the Carbine Rifle in his hands (or for every cop to be dead); they are removed when the stage
// ends. The first one is also what the add-on checks the stage by (DOES_SCRIPTED_COVER_POINT_EXIST_AT_COORDS).
struct CoverSpot { float x,y,z; };
constexpr CoverSpot prologueCover[]={{5332.273f,-5185.271f,81.7757f},{5332.193f,-5191.912f,81.7758f},{5326.354f,-5185.249f,81.7796f},
    {5326.354f,-5191.832f,81.7743f},{5336.817f,-5193.333f,81.911f}};
constexpr int prologueCoverCount=int(sizeof(prologueCover)/sizeof(prologueCover[0]));
// The cover spot nearest to p within maxDistance (horizontal; the character stands ~1 m above the point), -1 = none.
inline int nearestCover(Vec3 p,const CoverSpot* spots,int n,float maxDistance){
    if(!finite(p)||!spots)return -1;int best=-1;float bestD=maxDistance;
    for(int i=0;i<n;++i){float dx=spots[i].x-p.x,dy=spots[i].y-p.y,dz=spots[i].z-p.z;
        if(std::abs(dz)>4)continue;float d=std::sqrt(dx*dx+dy*dy);if(d<=bestD){bestD=d;best=i;}}
    return best;
}
// When to put the character into cover there, and out of it. stage = the mission's cover points exist; nearby = the
// character is by the crates; back = the left stick pulled back (the way out: GTA leaves cover on its cover input).
// Once per stage: after the character has been in cover and is out again (the stick, GTA's cover key, the mission
// itself), the add-on leaves it alone until the stage starts again (a checkpoint restart re-adds the points).
class AutoCover {
    bool active=false,coverSeen=false,done=false,leaving=false;int tries=0;std::uint64_t nextTry=0,backSince=0;
public:
    static constexpr int MaxTries=3;static constexpr std::uint64_t RetryMs=4000,BackMs=400;
    enum class Act { None,Enter,Leave };
    void reset(){active=false;coverSeen=false;done=false;leaving=false;tries=0;nextTry=0;backSince=0;}
    bool stageActive()const{return active;}
    bool finished()const{return done;}
    bool wasInCover()const{return coverSeen;}
    int attempts()const{return tries;}
    Act update(bool stage,bool nearby,bool inCover,bool goingIn,bool back,std::uint64_t now){
        if(!stage){if(active)reset();return Act::None;}
        if(!active){active=true;coverSeen=false;done=false;leaving=false;tries=0;nextTry=now;backSince=0;}
        if(inCover){coverSeen=true;
            if(back){if(!backSince)backSince=now;
                if(!leaving&&now-backSince>=BackMs){leaving=true;return Act::Leave;}}
            else{backSince=0;leaving=false;}
            return Act::None;}
        backSince=0;leaving=false;
        if(coverSeen)done=true;   // out of cover again: the player's (or the mission's) choice from here on
        if(done||goingIn||!nearby||tries>=MaxTries||now<nextTry)return Act::None;
        ++tries;nextTry=now+RetryMs;return Act::Enter;
    }
};

// ---------- 0.15.8: the grip that holds a weapon ----------
// The friend's 0.15.7 video: guns vanished from the hand while he held them. A weapon in the hand was let go the
// moment the grip read below 0.65 - a hand that relaxed a little, or a reading that flickered around 0.65, put it
// back in its holster (and a squeeze right after closed an empty fist). Now: squeeze past 0.65 to take it; it stays
// until the grip is below 0.35 for 0.1 s.
class GripLatch {
    bool on=false;std::uint64_t lowSince=0;
public:
    static constexpr float On=.65f,Off=.35f;static constexpr std::uint64_t OffMs=100;
    void reset(){on=false;lowSince=0;}
    bool held()const{return on;}
    bool update(float value,std::uint64_t now){
        if(!std::isfinite(value))value=0;
        if(!on){if(value>On){on=true;lowSince=0;}return on;}
        if(value>=Off){lowSince=0;return on;}
        if(!lowSince)lowSince=now;
        if(now-lowSince>=OffMs){on=false;lowSince=0;}
        return on;
    }
};
// A weapon that left the hand without the hand being at a holster comes back with a squeeze within 0.8 s
// (anywhere): a grip that let go for a moment is not putting the weapon away. (The friend's clip: the hand opened
// and closed again about 0.4 s after the pistol left it.)
class RegrabWindow {
    int item=-1;std::uint64_t at=0;
public:
    static constexpr std::uint64_t WindowMs=800;
    void reset(){item=-1;at=0;}
    void dropped(int weapon,std::uint64_t now){item=weapon;at=now;}
    // The weapon to take back on this squeeze (-1 = none); one use.
    int take(std::uint64_t now){int w=item;bool ok=w>=0&&now>=at&&now-at<=WindowMs;item=-1;return ok?w:-1;}
    bool pending(std::uint64_t now)const{return item>=0&&now>=at&&now-at<=WindowMs;}
};
// Tracking lost for a moment (the controller near the headset, out of the cameras' view): what the hand holds
// stays in it for 1.5 s.
class TrackingGrace {
    std::uint64_t seen=0;
public:
    static constexpr std::uint64_t GraceMs=1500;
    void reset(){seen=0;}
    // tracked: the hand's pose is valid now. Returns true while the hand counts as there.
    bool update(bool tracked,std::uint64_t now){if(tracked){seen=now;return true;}return seen&&now>=seen&&now-seen<GraceMs;}
};

// ---------- a little health back for a kill ----------
// GTA's story characters: 100 = dead, 200 = full. A dying character (100 or less) gets nothing.
inline int healAfterKill(int health,int maxHealth,int amount){
    if(health<=100||maxHealth<=100||amount<=0)return health;
    return std::min(maxHealth,health+amount);
}
}
