#pragma once
// Weapons revamp (0.5.0): body holsters, recoil, and a physical magazine reload
// (drop the magazine, take a new one from the belt, push it into the gun, rack
// the slide / charging handle, shoot). Plain logic, tested in tests/weapons_test.cpp.
#include "core.hpp"
#include "weapons.hpp"
#include <array>

namespace handvr {
constexpr std::uint32_t UnarmedHash=0xA2719263u;

// ---------------- Holsters ----------------
enum class Holster : int { None=-1,RightHip=0,LeftHip=1,Chest=2,RightShoulder=3,LeftShoulder=4 };
constexpr int holsterCount=5;
inline const char* holsterName(Holster h){
    switch(h){case Holster::RightHip:return "right hip";case Holster::LeftHip:return "left hip";case Holster::Chest:return "chest";
        case Holster::RightShoulder:return "right shoulder";case Holster::LeftShoulder:return "left shoulder";default:return "none";}
}
struct HolsterZone { Vec3 center{};float radius=0; };
using HolsterZones=std::array<HolsterZone,holsterCount>;
// Tracking space (OpenVR: +Y up, -Z forward). The body follows the head's yaw only,
// so the zones work standing or seated (hips ~0.7 m below the eyes in both).
inline void bodyAxes(const Pose& head,Vec3& forward,Vec3& right){
    forward=-head.col(2);forward.y=0;forward=unit(forward,{0,0,-1});right=cross(forward,{0,1,0});
}
inline HolsterZones holsterZones(const Pose& head){
    Vec3 f,r;bodyAxes(head,f,r);Vec3 up{0,1,0},h=head.pos();
    HolsterZones z;
    z[int(Holster::RightHip)]={h-up*.70f+r*.20f+f*.03f,.16f};
    z[int(Holster::LeftHip)]={h-up*.70f-r*.20f+f*.03f,.16f};
    z[int(Holster::Chest)]={h-up*.38f+f*.12f,.13f};
    z[int(Holster::RightShoulder)]={h-up*.12f+r*.19f-f*.10f,.15f};
    z[int(Holster::LeftShoulder)]={h-up*.12f-r*.19f-f*.10f,.15f};
    return z;
}
inline Holster holsterAt(const HolsterZones& zones,Vec3 hand){
    if(!finite(hand))return Holster::None;
    Holster best=Holster::None;float bestRatio=1;
    for(int i=0;i<holsterCount;++i){float ratio=length(hand-zones[i].center)/zones[i].radius;if(ratio<bestRatio){bestRatio=ratio;best=Holster(i);}}
    return best;
}
// Pistols on the right hip, melee on the left hip, grenades on the chest, the main
// long gun over the right shoulder, snipers / heavy weapons over the left shoulder.
inline Holster holsterFor(const Weapon& w){
    if(w.hash==UnarmedHash||w.kind==WeaponKind::Utility)return Holster::None;
    if(w.kind==WeaponKind::Thrown)return Holster::Chest;
    if(w.kind==WeaponKind::Melee||w.group==0)return Holster::LeftHip;
    if(w.group==1)return Holster::RightHip;
    if(w.group==6||w.group==7)return Holster::LeftShoulder;
    return Holster::RightShoulder;   // SMGs, rifles, machine guns, shotguns
}
// Chooses the weapon a holster gives: the one last carried there if still owned,
// otherwise the first owned weapon by group priority (rifle before shotgun, SMG, MG).
inline int pickForHolster(Holster slot,const int* owned,int count,std::uint32_t preferredHash){
    int best=-1,bestRank=99;
    for(int i=0;i<count;++i){int index=owned[i];if(index<0||index>=weaponCount)continue;const Weapon& w=weapons[index];
        if(holsterFor(w)!=slot)continue;if(w.hash==preferredHash)return index;
        static constexpr int rank[8]={0,0,2,0,3,1,0,1};int r=rank[w.group&7];if(r<bestRank){bestRank=r;best=index;}}
    return best;
}
// Grip press inside a zone draws (or holsters) — the right hand only.
class HolsterGesture {
    bool previousGrip=true;Holster hovered=Holster::None;
public:
    struct Result { Holster entered=Holster::None;Holster activated=Holster::None; };
    Holster hover()const{return hovered;}
    void reset(){previousGrip=true;hovered=Holster::None;}   // a grip already held when resuming is not a press
    Result update(Holster at,bool grip,bool valid){
        Result r;
        if(!valid){previousGrip=grip;hovered=Holster::None;return r;}
        if(at!=hovered){hovered=at;r.entered=at;}
        bool press=grip&&!previousGrip;previousGrip=grip;
        if(press&&at!=Holster::None)r.activated=at;
        return r;
    }
};

// ---------------- Recoil ----------------
struct RecoilProfile { float pitchDegrees=0,backMetres=0,recoverSeconds=.1f; };
// supported: the left hand holds the fore-end (two-handed). One-handed long guns kick harder.
inline RecoilProfile recoilProfile(int group,bool supported){
    static constexpr RecoilProfile base[8]={{0,0,.1f},{7,.035f,.11f},{3.5f,.02f,.12f},{4,.028f,.14f},{3.5f,.03f,.15f},{14,.06f,.16f},{12,.06f,.20f},{9,.05f,.20f}};   // automatic weapons recover slower than they fire: the muzzle climbs
    RecoilProfile p=base[group&7];
    float k=group==1?(supported?.75f:1.0f):(group>=2?(supported?.6f:1.6f):1.0f);
    p.pitchDegrees*=k;p.backMetres*=k;return p;
}
class Recoil {
    float pitch=0,back=0,recover=.1f;
public:
    float pitchDegrees()const{return pitch;}
    float backMetres()const{return back;}
    void reset(){pitch=back=0;}
    void kick(const RecoilProfile& p,float scale=1){
        if(!(scale>0))return;pitch=std::min(pitch+p.pitchDegrees*scale,25.0f);back=std::min(back+p.backMetres*scale,.10f);recover=std::max(p.recoverSeconds,.02f);
    }
    void update(float dt){
        if(!(dt>0)||!std::isfinite(dt))return;float k=std::exp(-std::min(dt,.25f)/recover);pitch*=k;back*=k;
        if(pitch<.01f)pitch=0;if(back<.0002f)back=0;
    }
};
// Muzzle up around the gun's right axis and pushed back along the barrel.
inline WeaponPose applyRecoil(WeaponPose p,const Recoil& r){
    float a=rad(r.pitchDegrees());if(a==0&&r.backMetres()==0)return p;
    Vec3 f=unit(p.forward*std::cos(a)+p.up*std::sin(a),p.forward);
    p.up=unit(cross(p.right,f),p.up);p.forward=f;p.grip=p.grip-f*r.backMetres();return p;
}

// ---------------- Physical magazine reload ----------------
// A: drop the magazine. Left grip at the belt (left front hip) or chest: take a new
// one. Touch the gun's magazine well with it: it seats (no need to let go). If the
// chamber is empty, grip the slide / charging handle and pull it back 5 cm.
// A tactical reload (rounds left) keeps the chambered round: no rack needed.
enum class MagStage { Inserted,Out,Holding,Racking };
struct MagInput {
    bool eject=false,grip=false,atPouch=false,atWell=false,atBolt=false,valid=true;
    Vec3 hand{};Vec3 backward{0,0,1};
};
struct MagEvents { bool ejected=false,grabbed=false,dropped=false,inserted=false,chambered=false; };
class MagazineReload {
    bool previousGrip=true;Vec3 rackStart{};int before=0;
public:
    static constexpr float rackDistance=.05f;
    MagStage stage=MagStage::Inserted;bool chambered=true;
    int clipBeforeEject()const{return before;}
    bool busy()const{return stage!=MagStage::Inserted;}
    // Fresh weapon in hand: a magazine is in and a round is chambered if it has ammo.
    void reset(int clip){stage=MagStage::Inserted;chambered=clip>0;previousGrip=true;before=clip;}
    bool canFire(int clip)const{return chambered&&clip>0;}
    // 0.14.0: a fresh magazine chambers a round itself (RackSlide=0).
    void chamber(){chambered=true;}
    // 0.15.0 (Pavlov): the slide is locked back (the gun was fired empty) and a loaded magazine is in.
    bool slideBack(int clip)const{return stage==MagStage::Inserted&&!chambered&&clip>0;}
    // The slide release (A): a round goes into the chamber.
    bool releaseSlide(int clip){if(!slideBack(clip))return false;chambered=true;return true;}
    // After a shot: the next round is fed from the magazine, else the slide locks back.
    void fired(int clipAfter){if(clipAfter<=0||stage!=MagStage::Inserted)chambered=false;}
    // Rounds the game should report in the clip right after an event.
    int clipAfterEject()const{return chambered?1:0;}
    MagEvents update(const MagInput& in,int clip,int total){
        MagEvents e;
        if(!in.valid){previousGrip=in.grip;if(stage==MagStage::Holding){stage=MagStage::Out;e.dropped=true;}else if(stage==MagStage::Racking)stage=MagStage::Inserted;return e;}
        bool grab=in.grip&&!previousGrip,release=!in.grip&&previousGrip;previousGrip=in.grip;
        switch(stage){
            case MagStage::Inserted:
                if(in.eject&&total>0){before=clip;chambered=clip>0;stage=MagStage::Out;e.ejected=true;}
                else if(!chambered&&clip>0&&grab&&in.atBolt){stage=MagStage::Racking;rackStart=in.hand;}
                break;
            case MagStage::Out:
                if(grab&&in.atPouch&&total>(chambered?1:0)){stage=MagStage::Holding;e.grabbed=true;}
                break;
            case MagStage::Holding:
                if(in.atWell){stage=MagStage::Inserted;e.inserted=true;}
                else if(release){stage=MagStage::Out;e.dropped=true;}
                break;
            case MagStage::Racking:
                if(dot(in.hand-rackStart,unit(in.backward,{0,0,1}))>=rackDistance){chambered=true;stage=MagStage::Inserted;e.chambered=true;}
                else if(release)stage=MagStage::Inserted;
                break;
        }
        return e;
    }
    const char* instruction(int clip)const{
        switch(stage){
            case MagStage::Out:return chambered?"Magazine out (1 in the chamber) | left grip over your shoulder (or at your belt): new magazine":"Left grip over your shoulder (or at your belt): new magazine";
            case MagStage::Holding:return "Push the magazine into the gun";
            case MagStage::Racking:return "Pull it back";
            default:
                if(clip<=0)return "EMPTY | drop the magazine";
                if(!chambered)return "Slide locked back: pull the slide with the left hand, or press A";
                return "";
        }
    }
};
// Where the left hand finds the magazine well and the slide / charging handle,
// relative to the gun (world space, metres before WorldScale).
struct GunAnchors { Vec3 well{},bolt{}; };
inline GunAnchors gunAnchors(const WeaponPose& p,int group,float scale=1){
    GunAnchors a;
    if(group==1){a.well=p.grip-p.up*(.09f*scale);a.bolt=p.grip+p.forward*(.05f*scale)+p.up*(.06f*scale);}
    else if(group==6){a.well=p.grip+p.forward*(.10f*scale)-p.up*(.09f*scale);a.bolt=p.grip+p.forward*(.02f*scale)+p.up*(.06f*scale)+p.right*(.04f*scale);}
    else{a.well=p.grip+p.forward*(.08f*scale)-p.up*(.10f*scale);a.bolt=p.grip+p.forward*(.03f*scale)+p.up*(.08f*scale);}
    return a;
}
// Belt pouch (front-left hip) and chest pouch, tracking space.
inline Vec3 magazinePouchCenter(const Pose& head){Vec3 f,r;bodyAxes(head,f,r);return head.pos()-Vec3{0,1,0}*.62f-r*.17f+f*.08f;}
inline bool atMagazinePouch(const Pose& head,Vec3 leftHand){
    Vec3 f,r;bodyAxes(head,f,r);Vec3 up{0,1,0},h=head.pos();
    return length(leftHand-(h-up*.62f-r*.17f+f*.08f))<.20f||length(leftHand-(h-up*.40f-r*.08f+f*.15f))<.15f;
}

// ---------------- Effects / haptics ----------------
struct ShotEffects { const char* flash;const char* shell; };
inline ShotEffects shotEffects(int group){
    switch(group){case 1:return {"muz_pistol","eject_pistol"};case 2:return {"muz_smg","eject_auto"};case 5:return {"muz_shotgun","eject_shotgun"};
        case 6:return {"muz_assault_rifle","eject_sniper"};case 3:case 4:return {"muz_assault_rifle","eject_auto"};default:return {"muz_assault_rifle",nullptr};}
}
// Haptic code carried through the shared memory: amplitude % (high 16 bits), duration ms (low 16).
inline std::uint32_t hapticCode(int amplitudePercent,int durationMs){
    return (std::uint32_t(std::clamp(amplitudePercent,1,100))<<16)|std::uint32_t(std::clamp(durationMs,5,500));
}
inline void decodeHaptic(std::uint32_t code,float& amplitude,float& seconds){
    if(!code){amplitude=.45f;seconds=.025f;return;}   // 0 = the original click
    amplitude=std::clamp(float(code>>16)/100.0f,.01f,1.0f);seconds=std::clamp(float(code&0xffffu)/1000.0f,.005f,.5f);
}
inline std::uint32_t shotHaptic(int group,bool supported){
    static constexpr int amp[8]={80,60,45,65,70,100,100,100},ms[8]={40,35,25,30,35,70,80,90};
    int a=amp[group&7];if(group>=2&&!supported)a=std::min(100,a+15);return hapticCode(a,ms[group&7]);
}
}
