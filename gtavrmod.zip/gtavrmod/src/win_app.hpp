#pragma once
#ifndef UNICODE
#define UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shlobj.h>
#include <shellapi.h>
#include <bcrypt.h>
#include <tlhelp32.h>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <stdexcept>
#include <chrono>
#include <algorithm>
#include "ini_text.hpp"
namespace app {
namespace fs=std::filesystem;
inline fs::path modulePath() { wchar_t p[32768]{};DWORD n=GetModuleFileNameW(nullptr,p,32768);if(!n||n>=32768)throw std::runtime_error("Cannot locate program.");return fs::path(p); }
inline fs::path localFolder() { PWSTR p=nullptr;if(FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,nullptr,&p)))throw std::runtime_error("Local AppData is unavailable.");fs::path result(p);CoTaskMemFree(p);return result/L"GTA5VR"; }
inline std::wstring wide(const std::string& value) { if(value.empty())return {};int n=MultiByteToWideChar(CP_UTF8,0,value.data(),int(value.size()),nullptr,0);std::wstring out(n,0);MultiByteToWideChar(CP_UTF8,0,value.data(),int(value.size()),out.data(),n);return out; }
inline std::string utf8(const std::wstring& value) { if(value.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,value.data(),int(value.size()),nullptr,0,nullptr,nullptr);std::string out(n,0);WideCharToMultiByte(CP_UTF8,0,value.data(),int(value.size()),out.data(),n,nullptr,nullptr);return out; }
inline std::string read(const fs::path& p,std::size_t max=8*1024*1024) { std::ifstream in(p,std::ios::binary);if(!in)throw std::runtime_error("Cannot read "+utf8(p.wstring()));in.seekg(0,std::ios::end);auto n=in.tellg();if(n<0||static_cast<std::size_t>(n)>max)throw std::runtime_error("Unexpected file size.");std::string out(static_cast<std::size_t>(n),0);in.seekg(0);if(n&&!in.read(out.data(),n))throw std::runtime_error("File read failed.");return out; }
inline void atomicWrite(const fs::path& p,const std::string& bytes) { fs::create_directories(p.parent_path());auto temp=p;temp+=L".gtavr-"+std::to_wstring(GetCurrentProcessId())+L".tmp";{std::ofstream out(temp,std::ios::binary|std::ios::trunc);if(!out||!out.write(bytes.data(),bytes.size())||!out.flush())throw std::runtime_error("Cannot write "+utf8(temp.wstring()));}if(!MoveFileExW(temp.c_str(),p.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){auto error=GetLastError();fs::remove(temp);throw std::runtime_error("Cannot replace "+utf8(p.wstring())+" (Windows error "+std::to_string(error)+"). Close GTA and check folder write permission.");} }
inline std::string sha256(const std::string& bytes) {
    BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;DWORD objectSize=0,size=0;std::vector<unsigned char> object;unsigned char result[32]{};
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)throw std::runtime_error("SHA-256 unavailable.");
    auto clean=[&]{if(hash)BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(alg,0);};
    if(BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&objectSize),sizeof(objectSize),&size,0)<0){clean();throw std::runtime_error("SHA-256 setup failed.");}
    object.resize(objectSize);
    if(BCryptCreateHash(alg,&hash,object.data(),objectSize,nullptr,0,0)<0||BCryptHashData(hash,reinterpret_cast<PUCHAR>(const_cast<char*>(bytes.data())),ULONG(bytes.size()),0)<0||BCryptFinishHash(hash,result,32,0)<0){clean();throw std::runtime_error("SHA-256 failed.");}
    clean();const char* digits="0123456789abcdef";std::string out;for(auto v:result){out+=digits[v>>4];out+=digits[v&15];}return out;
}
inline std::wstring ini(const fs::path& path,const wchar_t* section,const wchar_t* name,const wchar_t* fallback=L"") { wchar_t text[32768]{};GetPrivateProfileStringW(section,name,fallback,text,32768,path.c_str());return text; }
inline void put(const fs::path& path,const wchar_t* section,const wchar_t* name,const std::wstring& value) { if(!WritePrivateProfileStringW(section,name,value.c_str(),path.c_str()))throw std::runtime_error("Cannot save settings. Close the game and check write permission."); }
inline bool exists(const fs::path& p) { std::error_code e;return fs::is_regular_file(p,e); }
inline std::wstring version(const fs::path& p) { DWORD unused=0,n=GetFileVersionInfoSizeW(p.c_str(),&unused);if(!n)return L"unknown";std::vector<char> data(n);VS_FIXEDFILEINFO* v=nullptr;UINT size=0;if(!GetFileVersionInfoW(p.c_str(),0,n,data.data())||!VerQueryValueW(data.data(),L"\\",reinterpret_cast<void**>(&v),&size)||size<sizeof(*v))return L"unknown";return std::to_wstring(HIWORD(v->dwFileVersionMS))+L"."+std::to_wstring(LOWORD(v->dwFileVersionMS))+L"."+std::to_wstring(HIWORD(v->dwFileVersionLS))+L"."+std::to_wstring(LOWORD(v->dwFileVersionLS)); }
// The first n bytes of a file (fewer if it is shorter).
inline std::string readHead(const fs::path& p,std::size_t n) { std::ifstream in(p,std::ios::binary);if(!in)throw std::runtime_error("Cannot read "+utf8(p.wstring()));std::string out(n,0);in.read(out.data(),static_cast<std::streamsize>(n));out.resize(static_cast<std::size_t>(in.gcount()));return out; }
// A 64-bit Windows program? 0.16.0: reads only the headers (it read the whole file, up to 200 MB, before).
inline bool pe64(const fs::path& p) { try{auto b=readHead(p,4096);if(b.size()<64||b[0]!='M'||b[1]!='Z')return false;std::uint32_t offset=0;std::memcpy(&offset,b.data()+60,4);if(offset>1024*1024)return false;
    if(std::size_t(offset)+6>b.size())b=readHead(p,std::size_t(offset)+64);if(std::size_t(offset)+6>b.size()||b.compare(offset,4,std::string("PE\0\0",4))!=0)return false;std::uint16_t machine=0;std::memcpy(&machine,b.data()+offset+4,2);return machine==0x8664;}catch(...){return false;} }
inline fs::path browse(HWND parent) { BROWSEINFOW bi{};bi.hwndOwner=parent;bi.lpszTitle=L"Choose the GTA V Legacy folder containing GTA5.exe";bi.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE;auto id=SHBrowseForFolderW(&bi);if(!id)return {};wchar_t folder[MAX_PATH]{};bool ok=SHGetPathFromIDListW(id,folder)!=FALSE;CoTaskMemFree(id);return ok?fs::path(folder):fs::path(); }
inline std::wstring registryString(HKEY root,const wchar_t* key,const wchar_t* name) { wchar_t value[32768]{};DWORD n=sizeof(value);if(RegGetValueW(root,key,name,RRF_RT_REG_SZ,nullptr,value,&n)!=ERROR_SUCCESS)return {};return value; }
inline bool steamVRKnown() { auto steam=registryString(HKEY_CURRENT_USER,L"Software\\Valve\\Steam",L"SteamPath");return (!steam.empty()&&app::exists(fs::path(steam)/L"steamapps/common/SteamVR/bin/win64/vrserver.exe"))||app::exists(localFolder().parent_path()/L"openvr/openvrpaths.vrpath"); }
inline void open(HWND hwnd,const std::wstring& target) { auto result=ShellExecuteW(hwnd,L"open",target.c_str(),nullptr,nullptr,SW_SHOWNORMAL);if(reinterpret_cast<INT_PTR>(result)<=32)throw std::runtime_error("Windows could not open the selected item."); }
inline HANDLE spawn(const fs::path& exe,bool minimized=false) { std::wstring command=L"\""+exe.wstring()+L"\"";STARTUPINFOW si{};si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=minimized?SW_SHOWMINNOACTIVE:SW_SHOWNORMAL;PROCESS_INFORMATION pi{};auto dir=exe.parent_path().wstring();if(!CreateProcessW(exe.c_str(),command.data(),nullptr,nullptr,FALSE,CREATE_NEW_CONSOLE,nullptr,dir.c_str(),&si,&pi))throw std::runtime_error("Could not launch "+utf8(exe.filename().wstring())+" ("+std::to_string(GetLastError())+").");CloseHandle(pi.hThread);return pi.hProcess; }
inline bool processRunning(const wchar_t* filename) { HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(s==INVALID_HANDLE_VALUE)return false;PROCESSENTRY32W e{};e.dwSize=sizeof(e);bool result=false;if(Process32FirstW(s,&e))do{if(!_wcsicmp(e.szExeFile,filename)){result=true;break;}}while(Process32NextW(s,&e));CloseHandle(s);return result; }
inline void error(HWND h,const std::exception& e) { MessageBoxW(h,wide(e.what()).c_str(),L"GTA 5 VR",MB_OK|MB_ICONERROR); }
constexpr COLORREF bg=RGB(13,18,27),panel=RGB(22,30,43),ink=RGB(233,239,247),muted=RGB(163,178,198),accent=RGB(57,214,178);
inline HFONT font(int height,int weight=FW_NORMAL) { return CreateFontW(-height,0,0,0,weight,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI"); }
inline HWND control(HWND p,const wchar_t* cls,const wchar_t* label,DWORD style,int id,int x,int y,int w,int h,HFONT f) { auto c=CreateWindowExW(0,cls,label,WS_CHILD|WS_VISIBLE|style,x,y,w,h,p,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);SendMessageW(c,WM_SETFONT,reinterpret_cast<WPARAM>(f),TRUE);return c; }
inline void drawText(HDC dc,const wchar_t* text,RECT rect,HFONT f,COLORREF color,UINT format=DT_LEFT|DT_TOP|DT_WORDBREAK) { auto old=SelectObject(dc,f);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,color);DrawTextW(dc,text,-1,&rect,format);SelectObject(dc,old); }
inline void drawButton(DRAWITEMSTRUCT* d,HFONT f,bool primary) { COLORREF color=primary?accent:RGB(38,49,67);if(d->itemState&ODS_DISABLED)color=RGB(48,55,67);auto brush=CreateSolidBrush(color);FillRect(d->hDC,&d->rcItem,brush);DeleteObject(brush);wchar_t text[256]{};GetWindowTextW(d->hwndItem,text,256);drawText(d->hDC,text,d->rcItem,f,primary?RGB(5,26,24):ink,DT_CENTER|DT_VCENTER|DT_SINGLELINE);if(d->itemState&ODS_FOCUS){auto r=d->rcItem;InflateRect(&r,-4,-4);DrawFocusRect(d->hDC,&r);} }
}
