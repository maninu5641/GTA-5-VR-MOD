#pragma once
#include "ipc.hpp"
#include "hands.hpp"
// The generated C header typedefs bool when MinGW defines __WIN32.
// Preserve _WIN32 (ABI/calling convention) while using C++'s built-in bool.
#pragma push_macro("__WIN32")
#undef __WIN32
#include "openvr_capi.h"
#pragma pop_macro("__WIN32")
#include <cstdio>
#include <string>
#include <stdexcept>

using namespace handvr;
static std::string utf8(const std::wstring& s) {
    int n=WideCharToMultiByte(CP_UTF8,0,s.data(),int(s.size()),nullptr,0,nullptr,nullptr);
    std::string out(n,0);WideCharToMultiByte(CP_UTF8,0,s.data(),int(s.size()),out.data(),n,nullptr,nullptr);return out;
}
struct OpenVR {
    HMODULE dll=nullptr;
    using Init=std::uint32_t (__cdecl*)(EVRInitError*,EVRApplicationType);
    using Shutdown=void (__cdecl*)();
    using GetInterface=void* (__cdecl*)(const char*,EVRInitError*);
    using ErrorText=const char* (__cdecl*)(EVRInitError);
    GetInterface get=nullptr;Shutdown shutdown=nullptr;bool initialized=false;
    VR_IVRSystem_FnTable* system=nullptr;
    VR_IVRInput_FnTable* input=nullptr;
    VR_IVROverlay_FnTable* overlay=nullptr;
    template<class T> T function(const char* name) {
        auto p=GetProcAddress(dll,name);
        if(!p) throw std::runtime_error(std::string("Missing OpenVR export: ")+name);
        return reinterpret_cast<T>(p);
    }
    template<class T> T* table(const char* version) {
        EVRInitError error=EVRInitError_VRInitError_None;
        void* p=get((std::string("FnTable:")+version).c_str(),&error);
        if(error!=EVRInitError_VRInitError_None||!p) throw std::runtime_error(std::string("SteamVR lacks ")+version+". Update SteamVR.");
        return static_cast<T*>(p);
    }
    void start(const std::wstring& directory,bool scene=false,void(*progress)(const char*)=nullptr) {
        auto step=[&](const char* message){if(progress)progress(message);};
        step("OpenVR: loading openvr_api.dll");
        dll=LoadLibraryExW((directory+L"\\openvr_api.dll").c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
        if(!dll) throw std::runtime_error("Cannot load the bundled openvr_api.dll beside this program.");
        auto init=function<Init>("VR_InitInternal");shutdown=function<Shutdown>("VR_ShutdownInternal");get=function<GetInterface>("VR_GetGenericInterface");
        EVRInitError error=EVRInitError_VRInitError_None;
        step("OpenVR: calling VR_InitInternal; waiting for SteamVR");
        init(&error,scene?EVRApplicationType_VRApplication_Scene:EVRApplicationType_VRApplication_Overlay);
        if(error!=EVRInitError_VRInitError_None) throw std::runtime_error(function<ErrorText>("VR_GetVRInitErrorAsEnglishDescription")(error));
        initialized=true;
        step("OpenVR: runtime connected; requesting interfaces");
        system=table<VR_IVRSystem_FnTable>(IVRSystem_Version);
        input=table<VR_IVRInput_FnTable>(IVRInput_Version);
        overlay=table<VR_IVROverlay_FnTable>(IVROverlay_Version);
        auto apps=table<VR_IVRApplications_FnTable>(IVRApplications_Version);
        step("OpenVR: registering application manifest");
        auto manifest=utf8(directory+(scene?L"\\GTAHandVR-renderer.vrmanifest":L"\\GTAHandVR.vrmanifest"));
        if(apps->AddApplicationManifest(manifest.data(),true)!=EVRApplicationError_VRApplicationError_None)
            throw std::runtime_error("Cannot register GTAHandVR.vrmanifest.");
        std::string key=scene?"local.gta5vr.renderer":"local.gtahandvr.input";
        step("OpenVR: identifying the GTA process");
        if(apps->IdentifyApplication(GetCurrentProcessId(),key.data())!=EVRApplicationError_VRApplicationError_None)
            throw std::runtime_error("Cannot identify the controller companion to SteamVR.");
        auto actions=utf8(directory+(scene?L"\\renderer_actions.json":L"\\actions.json"));
        step("OpenVR: loading controller action manifest");
        if(input->SetActionManifestPath(actions.data())!=EVRInputError_VRInputError_None)
            throw std::runtime_error("Cannot load actions.json. Keep the package files together.");
        step("OpenVR: input manifest loaded");
    }
    ~OpenVR() { if(initialized&&shutdown) shutdown();if(dll) FreeLibrary(dll); }
};
static void check(EVRInputError e,const char* action) {
    if(e!=EVRInputError_VRInputError_None) throw std::runtime_error(std::string("SteamVR input action failed: ")+action+" ("+std::to_string(int(e))+")");
}
struct Actions {
    VR_IVRInput_FnTable* api;
    VRActiveActionSet_t set{};
    VRActionHandle_t left{},right{},trigger{},leftTrigger{},rightGrip{},leftGrip{},interact{},move{},stick{},wheel{},reload{},jump{},sprint{},support{},toggle{},haptic{};
    VRActionHandle_t leftSkeleton{},rightSkeleton{};   // 0.4.0 finger tracking; optional
    VRActionHandle_t leftAim{},rightAim{};             // 0.6.0 /pose/tip: the SteamVR laser direction; optional
    VRActionHandle_t moveTouch{};                      // 0.7.0 left stick touch: walking stops when the thumb leaves the stick; optional
    VRActionHandle_t handle(const char* name) {
        std::string path=std::string("/actions/main/")+name;
        VRActionHandle_t result{};check(api->GetActionHandle(path.data(),&result),name);return result;
    }
    explicit Actions(VR_IVRInput_FnTable* input):api(input) {
        char name[]="/actions/main";
        check(api->GetActionSetHandle(name,&set.ulActionSet),name);
        set.nPriority=0;
        left=handle("in/left_pose");right=handle("in/right_pose");trigger=handle("in/fire");
        move=handle("in/move");stick=handle("in/turn_select");wheel=handle("in/wheel");
        reload=handle("in/reload");jump=handle("in/jump");sprint=handle("in/sprint");
        support=handle("in/support");toggle=handle("in/toggle");haptic=handle("out/haptic");
        leftTrigger=handle("in/left_trigger");rightGrip=handle("in/right_grip");leftGrip=handle("in/left_grip");interact=handle("in/interact");
        // Older manifests lack the skeleton actions: keep running without fingers.
        std::string skeletonPath="/actions/main/in/left_skeleton";if(api->GetActionHandle(skeletonPath.data(),&leftSkeleton)!=EVRInputError_VRInputError_None)leftSkeleton=0;
        skeletonPath="/actions/main/in/right_skeleton";if(api->GetActionHandle(skeletonPath.data(),&rightSkeleton)!=EVRInputError_VRInputError_None)rightSkeleton=0;
        skeletonPath="/actions/main/in/left_aim";if(api->GetActionHandle(skeletonPath.data(),&leftAim)!=EVRInputError_VRInputError_None)leftAim=0;
        skeletonPath="/actions/main/in/right_aim";if(api->GetActionHandle(skeletonPath.data(),&rightAim)!=EVRInputError_VRInputError_None)rightAim=0;
        skeletonPath="/actions/main/in/move_touch";if(api->GetActionHandle(skeletonPath.data(),&moveTouch)!=EVRInputError_VRInputError_None)moveTouch=0;
    }
    bool digital(VRActionHandle_t h) {
        InputDigitalActionData_t d{};
        return api->GetDigitalActionData(h,&d,sizeof(d),0)==EVRInputError_VRInputError_None&&d.bActive&&d.bState;
    }
    bool analog(VRActionHandle_t h,float& x,float& y) {
        InputAnalogActionData_t d{};
        bool ok=api->GetAnalogActionData(h,&d,sizeof(d),0)==EVRInputError_VRInputError_None&&d.bActive;
        x=ok?d.x:0;y=ok?d.y:0;return ok;
    }
    bool pose(VRActionHandle_t h,Pose& out) {
        InputPoseActionData_t d{};
        bool ok=api->GetPoseActionDataRelativeToNow(h,ETrackingUniverseOrigin_TrackingUniverseStanding,0,&d,sizeof(d),0)==EVRInputError_VRInputError_None
            &&d.bActive&&d.pose.bPoseIsValid&&d.pose.bDeviceIsConnected;
        if(ok) std::memcpy(out.m,d.pose.mDeviceToAbsoluteTracking.m,sizeof(out.m));
        return ok&&validPose(out);
    }
    // Hand skeleton: 31 bone positions (model space), its root pose predicted like the
    // head, finger curls and the tracking level. WithoutController = full fist range.
    bool skeleton(VRActionHandle_t action,VRActionHandle_t fallbackPose,float predictSeconds,HandSkeleton& out) {
        out=HandSkeleton{};if(!action)return false;
        InputSkeletalActionData_t state{};
        if(api->GetSkeletalActionData(action,&state,sizeof(state))!=EVRInputError_VRInputError_None||!state.bActive)return false;
        VRBoneTransform_t bones[HandBoneCount]{};
        if(api->GetSkeletalBoneData(action,EVRSkeletalTransformSpace_VRSkeletalTransformSpace_Model,EVRSkeletalMotionRange_VRSkeletalMotionRange_WithoutController,bones,HandBoneCount)!=EVRInputError_VRInputError_None)return false;
        for(unsigned i=0;i<HandBoneCount;++i)out.model[i]={bones[i].position.v[0],bones[i].position.v[1],bones[i].position.v[2]};
        VRSkeletalSummaryData_t summary{};
        if(api->GetSkeletalSummaryData(action,EVRSummaryType_VRSummaryType_FromDevice,&summary)==EVRInputError_VRInputError_None)for(int i=0;i<5;++i)out.curl[i]=summary.flFingerCurl[i];
        EVRSkeletalTrackingLevel level=EVRSkeletalTrackingLevel_VRSkeletalTracking_Estimated;
        if(api->GetSkeletalTrackingLevel(action,&level)==EVRInputError_VRInputError_None)out.trackingLevel=int(level);
        InputPoseActionData_t pose{};
        bool ok=api->GetPoseActionDataRelativeToNow(action,ETrackingUniverseOrigin_TrackingUniverseStanding,predictSeconds,&pose,sizeof(pose),0)==EVRInputError_VRInputError_None&&pose.bActive&&pose.pose.bPoseIsValid;
        if(!ok){pose={};ok=api->GetPoseActionDataRelativeToNow(fallbackPose,ETrackingUniverseOrigin_TrackingUniverseStanding,predictSeconds,&pose,sizeof(pose),0)==EVRInputError_VRInputError_None&&pose.bActive&&pose.pose.bPoseIsValid;}
        if(ok)std::memcpy(out.root.m,pose.pose.mDeviceToAbsoluteTracking.m,sizeof(out.root.m));
        out.valid=ok&&validPose(out.root);
        return out.valid&&plausible(out);
    }
    bool read(InputFrame& frame) {
        if(api->UpdateActionState(&set,sizeof(set),1)!=EVRInputError_VRInputError_None) return false;
        if(pose(right,frame.right)) frame.flags|=RightValid;
        if(pose(left,frame.left)) frame.flags|=LeftValid;
        // 0.6.0: weapons point exactly where the controller points (the SteamVR laser = /pose/tip).
        // Keep the grip position, take the tip orientation.
        Pose aim{};
        if((frame.flags&RightValid)&&rightAim&&pose(rightAim,aim))for(int r=0;r<3;++r)for(int c=0;c<3;++c)frame.right.m[r][c]=aim.m[r][c];
        if((frame.flags&LeftValid)&&leftAim&&pose(leftAim,aim))for(int r=0;r<3;++r)for(int c=0;c<3;++c)frame.left.m[r][c]=aim.m[r][c];
        float unused=0;
        bool active=analog(trigger,frame.trigger,unused);
        analog(leftTrigger,frame.leftTrigger,unused);analog(rightGrip,frame.rightGrip,unused);analog(leftGrip,frame.leftGrip,unused);
        analog(move,frame.moveX,frame.moveY);analog(stick,frame.stickX,frame.stickY);
        if(active) frame.flags|=InputReady;
        if(digital(wheel)) frame.buttons|=WheelHeld;
        if(digital(reload)) frame.buttons|=ReloadHeld;
        if(digital(jump)) frame.buttons|=JumpHeld;
        if(digital(sprint)) frame.buttons|=SprintHeld;
        if(digital(support)) frame.buttons|=SupportGrip;
        if(digital(toggle)) frame.buttons|=ToggleHeld;
        if(frame.rightGrip>.65f) frame.buttons|=WeaponGrip;
        if(frame.leftGrip>.65f) frame.buttons|=SupportGrip;
        if(digital(interact)) frame.buttons|=InteractHeld;
        if(moveTouch){InputDigitalActionData_t d{};
            if(api->GetDigitalActionData(moveTouch,&d,sizeof(d),0)==EVRInputError_VRInputError_None&&d.bActive){frame.buttons|=TouchKnown;if(d.bState)frame.buttons|=MoveTouched;}}
        return true;
    }
};
