#pragma once
#include <string>
#include <algorithm>
#include <stdexcept>
namespace handvr {
inline std::string trim(std::string s) {
    auto a=s.find_first_not_of(" \t\r\n");if(a==std::string::npos)return {};
    return s.substr(a,s.find_last_not_of(" \t\r\n")-a+1);
}
inline std::string lower(std::string s) { for(char& c:s)if(c>='A'&&c<='Z')c+=32;return s; }
// Update an existing unique key, retaining unrelated lines and its inline comment.
// Missing / duplicate keys are explicit failures, never guessed configuration.
inline std::string updateExistingIniKey(const std::string& original,const std::string& key,const std::string& value) {
    std::string result;std::size_t pos=0;int matches=0;
    while(pos<original.size()) {
        auto end=original.find('\n',pos);if(end==std::string::npos)end=original.size();
        std::string line=original.substr(pos,end-pos);
        auto equals=line.find('=');auto start=line.find_first_not_of(" \t");
        if(start!=std::string::npos&&line[start]!=';'&&line[start]!='#'&&equals!=std::string::npos&&lower(trim(line.substr(0,equals)))==lower(key)) {
            ++matches;auto comment=line.find_first_of(";#",equals+1);
            bool cr=!line.empty()&&line.back()=='\r';
            std::string suffix=comment==std::string::npos?"":line.substr(comment);
            if(!suffix.empty()&&suffix.back()=='\r')suffix.pop_back();
            line=line.substr(0,equals+1)+" "+value+(suffix.empty()?"":" "+suffix)+(cr?"\r":"");
        }
        result+=line;if(end<original.size())result+='\n';pos=end+1;
    }
    if(matches!=1)throw std::runtime_error(matches?"Multiple VRAPI settings found in RealVR.ini; fix the duplicate first.":"No VRAPI setting found in RealVR.ini. Use the renderer's original configuration file.");
    return result;
}
}
