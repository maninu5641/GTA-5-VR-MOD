// GTA 5 VR installer. 0.8.0 revamp: finds GTA V Legacy (Epic / Steam / Rockstar), checks the folder
// (Script Hook V, ASI loader, SteamVR, other VR renderers, installed version) before installing,
// installs / updates with backup and rollback, and can uninstall.
// 0.16.0 (release): three numbered steps in plain words; an update also removes the files of the parts taken out of
// GTA 5 VR (the R.E.A.L. input companion, the OpenXR layer), backed up like every replaced file.
#include "install_tools.hpp"
#include "payload.hpp"
using namespace app;
namespace {
HWND window=nullptr,folderBox=nullptr,resetBox=nullptr;HFONT normal=nullptr,bold=nullptr,title=nullptr,smallFont=nullptr;HBRUSH background=nullptr,panelBrush=nullptr;
std::wstring status=L"Choose your GTA V Legacy folder. Folders from Epic, Steam and Rockstar are found automatically.";
std::vector<Check> checks;std::wstring installedNow;
enum { Browse=101,Install=102,Launch=103,ResetSettings=104,Uninstall=105,HookPage=106,FolderBox=107,RefreshTimer=1 };
constexpr const wchar_t* VersionText=L"0.16.3";
// Files of older GTA 5 VR versions that 0.16.0 no longer has (the R.E.A.L. input companion, the OpenXR layer, the old
// launcher's settings): removed on update, after a copy in the backup folder.
constexpr const wchar_t* obsoleteFiles[]={L"GTAHandVR/GTAHandVR-Bridge.exe",L"GTAHandVR/actions.json",L"GTAHandVR/bindings_oculus_touch.json",
    L"GTAHandVR/GTAHandVR.vrmanifest",L"GTAHandVR/Bridge.log",L"GTAHandVR/OpenXR/GTAHandVR-OpenXR.dll",L"GTAHandVR/OpenXR/GTAHandVR-layer.json",
    L"GTAHandVR/OpenXR/OpenXR-layer.log",L"GTAHandVR/OpenXR-LICENSE.txt",L"GTAHandVR-launcher.ini"};
std::string resource(int id){auto r=FindResourceW(nullptr,MAKEINTRESOURCEW(id),RT_RCDATA);if(!r)throw std::runtime_error("The installer is incomplete. Download a fresh copy of gta5vrmod setup.exe.");auto h=LoadResource(nullptr,r);auto size=SizeofResource(nullptr,r);auto* bytes=static_cast<const char*>(LockResource(h));if(!bytes||!size)throw std::runtime_error("The installer cannot read its files. Download a fresh copy of gta5vrmod setup.exe.");return std::string(bytes,size);}
fs::path folder(){wchar_t text[32768]{};GetWindowTextW(folderBox,text,32768);std::wstring t=text;
    while(!t.empty()&&(t.back()==L' '||t.back()==L'"'))t.pop_back();while(!t.empty()&&(t.front()==L' '||t.front()==L'"'))t.erase(t.begin());return fs::path(t);}
void setStatus(const std::wstring& text){status=text;InvalidateRect(window,nullptr,FALSE);}
// Re-check the chosen folder and enable the buttons that make sense for it.
void refresh(){
    fs::path root=folder();checks=folderChecks(root);installedNow=root.empty()?L"":installedVersion(root);
    bool canInstall=checksAllowInstall(checks);
    EnableWindow(GetDlgItem(window,Install),canInstall);SetWindowTextW(GetDlgItem(window,Install),installedNow.empty()?L"Install":L"Update");
    EnableWindow(GetDlgItem(window,Uninstall),canInstall&&!installedNow.empty());
    EnableWindow(GetDlgItem(window,Launch),canInstall&&app::exists(root/L"GTA5 VR.exe"));
    // "Get Script Hook V" only while Script Hook V or the ASI Loader is missing from a GTA V folder.
    bool hookMissing=canInstall&&(!app::exists(root/L"ScriptHookV.dll")||!app::exists(root/L"dinput8.dll"));
    ShowWindow(GetDlgItem(window,HookPage),hookMissing?SW_SHOW:SW_HIDE);
    InvalidateRect(window,nullptr,FALSE);
}
const wchar_t* installVerb(){return installedNow.empty()?L"Install":L"Update";}
void install() {
    fs::path root=folder();
    if(!looksLikeLegacy(root))throw std::runtime_error(looksLikeEnhanced(root)?"This is GTA V Enhanced. GTA 5 VR needs GTA V Legacy (DirectX 11).":"Choose your GTA V Legacy folder (the one with GTA5.exe and PlayGTAV.exe).");
    if(!legacyGame(root))throw std::runtime_error("GTA5.exe in this folder could not be read. Close GTA V and try again; if it keeps happening, repair the game files in your launcher.");
    if(processRunning(L"GTA5.exe")||processRunning(L"GTAHandVR-Bridge.exe")||processRunning(L"GTA5 VR.exe"))throw std::runtime_error("Close GTA V and the GTA 5 VR launcher before installing.");
    std::vector<std::string> verified;for(const auto& p:payload){auto bytes=resource(p.id);if(sha256(bytes)!=p.hash)throw std::runtime_error("The installer's files are damaged. Nothing was installed - download a fresh copy of gta5vrmod setup.exe.");verified.push_back(std::move(bytes));}
    auto backup=root/L"GTA5VR-Backups"/std::to_wstring(GetTickCount64());
    bool reset=SendMessageW(resetBox,BM_GETCHECK,0,0)==BST_CHECKED;
    struct Change {fs::path destination,old;bool existed;};std::vector<Change> changes;bool rollbackFailed=false;std::vector<std::wstring> removed;
    try {
        std::size_t i=0;for(const auto& p:payload){auto destination=root/fs::path(p.path);auto bytes=verified[i++];
            // Settings are kept unless "reset" is ticked (the old file goes to the backup folder).
            if(p.preserve&&app::exists(destination)&&!reset)continue;
            bool existed=app::exists(destination);auto old=backup/fs::path(p.path);
            if(existed)atomicWrite(old,read(destination,200*1024*1024));
            changes.push_back({destination,old,existed});atomicWrite(destination,bytes);
            if(sha256(read(destination,200*1024*1024))!=p.hash)throw std::runtime_error("A file could not be installed correctly.");
        }
        // 0.16.0: what older versions installed and this one does not have any more.
        for(const wchar_t* rel:obsoleteFiles){auto destination=root/fs::path(rel);if(!app::exists(destination))continue;
            auto old=backup/fs::path(rel);atomicWrite(old,read(destination,200*1024*1024));changes.push_back({destination,old,true});
            fs::remove(destination);removed.push_back(rel);}
        {std::error_code e;fs::path xr=root/L"GTAHandVR/OpenXR";if(fs::is_directory(xr,e)&&fs::is_empty(xr,e))fs::remove(xr,e);}
        std::string manifest="GTA 5 VR 0.16.3\r\nBackup: "+utf8(backup.wstring())+"\r\nCREATED / REPLACED / PRESERVED / REMOVED per file. Uninstall: gta5vrmod setup.exe.\r\n";
        for(const auto& p:payload){auto destination=root/fs::path(p.path);auto change=std::find_if(changes.begin(),changes.end(),[&](const Change& c){return c.destination==destination;});manifest+=(change==changes.end()?"PRESERVED":change->existed?"REPLACED":"CREATED");manifest+="  "+std::string(p.hash)+"  "+utf8(p.path)+"\r\n";}
        for(const auto& r:removed)manifest+="REMOVED  "+utf8(r)+"\r\n";
        atomicWrite(root/L"GTAHandVR/Installed-files.txt",manifest);
    } catch(const std::exception& e) {
        for(auto it=changes.rbegin();it!=changes.rend();++it)try{if(it->existed)atomicWrite(it->destination,read(it->old,200*1024*1024));else fs::remove(it->destination);}catch(...){rollbackFailed=true;}
        throw std::runtime_error(std::string(e.what())+(rollbackFailed?"\nNot everything could be put back. Your old files are in "+utf8(backup.wstring()):"\nNothing was changed (every file was put back)."));
    }
    refresh();
    bool hook=app::exists(root/L"ScriptHookV.dll")&&app::exists(root/L"dinput8.dll");
    setStatus(hook?std::wstring(L"Done! GTA 5 VR ")+VersionText+L" is installed"+(reset?L" with the default settings":L" (your settings were kept)")
            +(xboxAppFolder(root)?L". Start SteamVR, then GTA V Legacy from the Xbox app, and choose Story Mode: the VR view starts once it has loaded."
                :L". Start SteamVR, press Open launcher and then Play - or start GTA V from Epic, Steam or Rockstar. The VR view starts once Story Mode has loaded.")
        :std::wstring(L"GTA 5 VR ")+VersionText+L" is installed, but Script Hook V or the ASI Loader is still missing: install them (Get Script Hook V) before playing.");
}
void uninstall(){
    fs::path root=folder();
    if(MessageBoxW(window,L"Remove GTA 5 VR from this GTA V folder?\n\nRemoved: GTA 5 VR's files, settings and logs, and the GTA 5 VR launcher.\nKept: GTA V, Script Hook V and the ASI Loader.",L"Uninstall GTA 5 VR",MB_OKCANCEL|MB_ICONWARNING)!=IDOK)return;
    bool backups=MessageBoxW(window,L"Also delete the GTA5VR-Backups folder (copies of the files earlier installs replaced)?",L"Uninstall GTA 5 VR",MB_YESNO|MB_ICONQUESTION)==IDYES;
    auto r=uninstallAddon(root,backups);refresh();setStatus(L"GTA 5 VR was removed. "+describe(r));
}
// Layout (client area 760 x 700): three numbered steps.
constexpr int StepFolder=160,FolderRow=188,StepCheck=238,ChecksTop=266,CheckRow=26,StepInstall=456,ResetRow=484,ButtonRow=520,StatusTop=576;   // up to 7 checks
void drawChecks(HDC dc){
    int y=ChecksTop;
    for(const auto& c:checks){
        COLORREF color=c.state==CheckState::Ok?accent:c.state==CheckState::Warning?RGB(240,190,70):RGB(235,95,95);
        auto brush=CreateSolidBrush(color);auto pen=CreatePen(PS_SOLID,1,color);auto oldBrush=SelectObject(dc,brush);auto oldPen=SelectObject(dc,pen);
        Ellipse(dc,52,y+6,64,y+18);SelectObject(dc,oldBrush);SelectObject(dc,oldPen);DeleteObject(brush);DeleteObject(pen);
        drawText(dc,c.text.c_str(),{74,y,588,y+26},normal,c.state==CheckState::Ok?ink:color,DT_LEFT|DT_TOP|DT_SINGLELINE|DT_END_ELLIPSIS);
        y+=CheckRow;
    }
}
void drawStep(HDC dc,int number,const wchar_t* text,int y){
    RECT badge{30,y,52,y+22};auto brush=CreateSolidBrush(panel);FillRect(dc,&badge,brush);DeleteObject(brush);
    drawText(dc,std::to_wstring(number).c_str(),badge,bold,accent,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
    drawText(dc,text,{62,y,730,y+24},bold,ink,DT_LEFT|DT_VCENTER|DT_SINGLELINE);
}
LRESULT CALLBACK procedure(HWND h,UINT m,WPARAM w,LPARAM l) {
    try{switch(m){
        case WM_CREATE:{window=h;normal=font(17);bold=font(17,FW_SEMIBOLD);title=font(34,FW_BOLD);smallFont=font(15);background=CreateSolidBrush(bg);panelBrush=CreateSolidBrush(panel);
            folderBox=control(h,L"COMBOBOX",L"",CBS_DROPDOWN|CBS_AUTOHSCROLL|WS_VSCROLL|WS_TABSTOP,FolderBox,30,FolderRow,560,300,normal);
            control(h,L"BUTTON",L"Browse...",BS_OWNERDRAW|WS_TABSTOP,Browse,600,FolderRow-2,130,34,bold);
            control(h,L"BUTTON",L"Get Script Hook V",BS_OWNERDRAW|WS_TABSTOP,HookPage,600,ChecksTop,130,30,smallFont);
            resetBox=control(h,L"BUTTON",L"Start with the default settings (recommended; your old settings are backed up)",BS_AUTOCHECKBOX|WS_TABSTOP,ResetSettings,30,ResetRow,700,28,normal);
            SendMessageW(resetBox,BM_SETCHECK,BST_CHECKED,0);
            control(h,L"BUTTON",L"Install",BS_OWNERDRAW|WS_TABSTOP,Install,30,ButtonRow,200,44,bold);
            control(h,L"BUTTON",L"Uninstall",BS_OWNERDRAW|WS_TABSTOP,Uninstall,244,ButtonRow,160,44,bold);
            control(h,L"BUTTON",L"Open launcher",BS_OWNERDRAW|WS_TABSTOP,Launch,418,ButtonRow,200,44,bold);
            // Folders found on this PC (Epic / Steam / Rockstar); the first one is chosen.
            auto found=detectGameFolders();
            for(auto& f:found)SendMessageW(folderBox,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(f.wstring().c_str()));
            if(!found.empty())SendMessageW(folderBox,CB_SETCURSEL,0,0);
            refresh();
            if(!found.empty())status=found.size()==1?std::wstring(L"GTA V Legacy was found. Check the list above, then press ")+installVerb()+L".":std::wstring(L"Several GTA V Legacy folders were found: pick yours in the list, then press ")+installVerb()+L".";
            else status=L"GTA V Legacy was not found automatically. Press Browse... and choose the folder that contains GTA5.exe.";
            return 0;}
        case WM_COMMAND:
            if(LOWORD(w)==FolderBox){
                if(HIWORD(w)==CBN_SELCHANGE){int i=int(SendMessageW(folderBox,CB_GETCURSEL,0,0));if(i!=CB_ERR){wchar_t t[32768]{};if(SendMessageW(folderBox,CB_GETLBTEXTLEN,i,0)<32767){SendMessageW(folderBox,CB_GETLBTEXT,i,reinterpret_cast<LPARAM>(t));SetWindowTextW(folderBox,t);}}refresh();}
                else if(HIWORD(w)==CBN_EDITCHANGE)SetTimer(h,RefreshTimer,500,nullptr);   // typing: check after a short pause
                return 0;}
            switch(LOWORD(w)){
                case Browse:{auto f=browse(h);if(!f.empty()){SetWindowTextW(folderBox,f.c_str());refresh();setStatus(looksLikeLegacy(f)?std::wstring(L"Folder checked. Press ")+installVerb()+L" when the list above is green.":std::wstring(L"That folder does not contain GTA V Legacy (GTA5.exe and PlayGTAV.exe)."));}break;}
                case Install:install();break;
                case Uninstall:uninstall();break;
                case Launch:{auto p=spawn(folder()/L"GTA5 VR.exe");CloseHandle(p);break;}
                case HookPage:open(h,L"https://www.dev-c.com/gtav/scripthookv/");break;
            }return 0;
        case WM_TIMER:if(w==RefreshTimer){KillTimer(h,RefreshTimer);refresh();}return 0;
        case WM_DRAWITEM:drawButton(reinterpret_cast<DRAWITEMSTRUCT*>(l),reinterpret_cast<DRAWITEMSTRUCT*>(l)->CtlID==HookPage?smallFont:bold,LOWORD(w)==Install);return TRUE;
        case WM_CTLCOLORSTATIC:case WM_CTLCOLORBTN:SetTextColor(reinterpret_cast<HDC>(w),ink);SetBkColor(reinterpret_cast<HDC>(w),bg);return reinterpret_cast<LRESULT>(background);
        case WM_CTLCOLOREDIT:case WM_CTLCOLORLISTBOX:SetTextColor(reinterpret_cast<HDC>(w),ink);SetBkColor(reinterpret_cast<HDC>(w),panel);return reinterpret_cast<LRESULT>(panelBrush);
        case WM_PAINT:{PAINTSTRUCT ps;auto dc=BeginPaint(h,&ps);RECT r;GetClientRect(h,&r);FillRect(dc,&r,background);
            drawText(dc,L"GTA 5 VR Setup",{30,22,730,70},title,ink);
            drawText(dc,(std::wstring(L"Version ")+VersionText+L"   ·   GTA V Legacy (DirectX 11)   ·   Story Mode").c_str(),{31,74,730,100},normal,accent);
            drawText(dc,L"Installs GTA 5 VR into your GTA V Legacy folder. You also need Script Hook V and SteamVR.",{30,106,730,152},normal,muted);
            drawStep(dc,1,L"Choose your GTA V Legacy folder",StepFolder);
            drawStep(dc,2,L"Check what is there",StepCheck);
            drawChecks(dc);
            drawStep(dc,3,L"Install",StepInstall);
            drawText(dc,status.c_str(),{30,StatusTop,730,StatusTop+80},normal,ink);   // three lines
            drawText(dc,L"Story Mode only - GTA Online is not supported.",{30,664,730,690},smallFont,muted);
            EndPaint(h,&ps);return 0;}
        case WM_DESTROY:DeleteObject(normal);DeleteObject(bold);DeleteObject(title);DeleteObject(smallFont);DeleteObject(background);DeleteObject(panelBrush);PostQuitMessage(0);return 0;
    }}catch(const std::exception& e){error(h,e);if(window)refresh();}return DefWindowProcW(h,m,w,l);
}
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int show) {CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);SetProcessDPIAware();WNDCLASSW c{};c.lpfnWndProc=procedure;c.hInstance=instance;c.lpszClassName=L"GTA5VRSetup163";c.hCursor=LoadCursorW(nullptr,IDC_ARROW);RegisterClassW(&c);
    RECT r{0,0,760,700};AdjustWindowRect(&r,WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,FALSE);
    auto h=CreateWindowExW(0,c.lpszClassName,L"GTA 5 VR Setup",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,r.right-r.left,r.bottom-r.top,nullptr,nullptr,instance,nullptr);if(!h)return 1;ShowWindow(h,show);MSG m;while(GetMessageW(&m,nullptr,0,0)>0){if(!IsDialogMessageW(h,&m)){TranslateMessage(&m);DispatchMessageW(&m);}}CoUninitialize();return int(m.wParam);}
