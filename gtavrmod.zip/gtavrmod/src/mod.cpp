#include "ipc.hpp"
#include "native.hpp"
#include "native_ids.hpp"
#include "weapons.hpp"
#include "interactions.hpp"
#include "weapons_vr.hpp"
#include "vr_body.hpp"
#include "vr_play.hpp"
#include "vr_gun.hpp"
#include "vr_follow.hpp"
#include "vr_grip.hpp"
#include "vr_shot.hpp"
#include "vr_wheel.hpp"
#include "vr_aim.hpp"
#include "vr_menu.hpp"
#include "vr_assist.hpp"
#include <array>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>

using namespace handvr;
using namespace native;
using gta::call;
static HMODULE moduleHandle=nullptr;
static bool gameFocused() { DWORD id=0;GetWindowThreadProcessId(GetForegroundWindow(),&id);return id==GetCurrentProcessId(); }
// 0.15.3: real key presses for GTA's own character wheel (Left Alt, F5, F6, F7 - scan codes, like a keyboard).
// What is down here goes up whenever the add-on stops, however it stops (also when Script Hook V unloads it).
static bool keysDown[4]{};
static const WORD keyScans[4]={LeftAltScan,0x3F,0x40,0x41};
static bool sendKey(WORD scan,bool up){INPUT in{};in.type=INPUT_KEYBOARD;in.ki.wScan=scan;in.ki.dwFlags=KEYEVENTF_SCANCODE|(up?KEYEVENTF_KEYUP:0);return SendInput(1,&in,sizeof(in))==1;}
static void releaseWheelKeys(){for(int i:{1,2,3,0})if(keysDown[i]){sendKey(keyScans[i],true);keysDown[i]=false;}}   // F-keys first, Alt last
// 0.16.3: the keyboard's E held while A is GTA's action key (on foot), and key taps for a menu GTA's scripts show while
// the character has no control (a shop: a stick = arrow keys, A = Enter, B = Backspace, X = Space). Real keys, like the
// keyboard; they go up whenever the add-on stops, however it stops.
static bool actionKeyDown=false;
static KeyTaps menuTaps;
static bool sendKeyEx(std::uint16_t scan,bool extended,bool up){INPUT in{};in.type=INPUT_KEYBOARD;in.ki.wScan=WORD(scan);
    in.ki.dwFlags=KEYEVENTF_SCANCODE|(extended?KEYEVENTF_EXTENDEDKEY:0)|(up?KEYEVENTF_KEYUP:0);return SendInput(1,&in,sizeof(in))==1;}
static void releaseActionKey(){if(actionKeyDown){sendKeyEx(scan::E,false,true);actionKeyDown=false;}}
static void releaseMenuTaps(std::uint64_t now,bool all){menuTaps.release(now,[](const KeyTap& t){sendKeyEx(t.code,t.extended,true);},all);}
static std::wstring moduleDirectory() {
    wchar_t p[32768]{};DWORD n=GetModuleFileNameW(moduleHandle,p,32768);
    if(!n||n>=32768) return L".";
    std::wstring result(p);result.resize(result.find_last_of(L"\\/"));return result;
}
struct Settings {
    float scale=1,aimPitch=0,modelYaw=0,offsetRight=0,offsetForward=0,offsetUp=0,snap=30;
    float throwSpeed=1.5f,wheelLock=90;
    bool manual=true,requireSupport=true,physicalDriving=false;
    bool laser=false,twoHand=true,autoReload=false,locomotion=true,turning=true,showStatus=true;
    bool handsRendered=false,punchLocalized=true,punchProvoke=true;float punchForce=1;   // 0.4.0
    bool holsters=true,muzzleFlash=true,shellEject=true,showHolsterZones=true;float recoilScale=1;   // 0.5.0
    GripMode gripMode=GripMode::Hold;float holsterHeight=0;bool headMove=true,characterSwitch=true,characterWheel=true;   // 0.7.0
    bool enterTask=false;   // 0.8.0: walk the character to a car with a task when GTA's enter input does nothing (off: it caused "running by itself")
    // 0.9.0: weapons like GTA4VR (default) or the 0.7.0 holsters; right grip ejects; ejected rounds are lost; pump shotguns; stick cycling.
    WeaponStyle style=WeaponStyle::GTA4VR;bool ejectGrip=true,discardMagazine=true,pumpShotguns=true,stickCycle=true;
    // 0.10.0 [Body]: real steps walk the character under the headset (the renderer turns the body).
    bool roomScale=true;
    // 0.13.0 [Weapons]: Pavlov mode (the default) = holsters with the weapons visible on the body;
    // HandOnGun: the character's hand holds the gun the way GTA holds it (measured once per weapon).
    bool holsterModels=true,handOnGun=true,gripProbe=true;
    // 0.14.0: motion controls on from the start (F8 still toggles); the stick walks (StickSpeed=Run: a full push
    // runs, 0.13.0); RackSlide=1: an empty gun needs the slide pulled after a new magazine (0: it chambers a round);
    // MagazineModels: the weapon's own magazine at the pouch and in the hand instead of guide balls.
    bool startEnabled=true,walkDefault=true,rackSlide=false,magazineModels=true;
    // 0.15.0 [Weapons]: GunSound=Game (default): the gun in the VR hand is also GTA's weapon in the character's
    // hand (invisible) and GTA fires it - its own gunshot. Bullet = GTA's weapon in the hand, the mod fires the
    // bullets. Off = 0.14.0 (the character stays unarmed; silent shots).
    // RackSlide=1 (Pavlov: a gun fired empty needs the slide pulled after the new magazine; SlideRelease=1: A releases
    // it instead) was the 0.15.0 / 0.15.1 default; 0.15.2: RackSlide=0 again - the new magazine chambers a round.
    enum class GunSound { Game,Bullet,Off };GunSound gunSound=GunSound::Game;bool slideRelease=true;
    // 0.15.4 [Weapons] GunHold (the friend's video: the character's left hand stays glued to the rifle's fore-end).
    // GTA itself puts the left hand on a two-handed gun the character holds (its own grip IK - reset flag 324 set by a
    // script does not stop it). Shooting (default) = GTA's invisible copy only while the trigger is touched and 0.8 s
    // after the last shot: the left hand is free the rest of the time. Always = while the VR hand holds the gun (0.15.0 - 0.15.3).
    enum class GunHold { Shooting,Always };GunHold gunHold=GunHold::Shooting;
    bool boltAction=true;   // 0.15.0 [Weapons] BoltAction: the Sniper Rifle's bolt is worked by hand after every shot (Pavlov)
    // 0.15.1 [Weapons] WeaponWheel=0 (default): B no longer opens the weapon wheel (the right stick already switches the
    // weapon in the hand); 1 = 0.14.0 (on foot, B held). [Motion] CharacterKeys=1 (default): the add-on's own character
    // menu and GTA's select keys (F5 / F6 / F7, pressed like a keyboard); 0 = GTA's own wheel (0.14.0).
    bool weaponWheel=false,characterKeys=true;
    float characterKeyHold=.65f;   // 0.15.2 [Motion] CharacterKeyHold: seconds GTA's select key stays down (GTA switches after 0.3 s)
    // 0.15.3 [Motion] CharacterMenu (the friend: "use the menu that comes with the game"): GTA (default) = GTA's own
    // character wheel, opened with its real key (Left Alt) and pointed with F5 / F6 / F7, shown in the flat view;
    // Mod = the add-on's own menu of 0.15.1 / 0.15.2; Inputs = GTA's wheel through game inputs (0.14.0).
    // An INI without the key: GTA, or Inputs with CharacterKeys=0.
    enum class CharacterMenu { GTA,Mod,Inputs };CharacterMenu characterMenu=CharacterMenu::GTA;
    // 0.15.5 [Weapons] GtaAim=1 (default): while the VR gun points at a person the character aims in GTA too (people
    // and missions react to GTA's aim only: the prologue's hostages, shopkeepers, people putting their hands up).
    bool gtaAim=true;
    // 0.15.7 [Weapons] HandHold=1 (default): the weapon sits in the character's hand (attached to GTA's prop bone; the friend:
    // "the hand position on firearms and grenades is bugged"); 0 = 0.15.6 (the weapon at the controller, the hand sent to it).
    // Only while the renderer's arm IK moves the character's arms ([Hands] ArmIk not Off, the body not hidden: armsDriven).
    // [Motion] PhoneStick=1: the right stick pushed up takes GTA's phone out (held up with the phone out: put away).
    // [Missions] PrologueCover=1: the prologue's shoot-out - the character takes cover at the crates by itself.
    // [Gameplay] HealOnKill=15: health back for each person the player kills (GTA's story characters: 100 dead, 200 full; 0 = off).
    bool handHold=true,armsDriven=true,phoneStickUp=true,prologueCover=true;int healOnKill=15;
    // 0.15.8 [Weapons] GtaGrip=1: a gun in the hand the way GTA holds it (its grip read from GTA's copy); 0 = the prop bone (0.15.7).
    bool gtaGrip=true;
    // 0.16.3 [Controls] ReloadIsE=1: the Reload button (A) is GTA's action key E too (extraButtons, mod_aim.inc).
    // [Menu] Controllers=1 (the pause menu's setting): also a menu GTA's scripts show while the character has no control.
    bool reloadIsE=true,menuKeys=true;
    void load(const std::wstring& path) {
        auto number=[&](const wchar_t* name,float fallback,float lo,float hi) {
            wchar_t text[64]{};GetPrivateProfileStringW(L"Motion",name,L"",text,64,path.c_str());
            if(!text[0]) return fallback;
            wchar_t* end=nullptr;float value=std::wcstof(text,&end);
            return end==text||!std::isfinite(value)?fallback:std::clamp(value,lo,hi);
        };
        auto boolean=[&](const wchar_t* name,bool fallback) { return GetPrivateProfileIntW(L"Motion",name,fallback?1:0,path.c_str())!=0; };
        manual=boolean(L"ManualReload",true);requireSupport=boolean(L"RequireSupportGrip",false);physicalDriving=false;   // 0.16.0: physical driving taken out (cars: the controllers' triggers and sticks)
        throwSpeed=number(L"ThrowSpeedMultiplier",1.5f,.5f,3);wheelLock=number(L"WheelLockDegrees",90,30,180);
        scale=number(L"WorldScale",1,0.1f,3);aimPitch=number(L"AimPitchDegrees",0,-90,90);
        modelYaw=number(L"ModelYawDegrees",0,-180,180);
        offsetRight=number(L"OffsetRightMetres",0,-.4f,.4f);offsetForward=number(L"OffsetForwardMetres",0,-.4f,.4f);offsetUp=number(L"OffsetUpMetres",0,-.4f,.4f);
        snap=number(L"SnapTurnDegrees",30,15,90);laser=boolean(L"Laser",false);twoHand=boolean(L"TwoHandSupport",true);
        autoReload=boolean(L"AutoReload",false);locomotion=boolean(L"Locomotion",true);turning=boolean(L"SnapTurning",true);showStatus=boolean(L"ShowStatus",true);
        // The built-in renderer draws real hands, so the blue hand markers are not needed.
        const wchar_t* mode=L"Builtin";   // 0.16.0: the built-in renderer is the only one ([Renderer] Mode=External is no longer read)
        handsRendered=_wcsicmp(mode,L"External")!=0&&GetPrivateProfileIntW(L"Hands",L"Show",1,path.c_str())!=0;
        punchLocalized=GetPrivateProfileIntW(L"Punch",L"Localized",1,path.c_str())!=0;punchProvoke=GetPrivateProfileIntW(L"Punch",L"Provoke",1,path.c_str())!=0;
        wchar_t force[32]{};GetPrivateProfileStringW(L"Punch",L"Force",L"1",force,32,path.c_str());float f=std::wcstof(force,nullptr);punchForce=std::isfinite(f)?std::clamp(f,0.0f,3.0f):1;
        holsters=GetPrivateProfileIntW(L"Weapons",L"Holsters",1,path.c_str())!=0;muzzleFlash=GetPrivateProfileIntW(L"Weapons",L"MuzzleFlash",1,path.c_str())!=0;
        shellEject=GetPrivateProfileIntW(L"Weapons",L"ShellEject",1,path.c_str())!=0;showHolsterZones=GetPrivateProfileIntW(L"Weapons",L"ShowHolsterZones",1,path.c_str())!=0;
        wchar_t recoilText[32]{};GetPrivateProfileStringW(L"Weapons",L"Recoil",L"1",recoilText,32,path.c_str());float rv=std::wcstof(recoilText,nullptr);recoilScale=std::isfinite(rv)?std::clamp(rv,0.0f,3.0f):1;
        // 0.7.0: grip to hold (default) or toggle; holster height offset; head-relative walking; right-stick character switch.
        wchar_t option[32]{};GetPrivateProfileStringW(L"Weapons",L"GripMode",L"Hold",option,32,path.c_str());gripMode=_wcsicmp(option,L"Toggle")==0?GripMode::Toggle:GripMode::Hold;
        GetPrivateProfileStringW(L"Weapons",L"HolsterHeight",L"0",option,32,path.c_str());{float v=std::wcstof(option,nullptr);holsterHeight=std::isfinite(v)?std::clamp(v,-.3f,.3f):0;}
        GetPrivateProfileStringW(L"Motion",L"MoveDirection",L"Head",option,32,path.c_str());headMove=_wcsicmp(option,L"Body")!=0;
        characterSwitch=boolean(L"CharacterSwitch",true);characterWheel=boolean(L"CharacterWheel",true);enterTask=boolean(L"EnterVehicleTask",false);
        // 0.13.0: [Weapons] Mode replaces Style (old files kept Style=GTA4VR): Pavlov (default) / Holsters = holsters, GTA4VR = weapon always in hand.
        GetPrivateProfileStringW(L"Weapons",L"Mode",L"Pavlov",option,32,path.c_str());style=_wcsicmp(option,L"GTA4VR")==0?WeaponStyle::GTA4VR:WeaponStyle::Holsters;
        holsterModels=GetPrivateProfileIntW(L"Weapons",L"HolsterModels",1,path.c_str())!=0;handOnGun=GetPrivateProfileIntW(L"Weapons",L"HandOnGun",1,path.c_str())!=0;
        gripProbe=GetPrivateProfileIntW(L"Weapons",L"MeasureGrip",1,path.c_str())!=0;
        startEnabled=boolean(L"StartEnabled",true);
        GetPrivateProfileStringW(L"Motion",L"StickSpeed",L"Walk",option,32,path.c_str());walkDefault=_wcsicmp(option,L"Run")!=0;
        rackSlide=GetPrivateProfileIntW(L"Weapons",L"RackSlide",0,path.c_str())!=0;magazineModels=GetPrivateProfileIntW(L"Weapons",L"MagazineModels",1,path.c_str())!=0;
        // 0.15.2: RackSlide 0 again (the friend: "the gun does not fire after reloading").
        GetPrivateProfileStringW(L"Weapons",L"GunSound",L"Game",option,32,path.c_str());
        gunSound=!_wcsicmp(option,L"Off")||!_wcsicmp(option,L"0")?GunSound::Off:!_wcsicmp(option,L"Bullet")?GunSound::Bullet:GunSound::Game;
        GetPrivateProfileStringW(L"Weapons",L"GunHold",L"Shooting",option,32,path.c_str());gunHold=!_wcsicmp(option,L"Always")?GunHold::Always:GunHold::Shooting;
        gtaAim=GetPrivateProfileIntW(L"Weapons",L"GtaAim",1,path.c_str())!=0;   // 0.15.5
        reloadIsE=GetPrivateProfileIntW(L"Controls",L"ReloadIsE",1,path.c_str())!=0;menuKeys=GetPrivateProfileIntW(L"Menu",L"Controllers",1,path.c_str())!=0;   // 0.16.3
        slideRelease=GetPrivateProfileIntW(L"Weapons",L"SlideRelease",1,path.c_str())!=0;
        boltAction=GetPrivateProfileIntW(L"Weapons",L"BoltAction",1,path.c_str())!=0;
        weaponWheel=GetPrivateProfileIntW(L"Weapons",L"WeaponWheel",0,path.c_str())!=0;characterKeys=boolean(L"CharacterKeys",true);
        characterKeyHold=number(L"CharacterKeyHold",.65f,.35f,2.0f);
        GetPrivateProfileStringW(L"Motion",L"CharacterMenu",L"",option,32,path.c_str());
        characterMenu=!option[0]?(characterKeys?CharacterMenu::GTA:CharacterMenu::Inputs)
            :!_wcsicmp(option,L"Mod")?CharacterMenu::Mod:!_wcsicmp(option,L"Inputs")?CharacterMenu::Inputs:CharacterMenu::GTA;
        ejectGrip=GetPrivateProfileIntW(L"Weapons",L"EjectWithGrip",1,path.c_str())!=0;discardMagazine=GetPrivateProfileIntW(L"Weapons",L"DiscardMagazineAmmo",1,path.c_str())!=0;
        pumpShotguns=GetPrivateProfileIntW(L"Weapons",L"PumpAction",1,path.c_str())!=0;stickCycle=GetPrivateProfileIntW(L"Weapons",L"StickCycle",1,path.c_str())!=0;
        roomScale=GetPrivateProfileIntW(L"Body",L"RoomScale",1,path.c_str())!=0;
        // The character's own hands are visible in Body=Character mode: no blue hand markers either.
        wchar_t body[32]{};GetPrivateProfileStringW(L"Hands",L"Body",L"Character",body,32,path.c_str());
        if(_wcsicmp(mode,L"External")!=0&&_wcsicmp(body,L"Hidden")!=0)handsRendered=true;
        // 0.15.7
        handHold=GetPrivateProfileIntW(L"Weapons",L"HandHold",1,path.c_str())!=0;
        wchar_t arm[32]{};GetPrivateProfileStringW(L"Hands",L"ArmIk",L"Auto",arm,32,path.c_str());
        armsDriven=_wcsicmp(arm,L"Off")!=0&&_wcsicmp(arm,L"0")!=0&&_wcsicmp(arm,L"Position")!=0&&_wcsicmp(body,L"Hidden")!=0&&_wcsicmp(mode,L"External")!=0;   // the hand turned by the IK too
        phoneStickUp=boolean(L"PhoneStick",true);
        prologueCover=GetPrivateProfileIntW(L"Missions",L"PrologueCover",1,path.c_str())!=0;
        healOnKill=std::clamp(int(GetPrivateProfileIntW(L"Gameplay",L"HealOnKill",15,path.c_str())),0,100);
        gtaGrip=GetPrivateProfileIntW(L"Weapons",L"GtaGrip",1,path.c_str())!=0;   // 0.15.8
    }
};
static void text(const std::string& message,float x,float y,float size=0.30f,bool centered=true) {
    call(SET_TEXT_FONT,0);call(SET_TEXT_SCALE,0.0f,size);call(SET_TEXT_COLOUR,235,242,250,255);call(SET_TEXT_CENTRE,centered);
    call(BEGIN_TEXT_COMMAND_DISPLAY_TEXT,"STRING");call(ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME,message.c_str());call(END_TEXT_COMMAND_DISPLAY_TEXT,x,y,0);
}
static void rectangle(float x,float y,float w,float h,int r,int g,int b,int a) { call(DRAW_RECT,x,y,w,h,r,g,b,a,false); }
static std::string fixed(double value,int digits=1){char t[32];std::snprintf(t,sizeof(t),"%.*f",digits,value);return t;}
class MotionMod {
    Ipc ipc;InputFrame frame{};Settings config;
    Wheel wheel;FireGate fireGate;SnapTurn snapTurn;
    TapHold yButton;int enterFrames=0,exitFrames=0,vehicleTarget=0;std::uint64_t enterAt=0,exitAt=0,nextVehicleProbe=0;bool vehicleNear=false,fallbackDone=false;   // 0.6.0
    // 0.7.0: weapons held by the VR hands (the character itself stays unarmed: no GTA weapon animations).
    TorsoYaw torso;HandGrab grab[2];MoveFilter moveFilter;PressHold stickHold{350};SwitchSequence switcher;ClipBook clips;
    int rightHeld=-1,leftHeld=-1,leftObject=0,hoverZone[2]={-1,-1};std::uint32_t leftObjectHash=0,lastAdoptHash=0;bool leftBusy=false,selecting=false,sawUnarmed=true;
    int specialLogs=0;   // 0.15.8
    Character pick=Character::None,fallbackPick=Character::None;std::uint64_t lastHandsTick=0,ownedAt=0,lastAdoptAt=0,gtaWeaponUntil=0,vehicleLogAt=0,enteredAt=0,wheelReleasedAt=0,fallbackAt=0;
    int adoptFights=0,lastVehicle=0,deflectFrames=0,directKey=0,directKeyFrames=0;
    std::vector<int> owned;
    MagazineReload mag;HolsterGesture holsterGesture;Recoil recoil;std::array<std::uint32_t,holsterCount> lastInHolster{};std::uint64_t lastRecoilTick=0;bool ptfxRequested=false;
    HandMotion rightMotion,leftMotion;SwingGate swing[2];ThrowGesture throwing;WheelSteering steering;
    int manualPed=0,magazineObject=0,remoteObject=0,meleeRay[2]{};
    std::uint32_t manualHash=0,magazineModel=0,remoteModel=0,activeHash=0;
    Vec3 previousTip[2]{};bool tipValid[2]{},c4Armed=false,wasVehicle=false,drivingArmed=false;
    float raySpeed[2]{};std::uint64_t rayTime[2]{};Vec3 rayDir[2]{};
    struct PendingForce { int ped=0,bone=-1,frames=0;Vec3 force{}; };PendingForce pendingForce[4]{};   // applied once the ragdoll is active
    std::array<std::vector<int>,8> inventory;
    // ---------- 0.13.0: the hand on the gun, Pavlov holsters ----------
    // share: sent to the renderer every update (what each hand holds; where the right hand bone goes).
    HandShare share{};bool lastTwoHanded=false;
    // How GTA holds each weapon: its weapon object relative to the hand bone, measured once per weapon
    // (GTA equips it for a few frames). PH_R_Hand (GTA's prop bone) until then.
    struct GripEntry { std::uint32_t hash=0;Frame3 gun{};bool measured=false;int tries=0;std::uint64_t nextTry=0; };
    std::vector<GripEntry> grips;FrameAverage phSamples;Frame3 phDefault{};bool phReady=false;
    enum class Probe { Idle,Equipping };Probe probe=Probe::Idle;std::uint32_t probeHash=0;std::uint64_t probeStart=0,probeQuietUntil=0;int handMarker=0;FrameAverage probeSamples;
    // Weapons resting in their holsters (Pavlov): one weapon object per holster.
    struct HolsterProp { int object=0;std::uint32_t hash=0; };std::array<HolsterProp,holsterCount> holsterProps{};std::array<bool,holsterCount> holsterShown{};
    std::uint32_t lastGripLogHash=0;bool holsterLogged=false;
    // ---------- 0.14.0 ----------
    // Y = GTA's character wheel (tap: open, then a stick and Y / A / the trigger; hold: open, let go = switch);
    // B = enter / steal / leave a vehicle (or, held, the weapon wheel); A / B answer / hang up the phone.
    PressHold yHold{300};bool wheelByTap=false;std::uint64_t wheelOpenedAt=0;int confirmFrames=0;Character confirmPick=Character::None;
    enum class BMode { Idle,Vehicle,Wheel,Swallow };BMode bMode=BMode::Idle;std::uint64_t bDownAt=0;std::uint32_t rawButtons=0;bool triggerWasDown=false;
    bool specialOut=false;   // 0.15.1: GTA has put a special weapon / mission tool in the hands (B held = the weapon wheel then)
    int phoneFrames=0,phoneControl=0;bool phoneActive=false,phoneLogged=false;
    bool runLatched=false,speedLogged=false;std::uint64_t sprintDownAt=0,noFireLogAt=0;
    int pouchObject=0;bool rackLogged=false,shotBlocked=false;
    // ---------- 0.15.0 ----------
    // GTA's own gunshot: while the VR hand holds a gun, the character holds the same gun in GTA, invisible
    // (armedHash; armedPrev for GTA's weapon switch frames). Each shot asks GTA to fire it (ShotLearner, per weapon).
    std::uint32_t armedHash=0,armedPrev=0;int armedPed=0;std::uint64_t armedChangedAt=0,armRetryAt=0;bool armLogged=false,gtaReloadLogged=false;
    ShotLearner shotLearn;PendingRound pendingRound;
    struct PendingShot { int weapon=-1,damage=0;Vec3 muzzle{};WeaponPose pose{}; };PendingShot pendingShot;
    std::vector<std::uint32_t> soundLogged;int refusalLogs=0;
    // Pavlov magazines: the gun's own magazine (its component) leaves the gun model and comes back.
    int magObject=0,clipBone=-1,clipBoneObject=0;bool magShown=true,magLogged=false,magMissingLogged=false;
    DryFire dryFire;
    // ---------- 0.15.3 ----------
    // GTA's own character wheel, played like a keyboard (vr_wheel.hpp): the keys sent and what GTA did with them.
    WheelKeys gtaWheel;bool wheelAltSeen=false,wheelSeen=false,wheelChecked=false;
    bool wheelAltEnabled=false,wheelAltBlocked=false;   // 0.15.5: Left Alt seen as GTA's key, or only as a disabled (blocked) key
    bool wheelKeyAtStart=true,wheelKeyAtEnd=true;int wheelKeyOffStart=0,wheelKeyOffEnd=0,wheelKeyChecks=0;   // 0.15.6: GTA's character key enabled before / after this add-on's update
    std::uint64_t wheelViewUntil=0,wheelNoteUntil=0;std::string wheelNote;
    // GTA's invisible copy of the gun: put away when the VR hand lets go, hidden until GTA has it away (stowHash);
    // its weapon object hidden too (hiddenCopy); the grip measured from it (copyHash) instead of showing GTA's gun.
    std::uint32_t stowHash=0,copyHash=0;int stowPed=0,hiddenCopy=0,hiddenCopyPed=0;std::uint64_t stowSince=0,stowRetryAt=0,copySince=0;
    bool stowLogged=false,stowStuckLogged=false,objectShown=true;
    // 0.15.4: GTA's copy only around the shots (GunHold=Shooting): until when it is held, the round that waits for it.
    std::uint64_t copyUntil=0,deferAt=0;bool deferShot=false,deferLogged=false,holdLogged=false,lastAllowed=false;
    // ---------- 0.15.5 ----------
    // GTA's own aim from the VR gun (vr_aim.hpp, mod_aim.inc): the person the barrel points at; GTA's camera turned to
    // him while GTA aims (aimSteer - the view keeps its heading: the renderer reads it from share.viewYawBits).
    AimSteer aimSteer;int aimPed=0,aimReports=0;Vec3 aimPoint{};std::uint64_t aimHoldUntil=0,aimSince=0,steerSince=0;bool aimTouched=false,aimReported=false,aimLogged=false,aimAllowed=false;
    using PedList=int(*)(int*,int);PedList allPeds=nullptr;bool allPedsLooked=false;std::array<int,256> pedList{};
    // A button given GTA's action key / cover / phone / special ability in the VR menu (vr_menu.hpp): a press = a few
    // updates of GTA's own input. The phone with the right stick (its arrow keys).
    struct Pulse { int control=0,frames=0; };std::array<Pulse,6> pulses{};StickRepeat phoneStick;int phoneNav=0,phoneNavFrames=0;bool extrasLogged=false;int reloadELogs=0;   // 0.16.3
    bool actionKeyWanted=false,actionKeySpent=false;std::uint64_t actionKeySince=0;StickRepeat menuStick;bool menuKeysLogged=false,menuKeysOn=false,menuStickArmed=false;std::uint32_t menuHeld=0;   // 0.16.3
    // GTA's character wheel did not open: the chosen character's own key (F5 / F6 / F7) tapped alone afterwards.
    Character tapPick=Character::None;std::uint64_t tapAt=0,tapUpAt=0;bool tapDown=false;
    // GTAHandVR.ini changed (the VR menu saves it): read again.
    std::uint64_t iniCheckAt=0,aimFollowAfter=0;FILETIME iniStamp{};
    std::array<int,8> chosen{};
    bool enabled=false,previousF8=false,previousF9=false,cycleArmed=true;
    std::uint32_t previousButtons=0,objectHash=0,requestedHash=0,reloadHash=0;
    std::uint64_t nextConnect=0,reloadUntil=0,assetRequestedAt=0;
    int object=0,hiddenPed=0,ownerPed=0,lastHover=-1;
    std::wstring directory=moduleDirectory();
    std::string lastStatus;
    // 0.9.0: GTA4VR-style weapons. current = the weapon in the right hand (-1 = unarmed); rightHeld then
    // only holds a grenade taken from the chest (the weapon comes back after the throw).
    int current=-1;StickFlick flick;GripPress ejectPress;bool ejectRequest=false,pumpGripping=false;PumpAction pump;ShellLoader shells;std::uint64_t lastPumpTick=0;
    float savedCamHeading=0;bool sawSwitch=false;
    // 0.10.0: the body follows the player.
    RoomFollow follow;bool followLogged=false;std::uint64_t lastMoveTick=0;
    bool gta4vr()const{return config.style==WeaponStyle::GTA4VR;}
    const char* styleName()const{return gta4vr()?"GTA4VR style":"Pavlov style (holsters, weapons visible on the body)";}
    // 0.9.0: the world scale the renderer uses (WorldScale x the height calibration), sent with each input frame.
    float scale()const{float s=0;std::memcpy(&s,&frame.reserved,4);return std::isfinite(s)&&s>.2f&&s<4?s:config.scale;}
    // The player's body relative to the character (holster / pouch zones are sized for an average adult).
    float bodySize()const{float s=scale();return s>0?std::clamp(config.scale/s,.6f,1.5f):1.0f;}
    void log(const std::string& message) {
        FILE* f=_wfopen((directory+L"\\GTAHandVR.log").c_str(),L"a");
        if(f) { std::fprintf(f,"[%llu] %s\n",static_cast<unsigned long long>(GetTickCount64()),message.c_str());std::fclose(f); }
    }
    void status(const std::string& message,bool draw=true) {
        if(message!=lastStatus) { log(message);lastStatus=message; }
        if(draw&&config.showStatus) text(message,0.5f,0.94f,0.29f);
    }
    void destroyObject() {
        if(object&&call<bool>(DOES_ENTITY_EXIST,object)) call(DELETE_ENTITY,&object);
        object=0;objectHash=0;objectShown=true;
        releaseHeld();if(probe==Probe::Idle&&!copyHash)deleteProp(handMarker);   // 0.15.7: the weapon left the character's hand
        if(requestedHash) call(REMOVE_WEAPON_ASSET,requestedHash);
        requestedHash=0;assetRequestedAt=0;
    }
    void restoreWeapon() {
        if(armedHash||stowHash)return;   // 0.15.3: GTA's copy of the VR gun stays hidden while held and until GTA has put it away
        if(hiddenPed&&call<bool>(DOES_ENTITY_EXIST,hiddenPed)) call(SET_PED_CURRENT_WEAPON_VISIBLE,hiddenPed,true,false,true,true);
        hiddenPed=0;
    }
    void suspend() {
        resetInteractions();restoreWeapon();destroyObject();wheel.cancel();fireGate.reset();reloadUntil=0;reloadHash=0;activeHash=0;
        snapTurn.update(0,true,config.snap);cycleArmed=false;lastHover=-1;removeHolsterProps();abortProbe();deleteProp(pouchObject);runLatched=false;
        endAim(GetTickCount64());disarmGun();pendingRound.clear();   // 0.15.0 (0.15.5: GTA's aim ends first, its camera goes back)
        for(auto& p:pulses)p.frames=0;phoneNavFrames=0;phoneStick.reset();   // 0.15.5
        stopGtaWheel(call<int>(PLAYER_PED_ID),GetTickCount64());   // 0.15.3: GTA's wheel closes (no switch); its keys go up in driveGtaWheel
        specialOut=false;   // 0.15.1
        dropHands();moveFilter.reset();switcher.cancel();flick.reset();ejectPress.reset();ejectRequest=false;shells.reset();pumpGripping=false;follow.reset();lastMoveTick=0;
    }
    // 0.7.0: both hands let go (weapons back in their holsters, nothing thrown).
    void dropHands(){grab[0].reset();grab[1].reset();rightHeld=leftHeld=-1;leftBusy=false;hoverZone[0]=hoverZone[1]=-1;deleteLeftObject();resetHandLatches();holdingThrough=false;}
    void deleteLeftObject(){if(leftObject&&call<bool>(DOES_ENTITY_EXIST,leftObject))call(DELETE_ENTITY,&leftObject);leftObject=0;leftObjectHash=0;}
    void collectInventory(int ped) {
        for(auto& v:inventory) v.clear();
        for(int i=0;i<weaponCount;++i) if(i==0||(call<bool>(IS_WEAPON_VALID,weapons[i].hash)&&call<bool>(HAS_PED_GOT_WEAPON,ped,weapons[i].hash,false))) inventory[weapons[i].group].push_back(i);
        auto selected=call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped);
        for(int group=0;group<8;++group) {
            chosen[group]=std::clamp(chosen[group],0,std::max(0,int(inventory[group].size())-1));
            for(int i=0;i<int(inventory[group].size());++i) if(weapons[inventory[group][i]].hash==selected) chosen[group]=i;
        }
    }
    void drawWheel(int ped) {
        rectangle(.5f,.5f,.72f,.74f,9,15,23,224);
        text("WEAPONS",.5f,.16f,.43f);
        text("Right stick: category   |   Left stick: previous / next gun",.5f,.21f,.28f);
        for(int group=0;group<8;++group) {
            float angle=group*2*pi/8;
            float x=.5f+std::sin(angle)*.235f,y=.5f-std::cos(angle)*.21f;
            bool selected=wheel.hover==group;bool owned=!inventory[group].empty();
            rectangle(x,y,.20f,.085f,selected?20:23,selected?108:32,selected?135:45,245);
            text(groups[group],x,y-.033f,.28f);
            if(owned) {
                const auto& w=weapons[inventory[group][chosen[group]]];
                text(w.name,x,y-.007f,.265f);
                if(group) text(std::to_string(call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash))+" rounds",x,y+.020f,.23f);
            } else text("Not owned",x,y-.006f,.26f);
        }
        text(gta4vr()?"Release B: in your hand (grenades: chest)":config.gripMode==GripMode::Toggle?"Release B: in your hand / holster":"Release B: put it in its holster",.5f,.475f,.34f);
        text("Centre the right stick to cancel",.5f,.523f,.26f);
        text("Only weapons already in your inventory appear",.5f,.785f,.26f);
    }
    bool updateWheel(int ped) {
        bool held=(frame.buttons&WheelHeld)!=0;
        bool wasOpen=wheel.open;
        if(held&&!wasOpen) { cancelManualReload();throwing.reset();collectInventory(ped);cycleArmed=false;reloadUntil=0;reloadHash=0; }
        int selection=wheel.update(held,frame.stickX,frame.stickY,8);
        if(wheel.open) {
            if(std::abs(frame.moveX)<.3f) cycleArmed=true;
            if(cycleArmed&&std::abs(frame.moveX)>.7f&&wheel.hover>=0) {
                auto& list=inventory[wheel.hover];
                if(!list.empty()) chosen[wheel.hover]=(chosen[wheel.hover]+int(list.size())+(frame.moveX>0?1:-1))%int(list.size());
                cycleArmed=false;ipc.haptic();
            }
            if(lastHover!=wheel.hover&&wheel.hover>=0) ipc.haptic();
            lastHover=wheel.hover;drawWheel(ped);
        }
        if(selection>=0&&!inventory[selection].empty()) {
            int index=inventory[selection][chosen[selection]];const auto& w=weapons[index];
            if(selection==0||call<bool>(HAS_PED_GOT_WEAPON,ped,w.hash,false)) assignFromWheel(ped,index);
        }
        if(wasOpen||wheel.open) { fireGate.reset();return true; }
        return false;
    }
    void blockCombat(int player) {
        // 0.15.5: not GTA's aim (25) while the character aims in GTA at the person the VR gun points at (mod_aim.inc).
        // 0.15.6: only these controls (disableRelatedActions = false). With "related" GTA also turns off every control
        // that shares an input with them (Q: cover; and suspected: GTA's character wheel - Left Alt never counted).
        for(int control:{24,25,37,45,140,141,142,257,261,262}) if(control!=25||!aimSteer.steering()) call(DISABLE_CONTROL_ACTION,0,control,false);
        // 0.15.0: not while the character holds the VR gun for GTA's own gunshot (it would block that shot too);
        // GTA's attack / aim / reload inputs above stay off, so only the VR trigger fires.
        if(!(armedHash&&config.gunSound==Settings::GunSound::Game))call(DISABLE_PLAYER_FIRING,player,true);
    }
    // 0.7.0: the thumb leaving the stick stops the character (stick drift no longer keeps it walking),
    // start / stop thresholds with hysteresis, a short brake after release, and "forward" = where you look.
    // 0.10.0: where the character's eyes are (the renderer puts the camera on them).
    Vec3 eyesOf(int ped){Vec3 l=call<Vec3>(GET_PED_BONE_COORDS,ped,25260,0.0f,0.0f,0.0f),r=call<Vec3>(GET_PED_BONE_COORDS,ped,27474,0.0f,0.0f,0.0f);
        if(finite(l)&&finite(r)&&length(l-r)<.2f)return (l+r)*.5f;return call<Vec3>(GET_PED_BONE_COORDS,ped,31086,0.0f,0.0f,0.0f);}
    bool canFollow(int ped){return ped&&call<bool>(IS_PED_ON_FOOT,ped)&&!call<bool>(IS_PED_RAGDOLL,ped)&&!call<bool>(IS_PED_FALLING,ped)&&!call<bool>(IS_PED_CLIMBING,ped)
        &&!call<bool>(IS_PED_SWIMMING,ped)&&!call<bool>(IS_PED_IN_COVER,ped,false)&&!call<bool>(IS_PED_JUMPING,ped)&&!call<bool>(IS_PED_GETTING_UP,ped)&&!call<bool>(GET_IS_TASK_ACTIVE,ped,160);}
    void move(int ped,bool blocked) {
        std::uint64_t now=GetTickCount64();float dt=lastMoveTick?float(now-lastMoveTick)*.001f:0;lastMoveTick=now;
        bool stickIdle=true;
        if(config.locomotion) {
            auto m=moveFilter.update(frame.moveX,frame.moveY,(frame.buttons&TouchKnown)!=0,(frame.buttons&MoveTouched)!=0,blocked);
            float x=m.x,y=m.y;stickIdle=!m.moving&&!m.brake;
            Vec3 cam=call<Vec3>(GET_GAMEPLAY_CAM_ROT,2);
            if(m.moving&&config.headMove&&(frame.flags&CameraKnown)&&std::abs(frame.gameBasis.forward.z)<.9f){
                if(finite(cam))stickRelativeTo(x,y,gtaHeading(frame.gameBasis.forward),cam.z);}
            // 0.10.0: a real step away from the character -> it walks under the headset (GTA's walk moves the legs).
            // 0.15.5: not while GTA aims (GTA turns the character; the view's eye stays) and 0.7 s after.
            if(aimSteer.publishing())aimFollowAfter=now+700;
            bool followOk=config.roomScale&&stickIdle&&!blocked&&(frame.flags&CameraKnown)&&finite(cam)&&canFollow(ped)&&now>=aimFollowAfter;
            auto f=follow.update(followOk?frame.gameHead-eyesOf(ped):Vec3{},followOk,dt);
            if(f.walk){float fx=0,fy=f.speed;stickRelativeTo(fx,fy,gtaHeading(f.direction),cam.z);x=fx;y=fy;
                if(!followLogged){followLogged=true;log("Body: a real step - the character walks under your head (room scale; [Body] RoomScale=0 turns it off).");}}
            else if(follow.blocked()&&!followLogged){followLogged=true;log("Body: the character could not follow your step (wall or obstacle).");}
            call(SET_CONTROL_VALUE_NEXT_FRAME,0,30,x);
            call(SET_CONTROL_VALUE_NEXT_FRAME,0,31,-y);
            if(m.brake&&ped&&!call<bool>(GET_IS_TASK_ACTIVE,ped,160))call(SET_PED_RESET_FLAG,ped,6,true);   // CPED_RESET_FLAG_ZeroDesiredMoveBlendRatios: stop now
            // 0.14.0: the stick walks (GTA ran at a full push); a click of the left stick runs until the stick is
            // let go, holding the click sprints. Real steps (room scale) always walk.
            bool click=(frame.buttons&SprintHeld)!=0;
            if(click&&!(previousButtons&SprintHeld)){sprintDownAt=now;if(m.moving)runLatched=true;}
            if(!m.moving)runLatched=false;
            bool sprint=click&&now-sprintDownAt>=400&&m.moving;
            if(config.walkDefault&&ped&&((!runLatched&&!sprint)||f.walk)){call(SET_PED_MAX_MOVE_BLEND_RATIO,ped,1.0f);   // GTA's walk at most
                if(!speedLogged&&m.moving){speedLogged=true;log("Motion: the stick walks; click the left stick to run, hold the click to sprint ([Motion] StickSpeed=Run: a full push runs, like 0.13.0).");}}
            if(!blocked&&(config.walkDefault?sprint:click)) call(SET_CONTROL_VALUE_NEXT_FRAME,0,21,1.0f);
            if(!blocked&&(frame.buttons&JumpHeld)&&!(previousButtons&JumpHeld)) call(SET_CONTROL_VALUE_NEXT_FRAME,0,22,1.0f);
        }
        // 0.9.0: a clearly vertical right stick cycles weapons (GTA4VR style), it never snap-turns.
        // 0.14.0 Pavlov: also while the right hand holds a weapon (the stick swaps it for another of its holster).
        // 0.15.7: and while the stick is pushed up / down for GTA's phone (PhoneStick).
        bool verticalUse=((gta4vr()||rightHeld>=0)&&config.stickCycle)||config.phoneStickUp;
        float stickX=verticalUse&&StickFlick::vertical(frame.stickX,frame.stickY)?0.0f:frame.stickX;
        float turn=snapTurn.update(stickX,blocked||!config.turning,config.snap);
        // 0.15.5: while GTA's camera points at the person GTA aims at, a snap turn turns the view's heading (the renderer uses it).
        // 0.16.2: on foot the renderer keeps the view's heading itself and turns GTA's camera and the character to your body
        // (ViewHeading): the snap turn goes to it (share.turnTotal), not to GTA's camera.
        if(turn!=0){
            if(frame.flags&ViewHeading){share.turnTotal=std::uint16_t(share.turnTotal+int(std::lround(turn)));if(aimSteer.publishing())aimSteer.turn(turn);}
            else if(aimSteer.publishing())aimSteer.turn(turn);
            else call(SET_GAMEPLAY_CAM_RELATIVE_HEADING,call<float>(GET_GAMEPLAY_CAM_RELATIVE_HEADING)+turn);}
    }
    bool weaponObject(const Weapon& w,Vec3 position,std::uint64_t now) {
        if(objectHash==w.hash&&object&&call<bool>(DOES_ENTITY_EXIST,object)) return true;
        if(requestedHash!=w.hash) { destroyObject();requestedHash=w.hash;assetRequestedAt=now;call(REQUEST_WEAPON_ASSET,w.hash,31,0); }
        if(!call<bool>(HAS_WEAPON_ASSET_LOADED,w.hash)) {
            if(now-assetRequestedAt>5000) status("Weapon model not ready. F8 returns to normal controls.");
            return false;
        }
        object=call<int>(CREATE_WEAPON_OBJECT,w.hash,0,position.x,position.y,position.z,true,1.0f,0,0,0);
        if(!object) return false;
        objectHash=w.hash;objectShown=true;
        call(SET_ENTITY_COLLISION,object,false,false);call(SET_ENTITY_DYNAMIC,object,false);call(FREEZE_ENTITY_POSITION,object,true);
        return true;
    }
    WeaponPose worldHand(Vec3 cameraPosition,const Basis& basis,const Weapon& w) {
        auto pose=mapHand(frame.head,frame.right,cameraPosition,basis,scale(),config.aimPitch);
        if(config.twoHand&&w.group>=2&&!leftBusy&&(frame.buttons&SupportGrip)&&(frame.flags&LeftValid)&&validPose(frame.left)) {
            auto left=mapHand(frame.head,frame.left,cameraPosition,basis,scale(),0);
            Vec3 delta=left.grip-pose.grip;float distance=length(delta);
            // Supporting hand must be in front of the grip, within a plausible fore-end reach.
            if(distance>.14f*scale()&&distance<.65f*scale()&&dot(unit(delta),pose.forward)>.65f) {
                pose.forward=unit(delta);pose.right=unit(cross(pose.forward,pose.up),pose.right);pose.up=unit(cross(pose.right,pose.forward),pose.up);
            }
        }
        pose.grip=pose.grip+pose.right*config.offsetRight+pose.forward*config.offsetForward+pose.up*config.offsetUp;
        return pose;
    }
    // 0.15.8: what the game says counts (the grip probe and grenades set the visibility directly): a weapon the game has
    // hidden while it should show is shown again (logged once - the friend's video: guns vanishing from the hand).
    bool objectHiddenLogged=false;
    void showObject(bool show){
        if(!object)return;bool visible=call<bool>(IS_ENTITY_VISIBLE,object);
        if(show==objectShown&&visible==show)return;
        if(show&&objectShown&&!visible&&!objectHiddenLogged){objectHiddenLogged=true;log("Hand: the VR weapon was invisible although it should show - shown again (0.15.8).");}
        call(SET_ENTITY_VISIBLE,object,show,false);objectShown=show;}
    void positionObject(const WeaponPose& p) {
        // GTA's weapon meshes point along local +X. Calibration rotates the model only.
        float angle=rad(config.modelYaw);
        Vec3 modelX=p.forward*std::cos(angle)+p.right*std::sin(angle);
        Vec3 modelY=-p.right*std::cos(angle)+p.forward*std::sin(angle);
        auto q=quaternion(modelX,modelY,p.up);
        call(SET_ENTITY_COORDS_NO_OFFSET,object,p.grip.x,p.grip.y,p.grip.z,false,false,false);
        call(SET_ENTITY_QUATERNION,object,q.x,q.y,q.z,q.w);
    }
    bool lineClear(int ped,Vec3 from,Vec3 to) {
        int ray=call<int>(START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE,from.x,from.y,from.z,to.x,to.y,to.z,511,ped,7);
        int hit=0,entity=0;gta::NativeVector end{},normal{};
        int state=call<int>(GET_SHAPE_TEST_RESULT,ray,&hit,&end,&normal,&entity);
        return state==2&&hit==0;
    }
    // 0.7.0: the character holds no GTA weapon, so the VR gun keeps its own magazine count (ClipBook).
    int capacityOf(int ped,const Weapon& w){int c=call<int>(GET_MAX_AMMO_IN_CLIP,ped,w.hash,true);return c>0&&c<10000?c:defaultCapacity(w.group);}
    int clipAmmo(int ped,const Weapon& w,int total) {
        if(!w.magazine&&w.group==7) return total;   // minigun / launchers without a magazine model: no magazine bookkeeping
        if(!clips.has(w.hash)){int gta=0;bool known=call<bool>(GET_AMMO_IN_CLIP,ped,w.hash,&gta)&&gta>0;clips.set(w.hash,known?gta:std::min(capacityOf(ped,w),total));}
        return std::clamp(clips.get(w.hash,0),0,total);
    }
    void setClip(int ped,const Weapon& w,int clip){(void)ped;clips.set(w.hash,clip);}
    void startReload(int ped,const Weapon& w,std::uint64_t now,int clip,int total) {
        int capacity=capacityOf(ped,w);
        if(capacity>clip&&total>clip) { reloadUntil=now+std::uint64_t(w.reloadSeconds*1000);reloadHash=w.hash;fireGate.reset();ipc.haptic(); }
    }
    void equip(int ped,const Weapon& w) {
        cancelManualReload();throwing.reset();call(SET_CURRENT_PED_WEAPON,ped,w.hash,true);destroyObject();restoreWeapon();recoil.reset();ipc.haptic(hapticCode(55,30));
    }
    // 0.7.0: B wheel. Special tools go to GTA's own hands (normal controls); weapons go to their
    // holster (and, in Toggle mode, straight into the right hand); "Unarmed" empties the right hand.
    void assignFromWheel(int ped,int index){
        const Weapon& w=weapons[index];
        if(w.kind==WeaponKind::Utility){equip(ped,w);return;}
        // 0.9.0 GTA4VR style: straight into the right hand (grenades stay on the chest).
        if(gta4vr()){
            if(w.kind==WeaponKind::Thrown){lastInHolster[int(Holster::Chest)]=w.hash;ownedAt=0;ipc.haptic(hapticCode(40,25));status(std::string(w.name)+" -> chest (squeeze the grip at your chest, let go to throw)");return;}
            current=w.hash==UnarmedHash?-1:index;ipc.haptic(hapticCode(40,25));status(std::string("In your hand: ")+w.name);
            return;}
        if(w.hash==UnarmedHash){rightHeld=-1;grab[1].reset();status("Hands free");return;}
        Holster h=holsterFor(w);if(h==Holster::None)return;lastInHolster[int(h)]=w.hash;ownedAt=0;
        if(config.gripMode==GripMode::Toggle&&w.kind!=WeaponKind::Thrown){rightHeld=index;grab[1].holding=true;grab[1].source=h;}
        ipc.haptic(hapticCode(40,25));status(std::string(w.name)+" -> "+holsterName(h)+" holster"+(config.gripMode==GripMode::Toggle&&w.kind!=WeaponKind::Thrown?" (in your hand)":" (squeeze the grip there)"));
    }
    // 0.5.0 / 0.9.0: GTA's "core" particle effect for an ejected shell (pump guns: when pumped, not when fired).
    void shellEffect(const Weapon& w,Vec3 at){
        if(!config.shellEject||!object)return;
        if(!ptfxRequested){call(REQUEST_NAMED_PTFX_ASSET,"core");ptfxRequested=true;}
        auto fx=shotEffects(w.group);if(!fx.shell||!call<bool>(HAS_NAMED_PTFX_ASSET_LOADED,"core"))return;
        Vec3 o=call<Vec3>(GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS,object,at.x,at.y,at.z);
        call(USE_PARTICLE_FX_ASSET,"core");call<bool>(START_PARTICLE_FX_NON_LOOPED_ON_ENTITY,fx.shell,object,o.x,o.y,o.z,0.0f,0.0f,0.0f,1.0f,false,false,false);
    }
    // Returns false when the muzzle is inside a wall (no shot, no recoil).
    // ---------- 0.15.0: GTA's own gunshot ----------
    // The friend: "it doesn't do any sound when shooting". The VR gun fired bullets of its own (a bullet created
    // between two points), and GTA plays no gunshot for those. Now, while the VR hand holds a gun, the character
    // also holds the same gun in GTA, invisible (only the VR gun shows), and each shot asks GTA to fire it at the
    // point the VR barrel points at: GTA's own gunshot, echo, hit effects and reactions. GTA's holding animations,
    // its left-hand grip and its crosshair stay off (the VR arms and hands keep the character's arms).
    // Whether GTA really fires is learned per weapon from its ammunition (vr_shot.hpp); if it does not, the mod
    // fires the bullet itself like 0.14.0 and the log says so ("Gun sound").
    bool gunMayArm(int ped,const Weapon& w,int total){
        return config.gunSound!=Settings::GunSound::Off&&w.kind==WeaponKind::Gun&&w.hash!=UnarmedHash&&total>0
            &&call<bool>(IS_PED_ON_FOOT,ped)&&!call<bool>(IS_PED_SWIMMING,ped)&&!call<bool>(IS_PED_CLIMBING,ped)
            &&!call<bool>(GET_IS_TASK_ACTIVE,ped,160)&&!call<bool>(IS_PED_RUNNING_MOBILE_PHONE_TASK,ped)&&call<bool>(HAS_PED_GOT_WEAPON,ped,w.hash,false);
    }
    bool ourGtaWeapon(std::uint32_t hash,std::uint64_t now)const{return hash&&(hash==armedHash||hash==stowHash||(hash==armedPrev&&now<armedChangedAt+1500));}
    // 0.15.4 (the friend's video: "take off the hand glued to the rifle"): GTA puts the character's left hand on the fore-end
    // of any two-handed gun it holds - also our invisible copy - and the VR left hand could not leave it. GunHold=Shooting:
    // the copy is taken out when the trigger is touched (or a round waits for it) and put away 0.8 s after, so the left
    // hand follows the controller the rest of the time. Only when the gun could fire (not during a reload, not in a menu).
    // 0.15.5: also while the VR gun points at a person (GTA aims at him: aiming).
    bool copyWanted(std::uint64_t now,bool menuBlocked,bool aiming=false){
        if(config.gunHold==Settings::GunHold::Always)return true;
        if((frame.trigger>.10f&&lastAllowed&&!menuBlocked)||deferShot||pendingRound.active||aiming||coverCopy)copyUntil=now+800;   // a round GTA may still fire keeps it (0.15.7: and the prologue's cover)
        else if(!lastAllowed&&copyUntil>now+250)copyUntil=now+250;   // pump / bolt / empty / magazine out: the left hand works the gun
        if(!holdLogged&&now<copyUntil){holdLogged=true;
            log("Gun sound: GTA's copy of the gun is held only while you shoot (trigger touched, 0.8 s after) - GTA puts the character's left hand on a two-handed gun it holds;"
                " the left hand is free the rest of the time. [Weapons] GunHold=Always = 0.15.0 - 0.15.3.");}
        return now<copyUntil;
    }
    // GTA's copy is in the character's hand and can fire (a round fired before that would not get GTA's gunshot).
    bool copyReady(int ped,const Weapon& w,std::uint64_t now){
        if(armedHash!=w.hash||armedPed!=ped||call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped)!=w.hash)return false;
        if(!call<int>(GET_CURRENT_PED_WEAPON_ENTITY_INDEX,ped,false))return false;
        return call<bool>(IS_PED_WEAPON_READY_TO_SHOOT,ped)||now>=armedChangedAt+150;
    }
    void armGun(int ped,const Weapon& w,int total,std::uint64_t now){
        if(armedHash!=w.hash||armedPed!=ped){armedPrev=armedHash;armedHash=w.hash;armedPed=ped;armedChangedAt=now;armRetryAt=0;}
        auto selected=call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped);
        if(selected!=w.hash&&now>=armRetryAt){call(SET_CURRENT_PED_WEAPON,ped,w.hash,true);armRetryAt=now+400;}
        hideCopy(ped);   // GTA's copy invisible (0.15.3: its weapon object too); the object stays (it fires)
        call(SET_PED_RESET_FLAG,ped,184,true);   // CPED_RESET_FLAG_BlockWeaponHoldingAnims: the arms stay the VR arms
        call(SET_PED_RESET_FLAG,ped,324,true);   // CPED_RESET_FLAG_CancelLeftHandGripIk (0.15.4: does not free the left hand from a script - hence GunHold)
        call(SET_PED_RESET_FLAG,ped,426,true);   // CPED_RESET_FLAG_SkipFPSUnHolsterTransition
        call(HIDE_HUD_COMPONENT_THIS_FRAME,14);call(HIDE_HUD_COMPONENT_THIS_FRAME,2);   // GTA's crosshair and weapon icon
        if(selected!=w.hash)return;
        // GTA's own magazine stays full, so GTA never reloads by itself (the VR magazine is the mod's).
        int max=call<int>(GET_MAX_AMMO_IN_CLIP,ped,w.hash,true),gtaClip=0,want=std::min(max,total);
        if(want>0&&call<bool>(GET_AMMO_IN_CLIP,ped,w.hash,&gtaClip)&&gtaClip<want)call<bool>(SET_AMMO_IN_CLIP,ped,w.hash,want);
        if(!gtaReloadLogged&&call<bool>(IS_PED_RELOADING,ped)){gtaReloadLogged=true;log(std::string("Gun sound: GTA started its own reload of the ")+w.name+" (should not happen; tell the developer).");}
        if(!armLogged){armLogged=true;log(std::string("Gun sound: the character holds the ")+w.name+" in GTA too (invisible, only the VR gun shows), so GTA can fire it with its own gunshot"
            +(config.gunSound==Settings::GunSound::Bullet?" - GunSound=Bullet: the mod fires the bullets.":". [Weapons] GunSound=Off: the character stays unarmed (0.14.0, silent)."));}
    }
    // 0.15.3 (the friend: "my gun is glued to my hand - take that out"): letting go of the gun made GTA's copy visible
    // at once (restoreWeapon) while GTA was still putting it away, and GTA could keep it in the character's hand 1.5 s
    // untouched. Now GTA is told to put it away every 250 ms until it has, and the copy stays hidden all that time.
    void disarmGun(){
        if(!armedHash)return;
        int ped=armedPed;std::uint32_t hash=armedHash;std::uint64_t now=GetTickCount64();
        armedPrev=armedHash;armedHash=0;armedPed=0;armedChangedAt=now;copyHash=0;
        if(ped&&call<bool>(DOES_ENTITY_EXIST,ped)&&call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped)==hash){
            stowHash=hash;stowPed=ped;stowSince=now;stowRetryAt=now+250;
            call(SET_CURRENT_PED_WEAPON,ped,UnarmedHash,true);hideCopy(ped);}
        else showCopyAgain();
    }
    void hideCopy(int ped){
        call(SET_PED_CURRENT_WEAPON_VISIBLE,ped,false,false,true,false);hiddenPed=ped;
        int e=call<int>(GET_CURRENT_PED_WEAPON_ENTITY_INDEX,ped,false);
        if(e&&call<bool>(DOES_ENTITY_EXIST,e)){if(call<bool>(IS_ENTITY_VISIBLE,e))call(SET_ENTITY_VISIBLE,e,false,false);hiddenCopy=e;hiddenCopyPed=ped;}
    }
    void showCopyAgain(){
        // Only while it is still GTA's weapon in that hand (GTA deletes it when it puts the gun away; a handle can be reused).
        if(hiddenCopy&&hiddenCopyPed&&call<bool>(DOES_ENTITY_EXIST,hiddenCopy)&&call<bool>(DOES_ENTITY_EXIST,hiddenCopyPed)&&call<bool>(IS_ENTITY_ATTACHED_TO_ENTITY,hiddenCopy,hiddenCopyPed))
            call(SET_ENTITY_VISIBLE,hiddenCopy,true,false);
        hiddenCopy=0;hiddenCopyPed=0;restoreWeapon();
    }
    // Every update (first, whatever happens below): GTA's copy hidden and put away until GTA has it away (3 s at most;
    // then the usual handling of a weapon GTA puts in the hands takes over).
    void serviceStow(std::uint64_t now){
        if(!stowHash)return;
        int ped=stowPed;std::uint32_t hash=stowHash;
        if(armedHash&&armedPed==ped){stowHash=0;stowPed=0;return;}   // a gun in the VR hand again: armGun holds (and hides) GTA's copy
        bool exists=ped&&call<bool>(DOES_ENTITY_EXIST,ped);
        if(!exists||call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped)!=hash){
            stowHash=0;stowPed=0;
            if(exists&&now-stowSince>300&&!stowLogged){stowLogged=true;log("Gun: GTA took "+std::to_string(now-stowSince)+" ms to put its copy of the gun away after the hand let go (hidden all that time).");}
            showCopyAgain();return;}
        hideCopy(ped);
        if(now-stowSince>=3000){stowHash=0;stowPed=0;showCopyAgain();
            if(!stowStuckLogged){stowStuckLogged=true;int i=weaponIndex(hash);log(std::string("Gun: GTA kept its ")+(i>=0?weapons[i].name:"gun")+" in the character's hand 3 s after the hand let go; the add-on now treats it as a weapon GTA put there. [Weapons] GunSound=Off stops the character holding the guns.");}
            return;}
        if(now>=stowRetryAt){call(SET_CURRENT_PED_WEAPON,ped,UnarmedHash,true);stowRetryAt=now+250;}
    }
    // Where the VR barrel points: the first thing on its line, else far along it (GTA fires at that point from
    // its own copy of the gun, a few centimetres from the VR one, so close targets are hit where the VR gun aims).
    Vec3 barrelPoint(int ped,Vec3 muzzle,Vec3 forward,float range){
        Vec3 distant=muzzle+forward*range;
        int ray=call<int>(START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE,muzzle.x,muzzle.y,muzzle.z,distant.x,distant.y,distant.z,511,ped,7);
        int hit=0,entity=0;gta::NativeVector end{},normal{};
        int state=call<int>(GET_SHAPE_TEST_RESULT,ray,&hit,&end,&normal,&entity);
        Vec3 point{end.x,end.y,end.z};
        if(state==2&&hit&&finite(point)&&length(point-muzzle)>.05f)return point+forward*.5f;   // just past the surface
        return distant;
    }
    // The mod's own bullets (0.5.0 - 0.14.0): GTA plays no gunshot for these.
    void scriptBullets(int ped,const Weapon& w,Vec3 muzzle,const WeaponPose& pose,int damage){
        for(int pellet=0;pellet<w.pellets;++pellet) {
            Vec3 direction=pose.forward;
            if(w.pellets>1) {
                float angle=pellet*2.39996323f;
                float radius=.032f*std::sqrt((pellet+.5f)/w.pellets);
                direction=unit(direction+pose.right*(std::cos(angle)*radius)+pose.up*(std::sin(angle)*radius));
            }
            Vec3 target=muzzle+direction*(w.group==6?1000.0f:300.0f);
            call(SHOOT_SINGLE_BULLET_BETWEEN_COORDS,muzzle.x,muzzle.y,muzzle.z,target.x,target.y,target.z,damage,true,w.hash,ped,pellet==0,false,-1.0f);
        }
    }
    bool soundWasLogged(std::uint32_t hash,ShotPath path){
        std::uint32_t key=hash^(std::uint32_t(path)*0x9E3779B9u);
        for(auto k:soundLogged)if(k==key)return true;soundLogged.push_back(key);return false;
    }
    std::string gtaWeaponState(int ped){
        return std::string("ready to shoot ")+(call<bool>(IS_PED_WEAPON_READY_TO_SHOOT,ped)?"yes":"no")+", blocked in first person "+(call<bool>(GET_PED_RESET_FLAG,ped,413)?"yes":"no")
            +", reloading "+(call<bool>(IS_PED_RELOADING,ped)?"yes":"no")+", in hand "+(call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped)==armedHash?"yes":"no");
    }
    // A round GTA was asked for and has not fired yet: GTA's ammunition shows whether it did (a few updates).
    // force: a new shot comes now, so this one is decided now (not fired yet = the mod fires it).
    void settlePending(int ped,bool force){
        if(!pendingRound.active)return;
        std::uint32_t hash=pendingRound.hash;int left=pendingRound.ammoLeft;
        int ammo=std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,hash));
        auto st=pendingRound.update(ammo);
        if(st==PendingRound::State::Waiting&&force){pendingRound.clear();st=ammo<left?PendingRound::State::Fired:PendingRound::State::Missed;}
        if(st==PendingRound::State::Waiting||st==PendingRound::State::Idle)return;
        int index=pendingShot.weapon;const char* name=index>=0?weapons[index].name:"gun";
        if(st==PendingRound::State::Fired){
            auto path=shotLearn.resolved(hash,true);
            if(!soundWasLogged(hash,path))log(std::string("Gun sound: GTA fired the ")+name+" itself a moment after the trigger (its own gunshot).");
            return;}
        // GTA did not fire it: the mod's bullet, like 0.14.0 (a little late), and the round counted here.
        if(index>=0){scriptBullets(ped,weapons[index],pendingShot.muzzle,pendingShot.pose,pendingShot.damage);call(SET_PED_AMMO,ped,hash,std::max(0,left-1),false);}
        auto path=shotLearn.resolved(hash,false);
        if(path==ShotPath::Script&&!soundWasLogged(hash,path))log(std::string("Gun sound: GTA did not fire the ")+name+" itself ("+gtaWeaponState(ped)+"); the mod fires its bullets now (GTA plays no gunshot for them). Send this log.");
        else if(refusalLogs<4){++refusalLogs;log(std::string("Gun sound: GTA did not fire the ")+name+" this time ("+gtaWeaponState(ped)+"); the mod fired the bullet.");}
    }
    // The VR gun's muzzle: its model's muzzle bone, else 18 cm along the barrel.
    Vec3 muzzleOf(const WeaponPose& pose){
        Vec3 muzzle=pose.grip+pose.forward*(.18f*scale());
        int bone=object?call<int>(GET_ENTITY_BONE_INDEX_BY_NAME,object,"gun_muzzle"):-1;
        if(bone>=0) {
            Vec3 candidate=call<Vec3>(GET_WORLD_POSITION_OF_ENTITY_BONE,object,bone);
            if(finite(candidate)&&length(candidate-pose.grip)<1.5f) muzzle=candidate;
        }
        return muzzle;
    }
    bool shoot(int ped,const Weapon& w,const WeaponPose& pose,Vec3 cameraPosition,int clip,int total,bool twoHanded,bool shellOnShot=true) {
        Vec3 muzzle=muzzleOf(pose);
        if(!lineClear(ped,cameraPosition,muzzle)) { shotBlocked=true;return false; }
        float damageValue=call<float>(GET_WEAPON_DAMAGE,w.hash,0u);
        int damage=std::isfinite(damageValue)?std::clamp(int(std::lround(damageValue)),1,1000):20;
        settlePending(ped,true);
        // 0.15.0: GTA fires its own (invisible) copy of the gun: its own gunshot. It takes the round from GTA's
        // ammunition itself (now, or a moment later: the round waits in pendingRound).
        bool gtaRound=false;
        if(config.gunSound==Settings::GunSound::Game&&armedHash==w.hash&&armedPed==ped&&shotLearn.askGame(w.hash)
            &&call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped)==w.hash){
            Vec3 aim=barrelPoint(ped,muzzle,pose.forward,w.group==6?1000.0f:300.0f);
            int before=std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash));
            call(SET_PED_SHOOTS_AT_COORD,ped,aim.x,aim.y,aim.z,true);
            int after=std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash));
            if(shotLearn.afterRequest(w.hash,after<before)==ShotLearner::After::Fired){
                if(!soundWasLogged(w.hash,ShotPath::Sync))log(std::string("Gun sound: GTA fired the ")+w.name+" itself (its own gunshot).");
            }else{pendingRound.start(w.hash,before);pendingShot={weaponIndex(w.hash),damage,muzzle,pose};}
            gtaRound=true;
        }
        if(!gtaRound){scriptBullets(ped,w,muzzle,pose,damage);call(SET_PED_AMMO,ped,w.hash,total-1,false);}
        setClip(ped,w,std::max(0,clip-1));
        // 0.5.0: muzzle flash and ejected shell from GTA's own "core" particle effects.
        if((config.muzzleFlash||config.shellEject)&&object) {
            if(!ptfxRequested){call(REQUEST_NAMED_PTFX_ASSET,"core");ptfxRequested=true;}
            if(call<bool>(HAS_NAMED_PTFX_ASSET_LOADED,"core")) {
                auto fx=shotEffects(w.group);
                if(config.muzzleFlash&&fx.flash){Vec3 o=call<Vec3>(GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS,object,muzzle.x,muzzle.y,muzzle.z);
                    call(USE_PARTICLE_FX_ASSET,"core");call<bool>(START_PARTICLE_FX_NON_LOOPED_ON_ENTITY,fx.flash,object,o.x,o.y,o.z,0.0f,0.0f,0.0f,1.0f,false,false,false);}
                if(shellOnShot&&config.shellEject&&fx.shell){Vec3 port=pose.grip+pose.forward*(.05f*scale())+pose.up*(.05f*scale());
                    Vec3 o=call<Vec3>(GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS,object,port.x,port.y,port.z);
                    call(USE_PARTICLE_FX_ASSET,"core");call<bool>(START_PARTICLE_FX_NON_LOOPED_ON_ENTITY,fx.shell,object,o.x,o.y,o.z,0.0f,0.0f,0.0f,1.0f,false,false,false);}
            }
        }
        ipc.haptic(shotHaptic(w.group,twoHanded));
        return true;
    }
    #include "mod_interactions.inc"
    #include "mod_grip.inc"
    #include "mod_hold.inc"
    #include "mod_aim.inc"
    #include "mod_assist.inc"
    void updateGun(int ped,const Weapon& w,std::uint64_t now,bool menuBlocked) {
        if(probe!=Probe::Idle&&w.hash!=probeHash)abortProbe();   // 0.13.0: the weapon left the hand during its grip measurement
        settlePending(ped,false);   // 0.15.0: a round GTA was asked to fire a moment ago
        if(activeHash!=w.hash){
            resetInteractions();fireGate.reset();activeHash=w.hash;recoil.reset();gripReadHash=0;   // 0.15.8: a new GTA-grip read window
            deferShot=false;copyUntil=0;lastAllowed=false;   // 0.15.4
            int t0=std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash));mag.reset(clipAmmo(ped,w,t0));
            pump.reset(clipAmmo(ped,w,t0)>0);shells.reset();pumpGripping=false;lastPumpTick=0;
            Holster h=holsterFor(w);if(h!=Holster::None)lastInHolster[int(h)]=w.hash;
            if(w.magazine&&w.magazineComponent){magazineModel=call<std::uint32_t>(GET_WEAPON_COMPONENT_TYPE_MODEL,w.magazineComponent);if(magazineModel&&call<bool>(IS_MODEL_VALID,magazineModel))call(REQUEST_MODEL,magazineModel);}
        }
        Vec3 cameraPosition=(frame.flags&CameraKnown)?frame.gameHead:call<Vec3>(GET_FINAL_RENDERED_CAM_COORD);
        Vec3 angles=call<Vec3>(GET_FINAL_RENDERED_CAM_ROT,2);
        if(!finite(cameraPosition)||!finite(angles)) { suspend();return; }
        Basis basis=(frame.flags&CameraKnown)?frame.gameBasis:cameraBasis(angles);
        float dt=lastRecoilTick?float(now-lastRecoilTick)*.001f:0;lastRecoilTick=now;recoil.update(dt);
        auto pose=applyRecoil(worldHand(cameraPosition,basis,w),recoil);
        bool unarmed=w.hash==joaat("WEAPON_UNARMED");
        if(!unarmed&&!weaponObject(w,pose.grip,now)) { disarmGun();restoreWeapon();fireGate.reset();return; }
        // 0.15.3: the VR gun only in the VR view (not floating at GTA's own camera while its character wheel is on the flat view).
        // 0.15.7: the weapon in the character's hand (mod_hold.inc) - else at the controller as before.
        if(unarmed)destroyObject();else{holdObject(ped,w,pose,now);showObject((frame.flags&CameraKnown)&&probe==Probe::Idle);shareRight(ped,w,pose,cameraPosition,basis,now,menuBlocked);}
        // 0.15.7: what you see is what shoots, reloads and hits - the weapon where the character's hand holds it.
        const WeaponPose& use=(!unarmed&&heldAttached&&heldSeenOk)?heldSeen:pose;
        // 0.15.0: GTA's own gunshot - the character holds this gun in GTA too (invisible) while the VR hand holds it.
        // 0.15.4: GunHold=Shooting - only around the shots (copyWanted), so GTA does not hold the left hand on the gun.
        // 0.15.5: GTA's own aim while the VR gun points at a person (mod_aim.inc): GTA's copy held for it too.
        bool aiming=!unarmed&&probe==Probe::Idle&&aimPick(ped,w,use,now,menuBlocked);
        if(probe==Probe::Idle){int t=std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash));
            if(!unarmed&&gunMayArm(ped,w,t)&&(copyWanted(now,menuBlocked,aiming)||gripReadWanted(w,now)))armGun(ped,w,t,now);else disarmGun();}
        aimDrive(ped,w,now,aiming&&armedHash==w.hash);
        if(w.kind==WeaponKind::Melee){melee(ped,w,use,cameraPosition,basis,now,menuBlocked);return;}
        if(w.kind==WeaponKind::Thrown){throwable(w,menuBlocked);return;}
        int total=std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash));
        int clip=clipAmmo(ped,w,total);
        if(reloadHash&&reloadHash!=w.hash) { reloadUntil=0;reloadHash=0; }
        if(reloadUntil&&now>=reloadUntil) {
            int capacity=capacityOf(ped,w);
            if(capacity>0) setClip(ped,w,std::min(capacity,total));
            reloadUntil=0;reloadHash=0;clip=clipAmmo(ped,w,total);ipc.haptic(hapticCode(60,35));
        }
        bool magMode=config.manual&&w.magazine;
        bool pumpMode=config.manual&&config.pumpShotguns&&pumpAction(w.hash);   // 0.9.0
        bool boltMode=config.manual&&config.boltAction&&boltActionRifle(w.hash);   // 0.15.0: the Sniper Rifle's bolt (the pump's state)
        bool reloadPressed=(frame.buttons&ReloadHeld)&&!(previousButtons&ReloadHeld);
        bool eject=reloadPressed||(gta4vr()&&config.ejectGrip&&ejectRequest);       // 0.9.0: right grip = A (GTA4VR)
        if(!menuBlocked&&magMode)physicalReload(ped,w,use,cameraPosition,basis,eject,clip,total);
        else if(!menuBlocked&&pumpMode)pumpWork(ped,w,use,cameraPosition,basis,clip,total,now);
        else if(!menuBlocked&&boltMode){boltWork(w,use,cameraPosition,basis,clip);if(!reloadUntil&&(eject||(config.autoReload&&clip==0)))startReload(ped,w,now,clip,total);}
        else if(!menuBlocked&&!reloadUntil&&(eject||(config.autoReload&&clip==0)))startReload(ped,w,now,clip,total);
        total=std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash));clip=clipAmmo(ped,w,total);
        bool twoHanded=w.group>=1&&supportPresent(use,cameraPosition,basis);lastTwoHanded=twoHanded;
        bool needsSupport=config.requireSupport&&!oneHandAllowed(w.group);
        bool supported=!needsSupport||twoHanded;
        bool allowed=!menuBlocked&&!reloadUntil&&clip>0&&total>0&&supported&&(!magMode||mag.canFire(clip))&&(!(pumpMode||boltMode)||pump.chambered());
        float interval=call<float>(GET_WEAPON_TIME_BETWEEN_SHOTS,w.hash);
        if(!std::isfinite(interval)||interval<.03f||interval>5) interval=w.intervalSeconds;
        if(pumpMode)interval=std::min(interval,.25f);   // the pump itself is the rate limit
        shotBlocked=false;bool fired=false;lastAllowed=allowed;
        bool pull=fireGate.update(frame.trigger,allowed,w.automatic,now,std::uint32_t(interval*1000));
        // 0.15.4: GTA's copy is only just being taken out (GunHold=Shooting): the round waits for it (0.3 s at most), so
        // GTA fires it with its own gunshot. Further pulls of an automatic meanwhile are the same round.
        bool copyLate=config.gunSound==Settings::GunSound::Game&&config.gunHold==Settings::GunHold::Shooting&&shotLearn.askGame(w.hash)&&gunMayArm(ped,w,total)&&!copyReady(ped,w,now);
        if(deferShot&&!allowed)deferShot=false;   // the magazine went out, a menu opened...: no round
        bool released=false;
        if(copyLate&&(pull||deferShot)){
            if(!deferShot){deferShot=true;deferAt=now;}
            pull=false;
            if(now>=deferAt+300){deferShot=false;pull=released=true;}}   // not ready in 0.3 s: fired anyway (the mod's bullet if GTA does not)
        else if(deferShot){deferShot=false;pull=released=true;}   // ready: the waiting round is this one (a pull now is the same round)
        if(released&&!deferLogged){deferLogged=true;
            log("Gun sound: the first round waited "+std::to_string(now-deferAt)+" ms for GTA's copy of the "+w.name+(copyLate?" (not ready in 0.3 s: fired anyway)":"")+".");}
        if(pull&&shoot(ped,w,use,cameraPosition,clip,total,twoHanded,!pumpMode&&!boltMode)) {
            if(magMode)mag.fired(clip-1);
            if(pumpMode||boltMode)pump.fired();
            recoil.kick(recoilProfile(w.group,twoHanded),config.recoilScale);fired=true;
        }
        // 0.15.0 (Pavlov): a pull on a gun that cannot fire (empty, slide back, magazine out, pump) = a dry click in the hand.
        bool dry=!menuBlocked&&!reloadUntil&&(clip<=0||(magMode&&!mag.canFire(clip))||((pumpMode||boltMode)&&!pump.chambered()));
        if(dryFire.update(frame.trigger,!dry)&&!fired)ipc.haptic(hapticCode(15,10));
        // 0.14.0 ("after the reload the gun does not fire"): the trigger is pulled and nothing happens -> why, in the log.
        if(!fired&&frame.trigger>=.65f&&now>=noFireLogAt){
            const char* why=shotBlocked?"the muzzle is inside a wall or object (GTA's line test from your eye to the muzzle is blocked)"
                :menuBlocked?"a menu or wheel is open":reloadUntil?"reloading":total<=0?"no ammunition":clip<=0?"the magazine is empty (A: drop it)"
                :!supported?"the left hand must hold the fore-end (RequireSupportGrip=1)":magMode&&mag.stage!=MagStage::Inserted?"the magazine is out (take a new one)"
                :magMode&&!mag.canFire(clip)?"the slide is back - the chamber is empty (pull the slide with the left hand, or press A)":pumpMode&&!pump.chambered()?"pump the shotgun":boltMode&&!pump.chambered()?"work the bolt (left hand: pull it back, push it forward)":nullptr;
            if(why){noFireLogAt=now+3000;log(std::string("Weapons: trigger pulled, ")+w.name+" did not fire: "+why+".");}
        }
        if(config.laser&&!menuBlocked) {
            Vec3 end=use.grip+use.forward*8;
            call(DRAW_LINE,use.grip.x,use.grip.y,use.grip.z,end.x,end.y,end.z,50,210,235,140);
        }
        if(!menuBlocked) {
            clip=clipAmmo(ped,w,std::max(0,call<int>(GET_AMMO_IN_PED_WEAPON,ped,w.hash)));
            std::string state=w.name;
            state+=reloadUntil?" | Reloading...":" | "+std::to_string(clip)+" / "+std::to_string(std::max(0,total-clip));
            const char* step=magMode?mag.instruction(clip):pumpMode?pumpInstruction(ped,w,clip,total):boltMode&&pump.needsPump()&&clip>0?"BOLT: left hand on the bolt (right side, behind the scope), pull back and push forward":"";
            const char* dropKey=gta4vr()&&config.ejectGrip?"right grip / A":"A";
            if(step[0])state=std::string(w.name)+" | "+step+(magMode&&clip<=0&&mag.stage==MagStage::Inserted?std::string(" (")+dropKey+")":std::string());
            else{state+=magMode?std::string(" | ")+dropKey+": drop magazine":pumpMode?std::string():std::string(" | ")+dropKey+": reload";
                if(!supported)state+=" | Hold left grip near the fore-end";
                if(clip==0&&!reloadUntil)state+=" | EMPTY";}
            if(gta4vr()&&config.stickCycle)state+=config.phoneStickUp?" | right stick down: weapon (up: phone)":" | right stick up / down: weapon";
            if(config.showStatus) text(state,.5f,.895f,.3f);
        }
    }
public:
    MotionMod() {
        // Rotate the previous session log; avoid unbounded logging across launches.
        MoveFileExW((directory+L"\\GTAHandVR.log").c_str(),(directory+L"\\GTAHandVR.previous.log").c_str(),MOVEFILE_REPLACE_EXISTING);
        config.load(directory+L"\\GTAHandVR.ini");log(std::string("GTA 5 VR 0.16.3 loaded. Backend protocol 4. Weapons: ")+styleName()+(config.handOnGun?", hand on the gun":"")+".");
        enabled=config.startEnabled;   // 0.14.0
        log(enabled?"Motion controls: on from the start (F8 turns them off; [Motion] StartEnabled=0 waits for F8). Buttons as chosen in the VR menu (Y in GTA's pause menu); by default Y = GTA's character wheel, B = vehicle, A / B = phone, right stick up = GTA's phone (down = next weapon), right stick click = GTA's action key E, both stick clicks = VR on / off.":"Motion controls: off until F8 ([Motion] StartEnabled=0).");
        log(std::string("GTA aim: ")+(config.gtaAim?"on - while the VR gun points at a person the character aims in GTA too (people and missions react).":"off ([Weapons] GtaAim=0)."));
        log(std::string("Hand: ")+(config.handHold&&config.armsDriven?"the weapons go into the character's hand (GTA's prop bone)":config.handHold?"the weapons float at the controllers ([Hands] ArmIk is not Auto or the body is hidden)":"the weapons float at the controllers ([Weapons] HandHold=0)")
            +". Prologue cover at the crates: "+(config.prologueCover?"on":"off")+". Health per kill: "+std::to_string(config.healOnKill)+".");
        // 0.15.8
        log(std::string("Grip: a weapon is taken past 65% of the grip and stays until it is below 35% for 0.1 s")+(config.gripMode==GripMode::Hold&&!gta4vr()?"; let go away from a holster, squeeze within 0.8 s: back in the hand":"")
            +"; a moment without usable input (lost tracking, a slow frame: up to 1.5 s) or a fall keeps what the hands hold. Guns: "
            +(config.gtaGrip&&config.handHold?"held the way GTA holds them (GTA's grip read from its copy right after you take each one; [Weapons] GtaGrip=0 = 0.15.7).":"at the prop bone (GtaGrip=0)."));
    }
    ~MotionMod() { suspend();releaseWheelKeys();releaseActionKey();releaseMenuTaps(0,true); }
    void tick() {
        std::uint64_t now=GetTickCount64();
        releaseCharacterKey(now);   // 0.15.1: GTA's select key (F5 / F6 / F7) is let go here, whatever happens below
        releaseMenuTaps(now,false);actionKeyWanted=false;   // 0.16.3: a menu tap is over; E stays down only if this update wants it
        driveGtaWheel(now);         // 0.15.3: GTA's own wheel - Left Alt / F5-F7 follow its state, every key up when it closes
        driveDirectTap(now);        // 0.15.5: GTA's wheel did not open - the chosen character's key tapped alone
        serviceStow(now);           // 0.15.3: GTA's copy of a gun the hand let go: hidden until GTA has put it away
        serviceAim(now);            // 0.15.5: after GTA's aim, its camera back to the view's heading
        checkIni(now);              // 0.15.5: the VR menu saved GTAHandVR.ini
        aimTouched=false;
        if(now>=nextConnect) { ipc.open(false);nextConnect=now+1000; }
        ipc.read(frame,now);
        bool focus=gameFocused(),inputValid=usable(frame,now);
        bool f8=(GetAsyncKeyState(VK_F8)&0x8000)!=0,f9=(GetAsyncKeyState(VK_F9)&0x8000)!=0;
        // 0.15.6: was (.., true): "related actions" of INPUT_SELECT_CHARACTER_MULTIPLAYER - suspected to be GTA's whole
        // character switch (Left Alt, F5-F7): GTA's wheel never opened with this add-on running, GTA's hint was there.
        wheelKeyAtStart=call<bool>(IS_CONTROL_ENABLED,0,19);   // before this add-on disables anything this frame
        call(DISABLE_CONTROL_ACTION,0,169,false);  // 0.7.0: F8 is also GTA's "switch to GTA Online" key; it only toggles this add-on
        // 0.14.0: Y = GTA's character wheel (characterSwitch), B = vehicles (bButton); F8 = motion controls on / off.
        rawButtons=frame.buttons;
        auto yEvent=yHold.update(inputValid&&(frame.buttons&ToggleHeld),now);
        if(focus&&f8&&!previousF8) { enabled=!enabled;suspend();log(enabled?"Motion controls: on (F8).":"Motion controls: off (F8)."); }
        if(focus&&f9&&!previousF9) { config.load(directory+L"\\GTAHandVR.ini");suspend(); }
        previousF8=f8;previousF9=f9;
        share.flags=0;share.rightGrip=share.leftGrip=GripNone;lastTwoHanded=false;   // 0.13.0: filled during this update
        // 0.15.8: previousButtons kept through a short dropout (holdThrough): a button held across it is no new press.
        const auto finish=[&]() { previousButtons=inputValid?rawButtons:holdingThrough?previousButtons:0;if(selecting||now<wheelViewUntil)share.flags|=CharacterWheel;   // 0.15.3: flat a moment after GTA's wheel
            if(actionKeyDown&&!actionKeyWanted)releaseActionKey();   // 0.16.3: A let go, a menu, a pause...: E up
            // 0.15.6: while GTA's character keys are down, they count - whatever this add-on disabled in this update.
            if(gtaWheel.active()||tapDown||keysDown[0]){wheelKeyAtEnd=call<bool>(IS_CONTROL_ENABLED,0,19);++wheelKeyChecks;
                if(!wheelKeyAtStart)++wheelKeyOffStart;if(!wheelKeyAtEnd)++wheelKeyOffEnd;
                for(int c:{19,166,167,168})call(ENABLE_CONTROL_ACTION,0,c,false);}
            if(aimSteer.steering()&&!aimTouched)endAim(now);   // 0.15.5: the gun left the hand / an early return: GTA's aim ends
            if(aimSteer.publishing()){share.flags|=AimHeading;float yaw=aimSteer.base();std::memcpy(&share.viewYawBits,&yaw,4);}
            publishHands(now); };
        // These checks run before the add-on changes any combat, inventory or locomotion.
        if(call<bool>(NETWORK_IS_SESSION_ACTIVE)||call<bool>(NETWORK_IS_SESSION_STARTED)) {
            enabled=false;suspend();status("GTA 5 VR is disabled in Online.");finish();return;
        }
        int ped=call<int>(PLAYER_PED_ID),player=call<int>(PLAYER_ID);
        if(ped!=ownerPed) { suspend();ownerPed=ped;resetGrips(); }
        if(!enabled) { selecting=false;stickHold.reset();status("GTA Hand VR | F8: motion controls on",focus);finish();return; }
        // 0.15.5: a cutscene that plays (IS_CUTSCENE_ACTIVE is also true while a mission only loads the next one).
        if(!focus||call<bool>(IS_PAUSE_MENU_ACTIVE)||call<bool>(IS_CUTSCENE_PLAYING)||call<bool>(IS_SCREEN_FADED_OUT)) {
            suspend();status("Motion input paused for menu, cutscene or focus.",false);finish();return;
        }
        // 0.8.0: the right stick click opens GTA's own character wheel (also while GTA pauses control for it).
        // 0.14.0: the phone first: A answers / selects, B hangs up / goes back (GTA's own phone inputs); the
        // add-on's own A / B actions wait while the phone rings or is up.
        phoneStickTick(ped,inputValid,now);   // 0.15.7: right stick up = GTA's phone (before the phone's own arrows read the stick)
        phoneUpdate(ped,inputValid,now);
        if(inputValid&&ped&&call<bool>(DOES_ENTITY_EXIST,ped)){auto stickEvent=stickHold.update((frame.buttons&InteractHeld)!=0,now);characterSwitch(ped,stickEvent,yEvent,now);}
        else{stopGtaWheel(ped,now);selecting=gtaWheel.active();stickHold.reset();}
        if(!ped||!call<bool>(DOES_ENTITY_EXIST,ped)||call<bool>(IS_ENTITY_DEAD,ped,false)||!call<bool>(IS_PLAYER_CONTROL_ON,player)) {
            scriptMenuKeys(ped,inputValid,now);   // 0.16.3: a shop's menu (the character has no control meanwhile)
            suspend();status("Motion input paused while the character is unavailable.",false);finish();return;
        }
        menuStick.reset();menuKeysOn=false;
        healOnKill(ped,now);   // 0.15.7: a person killed by the player gives some health back
        if(!inputValid) {
            // 0.15.0: VR off (flat screen: both stick clicks / F11) or the SteamVR dashboard: paused on purpose, nothing drawn.
            bool paused=frame.magic==protocolMagic&&fresh(frame.timeMs,now)&&(frame.flags&DashboardOpen);
            // 0.15.8: a moment of lost tracking or a slow game frame keeps what the hands hold (up to 1.5 s, mod_hold.inc).
            if(!paused&&holdThrough(now,inputProblem(frame,now),false)){
                if(config.showStatus&&now-throughSince>200)text("Tracking lost for a moment - your hands keep what they hold",.5f,.83f,.3f);finish();return;}
            suspend();
            status(paused?"Motion controls paused: VR off (flat screen) or SteamVR dashboard.":"Waiting for controller input / tracking / bindings. Release trigger to resume.",!paused);finish();return; }
        if(!holdingThrough||!throughFall)throughEnded(now);   // 0.15.8: the input is back (a fall / ragdoll: when it ends)
        lastUsable=now;
        // 0.14.0: B enters / steals the vehicle in reach and leaves it (Y before); held on foot = the weapon wheel.
        // 0.15.1: B is the vehicle only (the weapon wheel only while GTA holds a special weapon, or WeaponWheel=1).
        bool inVehicle=call<bool>(IS_PED_IN_ANY_VEHICLE,ped,true);
        extraButtons(ped,inVehicle,now);   // 0.15.5: GTA's action key E, cover, phone, special ability (buttons chosen in the VR menu)
        if(!bButton(ped,(frame.buttons&WheelHeld)!=0,inVehicle,now))frame.buttons&=~WheelHeld;
        updateVehicleRequest(ped,now);
        if(inVehicle) { if(!wasVehicle)suspend();wasVehicle=true;drive(ped,now);finish();return; }
        if(!call<bool>(IS_PED_HUMAN,ped)) { disarmGun();restoreWeapon();destroyObject();removeHolsterProps();move(ped,selecting);status("Animal: left stick moves, right stick turns",false);finish();return; }   // Chop
        vehicleHint(ped,now);
        if(wasVehicle){suspend();wasVehicle=false;}
        // 0.15.8: a fall / ragdoll keeps what the hands hold (until 0.15.7 the weapons went back to their holsters).
        if(call<bool>(IS_PED_RAGDOLL,ped)||call<bool>(IS_PED_FALLING,ped)){
            if(holdThrough(now,"falling / ragdolling",true)){finish();return;}
            suspend();status("Motion input paused while falling or ragdolling.");finish();return;}
        throughEnded(now);
        prologueCoverUpdate(ped,now);   // 0.15.7: the prologue's shoot-out - cover at the crates by itself
        bool menuBlocked=updateWheel(ped)||selecting||now<menuGraceUntil;   // 0.15.1: and just after the character menu closed
        move(ped,menuBlocked);
        // 0.7.0: the character stays unarmed (no GTA weapon animations); the VR hands hold the weapons.
        // A weapon GTA puts in the character's hands (its own wheel, a mission) goes to its holster.
        // 0.15.0: except the gun the VR hand holds: the character holds it too, invisible (GTA's own gunshot).
        // 0.13.0: while GTA holds a weapon for the grip measurement, its weapon switch is ours, not the player's.
        runProbe(ped,now);bool probing=probe!=Probe::Idle||now<probeQuietUntil;
        auto hash=call<std::uint32_t>(GET_SELECTED_PED_WEAPON,ped);
        int index=weaponIndex(hash);
        bool ours=ourGtaWeapon(hash,now);   // 0.15.0: the gun the character holds for GTA's own gunshot
        if(!probing&&!ours&&hash!=UnarmedHash&&(index<0||weapons[index].kind==WeaponKind::Utility||now<gtaWeaponUntil)) {
            if((rightHeld>=0||leftHeld>=0)&&specialLogs<5){++specialLogs;   // 0.15.8: why the hands let go (the log)
                char h[16];std::snprintf(h,sizeof(h),"0x%08X",unsigned(hash));
                log(std::string("Hands: GTA put ")+(index>=0?weapons[index].name:h)+" in the character's hands ("+(index<0?"not one of the add-on's weapons":now<gtaWeaponUntil?"the game kept equipping a weapon":"a mission tool")
                    +") - the VR hands let go of "+(rightHeld>=0?weapons[rightHeld].name:leftHeld>=0?weapons[leftHeld].name:"?")+"; normal GTA controls meanwhile.");}
            dropHands();restoreWeapon();destroyObject();fireGate.reset();reloadUntil=0;reloadHash=0;removeHolsterProps();
            armedHash=armedPrev=0;armedPed=0;pendingRound.clear();   // 0.15.0: GTA's weapon now; ours is no longer in the hand
            stowHash=0;stowPed=0;copyHash=0;showCopyAgain();         // 0.15.3: and GTA's weapon visible (it is GTA's now)
            specialOut=true;   // 0.15.1: B (held) = the weapon wheel back to your weapons, while this lasts
            resetInteractions();activeHash=0;status("Special weapon / mission tool: normal combat controls | B (hold): weapon wheel");finish();return;
        }
        specialOut=false;
        if(hash==UnarmedHash)sawUnarmed=true;else if(!probing&&!ours)adoptGtaWeapon(ped,index,now);
        handsUpdate(ped,now,menuBlocked);
        cycleWeapons(ped,menuBlocked);
        blockCombat(player);
        // 0.9.0 GTA4VR style: the current weapon is in the right hand unless it holds a grenade from the chest.
        int inHand=rightHeld>=0?rightHeld:(gta4vr()&&current>=0?current:weaponIndex(UnarmedHash));
        if(inHand>=0)updateGun(ped,weapons[inHand],now,menuBlocked);
        ejectRequest=false;
        leftHand(ped,now,menuBlocked);
        shareLeft();measurePropBone(ped);
        status("Motion controls active",false);
        finish();
    }
};
static void scriptMain() {
    MotionMod mod;
    while(true) { mod.tick();scriptWait(0); }
}
BOOL APIENTRY DllMain(HMODULE module,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH) { moduleHandle=module;DisableThreadLibraryCalls(module);scriptRegister(module,scriptMain); }
    else if(reason==DLL_PROCESS_DETACH){ releaseWheelKeys();releaseActionKey();releaseMenuTaps(0,true);scriptUnregister(module); }   // 0.15.3: no key stays down
    return TRUE;
}
