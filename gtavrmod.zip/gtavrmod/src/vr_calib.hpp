#pragma once
// 0.9.0: the character's body at the player's height.
//  - HeightCalibration: stand in a T-pose (arms straight out to the sides) and hold both
//    triggers for 2 s. The eye height above the real floor (SteamVR standing space) is saved.
//  - CharacterEyeHeight: how high the current character's eyes are above its feet (measured).
//  - bodyScale: character eyes / player eyes. The world is scaled by it (like WorldScale), so
//    the real floor, real arm reach and the character's body line up.
//  - HandStill: the controller has not moved for a moment (used to measure the arm IK).
//  - TriggerMute: triggers used for the calibration gesture never reach the weapons.
// Plain logic, tested in tests/vr_calib_test.cpp.
#include "core.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace handvr {

struct TPoseInput {
    Pose head{};Vec3 left{},right{};bool leftValid=false,rightValid=false;
    float leftTrigger=0,rightTrigger=0;bool allowed=true;
};
struct CalibrationResult { float eyeHeight=0,span=0; };

// SteamVR standing space: +Y up, -Z forward, floor at y = 0.
// T-pose: looking roughly ahead, one hand on each side about 1 m or more apart, both level
// around shoulder height and in the plane of the body.
inline bool tPoseShape(const TPoseInput& in){
    if(!in.leftValid||!in.rightValid||!validPose(in.head)||!finite(in.left)||!finite(in.right))return false;
    Vec3 h=in.head.pos(),f=-in.head.col(2);
    if(std::abs(f.y)>.45f)return false;
    Vec3 forward=unit(Vec3{f.x,0,f.z},{0,0,-1}),right=cross(forward,{0,1,0});
    float span=length(Vec3{in.left.x-in.right.x,0,in.left.z-in.right.z});
    if(span<.95f||span>2.6f)return false;
    if(std::abs(in.left.y-in.right.y)>.25f)return false;
    for(Vec3 p:{in.left,in.right}){
        if(p.y<h.y-.60f||p.y>h.y+.15f)return false;
        if(std::abs(dot(p-h,forward))>.45f)return false;
    }
    return dot(in.right-h,right)>.30f&&dot(in.left-h,right)<-.30f;
}
inline bool plausibleCalibration(const CalibrationResult& r){
    return std::isfinite(r.eyeHeight)&&std::isfinite(r.span)&&r.eyeHeight>.9f&&r.eyeHeight<2.2f&&r.span>.95f&&r.span<2.6f;
}

class HeightCalibration {
    enum class Stage { Idle,Holding,Latched };
    Stage stage=Stage::Idle;float held=0,sumEye=0,sumSpan=0;int samples=0;bool shape=false;
public:
    static constexpr float HoldSeconds=2.0f;
    enum Event { None,Started,Done,Cancelled };
    // Arms in the T, or the gesture not finished / released yet: the triggers must not shoot.
    bool posing()const{return shape||stage!=Stage::Idle;}
    bool holding()const{return stage==Stage::Holding;}
    float progress()const{return stage==Stage::Holding?std::clamp(held/HoldSeconds,0.0f,1.0f):0.0f;}
    void reset(){stage=Stage::Idle;held=sumEye=sumSpan=0;samples=0;shape=false;}
    Event update(const TPoseInput& in,float dt,CalibrationResult& out){
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        shape=in.allowed&&tPoseShape(in);
        bool pressing=in.leftTrigger>.75f&&in.rightTrigger>.75f;
        switch(stage){
            case Stage::Idle:
                if(shape&&pressing){stage=Stage::Holding;held=sumEye=sumSpan=0;samples=0;return Started;}
                return None;
            case Stage::Holding:
                if(!shape||!pressing){stage=(in.leftTrigger>.3f||in.rightTrigger>.3f)?Stage::Latched:Stage::Idle;held=0;return Cancelled;}
                held+=dt;
                if(held>=HoldSeconds*.5f){sumEye+=in.head.pos().y;sumSpan+=length(in.left-in.right);++samples;}
                if(held>=HoldSeconds&&samples>0){out={sumEye/float(samples),sumSpan/float(samples)};stage=Stage::Latched;return Done;}
                return None;
            case Stage::Latched:
                if(in.leftTrigger<.3f&&in.rightTrigger<.3f)stage=Stage::Idle;
                return None;
        }
        return None;
    }
};

// A trigger muted while the calibration pose is held stays muted until it is released,
// so letting the arms down with the trigger still squeezed does not fire.
class TriggerMute {
    bool muted=false;
public:
    float update(float value,bool mute){
        if(!std::isfinite(value))value=0;
        if(mute)muted=true;else if(value<.25f)muted=false;
        return muted?0.0f:value;
    }
    bool active()const{return muted;}
};

// Eyes above the feet of the current character (median of steady standing samples).
class CharacterEyeHeight {
    std::array<float,45> samples{};int count=0;float result=0;std::uint32_t modelHash=0;
public:
    static constexpr float Default=1.63f;
    void reset(std::uint32_t model){modelHash=model;count=0;result=0;}
    std::uint32_t model()const{return modelHash;}
    bool ready()const{return result>0;}
    float value()const{return result>0?result:Default;}
    // eyeZ: world eye height; toeZ: the lower toe bone (about 3 cm above the sole).
    void add(float eyeZ,float toeZ){
        if(result>0)return;float h=eyeZ-(toeZ-.03f);
        if(!std::isfinite(h)||h<1.30f||h>2.00f)return;
        samples[std::size_t(count++)]=h;
        if(count==int(samples.size())){std::sort(samples.begin(),samples.end());result=samples[samples.size()/2];}
    }
};
// Character eyes / player eyes: the world scale that puts the real floor under the character's feet.
inline float bodyScale(float characterEye,float playerEye){
    if(!std::isfinite(characterEye)||!std::isfinite(playerEye)||!(playerEye>.5f)||!(characterEye>.5f))return 1;
    return std::clamp(characterEye/playerEye,.70f,1.45f);
}

inline float angleDegrees(Vec3 a,Vec3 b){
    float la=length(a),lb=length(b);if(!(la>1e-6f)||!(lb>1e-6f))return 180;
    return std::acos(std::clamp(dot(a,b)/(la*lb),-1.0f,1.0f))*180/pi;
}
// The controller stayed within 3 cm / 8 degrees of where it was for `Needed` seconds.
class HandStill {
    Vec3 refPos{},refZ{},refY{};float since=0;bool primed=false;
public:
    static constexpr float MaxMove=.03f,MaxTurnDegrees=8,Needed=.35f;
    void reset(){primed=false;since=0;}
    bool still()const{return primed&&since>=Needed;}
    bool update(const Pose& p,float dt){
        if(!validPose(p)){reset();return false;}
        if(!(dt>=0)||!std::isfinite(dt))dt=0;
        Vec3 pos=p.pos(),z=p.col(2),y=p.col(1);
        if(!primed||length(pos-refPos)>MaxMove||angleDegrees(z,refZ)>MaxTurnDegrees||angleDegrees(y,refY)>MaxTurnDegrees){
            refPos=pos;refZ=z;refY=y;since=0;primed=true;return false;}
        since+=std::min(dt,.25f);return since>=Needed;
    }
};
}
