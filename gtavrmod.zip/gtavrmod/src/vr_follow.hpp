#pragma once
// 0.10.0: the whole body follows the player. The friend's spec: head = headset tracking,
// arms = both controllers, hands = controller orientation, legs = animation driven by the
// body's movement. GTA animates the legs itself, so the body is made to move like the player:
//  - RoomFollow: a real step away from the character makes it walk under the headset (GTA's
//    walk = the legs); consumeOffset tells the renderer how much of the head offset that walk
//    used up, so the camera stays exactly where the real head is.
//  - BodyTurn: standing still, the character turns to where the player's body faces, so the
//    arms never have to reach around a body that looks the other way.
//  - CrouchDetector: crouching for real puts the character in GTA's crouch stance.
// Plain logic, tested in tests/vr_follow_test.cpp.
#include "core.hpp"
#include <algorithm>
#include <cmath>

namespace handvr {
// GTA world: z is up; "flat" = the horizontal part.
inline Vec3 flat(Vec3 v){return {v.x,v.y,0};}
// a - b in degrees, wrapped to [-180, 180).
inline float headingDifference(float a,float b){
    if(!std::isfinite(a)||!std::isfinite(b))return 0;
    float d=std::fmod(a-b+540.0f,360.0f);if(d<0)d+=360;return d-180;
}

class RoomFollow {
public:
    static constexpr float Start=.30f,Stop=.10f,StallSeconds=1.5f,StallProgress=.05f;
    struct Out { bool walk=false;Vec3 direction{};float speed=0; };
private:
    bool walking=false,stalled=false;float best=0,stallTimer=0;Vec3 stallOffset{};
public:
    void reset(){walking=false;stalled=false;best=0;stallTimer=0;}
    bool active()const{return walking;}
    bool blocked()const{return stalled;}
    // offset: headset camera minus the character's eyes (world metres). idle: no stick input,
    // no menu, on foot and able to walk. Walks while the offset is large; a wall (no progress
    // for 1.5 s) stops it until the offset changes.
    Out update(Vec3 offset,bool idle,float dt){
        Out o;Vec3 d=flat(offset);float distance=length(d);
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        if(!idle||!std::isfinite(distance)){walking=false;if(!std::isfinite(distance))stalled=false;return o;}
        if(stalled){if(length(d-stallOffset)>.25f||distance<Stop)stalled=false;else return o;}
        if(!walking){if(distance<=Start)return o;walking=true;best=distance;stallTimer=0;}
        if(distance<Stop){walking=false;return o;}
        if(distance<best-StallProgress){best=distance;stallTimer=0;}else stallTimer+=dt;
        if(stallTimer>StallSeconds){walking=false;stalled=true;stallOffset=d;return o;}
        o.walk=true;o.direction=d*(1/distance);o.speed=distance>.70f?.75f:.45f;return o;
    }
};
// How much of the character's movement (delta, world) went toward the head offset - never more
// than the offset itself, nothing for a jump (teleport, vehicle) or a move away from the head.
inline Vec3 consumeOffset(Vec3 offset,Vec3 delta){
    Vec3 o=flat(offset),d=flat(delta);float len=length(o);
    if(!finite(o)||!finite(d)||!(len>.02f)||length(d)>2)return {};
    Vec3 u=o*(1/len);float along=std::clamp(dot(d,u),0.0f,len);return u*along;
}

// Standing still: once the player's body faces more than Start degrees away from the character
// for Delay seconds, the character turns until it is within Stop degrees.
class BodyTurn {
public:
    static constexpr float Start=45,Stop=10,Delay=.5f;
private:
    bool turning=false;float waited=0,goal=0;
public:
    void reset(){turning=false;waited=0;}
    bool active()const{return turning;}
    float target()const{return goal;}
    // Headings in degrees (GTA: 0 = north, + = counter-clockwise). Returns true while turning.
    bool update(float pedHeading,float bodyHeading,bool standing,float dt){
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        if(!standing||!std::isfinite(pedHeading)||!std::isfinite(bodyHeading)){turning=false;waited=0;return false;}
        float off=std::abs(headingDifference(bodyHeading,pedHeading));
        if(turning){goal=bodyHeading;if(off<Stop){turning=false;waited=0;}return turning;}
        if(off>Start){waited+=dt;if(waited>=Delay){turning=true;goal=bodyHeading;}}else waited=0;
        return turning;
    }
};
// One step of a manual turn (when GTA ignores the desired heading): at most rate deg/s.
inline float stepHeading(float current,float goal,float rate,float dt){
    float d=headingDifference(goal,current),step=std::max(0.0f,rate)*std::clamp(dt,0.0f,.25f);
    float next=current+std::clamp(d,-step,step);next=std::fmod(next,360.0f);if(next<0)next+=360;return next;
}

// The player's real crouch: head below enter x standing height for Hold seconds -> crouched;
// above leave x standing height for Hold seconds -> standing again.
class CrouchDetector {
public:
    static constexpr float Hold=.30f;
private:
    bool down=false;float timer=0;
public:
    void reset(){down=false;timer=0;}
    bool crouched()const{return down;}
    // Returns +1 when crouching starts, -1 when it ends, 0 otherwise. Not allowed = ends it.
    int update(float head,float stand,float enterRatio,float leaveRatio,float dt,bool allowed){
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        bool ok=allowed&&std::isfinite(head)&&std::isfinite(stand)&&stand>.8f&&enterRatio>.3f&&leaveRatio>enterRatio&&leaveRatio<1;
        if(!ok){timer=0;if(down){down=false;return -1;}return 0;}
        bool want=down?head<stand*leaveRatio:head<stand*enterRatio;
        if(want==down){timer=0;return 0;}
        timer+=dt;if(timer<Hold)return 0;
        timer=0;down=want;return down?1:-1;
    }
};
}
