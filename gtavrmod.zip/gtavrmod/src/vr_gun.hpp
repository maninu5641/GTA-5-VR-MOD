#pragma once
// 0.9.0: weapons like GTA4VR (github.com/bordplate/GTA4VR), adapted to Touch controllers:
//  - the current weapon stays in the right hand; the right stick up / down cycles through the
//    weapons the character owns (unarmed included), the B wheel picks one directly;
//  - the right grip ejects the magazine; the left hand takes a new one over a shoulder (or at
//    the belt), pushes it into the gun and racks the slide / charging handle when needed;
//  - ammunition left in an ejected magazine is lost;
//  - pump-action shotguns must be pumped after every shot (left hand on the fore-end: back,
//    then forward) and are loaded one shell at a time.
// Grenades stay on the chest (grab with either hand, let go to throw).
// Plain logic, tested in tests/vr_gun_test.cpp.
#include "vr_play.hpp"
#include <array>

namespace handvr {
enum class WeaponStyle { GTA4VR,Holsters };

inline bool pumpAction(std::uint32_t hash){
    switch(hash){
        case 0x1D073A89u:   // Pump Shotgun
        case 0x555AF99Au:   // Pump Shotgun Mk II
        case 0x7846A318u:   // Sawed-Off Shotgun
        case 0x9D61E50Fu:   // Bullpup Shotgun
        case 0x05A96BA4u:   // Combat Shotgun
            return true;
        default:return false;
    }
}
// 0.15.0 (Pavlov): bolt-action rifles - the bolt is worked by hand after every shot. GTA's Sniper Rifle is an
// Accuracy International-style bolt-action rifle (the Heavy Sniper and Marksman Rifle are semi-automatic).
inline bool boltActionRifle(std::uint32_t hash){return hash==0x05FC3C11u;}   // WEAPON_SNIPERRIFLE
// What the right stick cycles: unarmed, melee, pistols, SMGs, rifles, shotguns, machine guns,
// snipers, heavy weapons. Grenades (chest) and special tools (GTA's own controls) are left out.
inline bool cycles(const Weapon& w){return w.hash==UnarmedHash||w.kind==WeaponKind::Melee||w.kind==WeaponKind::Gun;}
inline int cycleRank(const Weapon& w){
    if(w.hash==UnarmedHash)return 0;
    if(w.kind==WeaponKind::Melee)return 1;
    static constexpr int rank[8]={1,2,3,4,6,5,7,8};return rank[w.group&7];
}
// owned: catalogue indices the character has. current: the weapon in the hand (-1 = unarmed).
// direction +1 / -1. Returns the next index (-1 = unarmed).
inline int cycleWeapon(const int* owned,int count,int current,int direction){
    const int unarmed=weaponIndex(UnarmedHash);
    std::array<int,weaponCount+1> list{};int n=0;list[std::size_t(n++)]=unarmed;
    for(int rank=1;rank<=8;++rank)for(int i=0;i<count;++i){int k=owned[i];
        if(k<0||k>=weaponCount||k==unarmed)continue;const Weapon& w=weapons[k];
        bool seen=false;for(int j=0;j<n;++j)if(list[std::size_t(j)]==k)seen=true;
        if(!seen&&cycles(w)&&cycleRank(w)==rank)list[std::size_t(n++)]=k;}
    int position=0;for(int i=0;i<n;++i)if(list[std::size_t(i)]==(current<0?unarmed:current))position=i;
    if(direction!=0)position=((position+(direction>0?1:-1))%n+n)%n;
    int result=list[std::size_t(position)];return result==unarmed?-1:result;
}
// Right stick pushed clearly up (+1) or down (-1). Diagonals and sideways pushes (snap turn) do not count.
class StickFlick {
    bool armed=false;
public:
    void reset(){armed=false;}
    static bool vertical(float x,float y){return std::isfinite(x)&&std::isfinite(y)&&std::abs(y)>.5f&&std::abs(y)>std::abs(x);}
    int update(float x,float y){
        if(!std::isfinite(x)||!std::isfinite(y)){armed=false;return 0;}
        if(std::abs(y)<.35f&&std::abs(x)<.5f)armed=true;
        if(armed&&std::abs(y)>.75f&&std::abs(y)>1.5f*std::abs(x)){armed=false;return y>0?1:-1;}
        return 0;
    }
};
// A full squeeze of an analog grip after it was released (a light hold is not a press).
class GripPress {
    bool down=true;
public:
    void reset(){down=true;}
    bool update(float value){
        if(!std::isfinite(value))value=0;
        if(down){if(value<.35f)down=false;return false;}
        if(value>.85f){down=true;return true;}
        return false;
    }
};
// Rounds lost with an ejected magazine: everything in it except a chambered round.
inline int ammoAfterEject(int total,int clip,bool chambered){
    int inMagazine=std::max(0,clip-(chambered&&clip>0?1:0));return std::max(0,total-inMagazine);
}

// ---------- Ammunition over the shoulders ----------
// GTA4VR: "left grip over the shoulder retrieves ammunition". Tracking space; yaw = torso yaw;
// size = player's body size relative to an average adult (1 = eyes ~1.62 m).
inline bool atShoulderAmmo(Vec3 headPos,float yaw,Vec3 hand,float heightOffset=0,float size=1){
    if(!finite(hand)||!finite(headPos))return false;
    if(!(size>.4f)||size>2)size=1;
    Vec3 f=yawForward(yaw),r=cross(f,{0,1,0}),h=headPos+Vec3{0,heightOffset,0};
    for(float side:{-1.0f,1.0f}){Vec3 c=h-Vec3{0,.08f*size,0}+r*(side*.17f*size)-f*(.12f*size);if(length(hand-c)<.22f*size)return true;}
    return false;
}

// ---------- Pump action ----------
// After a shot the chamber holds a spent shell. With the left hand gripping the fore-end, pull
// it back (the shell flies out) and push it forward (the next shell from the tube is chambered).
// Letting go after pulling back closes it too. A gun with a live round is not affected.
class PumpAction {
public:
    enum class Stage { Closed,Back };
    static constexpr float Pull=.06f,Push=.045f;
    struct Events { bool back=false,forward=false; };
private:
    Stage st=Stage::Closed;bool live=true,gripping=false;float extreme=0;
public:
    bool chambered()const{return live;}
    Stage stage()const{return st;}
    bool needsPump()const{return !live;}
    void reset(bool chamberLoaded){st=Stage::Closed;live=chamberLoaded;gripping=false;extreme=0;}
    void fired(){live=false;}
    // grip: left grip held at the fore-end; slide: the left hand's distance ahead of the right hand
    // along the barrel (metres, real scale); rounds: shells left in the gun (tube, no chamber).
    Events update(bool grip,float slide,int rounds){
        Events e;if(!std::isfinite(slide))grip=false;
        if(!grip){if(gripping&&st==Stage::Back){st=Stage::Closed;e.forward=true;live=rounds>0;}gripping=false;return e;}
        if(!gripping){gripping=true;extreme=slide;return e;}
        if(st==Stage::Closed){
            if(live){extreme=slide;return e;}
            extreme=std::max(extreme,slide);
            if(slide<=extreme-Pull){st=Stage::Back;e.back=true;extreme=slide;}
        }else{
            extreme=std::min(extreme,slide);
            if(slide>=extreme+Push){st=Stage::Closed;e.forward=true;live=rounds>0;extreme=slide;}
        }
        return e;
    }
};
// Shells one at a time: grab shells over a shoulder (or at the belt), hold the left hand at the
// loading port; one shell goes in every Interval seconds while there is room and ammunition.
class ShellLoader {
    bool holding=false,previousGrip=true;float timer=0;
public:
    static constexpr float Interval=.35f,First=.12f;
    struct Events { bool grabbed=false,dropped=false;int inserted=0; };
    bool holdingShells()const{return holding;}
    void reset(){holding=false;previousGrip=true;timer=0;}
    Events update(bool grip,bool atPouch,bool atPort,bool room,bool reserve,float dt){
        Events e;if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        bool press=grip&&!previousGrip,release=!grip&&previousGrip;previousGrip=grip;
        if(!holding){if(press&&atPouch&&room&&reserve){holding=true;e.grabbed=true;timer=Interval-First;}return e;}
        if(release){holding=false;e.dropped=true;timer=0;return e;}
        if(!room||!reserve){holding=false;e.dropped=true;timer=0;return e;}
        if(atPort){timer+=dt;if(timer>=Interval){timer=0;e.inserted=1;}}
        else timer=Interval-First;
        return e;
    }
};
// The left hand on the fore-end: anywhere along the barrel (where a supporting hand holds it), close
// to its axis. `holding`: already gripping it, so a pump stroke may wander a little further.
inline bool onForeEnd(const WeaponPose& p,Vec3 hand,bool sawedOff,bool holding,float scale=1){
    if(!finite(hand)||!finite(p.grip)||!(scale>0))return false;
    Vec3 d=hand-p.grip;float along=dot(d,p.forward)/scale,side=length(d-p.forward*dot(d,p.forward))/scale;
    float nearEnd=sawedOff?.08f:.12f,farEnd=sawedOff?.42f:.62f,radius=holding?.15f:.10f;
    return along>nearEnd-(holding?.05f:0.0f)&&along<farEnd&&side<radius;
}
// Where the left hand works a shotgun: the fore-end (pump) and the loading port, from the gun pose.
struct ShotgunAnchors { Vec3 foreEnd{},port{}; };
inline ShotgunAnchors shotgunAnchors(const WeaponPose& p,bool sawedOff,float scale=1){
    ShotgunAnchors a;
    a.foreEnd=p.grip+p.forward*((sawedOff?.20f:.32f)*scale)-p.up*(.04f*scale);
    a.port=p.grip+p.forward*(.09f*scale)-p.up*(.07f*scale);
    return a;
}
}
