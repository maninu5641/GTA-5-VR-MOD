#pragma once
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "core.hpp"
#if defined(__GNUC__) || defined(__clang__)
#define SHV_SYMBOL(name) __asm__(name)
#else
#define SHV_SYMBOL(name)
#endif
// Script Hook V's public x64 ABI. The runtime itself is NOT redistributed.
__declspec(dllimport) void nativeInit(std::uint64_t) SHV_SYMBOL("?nativeInit@@YAX_K@Z");
__declspec(dllimport) void nativePush64(std::uint64_t) SHV_SYMBOL("?nativePush64@@YAX_K@Z");
__declspec(dllimport) std::uint64_t* nativeCall() SHV_SYMBOL("?nativeCall@@YAPEA_KXZ");
__declspec(dllimport) void scriptRegister(HMODULE,void(*)()) SHV_SYMBOL("?scriptRegister@@YAXPEAUHINSTANCE__@@P6AXXZ@Z");
__declspec(dllimport) void scriptUnregister(HMODULE) SHV_SYMBOL("?scriptUnregister@@YAXPEAUHINSTANCE__@@@Z");
__declspec(dllimport) void scriptWait(DWORD) SHV_SYMBOL("?scriptWait@@YAXK@Z");
namespace gta {
struct NativeVector { alignas(8) float x;alignas(8) float y;alignas(8) float z; };
static_assert(sizeof(NativeVector)==24&&offsetof(NativeVector,y)==8&&offsetof(NativeVector,z)==16);
template<class R=void,class... Args> R call(std::uint64_t hash,Args... args) {
    nativeInit(hash);(nativePush64(handvr::argument(args)),...);
    auto result=nativeCall();
    if constexpr(std::is_same_v<R,handvr::Vec3>) {
        NativeVector v{};std::memcpy(&v,result,sizeof(v));return {v.x,v.y,v.z};
    } else if constexpr(!std::is_void_v<R>) {
        R value{};std::memcpy(&value,result,sizeof(R));return value;
    }
}
}
