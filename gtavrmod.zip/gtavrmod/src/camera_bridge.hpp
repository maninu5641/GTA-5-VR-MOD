#pragma once
#include "camera_api.h"
#include "stereo.hpp"
#include <cstddef>
#include <mutex>

namespace handvr {
static_assert(sizeof(Gta5VrHeadPose)==72 && offsetof(Gta5VrHeadPose,headToStanding)==24);
static_assert(sizeof(Gta5VrCameraSnapshot)==152 && offsetof(Gta5VrCameraSnapshot,nativeCamera)==88);
static_assert(std::is_trivially_copyable_v<Gta5VrHeadPose>);
static_assert(std::is_trivially_copyable_v<Gta5VrCameraSnapshot>);

inline Pose poseFromPacket(const Gta5VrHeadPose& packet) {
    Pose result{};std::memcpy(result.m,packet.headToStanding,sizeof(result.m));return result;
}
inline void cameraMatrix(float (&out)[12],const WorldCamera& camera) {
    const Vec3 columns[]={camera.basis.right,camera.basis.forward,camera.basis.up,camera.position};
    for(int c=0;c<4;++c){out[c]=columns[c].x;out[4+c]=columns[c].y;out[8+c]=columns[c].z;}
}
inline float orientationError(const Basis& expected,const Basis& actual) {
    float trace=dot(expected.right,actual.right)+dot(expected.forward,actual.forward)+dot(expected.up,actual.up);
    return std::acos(std::clamp((trace-1)*.5f,-1.0f,1.0f))*180/pi;
}
inline Gta5VrCameraSnapshot cameraSnapshot(const WorldCamera& requested,const WorldCamera& actual,
        float requestedFov,float actualFov,int handle,bool active,std::uint64_t now,std::uint64_t frame,std::uint32_t source) {
    Gta5VrCameraSnapshot result{};result.structSize=sizeof(result);result.version=GTA5VR_CAMERA_API_VERSION;
    result.timeMs=now;result.frame=frame;result.state=GTA5VR_CAMERA_ACTIVE;result.poseSource=source;result.cameraHandle=handle;
    cameraMatrix(result.requestedCamera,requested);cameraMatrix(result.nativeCamera,actual);
    result.requestedFov=requestedFov;result.nativeFov=actualFov;
    result.positionError=length(requested.position-actual.position);result.orientationErrorDegrees=orientationError(requested.basis,actual.basis);
    if(active)result.flags|=GTA5VR_CAMERA_NATIVE_ACTIVE;
    if(finite(requested.position)&&finite(actual.position)&&validBasis(requested.basis)&&validBasis(actual.basis)
        &&std::isfinite(requestedFov)&&std::isfinite(actualFov)&&result.positionError<=.02f
        &&result.orientationErrorDegrees<=.5f&&std::abs(requestedFov-actualFov)<=.1f)
        result.flags|=GTA5VR_CAMERA_READBACK_MATCHES;
    return result;
}

struct CameraTracking {
    Pose head{};bool valid=false,recenter=false;
    std::uint32_t source=GTA5VR_POSE_STEAMVR;
};
// A narrow thread-safe mailbox: public exports only move POD data. The script
// fiber owns all camera natives; the render callback never invokes them.
class CameraBridge {
    std::mutex mutex;
    Gta5VrHeadPose external{};
    Gta5VrCameraSnapshot latest{};
    bool enabled=false,overrideActive=false,recenterPending=false;
public:
    CameraBridge(){latest.structSize=sizeof(latest);latest.version=GTA5VR_CAMERA_API_VERSION;}
    void enable(bool value,std::uint64_t now){std::lock_guard<std::mutex> lock(mutex);
        if(value&&!enabled){latest={};latest.structSize=sizeof(latest);latest.version=GTA5VR_CAMERA_API_VERSION;latest.timeMs=now;}
        enabled=value;if(!value){overrideActive=false;external={};recenterPending=false;latest={};
            latest.structSize=sizeof(latest);latest.version=GTA5VR_CAMERA_API_VERSION;latest.state=GTA5VR_CAMERA_DISABLED;latest.timeMs=now;}
    }
    int submit(const Gta5VrHeadPose& packet,std::uint64_t now){
        if(packet.structSize!=sizeof(packet)||packet.version!=GTA5VR_CAMERA_API_VERSION||!packet.sequence||!validPose(poseFromPacket(packet)))
            return GTA5VR_CAMERA_BAD_ARGUMENT;
        if(!fresh(packet.sampleTimeMs,now,150))return GTA5VR_CAMERA_STALE_POSE;
        std::lock_guard<std::mutex> lock(mutex);
        if(!enabled)return GTA5VR_CAMERA_UNAVAILABLE;
        if(overrideActive&&(packet.sequence<=external.sequence||packet.sampleTimeMs<external.sampleTimeMs))return GTA5VR_CAMERA_OUT_OF_ORDER;
        if(!overrideActive)recenterPending=true;
        external=packet;overrideActive=true;return GTA5VR_CAMERA_OK;
    }
    int clear(){std::lock_guard<std::mutex> lock(mutex);if(!enabled)return GTA5VR_CAMERA_UNAVAILABLE;
        if(overrideActive)recenterPending=true;overrideActive=false;external={};return GTA5VR_CAMERA_OK;
    }
    int recenter(){std::lock_guard<std::mutex> lock(mutex);if(!enabled)return GTA5VR_CAMERA_UNAVAILABLE;
        recenterPending=true;return GTA5VR_CAMERA_OK;
    }
    CameraTracking select(const Pose& runtimeHead,bool runtimeValid,std::uint64_t now){std::lock_guard<std::mutex> lock(mutex);
        CameraTracking result;result.head=runtimeHead;result.valid=runtimeValid&&validPose(runtimeHead);
        result.recenter=recenterPending;recenterPending=false;
        if(overrideActive){result.source=GTA5VR_POSE_PLUGIN;result.valid=result.valid&&fresh(external.sampleTimeMs,now,150);
            if(result.valid)result.head=poseFromPacket(external);}
        return result;
    }
    void publish(const Gta5VrCameraSnapshot& value){std::lock_guard<std::mutex> lock(mutex);if(enabled)latest=value;}
    void suspend(std::uint64_t now,std::uint32_t source=GTA5VR_POSE_STEAMVR){std::lock_guard<std::mutex> lock(mutex);
        auto frame=latest.frame;latest={};latest.structSize=sizeof(latest);latest.version=GTA5VR_CAMERA_API_VERSION;
        latest.timeMs=now;latest.frame=frame;latest.poseSource=source;latest.state=enabled?GTA5VR_CAMERA_SUSPENDED:GTA5VR_CAMERA_DISABLED;
    }
    Gta5VrCameraSnapshot read(){std::lock_guard<std::mutex> lock(mutex);return latest;}
};
}
