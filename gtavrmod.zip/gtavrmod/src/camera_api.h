#pragma once
#include <stdint.h>

/* Public, in-process ABI. Resolve these functions with GetProcAddress on the
   already-loaded GTA5VRRenderer.asi. No GTA native may run on a caller thread.
   Read docs/CAMERA_API.md before supplying an external tracking pose. */
#if defined(_WIN32) && defined(GTA5VR_CAMERA_API_BUILD)
#define GTA5VR_CAMERA_PUBLIC __declspec(dllexport)
#else
#define GTA5VR_CAMERA_PUBLIC
#endif
#ifdef __cplusplus
extern "C" {
#endif

enum { GTA5VR_CAMERA_API_VERSION = 1 };
enum Gta5VrCameraResult {
    GTA5VR_CAMERA_OK = 0,
    GTA5VR_CAMERA_BAD_ARGUMENT = 1,
    GTA5VR_CAMERA_UNAVAILABLE = 2,
    GTA5VR_CAMERA_STALE_POSE = 3,
    GTA5VR_CAMERA_OUT_OF_ORDER = 4
};
enum Gta5VrCameraState {
    GTA5VR_CAMERA_STARTING = 0,
    GTA5VR_CAMERA_ACTIVE = 1,
    GTA5VR_CAMERA_SUSPENDED = 2,
    GTA5VR_CAMERA_DISABLED = 3
};
enum Gta5VrPoseSource {
    GTA5VR_POSE_STEAMVR = 1,
    GTA5VR_POSE_PLUGIN = 2
};
enum Gta5VrCameraFlags {
    GTA5VR_CAMERA_NATIVE_ACTIVE = 1,
    GTA5VR_CAMERA_READBACK_MATCHES = 2
};

/* Sample time uses Windows GetTickCount64(), not wall clock or predicted display
   time. Sequence must increase until ClearHeadPose(). Freshness limit: 150 ms.
   Row-major 3x4 rigid transform in OpenVR STANDING space: metres, +Y up, -Z front.
   It MUST share the runtime's coordinate system with the HMD/controllers. */
typedef struct Gta5VrHeadPose {
    uint32_t structSize;
    uint32_t version;
    uint64_t sampleTimeMs;
    uint64_t sequence;
    float headToStanding[12];
} Gta5VrHeadPose;

/* Matrices map camera-local (right, forward, up) into GTA world axes. They are
   row-major 3x4 transforms. Readback is from GET_CAM_COORD/ROT after setters; it
   does not prove which view the engine rendered into a particular backbuffer. */
typedef struct Gta5VrCameraSnapshot {
    uint32_t structSize;
    uint32_t version;
    uint64_t timeMs;
    uint64_t frame;
    uint32_t state;
    uint32_t poseSource;
    uint32_t flags;
    int32_t cameraHandle;
    float requestedCamera[12];
    float nativeCamera[12];
    float requestedFov;
    float nativeFov;
    float positionError;
    float orientationErrorDegrees;
} Gta5VrCameraSnapshot;

GTA5VR_CAMERA_PUBLIC uint32_t GTA5VR_GetCameraApiVersion(void);
GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_SubmitHeadPose(const Gta5VrHeadPose* pose, uint32_t bytes);
GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_ClearHeadPose(void);
GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_RequestRecenter(void);
GTA5VR_CAMERA_PUBLIC int32_t GTA5VR_ReadCamera(Gta5VrCameraSnapshot* snapshot, uint32_t bytes);

#ifdef __cplusplus
}
#endif
