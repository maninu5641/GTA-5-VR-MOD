#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <type_traits>

namespace handvr {
constexpr float pi = 3.14159265358979323846f;
constexpr float rad(float degrees) { return degrees * pi / 180.0f; }
struct Vec3 {
    float x{}, y{}, z{};
    Vec3 operator+(Vec3 b) const { return {x+b.x,y+b.y,z+b.z}; }
    Vec3 operator-(Vec3 b) const { return {x-b.x,y-b.y,z-b.z}; }
    Vec3 operator*(float s) const { return {x*s,y*s,z*s}; }
    Vec3 operator-() const { return {-x,-y,-z}; }
};
inline float dot(Vec3 a,Vec3 b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline Vec3 cross(Vec3 a,Vec3 b) { return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x}; }
inline float length(Vec3 v) { return std::sqrt(dot(v,v)); }
inline Vec3 unit(Vec3 v,Vec3 fallback={0,1,0}) { float n=length(v); return n>1e-6f ? v*(1/n) : fallback; }
inline bool finite(Vec3 v) { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z); }
struct Pose {
    // OpenVR row-major tracking-space transform: metres, +Y up, -Z forward.
    float m[3][4]{};
    Vec3 pos() const { return {m[0][3],m[1][3],m[2][3]}; }
    Vec3 col(int c) const { return {m[0][c],m[1][c],m[2][c]}; }
    Vec3 rotate(Vec3 v) const { return col(0)*v.x+col(1)*v.y+col(2)*v.z; }
    Vec3 inverseRotate(Vec3 v) const { return {dot(col(0),v),dot(col(1),v),dot(col(2),v)}; }
};
inline bool validPose(const Pose& p) {
    if(!finite(p.pos())||length(p.pos())>10000) return false;
    for(int i=0;i<3;++i) if(!finite(p.col(i))||std::abs(length(p.col(i))-1)>0.03f) return false;
    return std::abs(dot(p.col(0),p.col(1)))<0.03f && dot(cross(p.col(0),p.col(1)),p.col(2))>0.97f;
}
struct Basis { Vec3 right,forward,up; };
// GTA camera rotation order 2 = ZXY, degrees (pitch, roll, heading).
inline Basis cameraBasis(Vec3 e) {
    float p=rad(e.x),r=rad(e.y),y=rad(e.z);
    Vec3 f{-std::sin(y)*std::cos(p),std::cos(y)*std::cos(p),std::sin(p)};
    Vec3 right{std::cos(y),std::sin(y),0};
    Vec3 up=cross(right,f);
    return {right*std::cos(r)-up*std::sin(r),f,up*std::cos(r)+right*std::sin(r)};
}
inline Vec3 headLocalToWorld(Vec3 local,const Basis& camera) {
    return camera.right*local.x+camera.up*local.y-camera.forward*local.z;
}
inline Vec3 trackingVectorToWorld(Vec3 tracking,const Pose& head,const Basis& camera) {
    return headLocalToWorld(head.inverseRotate(tracking),camera);
}
struct WeaponPose { Vec3 grip,forward,right,up; };
inline WeaponPose mapHand(const Pose& head,const Pose& hand,Vec3 cameraPosition,
                          const Basis& camera,float scale,float pitchDegrees) {
    const float p=rad(pitchDegrees);
    Vec3 f=unit(trackingVectorToWorld(hand.rotate({0,std::sin(p),-std::cos(p)}),head,camera));
    Vec3 r=unit(trackingVectorToWorld(hand.col(0),head,camera));
    Vec3 u=unit(cross(r,f),camera.up);
    r=unit(cross(f,u),camera.right);
    return {cameraPosition+trackingVectorToWorld(hand.pos()-head.pos(),head,camera)*scale,f,r,u};
}
struct Quaternion { float x,y,z,w; };
// A proper orthonormal basis, expressed as local X/Y/Z columns.
inline Quaternion quaternion(Vec3 x,Vec3 y,Vec3 z) {
    float m[3][3]={{x.x,y.x,z.x},{x.y,y.y,z.y},{x.z,y.z,z.z}};
    float q[4]{}; float trace=m[0][0]+m[1][1]+m[2][2];
    if(trace>0) {
        float s=std::sqrt(trace+1)*2;
        q[3]=0.25f*s; q[0]=(m[2][1]-m[1][2])/s; q[1]=(m[0][2]-m[2][0])/s; q[2]=(m[1][0]-m[0][1])/s;
    } else {
        int i=0; if(m[1][1]>m[0][0]) i=1; if(m[2][2]>m[i][i]) i=2;
        int j=(i+1)%3,k=(j+1)%3;
        float s=std::sqrt(std::max(0.0f,1+m[i][i]-m[j][j]-m[k][k]))*2;
        if(s<1e-6f) return {0,0,0,1};
        q[i]=s*0.25f; q[j]=(m[j][i]+m[i][j])/s; q[k]=(m[k][i]+m[i][k])/s; q[3]=(m[k][j]-m[j][k])/s;
    }
    return {q[0],q[1],q[2],q[3]};
}
inline float deadzone(float v,float d=0.18f) {
    if(!std::isfinite(v)||std::abs(v)<=d) return 0;
    return std::copysign(std::min(1.0f,(std::abs(v)-d)/(1-d)),v);
}
inline int wheelSector(float x,float y,int count,float threshold=0.35f) {
    if(count<=0||!std::isfinite(x)||!std::isfinite(y)||x*x+y*y<threshold*threshold) return -1;
    float angle=std::atan2(x,y); if(angle<0) angle+=2*pi;
    return int(std::floor(angle*count/(2*pi)+0.5f))%count;
}
class Wheel {
public:
    bool open=false; int hover=-1;
    // Returns a selection only on release; returning the stick to centre cancels.
    int update(bool held,float x,float y,int count) {
        if(held) { open=true; hover=wheelSector(x,y,count); return -1; }
        int selected=open?wheelSector(x,y,count):-1; cancel(); return selected;
    }
    void cancel() { open=false; hover=-1; }
};
class FireGate {
    bool armed=false,wasDown=false;
    std::uint64_t next=0;
public:
    void reset() { armed=false; wasDown=false; next=0; }
    // Releasing the trigger is required after any interruption.
    bool update(float trigger,bool allowed,bool automatic,std::uint64_t now,std::uint32_t intervalMs) {
        bool down=trigger>=0.65f;
        if(!allowed) { reset(); return false; }
        if(trigger<=0.25f) armed=true;
        bool fire=armed&&down&&(automatic||!wasDown)&&now>=next;
        wasDown=down;
        if(fire) next=now+std::max(30u,intervalMs);
        return fire;
    }
};
class SnapTurn {
    bool armed=true;
public:
    float update(float x,bool blocked,float degrees) {
        if(blocked) { armed=false; return 0; }
        if(std::abs(x)<0.3f) armed=true;
        if(armed&&std::abs(x)>0.75f) { armed=false; return x>0?-degrees:degrees; }
        return 0;
    }
};
inline bool fresh(std::uint64_t sample,std::uint64_t now,std::uint64_t age=200) {
    return sample!=0&&sample<=now&&now-sample<=age;
}
constexpr std::uint32_t joaat(const char* text) {
    std::uint32_t h=0;
    for(;*text;++text) { unsigned char c=static_cast<unsigned char>(*text); if(c>='A'&&c<='Z') c+=32; h+=c;h+=(h<<10);h^=(h>>6); }
    h+=(h<<3);h^=(h>>11);h+=(h<<15);return h;
}
template<class T> std::uint64_t argument(T value) {
    static_assert(sizeof(T)<=8);
    if constexpr(std::is_pointer_v<T>) return reinterpret_cast<std::uint64_t>(value);
    else if constexpr(std::is_floating_point_v<T>) { static_assert(sizeof(T)==4,"GTA natives use float, never double");std::uint64_t bits=0;std::memcpy(&bits,&value,4);return bits; }
    else { std::uint64_t bits=0;std::memcpy(&bits,&value,sizeof(T));return bits; }
}
} // namespace handvr
