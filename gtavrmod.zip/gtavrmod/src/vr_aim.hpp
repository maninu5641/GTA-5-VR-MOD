#pragma once
// 0.15.5 (the friend: "the person does not react when I aim - if I aim at someone, instead of being scared they
// don't move, like in the first mission"): people and missions react to a gun only through GTA's own aim (the
// prologue's hostages stand up when the player "free aims" at them; a shopkeeper empties the till). The VR gun is
// not GTA's aim. Now, while the VR barrel points at a person, the character aims in GTA too: GTA's invisible copy
// of the gun in the hand, GTA's aim input held, and GTA's camera (not the view) turned to that person. The view
// keeps its own heading meanwhile (the renderer takes it from the motion add-on: AimSteer).
// Portable: tests/vr_aim_test.cpp.
#include "core.hpp"
namespace handvr {
inline float aimWrap(float a){if(!std::isfinite(a))return 0;a=std::fmod(a+180.0f,360.0f);if(a<0)a+=360;return a-180;}
// GTA headings: degrees, 0 = north (+Y), counter-clockwise (90 = west, -X). Pitch: degrees, up positive.
inline float headingTo(Vec3 from,Vec3 to){Vec3 d=to-from;return std::atan2(-d.x,d.y)*180/pi;}
inline float pitchTo(Vec3 from,Vec3 to){Vec3 d=to-from;return std::atan2(d.z,std::sqrt(d.x*d.x+d.y*d.y))*180/pi;}
inline Vec3 headingVector(float heading,float pitch){float h=rad(heading),p=rad(pitch);return {-std::sin(h)*std::cos(p),std::cos(h)*std::cos(p),std::sin(p)};}

// The person the barrel points at: the smallest angle between the barrel and the line to each one's chest, within
// max(minDegrees, the angle a 0.35 m body radius makes at that distance), nearer than maxDistance, not behind the
// muzzle. Score = angle / allowed angle (ties: the nearer one).
struct AimPick { int index=-1;float angle=0,distance=0; };
inline AimPick pickAimTarget(Vec3 muzzle,Vec3 forward,const Vec3* chests,int count,float maxDistance,float minDegrees=3.0f,float radius=.35f){
    AimPick best{};float bestScore=1e9f;
    Vec3 f=unit(forward,{0,0,0});if(length(f)<.5f||!finite(muzzle)||!chests)return best;
    for(int i=0;i<count;++i){
        if(!finite(chests[i]))continue;
        Vec3 d=chests[i]-muzzle;float dist=length(d);
        if(!(dist>.3f)||dist>maxDistance)continue;
        float c=std::clamp(dot(d*(1/dist),f),-1.0f,1.0f);float angle=std::acos(c)*180/pi;
        float allowed=std::max(minDegrees,std::atan(radius/dist)*180/pi);
        if(angle>allowed)continue;
        float score=angle/allowed+dist*.001f;
        if(score<bestScore){bestScore=score;best={i,angle,dist};}
    }
    return best;}

// GTA's camera while GTA aims, and the heading the view keeps (base):
//  Off -> Steering (start: base = GTA's camera heading at that moment) -> Settling (release: GTA's camera is sent
//  back to base) -> Off once GTA's camera is within 3 degrees of base for 2 updates (at least 3 updates; 0.6 s at
//  most). A snap turn meanwhile turns base (the view turns; GTA's camera stays on the person).
class AimSteer {
public:
    enum class Phase { Off,Steering,Settling };
private:
    Phase now_=Phase::Off;float base_=0;std::uint64_t since=0;int ticks=0,close=0;
public:
    static constexpr std::uint64_t SettleMaxMs=600;
    Phase phase()const{return now_;}
    bool steering()const{return now_==Phase::Steering;}
    bool publishing()const{return now_!=Phase::Off;}
    float base()const{return base_;}
    void start(float cameraHeading){if(now_==Phase::Off)base_=aimWrap(cameraHeading);now_=Phase::Steering;}
    void turn(float degrees){if(now_!=Phase::Off&&std::isfinite(degrees))base_=aimWrap(base_+degrees);}
    void release(std::uint64_t now){if(now_!=Phase::Steering)return;now_=Phase::Settling;since=now;ticks=0;close=0;}
    // Each update while settling (GTA's camera already sent back to base this update): true once done.
    bool settle(float cameraHeading,std::uint64_t now){
        if(now_!=Phase::Settling)return now_==Phase::Off;
        ++ticks;close=std::abs(aimWrap(cameraHeading-base_))<3.0f?close+1:0;
        if((ticks>=3&&close>=2)||now-since>=SettleMaxMs){now_=Phase::Off;ticks=close=0;return true;}
        return false;}
    void stop(){now_=Phase::Off;ticks=close=0;}
};

// Renderer: the heading the eye position is placed with. GTA turns the character to where it aims; the eye sits
// 25 cm in front of the body, so following that turn would swing the view sideways. While GTA aims, the heading the
// character had is kept (turned by snap turns only); after the aim it goes over to the character's real heading in
// 0.4 s. hold() = do not re-measure the eye offset meanwhile.
class AnchorHeading {
    bool active=false,blending=false;float frozen=0,lastBase=0,t=1;
public:
    static constexpr float BlendSeconds=.4f;
    bool hold()const{return active||blending;}
    float update(bool aiming,float base,float pedHeading,float dt){
        if(!std::isfinite(pedHeading))return pedHeading;
        if(aiming){
            if(!active){active=true;blending=false;frozen=aimWrap(pedHeading);lastBase=base;}
            else if(std::isfinite(base)){frozen=aimWrap(frozen+aimWrap(base-lastBase));lastBase=base;}
            return frozen;}
        if(active){active=false;blending=true;t=0;}
        if(!blending)return pedHeading;
        t+=std::isfinite(dt)&&dt>0?std::min(dt,.1f)/BlendSeconds:0;
        if(t>=1){blending=false;return pedHeading;}
        float s=t*t*(3-2*t);
        return aimWrap(frozen+aimWrap(pedHeading-frozen)*s);}
    void reset(){active=blending=false;t=1;}
};
}
