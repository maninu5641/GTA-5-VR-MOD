#pragma once
// 0.15.3, tested in tests/vr_wheel_test.cpp: GTA's own character wheel, played like a PC keyboard.
// The friend (0.15.2 test): "the character menu still does not work - use the menu that comes with the game instead
// of making your own". What GTA's selector script does (decompiled selector.c, story mode, PC keyboard):
//  - Left Alt ("Character Selector", INPUT_CHARACTER_WHEEL) held: the wheel opens; it is fully open 300 ms later;
//  - while it is fully open, F5 / F6 / F7 held select Michael (left) / Franklin (up) / Trevor (right); with two of
//    them held, the first in that order wins;
//  - letting go of Alt, or of an F-key while no other F-key is held, switches to the selected character - only once
//    the wheel is fully open (earlier it just closes); the character already played = no switch.
// WheelKeys turns open / point / confirm / cancel into the keys that must be down at each moment:
//  - a new character's key goes down before the old one is let go (an F-key let go alone would switch at once);
//  - the keys are let go together only when the wheel has been fully open a while and the chosen key has been the
//    only F-key down long enough for GTA to select it (GTA reads the keys once per frame; 15-35 fps here);
//  - cancel = the character already played is selected, then the keys are let go: GTA closes its wheel, no switch.
#include "vr_play.hpp"
#include <cstdint>

namespace handvr {

constexpr std::uint16_t LeftAltScan=0x38;   // set 1 scan code of Left Alt: GTA's "Character Selector" key on PC
inline int characterSlot(Character c){switch(c){case Character::Michael:return 0;case Character::Franklin:return 1;case Character::Trevor:return 2;default:return -1;}}
inline Character slotCharacter(int i){return i==0?Character::Michael:i==1?Character::Franklin:i==2?Character::Trevor:Character::None;}

// The keys that must be down: Left Alt and F5 / F6 / F7 (Michael / Franklin / Trevor).
struct WheelKeysOut {
    bool alt=false;bool f[3]{};
    int fCount()const{return int(f[0])+int(f[1])+int(f[2]);}
    bool any()const{return alt||fCount()>0;}
};

class WheelKeys {
public:
    static constexpr std::uint64_t OpenMs=600;       // GTA's wheel is fully open 300 ms after Alt (+ slow frames, input delay)
    static constexpr std::uint64_t PickMs=200;       // the chosen key alone this long before the release (several frames)
    static constexpr std::uint64_t HandoverMs=100;   // the old key goes up this long after the new one went down
    static constexpr std::uint64_t MaxMs=20000;      // never longer than this (safety)
    enum class Result { None,Switched,Cancelled,Aborted };
private:
    enum class Phase { Idle,Open,Closing };
    Phase phase=Phase::Idle;
    std::uint64_t opened=0,soleSince=0;bool sole=false;
    bool down[3]{};std::uint64_t upAt[3]{};   // upAt: 0 = stays down
    int held=-1;                              // the character whose key stays down: GTA's selection
    Result closing=Result::None,last=Result::None;
    Character lastTarget=Character::None;
    void press(int i,std::uint64_t now){
        if(i<0)return;
        down[i]=true;upAt[i]=0;
        if(held>=0&&held!=i&&down[held])upAt[held]=now+HandoverMs;   // the old key goes up a little later
        held=i;sole=false;
    }
    void releaseAll(Result r){
        phase=Phase::Idle;for(int i=0;i<3;++i){down[i]=false;upAt[i]=0;}
        held=-1;sole=false;soleSince=0;last=r;closing=Result::None;
    }
public:
    bool active()const{return phase!=Phase::Idle;}
    bool closingNow()const{return phase==Phase::Closing;}
    Character selected()const{return slotCharacter(held);}
    Character target()const{return lastTarget;}   // where the last release went (the character already played on cancel)
    std::uint64_t openedAt()const{return opened;}
    // Alt goes down: GTA's wheel opens.
    bool open(std::uint64_t now){
        if(phase!=Phase::Idle)return false;
        for(int i=0;i<3;++i){down[i]=false;upAt[i]=0;}
        held=-1;sole=false;soleSince=0;closing=Result::None;
        phase=Phase::Open;opened=now;lastTarget=Character::None;return true;
    }
    // A stick points at a character: its key goes down (the old one up a moment later). None: the selection stays.
    void point(Character c,std::uint64_t now){
        if(phase!=Phase::Open)return;
        int i=characterSlot(c);if(i<0||i==held)return;
        press(i,now);
    }
    // Let go toward the selected character: GTA switches. False when nothing is selected (then cancel).
    bool confirm(){
        if(phase!=Phase::Open||held<0)return false;
        phase=Phase::Closing;closing=Result::Switched;lastTarget=slotCharacter(held);return true;
    }
    // Close without switching: the character already played is selected first, then the keys go up.
    // Unknown character (not Michael / Franklin / Trevor): the keys just go up.
    void cancel(Character current,std::uint64_t now){
        if(phase==Phase::Idle)return;
        int i=characterSlot(current);
        lastTarget=current;
        if(i<0){releaseAll(Result::Cancelled);return;}
        if(i!=held||!down[i])press(i,now);
        phase=Phase::Closing;closing=Result::Cancelled;
    }
    // At once (focus lost, the add-on stopping): every key up now.
    void abort(){if(phase!=Phase::Idle)releaseAll(Result::Aborted);}
    // The keys that must be down now; the final release happens here.
    WheelKeysOut update(std::uint64_t now){
        WheelKeysOut o;
        if(phase==Phase::Idle)return o;
        if(now<opened)opened=now;   // clock went back: start again from now
        if(now-opened>MaxMs){releaseAll(closing==Result::None?Result::Aborted:closing);return o;}
        // Old keys go up when their time comes; the selected key stays down (never an F-key let go alone).
        for(int i=0;i<3;++i)if(i!=held&&down[i]&&upAt[i]&&now>=upAt[i]){down[i]=false;upAt[i]=0;}
        bool alone=held>=0&&down[held]&&int(down[0])+int(down[1])+int(down[2])==1;
        if(alone&&!sole){sole=true;soleSince=now;}
        if(!alone)sole=false;
        if(phase==Phase::Closing){
            bool ready=now>=opened+OpenMs&&(held<0||(sole&&now>=soleSince+PickMs));
            if(ready){releaseAll(closing);return o;}
        }
        o.alt=true;for(int i=0;i<3;++i)o.f[i]=down[i];
        return o;
    }
    // What the last release did (once).
    Result takeResult(){Result r=last;last=Result::None;return r;}
};
inline const char* wheelResultName(WheelKeys::Result r){
    switch(r){case WheelKeys::Result::Switched:return "switch";case WheelKeys::Result::Cancelled:return "cancel";case WheelKeys::Result::Aborted:return "stopped";default:return "none";}
}

} // namespace handvr
