#pragma once
// 0.7.0: the GTA character's own arms and hands follow the player's real hands, through GTA's
// arm IK (SET_IK_TARGET): the hand goes to a target and, with ITF_ARM_USE_ORIENTATION, turns to
// an invisible target entity's orientation.
// 0.11.0: closed loop instead of one-shot tests. The 0.10.0 log showed every way of calling the IK
// leaving the hand 22-31 cm from the controller, and the hand turning only part of the test swings.
// Nothing is assumed about how much of the request GTA carries out:
//  - ReachLoop: the hand bone's miss after each request is added to the next request.
//  - TargetReadback: the target entity's orientation is read back from the game (quaternion check).
//  - HandTurn: the hand-to-target relation D (hand = target * D) is learned from the player's own
//    movements and kept only if it stays consistent while the hand turns; otherwise position only.
// 0.12.0: the 0.11.0 video showed why nothing measured ever matched: the hands moved with the IK, but
// GTA gives scripts the arm bone positions from the animation, before its IK. The renderer is open loop
// again (target = the real wrist, rotation through RigCalibration, which any pose gives because the
// hand is rigid). ReachLoop and HandTurn stay here, tested, for a measurement of the IK result (the
// renderer checks a marker attached to the hand bone).
// Plain logic, tested in tests/vr_arms_test.cpp.
#include "core.hpp"
#include <algorithm>
#include <array>
#include <cmath>

namespace handvr {

// Rotation as three orthonormal columns: the local X / Y / Z axes in world space.
struct Rot { Vec3 x{1,0,0},y{0,1,0},z{0,0,1}; };
inline Vec3 apply(const Rot& r,Vec3 v){return r.x*v.x+r.y*v.y+r.z*v.z;}
inline Vec3 applyT(const Rot& r,Vec3 v){return {dot(r.x,v),dot(r.y,v),dot(r.z,v)};}
inline Rot mul(const Rot& a,const Rot& b){return {apply(a,b.x),apply(a,b.y),apply(a,b.z)};}
inline Rot transpose(const Rot& r){return {{r.x.x,r.y.x,r.z.x},{r.x.y,r.y.y,r.z.y},{r.x.z,r.y.z,r.z.z}};}
inline bool finiteRot(const Rot& r){return finite(r.x)&&finite(r.y)&&finite(r.z);}
// Gram-Schmidt from a primary and a secondary axis; z = x cross y (right-handed).
inline bool rotFromXY(Vec3 x,Vec3 y,Rot& out){
    if(!finite(x)||!finite(y)||length(x)<1e-4f||length(y)<1e-4f)return false;
    x=unit(x);y=y-x*dot(x,y);if(length(y)<1e-3f)return false;y=unit(y);
    out={x,y,cross(x,y)};return true;
}
inline float rotAngleDegrees(const Rot& a,const Rot& b){
    Rot d=mul(transpose(a),b);float c=(d.x.x+d.y.y+d.z.z-1)*.5f;return std::acos(std::clamp(c,-1.0f,1.0f))*180/pi;
}
inline bool orthonormalRot(const Rot& r,float tolerance=.05f){
    return finiteRot(r)&&std::abs(length(r.x)-1)<tolerance&&std::abs(length(r.y)-1)<tolerance&&std::abs(length(r.z)-1)<tolerance
        &&std::abs(dot(r.x,r.y))<tolerance&&std::abs(dot(r.y,r.z))<tolerance&&std::abs(dot(r.x,r.z))<tolerance&&dot(cross(r.x,r.y),r.z)>.9f;
}
// Bone axes from GET_PED_BONE_COORDS probes: origin and the points at +s along local X / Y / Z.
inline bool boneFrame(Vec3 origin,Vec3 px,Vec3 py,Vec3 pz,float s,Rot& out){
    if(!(s>0))return false;Rot r{(px-origin)*(1/s),(py-origin)*(1/s),(pz-origin)*(1/s)};
    if(!orthonormalRot(r,.08f))return false;
    return rotFromXY(r.x,r.y,out);
}
// Anatomical hand frame, identical for GTA bones and the SteamVR skeleton:
// y = wrist -> middle knuckle (fingers), x = pinky knuckle -> index knuckle (across), z = x cross y.
inline bool anatomicalFrame(Vec3 wrist,Vec3 index,Vec3 middle,Vec3 pinky,Rot& out){
    if(!finite(wrist)||!finite(index)||!finite(middle)||!finite(pinky))return false;
    Vec3 fingers=middle-wrist,across=index-pinky;
    float f=length(fingers),a=length(across);
    if(f<.04f||f>.20f||a<.02f||a>.13f)return false;
    Rot r;if(!rotFromXY(unit(fingers),across,r))return false;
    out={r.y,r.x,cross(r.y,r.x)};   // x = across, y = fingers
    out.z=cross(out.x,out.y);return true;
}

// Rotation averaging over a few samples: accumulate quaternions (sign-aligned), normalise.
class RotAverage {
    float q[4]{};unsigned n=0;
public:
    void reset(){q[0]=q[1]=q[2]=q[3]=0;n=0;}
    unsigned count()const{return n;}
    void add(const Rot& r){Quaternion s=quaternion(r.x,r.y,r.z);float v[4]={s.x,s.y,s.z,s.w};
        if(n&&v[0]*q[0]+v[1]*q[1]+v[2]*q[2]+v[3]*q[3]<0)for(float& c:v)c=-c;
        for(int i=0;i<4;++i)q[i]+=v[i];++n;}
    Rot mean()const{float l=std::sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3]);if(!(l>0))return {};
        float x=q[0]/l,y=q[1]/l,z=q[2]/l,w=q[3]/l;
        return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};}
};

// The anatomical frame expressed in the hand bone's local axes: M = Bone^T * Anatomy (constant per rig).
class RigCalibration {
    RotAverage avg;Rot first{};bool firstSet=false,isReady=false;Rot result{};float worst=0;
public:
    static constexpr unsigned Needed=20;
    bool ready()const{return isReady;}
    const Rot& value()const{return result;}
    float spreadDegrees()const{return worst;}
    void reset(){avg.reset();firstSet=false;isReady=false;worst=0;}
    void add(const Rot& bone,const Rot& anatomy){
        if(isReady)return;Rot m=mul(transpose(bone),anatomy);
        if(!firstSet){first=m;firstSet=true;}
        float d=rotAngleDegrees(first,m);if(d>12){reset();return;}   // inconsistent: restart
        worst=std::max(worst,d);avg.add(m);
        if(avg.count()>=Needed){result=avg.mean();isReady=true;}
    }
    // Desired hand-bone frame for a desired anatomical frame.
    Rot boneFor(const Rot& anatomy)const{return mul(anatomy,transpose(result));}
};

// Keep the hand target reachable: not beyond the stretched arm, not inside the shoulder.
inline Vec3 clampReach(Vec3 target,Vec3 shoulder,float armLength){
    if(!finite(target)||!finite(shoulder)||!(armLength>.2f)||armLength>1.5f)return target;
    Vec3 d=target-shoulder;float l=length(d);
    if(l>armLength*.97f)return shoulder+d*(armLength*.97f/l);
    if(l<.10f&&l>1e-4f)return shoulder+d*(.10f/l);
    return target;
}
// Rotation between two others: t = 0 -> a, 1 -> b (normalised quaternion blend, shortest way).
inline Rot blendRot(const Rot& a,const Rot& b,float t){
    t=std::clamp(std::isfinite(t)?t:0.0f,0.0f,1.0f);
    Quaternion qa=quaternion(a.x,a.y,a.z),qb=quaternion(b.x,b.y,b.z);
    if(qa.x*qb.x+qa.y*qb.y+qa.z*qb.z+qa.w*qb.w<0){qb.x=-qb.x;qb.y=-qb.y;qb.z=-qb.z;qb.w=-qb.w;}
    float q[4]={qa.x+(qb.x-qa.x)*t,qa.y+(qb.y-qa.y)*t,qa.z+(qb.z-qa.z)*t,qa.w+(qb.w-qa.w)*t};
    float l=std::sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3]);if(!(l>1e-6f))return a;
    float x=q[0]/l,y=q[1]/l,z=q[2]/l,w=q[3]/l;
    return {{1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w)},{2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w)},{2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y)}};
}
// The character's body frame from its GTA heading (degrees, 0 = north, + = counter-clockwise):
// x = right, y = forward, z = up.
inline Rot headingRot(float headingDegrees){float h=rad(std::isfinite(headingDegrees)?headingDegrees:0.0f);
    return {{std::cos(h),std::sin(h),0},{-std::sin(h),std::cos(h),0},{0,0,1}};}

// ---------- 0.11.0: closed-loop reach ----------
// The hand bone read in this update is where the previous request took it. Its remaining miss is
// added to the next request: slowly (Tau), and only while the controller moves slowly (a fast move
// is lag, not error). Works whatever makes GTA fall short: a partial blend, a helper offset, the
// arm animation pulling back. Limited to MaxCorrection; without measurements the correction fades.
// If it sits at the limit for GiveUpSeconds without having brought the hand clearly closer than
// at the start (the hand does not respond: GTA ignores the request, or the bone reads come before
// the IK), the loop switches itself off for this arm rather than push the hand past the controller.
class ReachLoop {
public:
    static constexpr float Tau=.40f,MaxCorrection=.40f,FastHand=1.2f,Forget=1.5f,MaxError=.70f,GiveUpSeconds=3,Helped=.70f;
private:
    Vec3 corr{},last{};bool haveLast=false,primed=false,off=false;float steady=0,saturated=0,baseline=NAN;
public:
    void reset(){corr={};haveLast=false;primed=false;off=false;steady=0;saturated=0;baseline=NAN;}
    Vec3 correction()const{return corr;}
    // Average distance between the hand and where it should be while the controller moves slowly (NaN: no data).
    float steadyMiss()const{return primed?steady:NAN;}
    // The same before any correction was applied (NaN: not measured).
    float startMiss()const{return baseline;}
    // Seconds the correction has been at its limit (the hand does not get any closer).
    float saturatedSeconds()const{return saturated;}
    // The hand did not respond to the correction: the loop is off (until reset).
    bool unresponsive()const{return off;}
    // goal: where the hand bone should be this update (within reach); hand: where it is now (NaN = unknown).
    // Returns the target to send.
    Vec3 update(Vec3 goal,Vec3 hand,float dt){
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        if(!finite(goal)){haveLast=false;return goal;}
        float speed=haveLast&&dt>0?length(goal-last)/dt:0;
        float w=std::clamp(1-speed/FastHand,0.0f,1.0f);
        if(haveLast&&finite(hand)&&length(last-hand)<MaxError){Vec3 e=last-hand;float m=length(e);
            if(!off)corr=corr+e*(std::min(1.0f,dt/Tau)*w);
            if(w>.8f){steady=primed?steady*.9f+m*.1f:m;primed=true;
                if(length(corr)<.05f)baseline=std::isnan(baseline)?m:baseline*.9f+m*.1f;}}
        if(off||!(haveLast&&finite(hand)&&length(last-hand)<MaxError))corr=corr*std::max(0.0f,1-dt/Forget);
        float c=length(corr);
        if(c>MaxCorrection){corr=corr*(MaxCorrection/c);saturated+=dt;}else saturated=0;
        if(!off&&saturated>GiveUpSeconds&&!(primed&&steady<baseline*Helped)){off=true;saturated=0;}
        last=goal;haveLast=true;return goal+corr;
    }
    // The caller had to limit the target (reach): the correction is what was really sent.
    void sent(Vec3 goal,Vec3 target){if(haveLast&&finite(goal)&&finite(target))corr=target-goal;}
};

// ---------- 0.11.0: does the target entity really get the rotation that was sent? ----------
// Its axes are read back from the game (GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS). Proves the quaternion
// convention before anything is concluded about the hand: Direct, Transposed (read inverted: corrected),
// or Stuck (the entity does not turn: no hand rotation possible).
class TargetReadback {
public:
    enum class State { Unknown,Direct,Transposed,Stuck };
    static constexpr int Needed=8;
private:
    State st=State::Unknown;int direct=0,transposed=0,stuck=0;
public:
    State state()const{return st;}
    void reset(){st=State::Unknown;direct=transposed=stuck=0;}
    // sent: what was passed to SET_ENTITY_QUATERNION; actual: the axes read back. True when decided.
    bool observe(const Rot& sent,const Rot& actual){
        if(st!=State::Unknown||!orthonormalRot(actual,.08f)||!orthonormalRot(sent,.08f))return false;
        if(rotAngleDegrees(sent,transpose(sent))<20)return false;   // nearly its own inverse: proves nothing
        float a=rotAngleDegrees(sent,actual),b=rotAngleDegrees(transpose(sent),actual);
        if(a<6)++direct;else if(b<6)++transposed;else ++stuck;
        if(direct>=Needed){st=State::Direct;return true;}
        if(transposed>=Needed){st=State::Transposed;return true;}
        if(stuck>=Needed*3){st=State::Stuck;return true;}
        return false;
    }
    // What to send so that the entity ends up turned as `want`.
    Rot command(const Rot& want)const{return st==State::Transposed?transpose(want):want;}
};

// ---------- 0.11.0: the hand turns with yours, learned while you play ----------
// With ITF_ARM_USE_ORIENTATION GTA turns some frame of the hand to the target's: hand = target * D,
// D unknown (which helper the flags pick, the rig's bone axes). Every update gives D' = target^T * hand
// (target read back from the game, hand = the frame of the character's knuckles).
//  Settling: 0.5 s of steady D' becomes D; the targets sent are then desired * D^T.
//  Judging: while your hand is turned NeededTurn degrees or more relative to the body, D' must still equal D:
//    within Good -> Working (D keeps being refined); Bad or more -> GTA does not turn the hand with these
//    flags: the next flags, after the last one Ignored (position only). Turning on the spot proves
//    nothing (the body turns too), so the turn is measured relative to the body.
//  Working: if D' drifts away for RelearnSeconds (another animation / character), Settling again.
// No test twitch: it learns from your own hand movements.
class HandTurn {
public:
    static constexpr int Candidates=2;
    // ITF_ARM_USE_ORIENTATION (64) with the hand bone (1), then with the IK helper (4).
    static int candidateFlags(int i){static constexpr int f[Candidates]={65,68};return f[std::clamp(i,0,Candidates-1)];}
    static constexpr float SettleSeconds=.5f,NeededTurn=45,Good=18,Bad=32,JudgeLimit=30,RelearnSeconds=4,RefineSeconds=2;
    enum class State { Settling,Judging,Working,Ignored };
private:
    State st=State::Settling;int cand=0;Rot d{};bool haveD=false;RotAverage settle;float t=0;
    Rot first{};bool haveFirst=false,primed=false;float turned=0,deviation=0,badTime=0;
    void startSettling(){st=State::Settling;settle.reset();t=0;haveFirst=false;primed=false;turned=0;deviation=0;badTime=0;}
    bool nextFlags(){if(cand+1>=Candidates){st=State::Ignored;return true;}++cand;haveD=false;d={};startSettling();return true;}
public:
    State state()const{return st;}
    int candidate()const{return cand;}
    int flags()const{return candidateFlags(cand);}
    bool active()const{return st!=State::Ignored;}
    bool working()const{return st==State::Working;}
    float turnedDegrees()const{return turned;}
    float deviationDegrees()const{return deviation;}
    const Rot& response()const{return d;}
    void reset(){cand=0;haveD=false;d={};startSettling();}
    // Target orientation for the desired hand frame.
    Rot target(const Rot& desired)const{return haveD?mul(desired,transpose(d)):desired;}
    // target: the target entity's orientation last update (read back); hand: the character's hand frame now;
    // body: the character's heading frame; steady: your hand turns slowly and the hand is near the controller.
    // True when the state changed.
    bool observe(const Rot& target,const Rot& hand,const Rot& body,bool steady,float dt){
        if(st==State::Ignored||!steady)return false;
        if(!(dt>=0)||!std::isfinite(dt))dt=0;dt=std::min(dt,.25f);
        if(!orthonormalRot(target,.08f)||!orthonormalRot(hand,.08f))return false;
        Rot di=mul(transpose(target),hand);
        if(st==State::Settling){settle.add(di);t+=dt;
            if(t>=SettleSeconds&&settle.count()>=5){d=settle.mean();haveD=true;st=State::Judging;t=0;haveFirst=false;primed=false;turned=0;return true;}
            return false;}
        float dev=rotAngleDegrees(d,di);
        if(st==State::Judging){
            Rot local=mul(transpose(body),target);
            if(!haveFirst){first=local;haveFirst=true;}
            float now=rotAngleDegrees(first,local);turned=std::max(turned,now);
            deviation=primed?deviation*.8f+dev*.2f:dev;primed=true;t+=dt;
            if(now>=NeededTurn){   // judged while the hand IS turned, not after it came back
                if(deviation<=Good){st=State::Working;badTime=0;return true;}
                if(deviation>=Bad)return nextFlags();}
            if(t>JudgeLimit){if(turned>=NeededTurn)return nextFlags();t=0;}   // undecided for long: next flags
            return false;}
        deviation=deviation*.9f+dev*.1f;
        if(dev<Good)d=blendRot(d,di,std::min(1.0f,dt/RefineSeconds));
        if(deviation>Bad){badTime+=dt;if(badTime>RelearnSeconds){startSettling();return true;}}else badTime=0;
        return false;
    }
};

// Anatomical frame (x = pinky -> index knuckles, y = wrist -> fingers) of a hand holding a
// controller, from the controller's aim pose (+Y up through the buttons, -Z pointing ahead).
// Used when SteamVR gives no hand skeleton.
inline Rot controllerAnatomy(const Pose& aim){Rot r;if(!rotFromXY(aim.col(1),-aim.col(2),r))return {};return r;}
}
