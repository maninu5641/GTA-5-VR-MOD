"""Build Windows x64 outputs. No downloads.
Usage: python build.py --zig /path/to/zig [--test]
   or: python build.py --llvm-mingw /path/to/llvm-mingw [--test]   (0.3.3+ release builds)"""
import argparse, hashlib, json, os, pathlib, shutil, subprocess
ROOT = pathlib.Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig', default='zig')
    parser.add_argument('--llvm-mingw', help='llvm-mingw root (LLVM 18 + mingw-w64 UCRT); used instead of Zig')
    parser.add_argument('--host-cxx', default='clang++', help='host compiler for tests with --llvm-mingw')
    parser.add_argument('--test', action='store_true')
    parser.add_argument('--dxc', help='DXC binary: validate the hand HLSL (compiled at runtime by d3dcompiler_47)')
    args = parser.parse_args()
    if args.llvm_mingw:
        bin_ = pathlib.Path(args.llvm_mingw).resolve()/'bin'
        cxx = [bin_/'x86_64-w64-mingw32-clang++', '-static', '-Wl,-s', '-Wno-unused-command-line-argument']  # strip at link time; -c ignores it
        dlltool = [bin_/'llvm-dlltool']
        def rc_cmd(out, src): return [bin_/'x86_64-w64-mingw32-windres', '-O', 'coff', src, '-o', out]
        host_cxx = [shutil.which(args.host_cxx) or args.host_cxx]
    else:
        zig = shutil.which(args.zig)
        if not zig: parser.error('Zig not found; provide --zig with its full path, or --llvm-mingw.')
        zig = str(pathlib.Path(zig).resolve())
        cxx = [zig, 'c++', '-target', 'x86_64-windows-gnu']
        dlltool = [zig, 'dlltool']
        def rc_cmd(out, src): return [zig, 'rc', '/fo', out, '--', src]
        host_cxx = [zig, 'c++']
    build = ROOT / 'build'; build.mkdir(exist_ok=True)
    dist = ROOT / 'dist'; (dist / 'GTAHandVR').mkdir(parents=True, exist_ok=True)
    def run(*command):
        print('Running:', ' '.join(map(str, command)), flush=True)
        subprocess.run([str(c) for c in command], cwd=ROOT, check=True)
    common = [*cxx, '-std=c++17', '-O2', '-Wall', '-Wextra', '-Werror', '-Wno-unused-variable', '-Wno-missing-field-initializers', '-I', ROOT/'src', '-I', build]
    run(*dlltool, '-m', 'i386:x86-64', '-d', ROOT/'src/ScriptHookV.def', '-l', build/'libScriptHookV.a')
    run(*common, '-shared', ROOT/'src/mod.cpp', build/'libScriptHookV.a', '-luser32', '-o', dist/'GTAHandVR.asi')
    run(*common,'-shared','-I',ROOT/'third_party/openvr',ROOT/'src/renderer.cpp',build/'libScriptHookV.a','-ldxguid','-luser32','-o',dist/'GTA5VRRenderer.asi')
    run(*common,'-c',ROOT/'examples/camera_client.cpp','-o',build/'camera_client.obj')
    # 0.16.0: the built-in renderer only - the R.E.A.L. input companion (bridge.cpp) and the OpenXR layer are no longer part of GTA 5 VR.
    # Explicit allow-list: never embed PDBs, import libraries or build caches.
    paths = ['GTAHandVR.asi', 'GTAHandVR.ini', 'GTAHandVR/openvr_api.dll', 'GTAHandVR/OpenVR-LICENSE.txt', 'GTAHandVR/READ_ME_FIRST.txt']
    paths += ['GTA5VRRenderer.asi','GTAHandVR/renderer_actions.json','GTAHandVR/renderer_bindings_oculus_touch.json','GTAHandVR/GTAHandVR-renderer.vrmanifest','GTAHandVR/MinHook-LICENSE.txt']
    shutil.copyfile(ROOT/'third_party/minhook/LICENSE.txt',dist/'GTAHandVR/MinHook-LICENSE.txt')
    for p in (ROOT/'third_party/licenses').iterdir():
        if p.is_file():
            destination=dist/'GTAHandVR/Licenses'/p.name; destination.parent.mkdir(exist_ok=True); shutil.copyfile(p,destination); paths.append(destination.relative_to(dist).as_posix())
    shutil.copyfile(ROOT/'LICENSE.txt', dist/'GTAHandVR/LICENSE.txt'); paths.append('GTAHandVR/LICENSE.txt')
    def digest(name): return hashlib.sha256((dist/name).read_bytes()).hexdigest()
    expected=[p for p in paths if p.endswith(('.asi','.dll','.exe','.json','.vrmanifest'))]
    header='#pragma once\nstruct ExpectedFile { const wchar_t* path;const char* hash; };\nconstexpr ExpectedFile expectedFiles[]={\n'
    for p in expected: header+=f'    {{L{json.dumps(p)},{json.dumps(digest(p))}}},\n'
    (build/'expected_files.hpp').write_text(header+'};\n')
    manifest='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
<assemblyIdentity version="0.16.3.0" processorArchitecture="amd64" name="GTA5VR" type="win32"/>
<trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges><requestedExecutionLevel level="asInvoker" uiAccess="false"/></requestedPrivileges></security></trustInfo>
<application xmlns="urn:schemas-microsoft-com:asm.v3"><windowsSettings><dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true</dpiAware></windowsSettings></application>
</assembly>'''
    (build/'app.manifest').write_text(manifest); (build/'launcher.rc').write_text('1 24 "app.manifest"\n')
    run(*rc_cmd(build/'launcher.res', build/'launcher.rc'))
    windows=['-municode','-Wl,--subsystem,windows','-luser32','-lgdi32','-lshell32','-lole32','-luuid','-ladvapi32','-lversion','-lbcrypt']
    run(*common,ROOT/'src/launcher.cpp',build/'launcher.res',*windows,'-o',dist/'GTA5 VR.exe'); paths.append('GTA5 VR.exe')
    header='#pragma once\nstruct Payload { int id;const wchar_t* path;const char* hash;bool preserve; };\nconstexpr Payload payload[]={\n';rc='1 24 "app.manifest"\n'
    for i,p in enumerate(paths,200):
        header+=f'    {{{i},L{json.dumps(p)},{json.dumps(digest(p))},{str(p.endswith(".ini")).lower()}}},\n'
        rc+=f'{i} 10 {json.dumps(str((dist/p).resolve()))}\n'
    (build/'payload.hpp').write_text(header+'};\n'); (build/'setup.rc').write_text(rc)
    run(*rc_cmd(build/'setup.res', build/'setup.rc'))
    run(*common,ROOT/'src/setup.cpp',build/'setup.res',*windows,'-o',ROOT/'gta5vrmod setup.exe')
    (ROOT/'package_files.json').write_text(json.dumps(paths,indent=2)+'\n')
    if args.test:
        for name in ['core_test','interactions_test','stereo_test','camera_bridge_test','frame_sync_test','hands_test','camera_anchor_test','weapons_test','vr_body_test','vr_view_test','vr_arms_test','vr_play_test','install_parse_test','vr_calib_test','vr_map_test','vr_gun_test','vr_follow_test','vr_grip_test','vr_shot_test','vr_wheel_test','vr_menu_test','vr_aim_test','vr_assist_test']:
            test=build/(name+('.exe' if os.name=='nt' else ''))
            run(*host_cxx,'-std=c++17','-O2','-Wall','-Wextra','-Werror','-Wno-missing-field-initializers','-Wno-misleading-indentation','-I',ROOT/'src','-I',ROOT/'tests',ROOT/'tests'/(name+'.cpp'),'-o',test);run(test)
    if args.dxc: run('python3' if os.name!='nt' else 'python', ROOT/'tests/check_shaders.py', args.dxc)
    print('Build complete. GTA, VR hardware and Windows installer execution are NOT tested by this build.')
if __name__=='__main__': main()
