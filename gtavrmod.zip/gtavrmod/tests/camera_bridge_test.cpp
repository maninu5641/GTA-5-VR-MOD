#include "camera_bridge.hpp"
#include <atomic>
#include <iostream>
#include <limits>
#include <thread>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
Pose identity(Vec3 p={}){Pose t{};t.m[0][0]=t.m[1][1]=t.m[2][2]=1;t.m[0][3]=p.x;t.m[1][3]=p.y;t.m[2][3]=p.z;return t;}
Gta5VrHeadPose packet(std::uint64_t seq,std::uint64_t time,Vec3 p={.1f,1.6f,-.2f}){
    Gta5VrHeadPose r{};r.structSize=sizeof(r);r.version=GTA5VR_CAMERA_API_VERSION;r.sequence=seq;r.sampleTimeMs=time;
    auto head=identity(p);std::memcpy(r.headToStanding,head.m,sizeof(head.m));return r;
}
int main(){try{
    CameraBridge bridge;auto runtime=identity({0,1.6f,0});
    CHECK(bridge.read().state==GTA5VR_CAMERA_STARTING);
    CHECK(bridge.submit(packet(1,1000),1000)==GTA5VR_CAMERA_UNAVAILABLE);
    CHECK(bridge.clear()==GTA5VR_CAMERA_UNAVAILABLE);
    CHECK(bridge.recenter()==GTA5VR_CAMERA_UNAVAILABLE);
    // Disabled camera overrides must not remove head tracking from flat cinema.
    bridge.enable(false,900);CHECK(bridge.select(runtime,true,900).valid);
    CHECK(bridge.read().state==GTA5VR_CAMERA_DISABLED);
    bridge.enable(true,1000);
    auto selected=bridge.select(runtime,true,1000);CHECK(selected.valid&&selected.source==GTA5VR_POSE_STEAMVR&&!selected.recenter);
    auto bad=packet(1,1000);bad.version=2;CHECK(bridge.submit(bad,1000)==GTA5VR_CAMERA_BAD_ARGUMENT);
    bad=packet(1,1000);bad.structSize=8;CHECK(bridge.submit(bad,1000)==GTA5VR_CAMERA_BAD_ARGUMENT);
    bad=packet(0,1000);CHECK(bridge.submit(bad,1000)==GTA5VR_CAMERA_BAD_ARGUMENT);
    bad=packet(1,1000);bad.headToStanding[0]=std::numeric_limits<float>::quiet_NaN();CHECK(bridge.submit(bad,1000)==GTA5VR_CAMERA_BAD_ARGUMENT);
    bad=packet(1,1000);bad.headToStanding[0]=-1;CHECK(bridge.submit(bad,1000)==GTA5VR_CAMERA_BAD_ARGUMENT);
    bad=packet(1,1000);bad.headToStanding[5]=2;CHECK(bridge.submit(bad,1000)==GTA5VR_CAMERA_BAD_ARGUMENT);
    bad=packet(1,1000);bad.headToStanding[3]=20000;CHECK(bridge.submit(bad,1000)==GTA5VR_CAMERA_BAD_ARGUMENT);
    CHECK(bridge.submit(packet(1,0),1000)==GTA5VR_CAMERA_STALE_POSE);
    CHECK(bridge.submit(packet(1,1001),1000)==GTA5VR_CAMERA_STALE_POSE);
    CHECK(bridge.submit(packet(1,849),1000)==GTA5VR_CAMERA_STALE_POSE);
    CHECK(bridge.submit(packet(1,850),1000)==GTA5VR_CAMERA_OK);
    selected=bridge.select(runtime,true,1000);CHECK(selected.valid&&selected.recenter&&selected.source==GTA5VR_POSE_PLUGIN);
    CHECK(std::abs(selected.head.pos().x-.1f)<.0001f);
    CHECK(!bridge.select(runtime,true,1000).recenter);
    // Replayed or malformed packets cannot replace the accepted pose or refresh its age.
    CHECK(bridge.submit(packet(1,1000,{9,9,9}),1000)==GTA5VR_CAMERA_OUT_OF_ORDER);
    CHECK(bridge.submit(packet(2,849),900)==GTA5VR_CAMERA_OUT_OF_ORDER);
    selected=bridge.select(runtime,true,1001);CHECK(!selected.valid&&selected.source==GTA5VR_POSE_PLUGIN);
    CHECK(bridge.submit(packet(2,1002),1002)==GTA5VR_CAMERA_OK);
    selected=bridge.select(runtime,false,1002);CHECK(!selected.valid);
    selected=bridge.select(runtime,true,1002);CHECK(selected.valid);
    CHECK(bridge.recenter()==GTA5VR_CAMERA_OK);
    CHECK(bridge.select(runtime,true,1002).recenter);
    CHECK(!bridge.select(runtime,true,1002).recenter);
    CHECK(bridge.clear()==GTA5VR_CAMERA_OK);
    selected=bridge.select(runtime,true,1003);CHECK(selected.valid&&selected.recenter&&selected.source==GTA5VR_POSE_STEAMVR);
    CHECK(bridge.submit(packet(1,1003),1003)==GTA5VR_CAMERA_OK); // new provider epoch
    CHECK(bridge.clear()==GTA5VR_CAMERA_OK);

    // Known world transform checks layout and wrapped headings, not just inverse functions.
    WorldCamera wanted{{10,20,30},cameraBasis({0,0,90})};
    auto snapshot=cameraSnapshot(wanted,wanted,90,90,42,true,1004,7,GTA5VR_POSE_STEAMVR);
    CHECK(snapshot.flags==(GTA5VR_CAMERA_NATIVE_ACTIVE|GTA5VR_CAMERA_READBACK_MATCHES));
    CHECK(snapshot.nativeCamera[3]==10&&snapshot.nativeCamera[7]==20&&snapshot.nativeCamera[11]==30);
    CHECK(std::abs(snapshot.nativeCamera[1]+1)<.0001f&&std::abs(snapshot.nativeCamera[4]-1)<.0001f&&snapshot.nativeCamera[10]==1);
    CHECK(snapshot.cameraHandle==42&&snapshot.frame==7&&snapshot.timeMs==1004);
    WorldCamera actual=wanted;actual.position.x+=.03f;
    CHECK(!(cameraSnapshot(wanted,actual,90,90,42,true,1004,8,1).flags&GTA5VR_CAMERA_READBACK_MATCHES));
    actual=wanted;actual.basis=cameraBasis({0,0,91});
    auto angle=cameraSnapshot(wanted,actual,90,90,42,true,1004,9,1);
    CHECK(std::abs(angle.orientationErrorDegrees-1)<.01f&&!(angle.flags&GTA5VR_CAMERA_READBACK_MATCHES));
    actual.basis=cameraBasis({0,0,450});
    CHECK(cameraSnapshot(wanted,actual,90,90,42,true,1004,10,1).flags&GTA5VR_CAMERA_READBACK_MATCHES);
    CHECK(!(cameraSnapshot(wanted,wanted,90,91,42,true,1004,11,1).flags&GTA5VR_CAMERA_READBACK_MATCHES));
    CHECK(!(cameraSnapshot(wanted,wanted,90,90,42,false,1004,12,1).flags&GTA5VR_CAMERA_NATIVE_ACTIVE));
    actual=wanted;actual.position.x=std::numeric_limits<float>::infinity();
    CHECK(!(cameraSnapshot(wanted,actual,90,90,42,true,1004,13,1).flags&GTA5VR_CAMERA_READBACK_MATCHES));
    bridge.publish(snapshot);CHECK(bridge.read().cameraHandle==42);
    bridge.suspend(1100,GTA5VR_POSE_PLUGIN);auto paused=bridge.read();
    CHECK(paused.state==GTA5VR_CAMERA_SUSPENDED&&paused.flags==0&&paused.cameraHandle==0&&paused.frame==7&&paused.timeMs==1100);
    bridge.enable(false,1101);bridge.publish(snapshot);
    CHECK(bridge.read().state==GTA5VR_CAMERA_DISABLED&&bridge.read().cameraHandle==0);
    bridge.enable(true,1102);CHECK(bridge.select(runtime,true,1102).source==GTA5VR_POSE_STEAMVR);

    // Cross-thread readers must never observe a torn frame/matrix combination.
    std::atomic<bool> done{false},coherent{true};
    std::thread writer([&]{for(unsigned i=1;i<=3000;++i){auto s=snapshot;s.frame=i;s.timeMs=i;s.cameraHandle=int(i);
        for(float& x:s.nativeCamera)x=float(i);bridge.publish(s);}done.store(true);});
    std::thread reader([&]{while(!done.load()){auto s=bridge.read();if(s.state!=GTA5VR_CAMERA_ACTIVE)continue;
        if(s.frame!=s.timeMs||s.cameraHandle!=int(s.frame))coherent.store(false);
        for(float x:s.nativeCamera)if(x!=float(s.frame))coherent.store(false);}});
    writer.join();reader.join();CHECK(coherent.load());CHECK(bridge.read().frame==3000);
    std::cout<<checks<<" camera bridge checks passed. Native calls / GTA / VR hardware not executed.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
