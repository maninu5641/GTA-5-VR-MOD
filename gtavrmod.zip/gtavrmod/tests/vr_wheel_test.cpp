// 0.15.3: GTA's own character wheel played like a PC keyboard (Left Alt + F5 / F6 / F7), see vr_wheel.hpp.
#include "vr_wheel.hpp"
#include <cstdint>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool same(const WheelKeysOut& o,bool alt,bool m,bool f,bool t){return o.alt==alt&&o.f[0]==m&&o.f[1]==f&&o.f[2]==t;}

int main(){try{
    CHECK(LeftAltScan==0x38);
    CHECK(characterSlot(Character::Michael)==0&&characterSlot(Character::Franklin)==1&&characterSlot(Character::Trevor)==2&&characterSlot(Character::None)==-1);
    for(int i=0;i<3;++i)CHECK(characterSlot(slotCharacter(i))==i);
    CHECK(slotCharacter(3)==Character::None&&slotCharacter(-1)==Character::None);
    // The F-keys line up with GTA's keys (F5 Michael, F6 Franklin, F7 Trevor) through the slot order.
    CHECK(characterScan(slotCharacter(0))==0x3F&&characterScan(slotCharacter(1))==0x40&&characterScan(slotCharacter(2))==0x41);

    // --- Idle: nothing down.
    {   WheelKeys w;CHECK(!w.active()&&!w.update(0).any()&&w.takeResult()==WheelKeys::Result::None);
        CHECK(!w.confirm());w.point(Character::Michael,0);CHECK(!w.update(10).any());w.cancel(Character::Franklin,10);CHECK(!w.active());}

    // --- Open, point Michael, confirm early: the keys stay until GTA's wheel is fully open, then all go up together.
    {   WheelKeys w;CHECK(w.open(1000)&&w.active()&&!w.open(1001));
        CHECK(same(w.update(1000),true,false,false,false));            // Alt alone: GTA's wheel opens
        w.point(Character::Michael,1050);CHECK(same(w.update(1050),true,true,false,false)&&w.selected()==Character::Michael);
        CHECK(w.confirm()&&w.closingNow()&&w.target()==Character::Michael);
        w.point(Character::Trevor,1100);                                // decided: pointing elsewhere changes nothing
        CHECK(same(w.update(1100),true,true,false,false));
        CHECK(same(w.update(1599),true,true,false,false));             // the wheel may not be fully open yet
        CHECK(!w.update(1600).any()&&!w.active());                      // 600 ms after Alt: let go -> GTA switches
        CHECK(w.takeResult()==WheelKeys::Result::Switched&&w.takeResult()==WheelKeys::Result::None&&w.target()==Character::Michael);}

    // --- Pointed late: the chosen key alone for 200 ms before the release.
    {   WheelKeys w;w.open(0);w.update(0);
        w.point(Character::Trevor,900);CHECK(same(w.update(900),true,false,false,true));
        CHECK(w.confirm());CHECK(w.update(1000).alt&&w.update(1099).alt);
        CHECK(!w.update(1100).any()&&w.takeResult()==WheelKeys::Result::Switched);}

    // --- A new character's key goes down before the old one is let go (never an F-key alone going up).
    {   WheelKeys w;w.open(0);w.update(0);
        w.point(Character::Michael,50);CHECK(same(w.update(50),true,true,false,false));
        w.point(Character::Trevor,300);CHECK(same(w.update(300),true,true,false,true));   // both down a moment
        CHECK(same(w.update(399),true,true,false,true));CHECK(same(w.update(400),true,false,false,true));
        CHECK(w.selected()==Character::Trevor);
        // Back to the old one during a handover: it simply stays down.
        w.point(Character::Franklin,500);w.point(Character::Trevor,550);
        CHECK(same(w.update(560),true,false,true,true));CHECK(same(w.update(650),true,false,false,true));   // Franklin up 100 ms after it lost
        CHECK(w.confirm());CHECK(w.update(700).alt);                    // Trevor alone only since 650: 200 ms more
        CHECK(w.update(849).alt);CHECK(!w.update(850).any()&&w.takeResult()==WheelKeys::Result::Switched&&w.target()==Character::Trevor);}

    // --- Cancel: the character already played is selected first (no switch), then the keys go up.
    {   WheelKeys w;w.open(0);w.update(0);w.point(Character::Michael,100);w.update(100);
        w.cancel(Character::Franklin,200);CHECK(w.closingNow()&&w.target()==Character::Franklin);
        CHECK(same(w.update(200),true,true,true,false));CHECK(same(w.update(300),true,false,true,false));
        CHECK(w.update(599).alt);CHECK(!w.update(600).any()&&w.takeResult()==WheelKeys::Result::Cancelled);}
    {   WheelKeys w;w.open(0);w.cancel(Character::Trevor,10);         // never pointed: the current key, then up
        CHECK(same(w.update(10),true,false,false,true));CHECK(!w.update(600).any()&&w.takeResult()==WheelKeys::Result::Cancelled);}
    {   WheelKeys w;w.open(0);w.update(0);w.point(Character::Franklin,20);w.update(20);
        w.cancel(Character::Franklin,30);CHECK(same(w.update(30),true,false,true,false));   // already the current one
        CHECK(!w.update(600).any()&&w.takeResult()==WheelKeys::Result::Cancelled);}
    {   WheelKeys w;w.open(0);w.update(0);w.point(Character::Michael,10);
        w.cancel(Character::None,20);CHECK(!w.active()&&!w.update(20).any()&&w.takeResult()==WheelKeys::Result::Cancelled);}   // unknown: just up
    // Cancel after a confirm (B right after Y): the cancel wins.
    {   WheelKeys w;w.open(0);w.update(0);w.point(Character::Trevor,10);w.update(10);CHECK(w.confirm());
        w.cancel(Character::Michael,50);CHECK(same(w.update(50),true,true,false,true));CHECK(same(w.update(150),true,true,false,false));
        CHECK(!w.update(600).any()&&w.takeResult()==WheelKeys::Result::Cancelled&&w.target()==Character::Michael);}

    // --- Nothing selected: confirm is refused (the add-on cancels instead).
    {   WheelKeys w;w.open(0);w.update(0);CHECK(!w.confirm()&&w.active()&&!w.closingNow());w.point(Character::None,5);CHECK(!w.confirm());}

    // --- Abort and the safety limit: every key up at once.
    {   WheelKeys w;w.open(0);w.point(Character::Michael,0);w.update(0);w.abort();CHECK(!w.active()&&!w.update(1).any()&&w.takeResult()==WheelKeys::Result::Aborted);
        w.abort();CHECK(w.takeResult()==WheelKeys::Result::None);}
    {   WheelKeys w;w.open(0);w.point(Character::Michael,0);CHECK(w.update(WheelKeys::MaxMs).alt);
        CHECK(!w.update(WheelKeys::MaxMs+1).any()&&w.takeResult()==WheelKeys::Result::Aborted);}
    {   WheelKeys w;w.open(500);CHECK(w.update(400).alt&&w.openedAt()==400);}   // the clock going back restarts the timing

    // --- A new open after a release starts clean.
    {   WheelKeys w;w.open(0);w.point(Character::Michael,0);w.update(0);CHECK(w.confirm());w.update(600);CHECK(w.takeResult()==WheelKeys::Result::Switched);
        CHECK(w.open(700)&&w.selected()==Character::None);CHECK(same(w.update(700),true,false,false,false));}

    // --- Random use: the rules GTA's selector needs, whatever the player does.
    {   std::mt19937 rng(1503);
        for(int run=0;run<4000;++run){
            WheelKeys w;std::uint64_t t=0;WheelKeysOut prev{};std::uint64_t opened=0,keyDown[3]{},aloneSince=0;int alone=-1;bool any=false;
            for(int step=0;step<80;++step){
                t+=rng()%90;int a=int(rng()%10);
                if(a==0&&!w.active()){w.open(t);opened=t;}
                else if(a<=4)w.point(slotCharacter(int(rng()%4)-0),t);
                else if(a==5)w.confirm();
                else if(a==6)w.cancel(slotCharacter(int(rng()%4)),t);
                else if(a==7&&rng()%20==0)w.abort();
                WheelKeysOut o=w.update(t);auto r=w.takeResult();
                for(int i=0;i<3;++i)if(o.f[i]&&!prev.f[i])keyDown[i]=t;
                int n=o.fCount();if(n==1){int k=o.f[0]?0:o.f[1]?1:2;if(alone!=k){alone=k;aloneSince=t;}}else alone=-1;
                if(o.alt&&prev.alt){   // the wheel stays open: an F-key going up never leaves no F-key down
                    for(int i=0;i<3;++i)if(prev.f[i]&&!o.f[i])CHECK(n>=1);}
                if(o.any())CHECK(o.alt);                                   // F-keys only with Alt
                if(prev.alt&&!o.alt){                                       // the release: everything at once
                    CHECK(!o.any());
                    if(r==WheelKeys::Result::Switched){CHECK(t>=opened+WheelKeys::OpenMs);CHECK(prev.fCount()==1);
                        int k=prev.f[0]?0:prev.f[1]?1:2;CHECK(slotCharacter(k)==w.target());}
                    any=true;}
                if(r==WheelKeys::Result::Switched||r==WheelKeys::Result::Cancelled)CHECK(!o.alt);
                prev=o;
            }
            (void)any;(void)aloneSince;(void)keyDown;
        }
    }
    std::cout<<checks<<" wheel key checks passed (Left Alt + F5 / F6 / F7: open, handover, release after the wheel is fully open, cancel on the current character, abort, random use). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<"vr_wheel_test FAILED: "<<e.what()<<"\n";return 1;}}
