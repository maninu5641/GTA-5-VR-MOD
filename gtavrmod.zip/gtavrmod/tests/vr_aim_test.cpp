// 0.15.5: GTA's own aim from the VR gun - who the barrel points at, GTA's camera turned there while the view keeps
// its heading, and the eye heading while GTA turns the character (vr_aim.hpp).
#include "vr_aim.hpp"
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=.01f){return std::abs(a-b)<=e;}

int main(){try{
    // --- GTA's heading convention: 0 north (+Y), 90 west (-X), 180 south, -90 east; pitch up positive.
    Vec3 o{10,20,5};
    CHECK(near(headingTo(o,o+Vec3{0,5,0}),0)&&near(headingTo(o,o+Vec3{-5,0,0}),90)&&near(headingTo(o,o+Vec3{5,0,0}),-90));
    CHECK(near(std::abs(headingTo(o,o+Vec3{0,-5,0})),180));
    CHECK(near(pitchTo(o,o+Vec3{0,5,5}),45)&&near(pitchTo(o,o+Vec3{3,0,-3}),-45)&&near(pitchTo(o,o+Vec3{1,1,0}),0));
    for(float h=-170;h<=170;h+=17.5f)for(float p=-60;p<=60;p+=15){Vec3 t=o+headingVector(h,p)*7;
        CHECK(near(headingTo(o,t),h,.05f)&&near(pitchTo(o,t),p,.05f));}
    CHECK(near(aimWrap(190),-170)&&near(aimWrap(-190),170)&&near(std::abs(aimWrap(540)),180,.001f)&&aimWrap(NAN)==0);

    // --- Who the barrel points at.
    {Vec3 muzzle{0,0,1.4f},fwd{0,1,0};
     Vec3 people[]={{0,10,1.3f},{1.5f,10,1.3f},{0,-5,1.3f},{0,80,1.3f},{.05f,3,1.38f}};
     auto p=pickAimTarget(muzzle,fwd,people,3,40);CHECK(p.index==0&&near(p.distance,10,.01f));       // straight ahead
     p=pickAimTarget(muzzle,fwd,people+1,2,40);CHECK(p.index==-1);                                   // 8.5 deg off at 10 m; behind
     p=pickAimTarget(muzzle,fwd,people+3,1,40);CHECK(p.index==-1);                                   // too far
     p=pickAimTarget(muzzle,fwd,people,5,40);CHECK(p.index==4);                                       // nearer and better aimed (relative to its size) wins
     Vec3 one[]={{1.5f,10,1.3f}};p=pickAimTarget(muzzle,unit(Vec3{1.5f,10,-.1f}),one,1,40);CHECK(p.index==0&&p.angle<.5f);
     // Tolerance: 3 degrees far away, the body's size close by.
     Vec3 far[]={{0,30,1.4f}};p=pickAimTarget(muzzle,headingVector(-2.5f,0),far,1,40);CHECK(p.index==0);
     p=pickAimTarget(muzzle,headingVector(-3.5f,0),far,1,40);CHECK(p.index==-1);
     Vec3 closeBy[]={{0,2,1.4f}};p=pickAimTarget(muzzle,headingVector(9,0),closeBy,1,40);CHECK(p.index==0);   // atan(.35/2)=9.9 deg
     p=pickAimTarget(muzzle,headingVector(11,0),closeBy,1,40);CHECK(p.index==-1);
     Vec3 bad[]={{NAN,0,0},{0,0,1.4f}};CHECK(pickAimTarget(muzzle,fwd,bad,2,40).index==-1);                // invalid / at the muzzle
     CHECK(pickAimTarget(muzzle,Vec3{},people,3,40).index==-1&&pickAimTarget(muzzle,fwd,nullptr,3,40).index==-1);}

    // --- GTA's camera while GTA aims; the heading the view keeps.
    {AimSteer s;CHECK(!s.publishing()&&s.phase()==AimSteer::Phase::Off&&s.settle(0,0));
     s.start(170);CHECK(s.steering()&&s.publishing()&&near(s.base(),170));
     s.start(10);CHECK(near(s.base(),170));                    // already steering: the base stays
     s.turn(30);CHECK(near(s.base(),-160));                    // a snap turn turns the view (wraps)
     s.release(1000);CHECK(s.phase()==AimSteer::Phase::Settling&&s.publishing());
     CHECK(!s.settle(100,1010));                               // GTA's camera still far away
     CHECK(!s.settle(-161,1020));                               // close once ...
     CHECK(s.settle(-159,1030)&&!s.publishing());               // ... twice, after 3 updates: done
     // Settling back into steering keeps the base; release again; the 0.6 s limit.
     s.start(-100);s.turn(-10);s.release(2000);s.start(50);CHECK(s.steering()&&near(s.base(),-110));
     s.release(3000);CHECK(!s.settle(0,3100)&&!s.settle(0,3599)&&s.settle(0,3600)&&s.phase()==AimSteer::Phase::Off);
     s.turn(45);CHECK(near(s.base(),-110));                    // off: turns do nothing
     s.release(4000);CHECK(s.phase()==AimSteer::Phase::Off);  // nothing to release
     s.start(5);CHECK(near(s.base(),5));s.stop();CHECK(!s.publishing());}

    // --- The eye heading while GTA turns the character to the aim.
    {AnchorHeading a;CHECK(!a.hold()&&near(a.update(false,0,33,.016f),33));
     CHECK(near(a.update(true,100,40,.016f),40)&&a.hold());     // frozen at the character's heading
     CHECK(near(a.update(true,100,75,.016f),40));               // GTA turns the character: the eye does not follow
     CHECK(near(a.update(true,130,90,.016f),70));               // a snap turn turns it
     float h=a.update(false,130,100,.1f);CHECK(a.hold()&&h>70&&h<100);   // after: over to the real heading
     float last=h;for(int i=0;i<3;++i){h=a.update(false,130,100,.1f);CHECK(h>=last-.001f);last=h;}
     CHECK(near(h,100)&&!a.hold());
     CHECK(near(a.update(false,0,-170,.016f),-170));
     a.update(true,0,170,.016f);a.update(true,0,-170,.016f);float w=a.update(false,0,-170,.2f);   // across +-180
     CHECK(std::abs(aimWrap(w-180))<=20.01f);
     CHECK(std::isnan(a.update(false,0,NAN,.016f)));}

    // --- Random paths: the settle always ends within 0.6 s; the eye heading stays finite and in range.
    {std::mt19937 rng(1505);std::uniform_real_distribution<float> u(-180,180);
     for(int run=0;run<2000;++run){AimSteer s;AnchorHeading a;std::uint64_t t=0;
        s.start(u(rng));for(int i=0;i<10;++i){s.turn(u(rng)*.2f);float e=a.update(true,s.base(),u(rng),.016f);CHECK(std::isfinite(e)&&e>=-180.001f&&e<=180.001f);}
        s.release(t);bool done=false;for(int i=0;i<200&&!done;++i){t+=16;done=s.settle(u(rng),t);}
        CHECK(done&&t<=AimSteer::SettleMaxMs+16);
        for(int i=0;i<40;++i){float e=a.update(false,s.base(),u(rng),.016f);CHECK(std::isfinite(e));}}}
    std::cout<<checks<<" aim checks passed (vr_aim.hpp). GTA NOT exercised.\n";
    return 0;
}catch(const std::exception& e){std::cerr<<"FAILED: "<<e.what()<<"\n";return 1;}}
