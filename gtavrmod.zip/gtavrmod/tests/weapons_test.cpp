// 0.5.0 weapons revamp: holsters, recoil, physical magazine reload, effects, haptics.
#include "weapons_vr.hpp"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static Pose headAt(Vec3 p,float yawDegrees=0){Pose t{};float c=std::cos(rad(yawDegrees)),s=std::sin(rad(yawDegrees));
    t.m[0][0]=c;t.m[0][2]=s;t.m[1][1]=1;t.m[2][0]=-s;t.m[2][2]=c;t.m[0][3]=p.x;t.m[1][3]=p.y;t.m[2][3]=p.z;return t;}
static int indexOf(const char* name){for(int i=0;i<weaponCount;++i)if(std::string(weapons[i].name)==name)return i;throw std::runtime_error(std::string("weapon ")+name);}

int main(){try{
    // ---------- Holster zones (OpenVR: +X right, +Y up, -Z forward)
    Pose head=headAt({0,1.7f,0});auto zones=holsterZones(head);
    CHECK(zones[int(Holster::RightHip)].center.x>.15f&&near(zones[int(Holster::RightHip)].center.y,1.0f));
    CHECK(zones[int(Holster::LeftHip)].center.x<-.15f);
    CHECK(zones[int(Holster::RightShoulder)].center.z>0&&zones[int(Holster::RightShoulder)].center.y>1.5f);   // behind the shoulder
    CHECK(zones[int(Holster::Chest)].center.z<0);                                                             // in front
    CHECK(holsterAt(zones,{.2f,1.0f,-.03f})==Holster::RightHip);
    CHECK(holsterAt(zones,{-.19f,1.58f,.1f})==Holster::LeftShoulder);
    CHECK(holsterAt(zones,{0,1.32f,-.12f})==Holster::Chest);
    CHECK(holsterAt(zones,{0,1.2f,-.6f})==Holster::None);                                                   // hand forward: aiming, no holster
    CHECK(holsterAt(zones,{NAN,0,0})==Holster::None);
    for(int i=0;i<holsterCount;++i)for(int j=i+1;j<holsterCount;++j)                                           // zones do not overlap
        CHECK(length(zones[i].center-zones[j].center)>zones[i].radius+zones[j].radius-.02f);
    {   Pose turned=headAt({0,1.7f,0},90);auto z=holsterZones(turned);                                          // follows the body's yaw
        CHECK(z[int(Holster::RightHip)].center.z< -.15f);
        Pose looking=head;looking.m[1][1]=std::cos(rad(-60));looking.m[2][1]=std::sin(rad(-60));looking.m[1][2]=-std::sin(rad(-60));looking.m[2][2]=std::cos(rad(-60));
        CHECK(near(holsterZones(looking)[0].center,zones[0].center,1e-3f));}                                   // looking down does not move the belt
    // Weapon -> holster
    CHECK(holsterFor(weapons[indexOf("Pistol")])==Holster::RightHip);
    CHECK(holsterFor(weapons[indexOf("Knife")])==Holster::LeftHip);
    CHECK(holsterFor(weapons[indexOf("Grenade")])==Holster::Chest);
    CHECK(holsterFor(weapons[indexOf("Carbine Rifle")])==Holster::RightShoulder);
    CHECK(holsterFor(weapons[indexOf("Pump Shotgun")])==Holster::RightShoulder);
    CHECK(holsterFor(weapons[indexOf("Sniper Rifle")])==Holster::LeftShoulder);
    CHECK(holsterFor(weapons[indexOf("Unarmed")])==Holster::None);
    {   int owned[]={indexOf("Pistol"),indexOf("Pump Shotgun"),indexOf("Carbine Rifle"),indexOf("Micro SMG"),indexOf("Sniper Rifle"),indexOf("Knife")};
        CHECK(pickForHolster(Holster::RightShoulder,owned,6,0)==indexOf("Carbine Rifle"));                   // rifle preferred
        CHECK(pickForHolster(Holster::RightShoulder,owned,6,weapons[indexOf("Pump Shotgun")].hash)==indexOf("Pump Shotgun"));   // last carried
        CHECK(pickForHolster(Holster::RightHip,owned,6,0)==indexOf("Pistol"));
        CHECK(pickForHolster(Holster::LeftShoulder,owned,6,0)==indexOf("Sniper Rifle"));
        CHECK(pickForHolster(Holster::Chest,owned,6,0)==-1);                                                  // no grenades owned
        int bad[]={-5,9999};CHECK(pickForHolster(Holster::RightHip,bad,2,0)==-1);}
    {   HolsterGesture g;
        CHECK(g.update(Holster::RightHip,true,true).activated==Holster::None);   // grip already held when it started
        auto r=g.update(Holster::RightHip,false,true);CHECK(r.activated==Holster::None);
        r=g.update(Holster::RightHip,true,true);CHECK(r.activated==Holster::RightHip);
        r=g.update(Holster::RightHip,true,true);CHECK(r.activated==Holster::None);     // one press, one action
        g.update(Holster::None,false,true);r=g.update(Holster::Chest,false,true);CHECK(r.entered==Holster::Chest);
        r=g.update(Holster::None,true,true);CHECK(r.activated==Holster::None);         // grip away from the body
        g.update(Holster::Chest,false,false);CHECK(g.hover()==Holster::None);}

    // ---------- Recoil
    {   auto pistol=recoilProfile(1,false),rifleTwo=recoilProfile(3,true),rifleOne=recoilProfile(3,false),shotgun=recoilProfile(5,true);
        CHECK(rifleOne.pitchDegrees>rifleTwo.pitchDegrees*2);CHECK(shotgun.pitchDegrees>pistol.pitchDegrees);
        CHECK(recoilProfile(0,false).pitchDegrees==0);
        Recoil r;r.kick(pistol);CHECK(near(r.pitchDegrees(),7));
        r.update(.11f);CHECK(near(r.pitchDegrees(),7*std::exp(-1.0f),1e-3f));
        for(int i=0;i<40;++i)r.update(.05f);CHECK(r.pitchDegrees()==0&&r.backMetres()==0);
        Recoil auto_;for(int i=0;i<30;++i){auto_.update(.09f);auto_.kick(rifleOne);}CHECK(auto_.pitchDegrees()<=25&&auto_.pitchDegrees()>rifleOne.pitchDegrees*1.8f);   // sustained fire climbs (peak), capped
        Recoil none;none.kick(pistol,0);CHECK(none.pitchDegrees()==0);none.update(NAN);
        WeaponPose p{{1,2,3},{0,1,0},{1,0,0},{0,0,1}};Recoil k;k.kick({10,.05f,.1f});auto q=applyRecoil(p,k);
        CHECK(near(q.forward,{0,std::cos(rad(10)),std::sin(rad(10))}));CHECK(near(dot(q.forward,q.up),0)&&near(length(q.up),1));
        CHECK(near(q.grip,Vec3{1,2,3}-q.forward*.05f));CHECK(near(q.right,p.right));
        Recoil zero;auto same=applyRecoil(p,zero);CHECK(near(same.forward,p.forward)&&near(same.grip,p.grip));}

    // ---------- Magazine reload
    MagInput in;
    {   // Empty gun: drop, grab at belt, push in (no release needed), rack, ready.
        MagazineReload m;m.reset(0);CHECK(!m.chambered);CHECK(std::string(m.instruction(0)).find("EMPTY")==0);
        in=MagInput{};in.eject=true;auto e=m.update(in,0,60);CHECK(e.ejected&&m.stage==MagStage::Out&&!m.chambered&&m.clipAfterEject()==0);
        in=MagInput{};in.grip=true;in.atPouch=false;e=m.update(in,0,60);CHECK(!e.grabbed);                          // grip away from belt
        in.grip=false;m.update(in,0,60);in.grip=true;in.atPouch=true;e=m.update(in,0,60);CHECK(e.grabbed&&m.stage==MagStage::Holding);
        in.atPouch=false;in.atWell=true;e=m.update(in,0,60);CHECK(e.inserted&&m.stage==MagStage::Inserted);         // seats on contact, still gripping
        CHECK(!m.canFire(12));CHECK(std::string(m.instruction(12)).find("slide")!=std::string::npos);
        in=MagInput{};in.grip=false;m.update(in,12,60);
        in.grip=true;in.atBolt=true;in.hand={0,0,0};in.backward={0,0,1};m.update(in,12,60);CHECK(m.stage==MagStage::Racking);
        in.hand={0,0,.02f};e=m.update(in,12,60);CHECK(!e.chambered&&m.stage==MagStage::Racking);
        in.hand={0,0,.055f};e=m.update(in,12,60);CHECK(e.chambered&&m.canFire(12)&&m.stage==MagStage::Inserted);    // no release needed
        CHECK(std::string(m.instruction(12)).empty());}
    {   // Tactical reload: rounds left -> one stays chambered, no rack, can even fire it with the magazine out.
        MagazineReload m;m.reset(8);CHECK(m.canFire(8));
        in=MagInput{};in.eject=true;m.update(in,8,60);CHECK(m.chambered&&m.clipAfterEject()==1&&m.clipBeforeEject()==8);
        CHECK(m.canFire(1));m.fired(0);CHECK(!m.chambered);                                                      // fired the chambered round
        m.reset(8);in=MagInput{};in.eject=true;m.update(in,8,60);
        in=MagInput{};m.update(in,1,60);in.grip=true;in.atPouch=true;m.update(in,1,60);in.atWell=true;auto e=m.update(in,1,60);
        CHECK(e.inserted&&m.canFire(12));}
    {   // Letting go of the magazine away from the gun drops it; you need another one.
        MagazineReload m;m.reset(0);in=MagInput{};in.eject=true;m.update(in,0,60);
        in=MagInput{};m.update(in,0,60);in.grip=true;in.atPouch=true;m.update(in,0,60);
        in.grip=false;in.atPouch=false;auto e=m.update(in,0,60);CHECK(e.dropped&&m.stage==MagStage::Out);
        // Tracking lost while holding: dropped.
        in.grip=true;in.atPouch=true;m.update(in,0,60);CHECK(m.stage==MagStage::Holding);in.valid=false;e=m.update(in,0,60);CHECK(e.dropped);}
    {   // Firing feeds from the magazine until it is empty, then the slide locks back.
        MagazineReload m;m.reset(3);m.fired(2);CHECK(m.canFire(2));m.fired(1);m.fired(0);CHECK(!m.canFire(0));
        // No ammo at all: A does nothing.
        MagazineReload n;n.reset(0);in=MagInput{};in.eject=true;CHECK(!n.update(in,0,0).ejected);
        // Only the chambered round left in total: cannot grab a magazine.
        MagazineReload o;o.reset(1);in=MagInput{};in.eject=true;o.update(in,1,1);in=MagInput{};o.update(in,1,1);in.grip=true;in.atPouch=true;CHECK(!o.update(in,1,1).grabbed);
        // Racking a chambered gun is not needed and ignored.
        MagazineReload q;q.reset(5);in=MagInput{};q.update(in,5,60);in.grip=true;in.atBolt=true;q.update(in,5,60);CHECK(q.stage==MagStage::Inserted);
        // Releasing the slide early: back to "needs rack".
        MagazineReload s;s.reset(0);in=MagInput{};in.eject=true;s.update(in,0,60);in=MagInput{};s.update(in,0,60);in.grip=true;in.atPouch=true;s.update(in,0,60);in.atWell=true;s.update(in,0,60);
        in=MagInput{};s.update(in,12,60);in.grip=true;in.atBolt=true;in.hand={0,0,0};s.update(in,12,60);in.grip=false;in.hand={0,0,.01f};s.update(in,12,60);
        CHECK(s.stage==MagStage::Inserted&&!s.chambered);}
    {   WeaponPose p{{0,0,1},{0,1,0},{1,0,0},{0,0,1}};
        for(int g:{1,2,3,5,6}){auto a=gunAnchors(p,g);CHECK(a.well.z<p.grip.z);CHECK(a.bolt.z>p.grip.z);CHECK(length(a.well-a.bolt)>.1f);}}
    CHECK(atMagazinePouch(head,Vec3{-.17f,1.08f,-.08f}));CHECK(atMagazinePouch(head,Vec3{-.08f,1.30f,-.15f}));
    CHECK(!atMagazinePouch(head,Vec3{.2f,1.0f,0}));CHECK(!atMagazinePouch(head,Vec3{-.1f,1.3f,-.6f}));

    // ---------- Effects and haptics
    CHECK(std::string(shotEffects(1).flash)=="muz_pistol"&&std::string(shotEffects(5).shell)=="eject_shotgun");
    CHECK(shotEffects(7).shell==nullptr);
    {   float a=0,s=0;decodeHaptic(0,a,s);CHECK(near(a,.45f)&&near(s,.025f));
        decodeHaptic(hapticCode(100,70),a,s);CHECK(near(a,1)&&near(s,.07f));
        decodeHaptic(hapticCode(500,9999),a,s);CHECK(near(a,1)&&near(s,.5f));
        float a1,s1,a2,s2;decodeHaptic(shotHaptic(5,true),a1,s1);decodeHaptic(shotHaptic(2,true),a2,s2);CHECK(a1>a2&&s1>s2);
        decodeHaptic(shotHaptic(3,false),a1,s1);decodeHaptic(shotHaptic(3,true),a2,s2);CHECK(a1>a2);}
    std::cout<<checks<<" weapon checks passed (holsters, recoil, physical magazine reload, effects, haptics). GTA props / particles / controllers NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
