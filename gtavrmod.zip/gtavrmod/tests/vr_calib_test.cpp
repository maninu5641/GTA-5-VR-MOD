// 0.9.0: height calibration (T-pose + both triggers), trigger mute, character eye height, body scale, still hand.
#include "vr_calib.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
// Head looking along yaw (radians, 0 = -Z) with pitch (radians, + = up) at pos.
static Pose headPose(float yaw,float pitch,Vec3 pos){
    Vec3 f{-std::sin(yaw)*std::cos(pitch),std::sin(pitch),-std::cos(yaw)*std::cos(pitch)};
    Vec3 r=unit(cross(f,{0,1,0}),{1,0,0}),u=cross(r,f);Pose p{};
    p.m[0][0]=r.x;p.m[1][0]=r.y;p.m[2][0]=r.z;p.m[0][1]=u.x;p.m[1][1]=u.y;p.m[2][1]=u.z;p.m[0][2]=-f.x;p.m[1][2]=-f.y;p.m[2][2]=-f.z;
    p.m[0][3]=pos.x;p.m[1][3]=pos.y;p.m[2][3]=pos.z;return p;
}
static TPoseInput tPose(float eye=1.58f,float yaw=0,float halfSpan=.72f){
    TPoseInput in;in.head=headPose(yaw,0,{.3f,eye,-.2f});Vec3 r{std::cos(yaw),0,-std::sin(yaw)};
    in.left=Vec3{.3f,eye-.25f,-.2f}-r*halfSpan;in.right=Vec3{.3f,eye-.25f,-.2f}+r*halfSpan;in.leftValid=in.rightValid=true;in.leftTrigger=in.rightTrigger=1;return in;
}

int main(){try{
    // --- T-pose shape
    {   CHECK(tPoseShape(tPose()));CHECK(tPoseShape(tPose(1.62f,1.3f)));CHECK(tPoseShape(tPose(1.2f,-2.5f,.6f)));   // any facing; seated / child span
        auto t=tPose();t.left.y-=.4f;CHECK(!tPoseShape(t));                                  // not level
        t=tPose();std::swap(t.left,t.right);CHECK(!tPoseShape(t));                            // crossed arms
        t=tPose(1.58f,0,.40f);CHECK(!tPoseShape(t));                                          // hands close together
        t=tPose();t.left.y=t.right.y=0.7f;CHECK(!tPoseShape(t));                              // arms down
        t=tPose();t.left.z-=.6f;t.right.z-=.6f;CHECK(!tPoseShape(t));                        // arms forward (aiming), not a T
        t=tPose();t.head=headPose(0,-.9f,t.head.pos());CHECK(!tPoseShape(t));                // looking at the floor
        t=tPose();t.leftValid=false;CHECK(!tPoseShape(t));}
    // --- Calibration: 2 s holding both triggers in the T; result = eye height and hand span.
    {   HeightCalibration c;CalibrationResult r;auto in=tPose(1.58f);
        CHECK(c.update(in,.016f,r)==HeightCalibration::Started&&c.holding()&&c.posing());
        int done=0,steps=0;for(;steps<400&&!done;++steps)if(c.update(in,1.0f/60,r)==HeightCalibration::Done)done=1;
        CHECK(done&&steps>=118&&steps<=122);CHECK(near(r.eyeHeight,1.58f,1e-3f)&&near(r.span,1.44f,1e-3f)&&plausibleCalibration(r));
        CHECK(!c.holding()&&c.posing());                                                     // latched until the triggers are released
        CHECK(c.update(in,1.0f,r)==HeightCalibration::None);                                // still held: no second calibration
        in.leftTrigger=in.rightTrigger=0;c.update(in,.016f,r);auto down=tPose();down.left.y=down.right.y=.7f;down.leftTrigger=down.rightTrigger=0;
        c.update(down,.016f,r);CHECK(!c.posing());
        // Releasing early cancels; the triggers alone (no T) never start it.
        HeightCalibration e;auto t=tPose();e.update(t,.016f,r);for(int i=0;i<60;++i)e.update(t,1.0f/60,r);t.rightTrigger=0;
        CHECK(e.update(t,.016f,r)==HeightCalibration::Cancelled);CHECK(e.posing());           // still latched by the left trigger
        HeightCalibration g;auto aim=tPose();aim.left.z-=.6f;aim.right.z-=.6f;CHECK(g.update(aim,.016f,r)==HeightCalibration::None&&!g.posing());
        HeightCalibration off;auto blocked=tPose();blocked.allowed=false;CHECK(off.update(blocked,.016f,r)==HeightCalibration::None);
        CalibrationResult silly{3.0f,1.4f};CHECK(!plausibleCalibration(silly));CalibrationResult nan{NAN,1.4f};CHECK(!plausibleCalibration(nan));}
    // --- Trigger mute: muted while posing, and until released afterwards.
    {   TriggerMute m;CHECK(near(m.update(.9f,false),.9f));CHECK(m.update(.9f,true)==0&&m.active());
        CHECK(m.update(.95f,false)==0);CHECK(m.update(.1f,false)==0.1f&&!m.active());CHECK(near(m.update(.8f,false),.8f));CHECK(m.update(NAN,false)==0);}
    // --- Character eye height (median) and body scale.
    {   CharacterEyeHeight h;h.reset(123);CHECK(!h.ready()&&near(h.value(),CharacterEyeHeight::Default)&&h.model()==123);
        for(int i=0;i<44;++i)h.add(1.70f+float(i%5)*.002f,.05f);CHECK(!h.ready());h.add(5.0f,.0f);CHECK(!h.ready());   // impossible sample ignored
        h.add(1.70f,.05f);CHECK(h.ready()&&h.value()>1.679f&&h.value()<1.69f);   // eyes 1.70 over toes 0.05 (3 cm above the sole)
        float v=h.value();h.add(1.9f,0);CHECK(near(h.value(),v));                                                        // fixed once measured
        CHECK(near(bodyScale(1.66f,1.66f),1));CHECK(near(bodyScale(1.66f,1.40f),1.66f/1.40f,1e-4f));CHECK(near(bodyScale(1.66f,.9f),1.45f));
        CHECK(near(bodyScale(1.66f,0),1));CHECK(near(bodyScale(NAN,1.6f),1));CHECK(near(bodyScale(1.6f,2.6f),.70f));}
    // --- Still hand
    {   HandStill s;Pose p=headPose(.2f,.1f,{0,1,0});CHECK(!s.update(p,0));int frames=0;while(!s.update(p,1.0f/60)&&frames<100)++frames;CHECK(frames>=19&&frames<=22&&s.still());
        Pose moved=p;moved.m[0][3]+=.05f;CHECK(!s.update(moved,1.0f/60)&&!s.still());
        Pose turned=headPose(.2f+rad(15),.1f,moved.pos());s.update(moved,.25f);s.update(moved,.25f);CHECK(s.still());CHECK(!s.update(turned,1.0f/60));
        Pose bad{};CHECK(!s.update(bad,.5f));CHECK(near(angleDegrees({1,0,0},{0,1,0}),90,1e-3f));}
    std::cout<<checks<<" calibration checks passed (T-pose, height calibration, trigger mute, character eye height, body scale, still hand). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
