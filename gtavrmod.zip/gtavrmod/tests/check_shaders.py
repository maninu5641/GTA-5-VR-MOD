"""Validate the runtime-compiled HLSL with DXC (syntax/semantics; DXC targets SM6,
the game compiles the same text as vs_5_0/ps_5_0 with d3dcompiler_47).
Usage: python tests/check_shaders.py /path/to/dxc"""
import pathlib, re, subprocess, sys, tempfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
source = (ROOT / 'src/hand_overlay.hpp').read_text()
hlsl = re.search(r'R"HLSL\((.*?)\)HLSL"', source, re.S).group(1)
dxc = sys.argv[1]
with tempfile.TemporaryDirectory() as tmp:
    path = pathlib.Path(tmp) / 'hands.hlsl'; path.write_text(hlsl)
    for entry, target in [('VSMain', 'vs_6_0'), ('PSMain', 'ps_6_0')]:
        out = pathlib.Path(tmp) / (entry + '.bin')
        subprocess.run([dxc, '-T', target, '-E', entry, '-WX', '-Fo', str(out), str(path)], check=True)
        assert out.stat().st_size > 0
print('Hand shaders: VSMain and PSMain compile with DXC (warnings as errors). Runtime compile uses d3dcompiler_47 vs_5_0/ps_5_0.')
