"""Inspect packaged PE files and embedded payloads without running Windows code.
Run after build.py: python tests/check_package.py (requires objdump).
"""
import hashlib
import json
import pathlib
import struct
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]

def pe(data):
    start = struct.unpack_from('<I', data, 60)[0]
    assert data[start:start + 4] == b'PE\0\0'
    machine, count = struct.unpack_from('<HH', data, start + 4)
    optional_size = struct.unpack_from('<H', data, start + 20)[0]
    optional = start + 24
    assert machine == 0x8664 and struct.unpack_from('<H', data, optional)[0] == 0x20b
    sections = []
    for i in range(count):
        pos = optional + optional_size + 40 * i
        virtual_size, rva, raw_size, raw = struct.unpack_from('<IIII', data, pos + 8)
        sections.append((rva, max(virtual_size, raw_size), raw))
    def offset(rva):
        for start, size, raw in sections:
            if start <= rva < start + size:
                return raw + rva - start
        raise ValueError('Unknown RVA')
    return optional, offset

def main():
    paths = json.loads((ROOT / 'package_files.json').read_text())
    setup = (ROOT / 'gta5vrmod setup.exe').read_bytes()
    optional, offset = pe(setup)
    base = offset(struct.unpack_from('<I', setup, optional + 112 + 2 * 8)[0])
    resources = {}
    def walk(pos, keys):
        count = sum(struct.unpack_from('<HH', setup, pos + 12))
        for i in range(count):
            name, child = struct.unpack_from('<II', setup, pos + 16 + 8 * i)
            key = name if not name & 0x80000000 else 'named'
            if child & 0x80000000:
                walk(base + (child & 0x7fffffff), keys + [key])
            else:
                rva, size, _, _ = struct.unpack_from('<IIII', setup, base + child)
                resources[tuple(keys + [key])] = setup[offset(rva):offset(rva) + size]
    walk(base, [])
    for i, path in enumerate(paths, 200):
        matching = [v for k, v in resources.items() if k[:2] == (10, i)]
        assert len(matching) == 1 and matching[0] == (ROOT / 'dist' / path).read_bytes(), path
    report = {'setup_payloads_verified': len(paths), 'native_binaries': []}
    # 0.16.0: the built-in renderer only - no R.E.A.L. input companion, no OpenXR layer in the package or in dist.
    removed = ['GTAHandVR/GTAHandVR-Bridge.exe', 'GTAHandVR/actions.json', 'GTAHandVR/bindings_oculus_touch.json', 'GTAHandVR/GTAHandVR.vrmanifest',
               'GTAHandVR/OpenXR/GTAHandVR-OpenXR.dll', 'GTAHandVR/OpenXR/GTAHandVR-layer.json', 'GTAHandVR/OpenXR-LICENSE.txt']
    for path in removed:
        assert path not in paths and not (ROOT / 'dist' / path).exists(), path
    assert not (ROOT / 'dist/GTAHandVR/OpenXR').exists() and not (ROOT / 'src/bridge.cpp').exists() and not (ROOT / 'src/openxr_layer.cpp').exists()
    report['removed_companion_and_openxr_verified'] = True
    for relative in ['gta5vrmod setup.exe', 'dist/GTA5 VR.exe', 'dist/GTAHandVR.asi', 'dist/GTA5VRRenderer.asi']:
        path = ROOT / relative
        data = path.read_bytes()
        optional, _ = pe(data)
        details = subprocess.check_output(['objdump', '-p', str(path)], text=True)
        imports = [line.strip().split(': ', 1)[1] for line in details.splitlines() if 'DLL Name:' in line]
        subsystem = struct.unpack_from('<H', data, optional + 68)[0]
        report['native_binaries'].append({'path': relative, 'architecture': 'x86_64',
            'subsystem': subsystem, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'imports': imports})
        if path.name in ['gta5vrmod setup.exe', 'GTA5 VR.exe']:
            assert subsystem == 2
        if path.name == 'GTA5 VR.exe':
            # 0.16.0 (release): no experimental / development wording, no OpenXR / R.E.A.L. / physical driving choices.
            for gone in ('xperimental', 'XPERIMENTAL', 'development build', 'OpenXR', 'R.E.A.L', 'Physical driving', 'PhysicalDriving', 'Bridge'):
                assert gone.encode('utf-16-le') not in data and gone.encode() not in data, (path.name, gone)
            for text in ('PLAY GTA 5 IN VR', 'First-person gameplay', 'Physical magazine reload', 'Support grip for heavier weapons', 'Show aiming laser',
                         'Ready to play', 'Not ready yet', 'Script Hook V is missing', 'Run gta5vrmod setup.exe again to repair it', 'FirstPerson', 'ManualReload', 'RequireSupportGrip', 'Laser'):
                assert text.encode('utf-16-le') in data, text
            for gone in ('Diagnostics', 'Save settings', 'Runtime', 'Uninstall'):
                assert gone.encode('utf-16-le') not in data, gone
            assert 'ms-windows-store://pdp/?productid=9N9RSV4F7ZR0'.encode('utf-16-le') in data and 'GTA V Legacy from the Xbox app'.encode('utf-16-le') in data and 'The VR view starts once Story Mode has loaded'.encode('utf-16-le') in data
            report['launcher_0_16_0_four_options_and_play_verified'] = True
            assert "In game: A is GTA's E key (shops, people).".encode('utf-16-le') in data
            report['launcher_0_16_3_a_is_e_tip_verified'] = True
        if path.name == 'gta5vrmod setup.exe':
            for text in ('Choose your GTA V Legacy folder', 'Check what is there', 'Open launcher', 'Get Script Hook V', 'Start with the default settings',
                         'GTAHandVR/GTAHandVR-Bridge.exe', 'GTAHandVR/OpenXR/GTAHandVR-OpenXR.dll', 'Story Mode only - GTA Online is not supported.'):
                assert text.encode('utf-16-le') in data, text
            assert b'GTA 5 VR 0.16.3\r\nBackup: ' in data and b'REMOVED  ' in data
            # The setup carries every payload (the renderer, READ_ME_FIRST...): only its own UI text (UTF-16) is checked here.
            for gone in ('xperimental', 'XPERIMENTAL', 'not tested by its developer', 'Physical driving', 'R.E.A.L', 'GTA 5 VR menu'):
                assert gone.encode('utf-16-le') not in data, ('setup', gone)
            for text in ('Xbox app (Game Pass) version: start GTA V from the Xbox app', 'MicrosoftGame.config', 'XboxGames', 'GTA5.exe could not be read',
                         'the VR view starts once it has loaded'):
                assert text.encode('utf-16-le') in data, text
            report['setup_0_16_0_steps_and_cleanup_verified'] = True
        if path.name == 'GTA5VRRenderer.asi':
            assert 'ScriptHookV.dll' in imports
            assert b'?presentCallbackRegister@@YAXP6AXPEAX@Z@Z' in data
            assert b'?presentCallbackUnregister@@YAXP6AXPEAX@Z@Z' in data
            assert 'D3D11CreateDeviceAndSwapChain' not in details
            report['renderer_sdk_callback_symbols_verified'] = True
            report['dummy_swapchain_creation_removed'] = True
            exports=['GTA5VR_GetCameraApiVersion','GTA5VR_SubmitHeadPose','GTA5VR_ClearHeadPose','GTA5VR_RequestRecenter','GTA5VR_ReadCamera']
            for symbol in exports:
                assert any(line.strip().endswith(' '+symbol) and '[' in line for line in details.splitlines()), symbol
            report['camera_api_exports_verified'] = exports
            assert b'Frame sync: frame tag found in a captured frame' in data
            assert b'Falling back to untagged alternate-eye capture' in data
            assert b'GTA 5 VR ' in data and b'0.16.3' in data
            assert b'D3DCompile' in data and b'Hands: overlay ready' in data and b'VSMain' in data
            report['renderer_hand_overlay_strings_verified'] = True
            assert b'CreateDXGIFactory1' in data and b'D3D11CreateDevice' in data and b'SubmitDevice' in data
            report['renderer_bridge_device_strings_verified'] = True
            report['renderer_frame_sync_strings_verified'] = True
            assert b'Body calibration' in data and b'Map: GTA' in data and b'CharacterWheelView' in data and b'Shift+End' in data and b'crouch stance' in data
            report['renderer_0_9_strings_verified'] = True
            assert b'quaternion check' in data and b'held level on foot' in data and 'IkBlendIn'.encode('utf-16-le') in data and 'LevelGameCamera'.encode('utf-16-le') in data
            report['renderer_0_11_arm_strings_verified'] = True
            assert b'open loop' in data and b'Arm IK check' in data and b'marker attached to the hand bone' in data and b'hand bone axes measured' in data
            report['renderer_0_12_arm_strings_verified'] = True
            assert b'Fingers: on' in data and b'the hand holds the gun the way GTA holds it' in data and b'animation task itself is checked' in data
            assert 'Fingers'.encode('utf-16-le') in data and 'CharacterWheelView'.encode('utf-16-le') in data
            report['renderer_0_13_finger_and_grip_strings_verified'] = True
            assert b'hand check done' in data and b'nm@hands' in data and b'middle finger' in data and b'whole-hand poses' in data and b"GTA's hand grip filters" in data
            report['renderer_0_14_hand_check_strings_verified'] = True
            assert b'VR mode: off (both stick clicks)' in data and b'Keep holding both sticks' in data and b'VR mode: on (F11)' in data and 'VrButton'.encode('utf-16-le') in data and 'VrButtonHold'.encode('utf-16-le') in data
            report['renderer_0_15_vr_button_strings_verified'] = True
            assert b'GTA 5 VR  -  VR SETTINGS' in data and b'VR menu: open (' in data and b"GTA's pause menu with the controllers" in data and b'SteamVR menu opened: GTA paused' in data
            assert b'Flat screen: ' in data and b'View: GTA aims at the person the VR gun points at' in data and b'(saved in GTAHandVR.ini)' in data
            assert 'Controls'.encode('utf-16-le') in data and 'RightStickClick'.encode('utf-16-le') in data and 'PauseOnDashboard'.encode('utf-16-le') in data and 'GtaAim'.encode('utf-16-le') in data
            report['renderer_0_15_5_vr_menu_and_aim_view_strings_verified'] = True
            assert b'its own did not close the hand' in data and b'PistolGrip=Rifle' in data and 'PistolGrip'.encode('utf-16-le') in data and 'Rifle'.encode('utf-16-le') in data
            assert b"GTA's rifle grip (whole-hand pose for a gun) did not load in 4 s" in data and b'weapons@rifle@lo@shotgun_assault' in data
            report['renderer_0_15_8_gun_grip_strings_verified'] = True
            assert b' experimental.' not in data and b'No successful GTA/headset rendering' not in data and b'Choose External for OpenXR' not in data
            assert b"still has an older build's renderer option (Mode=External / Backend=OpenXR) - ignored" in data
            report['renderer_0_16_0_builtin_only_verified'] = True
            assert b'Camera: StereoMode=Auto for a ' in data and b'(another VR mod) is in the game folder' in data
            assert b'Select External mode' not in data
            report['renderer_0_16_1_auto_stereo_verified'] = True
            assert b'View: on foot the view keeps its own heading' in data and b'Body: the character faces your body' in data
            assert b'Frame timing: GTA' in data and b'render_thread_lock_wait_ms=' in data and b'anchor_lean_skipped=' in data and b'images per eye' in data
            assert b' deg - the character turned with you (heading ' not in data and b"GTA's camera did not take the body turn" not in data
            report['renderer_0_16_2_own_view_heading_body_follow_timing_verified'] = True
            assert b'Magazine / reload / E / phone OK' in data   # 0.16.3: the VR menu's name of Reload
            report['renderer_0_16_3_reload_is_e_menu_name_verified'] = True
        if path.name == 'GTAHandVR.asi':
            assert b'0.16.3' in data and b'GTA4VR' in data and b'Character wheel' in data and b'PUMP' in data and b'walks under your head' in data
            report['motion_0_9_strings_verified'] = True
            assert b'Backend protocol 4' in data and b'Pavlov style' in data and b'Hand on the gun' in data and b'GTA holds the ' in data and b'Holsters: the weapons rest on the body' in data
            assert 'HolsterModels'.encode('utf-16-le') in data and 'MeasureGrip'.encode('utf-16-le') in data and 'HandOnGun'.encode('utf-16-le') in data and 'Pavlov'.encode('utf-16-le') in data
            report['motion_0_13_pavlov_strings_verified'] = True
            assert b'on from the start' in data and b'the stick walks' in data and b'INPUT_CELLPHONE_SELECT' in data and b'enter / steal the vehicle' in data and b'did not fire' in data and b'chambers a round' in data
            assert 'StartEnabled'.encode('utf-16-le') in data and 'StickSpeed'.encode('utf-16-le') in data and 'RackSlide'.encode('utf-16-le') in data and 'MagazineModels'.encode('utf-16-le') in data
            report['motion_0_14_controls_strings_verified'] = True
            assert b'Gun sound: GTA fired the ' in data and b'its own gunshot' in data and b'GTA did not fire the ' in data and b'WAPClip' in data and b'magazine leaves the gun model' in data
            assert b"released the " in data and b'bolt worked by hand' in data and b'Slide locked back' in data
            assert 'GunSound'.encode('utf-16-le') in data and 'SlideRelease'.encode('utf-16-le') in data and 'BoltAction'.encode('utf-16-le') in data
            report['motion_0_15_gunshot_and_reload_strings_verified'] = True
            assert b'Character menu: switch to ' in data and b'CHANGE CHARACTER' in data and b'did not switch to ' in data and b"select key " in data
            assert 'CharacterKeys'.encode('utf-16-le') in data and 'WeaponWheel'.encode('utf-16-le') in data and b'B = vehicle, A / B = phone' in data
            report['motion_0_15_1_character_menu_and_b_strings_verified'] = True
            assert b' let go after ' in data and b'GTA saw it held' in data and b'GTA did NOT see the key' in data and 'CharacterKeyHold'.encode('utf-16-le') in data
            report['motion_0_15_2_select_key_hold_strings_verified'] = True
            assert b"GTA's own wheel (Left Alt held like the keyboard" in data and b"Character wheel: keys let go on " in data and b"GTA's own wheel is open (its effect " in data
            assert b'SwitchHUDFranklinIn' in data and b'GTA says it is not safe to switch here' in data   # 0.15.6: no "GTA'S CHARACTER WHEEL" text any more
            assert b"GTA's window is no longer in front - every key let go" in data and 'CharacterMenu'.encode('utf-16-le') in data and 'Inputs'.encode('utf-16-le') in data
            report['motion_0_15_3_gta_wheel_strings_verified'] = True
            assert b'to put its copy of the gun away after the hand let go' in data and b"in the character's hand 3 s after the hand let go" in data
            assert b"read from GTA's invisible copy (nothing shown)" in data
            report['motion_0_15_3_gun_copy_strings_verified'] = True
            assert b"GTA's copy of the gun is held only while you shoot (trigger touched, 0.8 s after)" in data and b'Gun sound: the first round waited ' in data
            assert 'GunHold'.encode('utf-16-le') in data and 'Shooting'.encode('utf-16-le') in data and 'Always'.encode('utf-16-le') in data
            report['motion_0_15_4_gun_hold_strings_verified'] = True
            assert b'GTA aim: the gun points at a person ' in data and b'?worldGetAllPeds@@YAHPEAHH@Z' in data and b' tapped alone (GTA' in data
            assert b'Settings: GTAHandVR.ini changed' in data and b'only as a DISABLED key' in data and b'right stick: move' in data and 'GtaAim'.encode('utf-16-le') in data
            report['motion_0_15_5_gta_aim_buttons_and_switch_strings_verified'] = True
            assert b"GTA's character wheel did not open here" in data and b"GTA's character key off before this add-on's update in " in data
            assert b"GTA'S CHARACTER WHEEL  |  a stick" not in data
            report['motion_0_15_6_gta_wheel_only_strings_verified'] = True
            assert b"Hand: the weapon is in the character's hand now (attached to GTA's prop bone PH_R_Hand" in data and b'where your controller points it' in data
            assert b"in the character's hand, GTA's prop bone" in data and b'the weapon floats at the controller ' in data
            assert b'Phone: right stick up' in data and b'held up: put away' in data and b'right stick down: next weapon (up: phone)' in data
            assert b"Prologue: the shoot-out at the crates - the character takes cover there by itself" in data and b'pull the left stick back to leave cover' in data
            assert b' killed - health ' in data
            assert 'HandHold'.encode('utf-16-le') in data and 'PhoneStick'.encode('utf-16-le') in data and 'PrologueCover'.encode('utf-16-le') in data and 'HealOnKill'.encode('utf-16-le') in data
            assert 'Missions'.encode('utf-16-le') in data and 'Gameplay'.encode('utf-16-le') in data
            report['motion_0_15_7_hand_hold_phone_cover_heal_strings_verified'] = True
            assert b"is held the way GTA holds it - GTA's grip of it, read from GTA's copy in the character's hand" in data and b"attached GTA's way sits " in data and b" in the hand matches GTA's grip (" in data
            assert 'GtaGrip'.encode('utf-16-le') in data and b' cm, turned ' in data
            assert b' without usable controller input (' in data and b'the hands kept what they hold' in data and b'Tracking lost for a moment' in data and b'the input is late - older than 0.2 s' in data
            assert b'below 0.35 for 0.1 s' in data and b'was squeezed again within 0.8 s - back in the hand' in data and b'falling / ragdolling' in data
            assert b'the VR hands let go of ' in data and b'the VR weapon was invisible although it should show' in data
            report['motion_0_15_8_grip_latch_dropout_gta_grip_strings_verified'] = True
            assert b'GTA 5 VR 0.16.3 loaded. Backend protocol 4. Weapons: ' in data and b'development build' not in data and b'Experimental' not in data
            assert 'PhysicalDriving'.encode('utf-16-le') not in data
            report['motion_0_16_0_release_strings_verified'] = True
            assert b"Buttons: A = GTA's action key E (" in data and b'ReloadIsE'.decode().encode('utf-16-le') in data and b'the right hand holds no gun' in data
            assert b'Menu keys: the character has no control' in data
            report['motion_0_16_3_a_is_e_menu_keys_verified'] = True
    ini = (ROOT / 'dist/GTAHandVR.ini').read_text()
    for line in ('HandHold=1', 'PhoneStick=1', '[Missions]', 'PrologueCover=1', '[Gameplay]', 'HealOnKill=15'):
        assert ('\n' + line + '\n') in ini, line
    report['ini_0_15_7_settings_verified'] = True
    for line in ('GtaGrip=1', 'PistolGrip=Auto'):
        assert ('\n' + line + '\n') in ini, line
    report['ini_0_15_8_settings_verified'] = True
    for gone in ('PhysicalDriving', 'Mode=External', 'Mode=Builtin', 'Backend=', 'R.E.A.L', 'xperimental', 'OpenXR'):
        assert gone not in ini, gone
    report['ini_0_16_0_release_verified'] = True
    assert '\nReloadIsE=1\n' in ini and 'a stick = arrow keys, A = Enter, B = Backspace' in ini
    report['ini_0_16_3_reload_is_e_verified'] = True
    # 0.16.3 (the developer): the setup is "gta5vrmod setup.exe"; the old name is gone from the package.
    assert (ROOT / 'gta5vrmod setup.exe').is_file() and not (ROOT / 'GTA5_VR_Setup.exe').exists()
    report['setup_name_0_16_3_verified'] = 'gta5vrmod setup.exe'
    renderer_manifest = json.loads((ROOT / 'dist/GTAHandVR/renderer_actions.json').read_text())
    renderer_bindings = json.loads((ROOT / 'dist/GTAHandVR/renderer_bindings_oculus_touch.json').read_text())
    renderer_app = json.loads((ROOT / 'dist/GTAHandVR/GTAHandVR-renderer.vrmanifest').read_text())
    declared = {x['name'] for x in renderer_manifest['actions']}
    bound = set()
    def visit(obj):
        if isinstance(obj, dict):
            if 'output' in obj:
                bound.add(obj['output'])
            for v in obj.values():
                visit(v)
        elif isinstance(obj, list):
            for v in obj:
                visit(v)
    visit(renderer_bindings)
    assert declared == bound, (declared - bound, bound - declared)
    assert {'/actions/main/in/left_skeleton', '/actions/main/in/right_skeleton'} <= declared
    report['skeleton_actions_bound'] = True
    assert renderer_manifest['default_bindings'][0]['binding_url'] == 'renderer_bindings_oculus_touch.json'
    assert renderer_bindings['app_key'] == renderer_app['applications'][0]['app_key'] == 'local.gta5vr.renderer'
    report['renderer_actions_and_app_key_verified'] = True
    report['all_steamvr_actions_bound'] = True
    report['steamvr_action_count'] = len(declared)
    (ROOT / 'docs/STATIC_CHECKS.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Verified {len(paths)} embedded payloads, four x64 binaries, GUI subsystems, renderer SDK callback symbols, the release launcher and setup, and {len(declared)} bound SteamVR actions.')

if __name__ == '__main__':
    main()
