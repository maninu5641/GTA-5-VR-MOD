// 0.15.0: the VR on / off button, GTA's own gunshot (which path fires each weapon), Pavlov magazines
// (the slide release, the magazine lining up with the well) and the dry-fire click.
#include "vr_shot.hpp"
#include "weapons_vr.hpp"
#include "vr_gun.hpp"
#include "vr_play.hpp"
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}

int main(){try{
    // --- The VR button: both clicks for the hold time, once per hold; one click alone does nothing.
    {   BothClicksToggle t{1000};
        CHECK(!t.update(true,false,0)&&!t.swallowing());                 // one click: it goes on to the game
        CHECK(!t.update(true,true,100)&&t.swallowing()&&t.holding());   // both: swallowed from now on
        CHECK(near(t.progress(600),.5f));
        CHECK(!t.update(true,true,1099));CHECK(t.update(true,true,1100));   // 1 s: VR on / off
        CHECK(!t.update(true,true,3000)&&!t.holding());                   // once per hold
        CHECK(!t.update(true,false,3100)&&t.swallowing());                // still swallowed until both are let go
        CHECK(!t.update(false,false,3200)&&!t.swallowing());
        // Let go early: nothing; a new hold starts from zero.
        CHECK(!t.update(true,true,4000)&&!t.update(false,true,4800)&&!t.update(true,true,4900)&&!t.update(true,true,5800));
        CHECK(t.update(true,true,5900));
        t.setHold(50);CHECK(!t.update(false,false,6000)&&!t.update(true,true,6100)&&t.update(true,true,6300));   // at least 200 ms
        t.reset();CHECK(!t.swallowing()&&!t.holding()&&near(t.progress(0),0));}
    // --- GTA's own gunshot: which path fires each weapon.
    {   ShotLearner l;const std::uint32_t pistol=1,rifle=2,smg=3;
        CHECK(l.path(pistol)==ShotPath::Unknown&&l.askGame(pistol));
        // GTA fires the pistol during the request: Sync.
        CHECK(l.afterRequest(pistol,true)==ShotLearner::After::Fired&&l.path(pistol)==ShotPath::Sync);
        // A Sync weapon GTA refuses once: wait, then the mod fires it; it stays Sync (refusal counted).
        CHECK(l.afterRequest(pistol,false)==ShotLearner::After::Wait);CHECK(l.resolved(pistol,false)==ShotPath::Sync&&l.refusals(pistol)==1);
        CHECK(l.resolved(pistol,false)==ShotPath::Sync&&l.askGame(pistol));
        // The rifle fires a moment later: Late, and it stays Late even when a later round leaves at once.
        CHECK(l.afterRequest(rifle,false)==ShotLearner::After::Wait);CHECK(l.resolved(rifle,true)==ShotPath::Late);
        CHECK(l.afterRequest(rifle,true)==ShotLearner::After::Fired&&l.path(rifle)==ShotPath::Late);
        // The SMG never fires: after two tries the mod fires it (no more requests).
        CHECK(l.afterRequest(smg,false)==ShotLearner::After::Wait);CHECK(l.resolved(smg,false)==ShotPath::Unknown);
        CHECK(l.afterRequest(smg,false)==ShotLearner::After::Wait);CHECK(l.resolved(smg,false)==ShotPath::Script&&!l.askGame(smg));
        // One try that fires in between resets the count.
        ShotLearner m;m.afterRequest(9,false);m.resolved(9,false);m.afterRequest(9,false);m.resolved(9,true);m.afterRequest(9,false);
        CHECK(m.resolved(9,false)==ShotPath::Late&&m.askGame(9));
        l.forget();CHECK(l.path(smg)==ShotPath::Unknown);
        CHECK(std::string(shotPathName(ShotPath::Script))=="the mod fires it");}
    // --- A round waited for: GTA's ammunition drops = fired; not within the wait = missed.
    {   PendingRound r;CHECK(r.update(10)==PendingRound::State::Idle);
        r.start(7,30);CHECK(r.update(30)==PendingRound::State::Waiting&&r.update(30)==PendingRound::State::Waiting);
        CHECK(r.update(29)==PendingRound::State::Fired&&!r.active);
        r.start(7,30);for(int i=1;i<PendingRound::WaitUpdates;++i)CHECK(r.update(30)==PendingRound::State::Waiting);
        CHECK(r.update(30)==PendingRound::State::Missed&&!r.active);
        r.start(7,30);r.clear();CHECK(!r.active&&r.update(0)==PendingRound::State::Idle);
        r.start(7,30);CHECK(r.update(31)==PendingRound::State::Waiting);}   // more ammunition (a pickup) is not a shot
    // --- Pavlov magazines: the held magazine lines up near the well and reaches the gun's own magazine place.
    {   CHECK(near(wellSnap(.25f,.20f,.11f),0)&&near(wellSnap(.11f,.20f,.11f),1)&&near(wellSnap(.05f,.20f,.11f),1));
        CHECK(near(wellSnap(.155f,.20f,.11f),.5f));CHECK(near(wellSnap(NAN,.2f,.1f),0)&&near(wellSnap(.1f,.1f,.2f),0));
        Vec3 hand{0,0,0},clip{1,0,1},up{0,0,1};
        CHECK(near(magazineDrawPoint(hand,clip,up,0,.06f),hand));CHECK(near(magazineDrawPoint(hand,clip,up,1,.06f),clip));
        Vec3 mid=magazineDrawPoint(hand,clip,up,.5f,.06f);CHECK(near(mid,{.5f,0,.5f-.015f}));
        CHECK(near(magazineDrawPoint(hand,clip,up,3,.06f),clip));}
    // --- The slide release (A): only with the slide back and a loaded magazine in.
    {   MagazineReload m;m.reset(0);CHECK(!m.slideBack(0));
        MagInput in;in.eject=true;m.update(in,0,60);CHECK(m.stage==MagStage::Out&&!m.chambered&&!m.slideBack(0));
        in=MagInput{};m.update(in,0,60);in.grip=true;in.atPouch=true;m.update(in,0,60);in.atWell=true;CHECK(m.update(in,12,60).inserted);
        CHECK(m.slideBack(12)&&!m.canFire(12));CHECK(m.releaseSlide(12)&&m.canFire(12)&&!m.slideBack(12));
        CHECK(!m.releaseSlide(12));                                      // a round is in: nothing to release
        MagazineReload t;t.reset(8);CHECK(!t.slideBack(8)&&!t.releaseSlide(8));   // tactical: the slide never went back
        MagazineReload e;e.reset(0);CHECK(!e.releaseSlide(0));            // empty magazine: nothing to feed
        CHECK(std::string(m.instruction(12)).empty());
        MagazineReload h;h.reset(0);in=MagInput{};in.eject=true;h.update(in,0,60);in=MagInput{};h.update(in,0,60);in.grip=true;in.atPouch=true;h.update(in,0,60);in.atWell=true;h.update(in,12,60);
        CHECK(std::string(h.instruction(12)).find("press A")!=std::string::npos);}
    // --- Dry fire: one click per pull while the gun cannot fire; none while it can.
    {   DryFire d;CHECK(!d.update(.2f,false));CHECK(d.update(.7f,false));CHECK(!d.update(.9f,false));   // held: once
        CHECK(!d.update(.5f,false));CHECK(!d.update(.3f,false));CHECK(d.update(.8f,false));              // let go under .35, pull again
        CHECK(!d.update(.1f,true)&&!d.update(.9f,true));CHECK(!d.update(NAN,false));}
    // --- Bolt action (the Sniper Rifle only): the pump's strokes at the bolt - back 6 cm, forward 4.5 cm.
    {   CHECK(boltActionRifle(0x05FC3C11u)&&!boltActionRifle(0x0C472FE2u)&&!boltActionRifle(0x1D073A89u));
        PumpAction b;b.reset(true);b.fired();CHECK(b.needsPump());
        CHECK(!b.update(true,.02f,5).back);CHECK(!b.update(true,-.03f,5).back);CHECK(b.update(true,-.045f,5).back);
        CHECK(!b.update(true,-.01f,5).forward);CHECK(b.update(true,.0f,5).forward&&b.chambered());
        PumpAction e;e.reset(true);e.fired();e.update(true,0,0);e.update(true,-.07f,0);e.update(true,0,0);CHECK(!e.chambered());}   // no rounds: nothing chambered
    // --- 0.15.1: the character menu's keys - GTA's F5 / F6 / F7 as scan codes, the same characters as GTA's controls.
    {   CHECK(characterScan(Character::Michael)==0x3F&&characterScan(Character::Franklin)==0x40&&characterScan(Character::Trevor)==0x41&&characterScan(Character::None)==0);
        CHECK(std::string(characterKey(Character::Franklin))=="F6"&&std::string(characterKey(Character::None))=="-");
        for(Character c:{Character::Michael,Character::Franklin,Character::Trevor})CHECK(characterControl(c)-166==int(characterScan(c))-0x3F);
        // The menu's stick directions: left Michael, up Franklin, right Trevor; down / centre nothing.
        CHECK(characterForStick(-1,0)==Character::Michael&&characterForStick(0,1)==Character::Franklin&&characterForStick(1,0)==Character::Trevor);
        CHECK(characterForStick(0,-1)==Character::None&&characterForStick(.2f,.2f)==Character::None);
        // 0.15.2: the key stays down past GTA's selector opening (0.3 s): 0.65 s by default, never under 0.35 s.
        CHECK(selectKeyHoldMs(.65f)==650&&selectKeyHoldMs(.2f)==SelectorOpenMs+50&&selectKeyHoldMs(9)==2000&&selectKeyHoldMs(NAN)==650);
        CHECK(selectKeyHoldMs(.35f)>SelectorOpenMs);}
    std::cout<<checks<<" shot checks passed (VR button, GTA's own gunshot paths, waited rounds, magazine snap, slide release, dry fire, bolt action, character keys). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
