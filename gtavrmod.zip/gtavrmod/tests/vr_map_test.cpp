// 0.9.0: minimap rectangle, capture box, wrist / dashboard overlay placement, visibility.
#include "vr_map.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static bool rigid(const Pose& p){return validPose(p);}

int main(){try{
    // --- GTA's minimap: bottom-left, 1/(4*aspect) x 1/5.674, moved in by the safe zone.
    {   auto m=minimapRect(1.0f,16.0f/9);CHECK(near(m.x,0)&&near(m.w,9.0f/64,1e-5f)&&near(m.h,1/5.674f,1e-5f)&&near(m.y+m.h,1,1e-5f));
        auto s=minimapRect(.9f,16.0f/9);CHECK(near(s.x,.05f,1e-5f)&&near(s.y+s.h,.95f,1e-5f));
        auto w=minimapRect(1.0f,21.0f/9);CHECK(w.w<m.w&&near(w.h,m.h));                         // ultrawide: narrower
        auto bad=minimapRect(NAN,0);CHECK(near(bad.w,m.w)&&near(bad.x,0));
        auto c=radarCapture(m,.04f);CHECK(near(c.x,0)&&c.w>m.w&&c.y<m.y-.04f&&near(c.y+c.h,1,1e-5f));       // clamped to the screen
        auto inner=radarCapture(s,.04f);CHECK(inner.x<s.x&&inner.x+inner.w>s.x+s.w&&inner.y+inner.h>s.y+s.h);
        auto strip=radarStrip(s,.04f);CHECK(near(strip.y+strip.h,s.y-s.h*.04f)&&strip.y>inner.y-1e-5f);}
    // --- Pixels
    {   auto b=toPixels({0,.75f,.25f,.25f},1920,1080);CHECK(b.left==0&&b.right==480&&b.top==810&&b.bottom==1080&&b.width()==480&&b.height()==270);
        auto c=toPixels({-.1f,.9f,.3f,.3f},1000,1000);CHECK(c.left==0&&c.right==200&&c.bottom==1000);
        auto e=toPixels({.5f,.5f,0,0},100,100);CHECK(e.width()==0&&e.height()==0);CHECK(toPixels({0,0,1,1},0,0).width()==0);}
    // --- Overlay poses
    {   Pose L=wristOverlayLocal(true,{.035f,-.015f,.10f}),R=wristOverlayLocal(false,{.035f,-.015f,.10f});CHECK(rigid(L)&&rigid(R));
        CHECK(near(L.col(2),{-1,0,0})&&near(R.col(2),{1,0,0}));                                  // faces out of the back of each wrist
        CHECK(near(L.pos(),{-.035f,-.015f,.10f})&&near(R.pos(),{.035f,-.015f,.10f}));
        Pose t=wristOverlayLocal(true,{.035f,0,.1f},30);CHECK(rigid(t)&&near(dot(t.col(2),L.col(2)),std::cos(rad(30)),1e-4f));
        Pose up=tiltX(poseFromAxes({1,0,0},{0,1,0},{0,0,1},{}),30);CHECK(up.col(2).y>.49f&&rigid(up));   // positive tilt turns the face up
        Pose id{};id.m[0][0]=id.m[1][1]=id.m[2][2]=1;CHECK(near(composePoses(id,L).pos(),L.pos())&&near(composePoses(L,id).col(2),L.col(2)));}
    // --- Dashboard: in front of and below the recentred head, facing it.
    {   Pose origin{};origin.m[0][0]=origin.m[1][1]=origin.m[2][2]=1;origin.m[1][3]=1.2f;   // seated eyes 1.2 m, facing -Z
        Pose d=dashboardOverlay(origin,{.15f,-.33f,.48f},35);CHECK(rigid(d));
        CHECK(near(d.pos(),{.15f,1.2f-.33f,-.48f}));Vec3 eye{0,1.2f,0};CHECK(facingAmount(d,eye)>.9f);
        Pose flat=dashboardOverlay(origin,{0,-.33f,.48f},0);CHECK(facingAmount(flat,eye)>.75f&&facingAmount(flat,eye)<facingAmount(dashboardOverlay(origin,{0,-.33f,.48f},35),eye));}
    // --- Wrist visibility: the back of the left wrist turned to the face shows the radar.
    {   // Left controller in front of the chest, pointing right (+X), back of the hand up: controller -Z = +X, -X = up.
        Pose ctrl=poseFromAxes({0,-1,0},{0,0,1},{-1,0,0},{-.05f,1.25f,-.35f});CHECK(rigid(ctrl));
        Pose world=composePoses(ctrl,wristOverlayLocal(true,{.035f,-.015f,.10f}));Vec3 eye{0,1.62f,0};
        CHECK(near(world.col(2),{0,1,0},1e-4f));CHECK(facingAmount(world,eye)>.6f);
        CHECK(world.col(1).z<-.99f);                                                             // image top points away from the body
        Pose palmUp=poseFromAxes({0,1,0},{0,0,-1},{-1,0,0},{-.05f,1.25f,-.35f});CHECK(rigid(palmUp));
        CHECK(facingAmount(composePoses(palmUp,wristOverlayLocal(true,{.035f,-.015f,.10f})),eye)<0);
        Hysteresis h;CHECK(!h.update(.3f,.45f,.25f));CHECK(h.update(.5f,.45f,.25f));CHECK(h.update(.3f,.45f,.25f));CHECK(!h.update(.2f,.45f,.25f));CHECK(!h.update(NAN,.45f,.25f));}
    std::cout<<checks<<" map checks passed (minimap rectangle, capture box, pixels, wrist / dashboard overlays, visibility). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
