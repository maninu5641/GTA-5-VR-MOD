"""Ray-march the mod's hand capsules (same geometry + lighting as the HLSL) into preview images."""
import json, sys, numpy as np
from PIL import Image, ImageDraw, ImageFont
data = json.load(open(sys.argv[1])); out = sys.argv[2]
W = H = 340; fov = np.radians(48)
cam = np.array([0.05, 1.47, 0.06])
ys, xs = np.mgrid[0:H, 0:W]
dx = (xs + .5) / W * 2 - 1; dy = 1 - (ys + .5) / H * 2
t = np.tan(fov / 2)
dirs = np.stack([dx * t, dy * t, -np.ones_like(dx)], -1); dirs /= np.linalg.norm(dirs, axis=-1, keepdims=True)
dirs = dirs.reshape(-1, 3)
light = np.array([.35, .85, .40]); light /= np.linalg.norm(light)
def sdf(p, caps):
    best = np.full(p.shape[0], 1e9); col = np.zeros((p.shape[0], 3))
    for c in caps:
        a, ra, b, rb, color = np.array(c[0:3]), c[3], np.array(c[4:7]), c[7], np.array(c[8:11])
        ba = b - a; pa = p - a
        h = np.clip((pa @ ba) / max(ba @ ba, 1e-9), 0, 1)
        d = np.linalg.norm(pa - h[:, None] * ba, axis=1) - (ra + (rb - ra) * h)
        m = d < best; best = np.where(m, d, best); col[m] = color
    return best, col
tiles = []
for item in data:
    caps = item['capsules']
    pos = np.repeat(cam[None], dirs.shape[0], 0); dist = np.zeros(dirs.shape[0]); hit = np.zeros(dirs.shape[0], bool)
    for _ in range(90):
        live = ~hit & (dist < 2.0)
        if not live.any(): break
        d, _ = sdf(pos[live], caps)
        idx = np.where(live)[0]
        hit[idx[d < 4e-4]] = True
        step = np.maximum(d, 0) * .9
        dist[idx] += step; pos[idx] += dirs[idx] * step[:, None]
    img = np.zeros((dirs.shape[0], 3))
    bg = (0.10 + 0.10 * (dy.reshape(-1) + 1) / 2)[:, None] * np.array([1, 1, 1.15])
    img[:] = bg
    if hit.any():
        p = pos[hit]; e = 5e-4
        n = np.stack([sdf(p + np.array(v) * e, caps)[0] - sdf(p - np.array(v) * e, caps)[0] for v in np.eye(3)], -1)
        n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
        _, color = sdf(p, caps)
        diffuse = np.clip(n @ light, 0, 1); fill = np.clip(n @ np.array([0, -.3, .95]), 0, 1) * .25
        lin = np.clip(color * (.38 + diffuse * .75 + fill)[:, None], 0, 1)
        img[hit] = lin ** (1 / 2.2)
    tile = Image.fromarray((img.reshape(H, W, 3) * 255).astype(np.uint8))
    draw = ImageDraw.Draw(tile)
    try: font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 17); small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 13)
    except Exception: font = small = ImageFont.load_default()
    draw.text((10, 8), item['name'], fill=(240, 240, 240), font=font)
    draw.text((10, 30), 'detectado: ' + item['gesture'], fill=(170, 200, 255), font=small)
    tiles.append(tile)
sheet = Image.new('RGB', (W * 3 + 8, H * 2 + 4), (30, 30, 34))
for i, tile in enumerate(tiles): sheet.paste(tile, ((i % 3) * (W + 4), (i // 3) * (H + 4)))
sheet.save(out); print('saved', out)
