// 0.9.0: GTA4VR-style weapons: cycling, stick flicks, grip press, magazine ammo loss, shoulder ammo,
// pump action, shell loading.
#include "vr_gun.hpp"
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static int idx(std::uint32_t hash){int i=weaponIndex(hash);if(i<0)throw std::runtime_error("weapon missing");return i;}

int main(){try{
    const int pistol=idx(0x1B06D571u),smg=idx(0x2BE6766Bu),rifle=idx(0xBFEFFF6Du),pump=idx(0x1D073A89u),sniper=idx(0x05FC3C11u),
        knife=idx(0x99B507EAu),grenade=idx(0x93E220BDu),extinguisher=idx(0x060EC506u),rpg=idx(0xB1CA77B1u),mg=idx(0x9D07F764u);
    // --- Pump-action list
    {   CHECK(pumpAction(0x1D073A89u)&&pumpAction(0x7846A318u)&&pumpAction(0x555AF99Au)&&!pumpAction(0xE284C527u)&&!pumpAction(0xEF951FBBu)&&!pumpAction(0x1B06D571u));}
    // --- Cycle order: unarmed, melee, pistols, SMGs, rifles, shotguns, MGs, snipers, heavy; grenades / tools skipped.
    {   std::vector<int> owned{sniper,grenade,rifle,extinguisher,knife,pump,pistol,rpg,smg,mg,pistol};
        std::vector<int> seen;int w=-1;for(int i=0;i<12;++i){w=cycleWeapon(owned.data(),int(owned.size()),w,1);seen.push_back(w);}
        std::vector<int> expected{knife,pistol,smg,rifle,pump,mg,sniper,rpg,-1,knife,pistol,smg};CHECK(seen==expected);
        CHECK(cycleWeapon(owned.data(),int(owned.size()),-1,-1)==rpg);CHECK(cycleWeapon(owned.data(),int(owned.size()),knife,-1)==-1);
        CHECK(cycleWeapon(owned.data(),int(owned.size()),grenade,1)==knife);                    // not in the list: from unarmed
        CHECK(cycleWeapon(owned.data(),0,-1,1)==-1&&cycleWeapon(nullptr,0,pistol,1)==-1);           // nothing owned: unarmed
        CHECK(cycleWeapon(owned.data(),int(owned.size()),rifle,0)==rifle);
        CHECK(cycles(weapons[knife])&&!cycles(weapons[grenade])&&!cycles(weapons[extinguisher])&&cycleRank(weapons[pump])<cycleRank(weapons[mg]));}
    // --- Right stick flicks
    {   StickFlick f;CHECK(f.update(0,1)==0);CHECK(f.update(0,0)==0);CHECK(f.update(0,.9f)==1);CHECK(f.update(0,.95f)==0);   // armed only from the centre
        f.update(0,0);CHECK(f.update(.1f,-.9f)==-1);f.update(0,0);CHECK(f.update(.8f,.8f)==0);                                 // diagonal: no
        f.update(0,0);CHECK(f.update(.95f,.1f)==0);CHECK(f.update(NAN,1)==0);
        CHECK(StickFlick::vertical(.2f,.8f)&&!StickFlick::vertical(.8f,.2f)&&!StickFlick::vertical(.1f,.3f));}
    // --- Grip press: full squeeze after a release; held at start is not a press.
    {   GripPress g;CHECK(!g.update(1));CHECK(!g.update(.5f));CHECK(!g.update(.2f));CHECK(!g.update(.7f));CHECK(g.update(.9f));CHECK(!g.update(1));
        g.update(0);CHECK(g.update(1));CHECK(!g.update(NAN));}
    // --- Magazine ammunition is lost when ejected (the chambered round stays).
    {   CHECK(ammoAfterEject(120,30,true)==91);CHECK(ammoAfterEject(120,30,false)==90);CHECK(ammoAfterEject(5,10,true)==0);CHECK(ammoAfterEject(50,0,false)==50);}
    // --- Over-the-shoulder ammunition
    {   Vec3 h{0,1.6f,0};CHECK(atShoulderAmmo(h,0,{.17f,1.52f,.12f})&&atShoulderAmmo(h,0,{-.17f,1.52f,.12f}));CHECK(!atShoulderAmmo(h,0,{0,1.0f,-.4f}));
        CHECK(atShoulderAmmo(h,pi/2,{.12f,1.52f,.17f}));CHECK(!atShoulderAmmo(h,0,{NAN,1,0}));
        CHECK(atShoulderAmmo(h,0,{.17f*.8f,1.6f-.08f*.8f,.12f*.8f},0,.8f));}
    // --- Pump action: shot -> spent; back 6 cm, forward again -> next shell chambered.
    {   PumpAction p;p.reset(true);CHECK(p.chambered()&&!p.needsPump());
        auto e=p.update(true,.30f,7);e=p.update(true,.22f,7);CHECK(!e.back&&p.chambered());          // a live round: pumping does nothing
        p.update(false,0,7);p.fired();CHECK(p.needsPump());
        p.update(true,.30f,6);e=p.update(true,.27f,6);CHECK(!e.back);e=p.update(true,.235f,6);CHECK(e.back&&p.stage()==PumpAction::Stage::Back&&!p.chambered());
        e=p.update(true,.25f,6);CHECK(!e.forward);e=p.update(true,.29f,6);CHECK(e.forward&&p.chambered()&&p.stage()==PumpAction::Stage::Closed);
        p.fired();p.update(true,.30f,0);p.update(true,.20f,0);e=p.update(true,.30f,0);CHECK(e.forward&&!p.chambered());   // empty tube: nothing chambered
        PumpAction q;q.reset(false);q.update(true,.3f,4);q.update(true,.2f,4);e=q.update(false,0,4);CHECK(e.forward&&q.chambered());   // let go after pulling: closes
        PumpAction r;r.reset(false);r.update(true,.3f,4);e=r.update(true,NAN,4);CHECK(!e.back&&!r.chambered());}
    // --- Shells: grab at the pouch, one every 0.35 s at the port while there is room and ammo.
    {   ShellLoader s;auto e=s.update(true,true,false,true,true,.016f);CHECK(!e.grabbed);                // grip already held: not a press
        s.update(false,true,false,true,true,.016f);e=s.update(true,true,false,true,true,.016f);CHECK(e.grabbed&&s.holdingShells());
        int in=0;for(int i=0;i<60;++i){e=s.update(true,false,true,true,true,1.0f/60);in+=e.inserted;}
        CHECK(in==3);                                                                              // 0.12 s, then every 0.35 s: 0.12 / 0.47 / 0.82
        e=s.update(true,false,true,false,true,.016f);CHECK(e.dropped&&!s.holdingShells());          // tube full
        ShellLoader n;n.update(false,true,false,true,false,.016f);CHECK(!n.update(true,true,false,true,false,.016f).grabbed);   // no reserve
        ShellLoader r;r.update(false,true,false,true,true,.016f);r.update(true,true,false,true,true,.016f);CHECK(r.update(false,false,false,true,true,.016f).dropped);}
    // --- Shotgun anchors
    {   WeaponPose p{{0,0,1},{0,1,0},{1,0,0},{0,0,1}};auto a=shotgunAnchors(p,false),b=shotgunAnchors(p,true);
        CHECK(near(a.foreEnd,{0,.32f,.96f})&&near(b.foreEnd,{0,.20f,.96f})&&near(a.port,{0,.09f,.93f}));
        CHECK(onForeEnd(p,{0,.35f,.97f},false,false)&&onForeEnd(p,{0,.55f,1.0f},false,false)&&!onForeEnd(p,{0,.05f,1},false,false));   // along the barrel
        CHECK(!onForeEnd(p,{.2f,.35f,1},false,false)&&onForeEnd(p,{.12f,.35f,1},false,true));                                          // off the axis; wider while holding
        CHECK(!onForeEnd(p,{0,.50f,1},true,false)&&onForeEnd(p,{0,.30f,1},true,false)&&!onForeEnd(p,{NAN,0,0},false,false));
        CHECK(onForeEnd(p,{0,.70f,1.0f},false,false,1.2f)&&!onForeEnd(p,{0,.70f,1.0f},false,false,1.0f));}                              // world scale
    std::cout<<checks<<" gun checks passed (pump list, cycle order, stick flicks, grip press, magazine loss, shoulder ammo, pump action, shells). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
