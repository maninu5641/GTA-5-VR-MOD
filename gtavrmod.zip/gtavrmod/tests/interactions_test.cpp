#include "interactions.hpp"
#include "ini_text.hpp"
#include <iostream>
#include <limits>
#include <stdexcept>
using namespace handvr;
static int checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error(std::string("Failed: ")+#x+" line "+std::to_string(__LINE__));}while(0)
int main(){try{
    // Magazine reload tests moved to weapons_test.cpp (0.5.0).
    ThrowGesture throwing;CHECK(!throwing.update(true,true,true,true,{1,0,0}).released);CHECK(!throwing.held); // held during resume
    throwing.update(false,false,true,true,{});throwing.update(true,false,true,true,{});CHECK(throwing.held);
    CHECK(!throwing.update(false,false,true,true,{}).released);CHECK(!throwing.held); // unprimed release cancels
    throwing.update(true,true,true,true,{});auto t=throwing.update(false,true,true,true,{30,0,0});CHECK(t.released&&length(t.velocity)<=12.0001f);
    CHECK(!throwing.update(false,true,true,true,{30,0,0}).released); // one release, one projectile
    throwing.update(true,true,true,true,{});throwing.update(true,true,false,true,{});CHECK(!throwing.update(false,true,true,true,{3,0,0}).released);
    throwing.update(false,false,true,true,{});throwing.update(true,true,true,false,{});CHECK(!throwing.held);
    HandMotion motion;CHECK(length(motion.update({0,0,0},100))==0);CHECK(std::abs(motion.update({.05f,0,0},150).x-1)<.001f);
    CHECK(length(motion.update({10,0,0},160))==0); // tracking discontinuity does not become a 10m swing
    CHECK(length(motion.update({10,0,0},500))==0); // stale sample resets velocity
    CHECK(length(motion.update({std::numeric_limits<float>::quiet_NaN(),0,0},510))==0);
    // Game locomotion never enters this estimator: only tracking positions do.
    motion.update({0,0,0},1000);CHECK(length(motion.update({0,0,0},1050))==0);
    SwingGate swing;CHECK(!swing.update(2,true,100));swing.update(0,false,110);CHECK(swing.update(2,true,120));CHECK(!swing.update(2,true,700));
    swing.update(0,false,710);CHECK(swing.update(2,true,720));swing.reset();CHECK(!swing.update(2,true,900));
    WheelSteering wheel;CHECK(wheel.update(-1,.001f,true)==0);CHECK(std::abs(wheel.update(-1,-.001f,true))<.01f); // wraps across +/-pi
    wheel.reset();wheel.update(1,0,true);CHECK(std::abs(wheel.update(0,1,true)+1)<.001f);CHECK(wheel.update(0,1,false)==0);
    CHECK(wheel.update(0,0,true)==0);CHECK(wheel.update(std::numeric_limits<float>::infinity(),0,true)==0);
    CHECK(oneHandAllowed(1)&&oneHandAllowed(3));for(int group:{0,2,4,5,6,7})CHECK(!oneHandAllowed(group));
    const std::string original="; Renderer configuration\r\n[VR]\r\nVRAPI = 2 ; preserve this comment\r\nOther=unchanged\r\n";
    auto updated=updateExistingIniKey(original,"VRAPI","3");CHECK(updated=="; Renderer configuration\r\n[VR]\r\nVRAPI = 3 ; preserve this comment\r\nOther=unchanged\r\n");
    CHECK(updateExistingIniKey("VRAPI=2","vrapi","3")=="VRAPI= 3");
    bool threw=false;try{updateExistingIniKey("Other=2\n","VRAPI","3");}catch(...){threw=true;}CHECK(threw);
    threw=false;try{updateExistingIniKey("VRAPI=2\nVRAPI=3\n","VRAPI","3");}catch(...){threw=true;}CHECK(threw);
    // Localized punches (0.4.0): nearest bone decides the region; head hits hurt more and knock down.
    {   Vec3 bones[bodyBoneCount];for(std::size_t k=0;k<bodyBoneCount;++k)bones[k]={0,0,0};
        auto index=[&](int id){for(std::size_t k=0;k<bodyBoneCount;++k)if(bodyBones[k].id==id)return int(k);return -1;};
        bones[index(31086)]={10,10,1.70f};bones[index(39317)]={10,10,1.55f};bones[index(24818)]={10,10,1.35f};bones[index(11816)]={10,10,1.0f};
        bones[index(40269)]={10.2f,10,1.4f};bones[index(28252)]={10.3f,10,1.2f};bones[index(51826)]={10.1f,10,.8f};bones[index(36864)]={10.1f,10,.45f};
        CHECK(bodyBones[nearestBone(bones,bodyBoneCount,{10,9.9f,1.72f})].region==HitRegion::Head);
        CHECK(bodyBones[nearestBone(bones,bodyBoneCount,{10,9.9f,1.3f})].region==HitRegion::Torso);
        CHECK(bodyBones[nearestBone(bones,bodyBoneCount,{10.32f,9.95f,1.18f})].region==HitRegion::Arm);
        CHECK(bodyBones[nearestBone(bones,bodyBoneCount,{10.1f,9.9f,.5f})].region==HitRegion::Leg);
        CHECK(nearestBone(bones,bodyBoneCount,{50,50,50})==-1);
        CHECK(nearestBone(bones,bodyBoneCount,{NAN,0,0})==-1);
        Vec3 none[3]{};CHECK(nearestBone(none,3,{0,0,0})==-1);}                 // bones not found (0,0,0)
    {   auto head=punchOutcome(3,HitRegion::Head,20),torso=punchOutcome(3,HitRegion::Torso,20),arm=punchOutcome(3,HitRegion::Arm,20);
        CHECK(head.damage>torso.damage&&torso.damage>arm.damage);
        CHECK(head.ragdoll&&head.ragdollType==0&&head.ragdollMs>=1400);              // strong head hit knocks down
        CHECK(torso.ragdoll&&torso.ragdollType==3);                                   // same speed to the body: stumble
        CHECK(punchOutcome(4,HitRegion::Torso,20).ragdollType==0);                    // full-power body hit knocks down
        auto soft=punchOutcome(1.3f,HitRegion::Head,20);CHECK(!soft.ragdoll&&soft.impulse==0&&soft.damage>0);
        CHECK(punchOutcome(9,HitRegion::Head,20).damage==punchOutcome(4,HitRegion::Head,20).damage);   // capped power
        CHECK(punchOutcome(4,HitRegion::Head,500).damage==150);
        CHECK(punchOutcome(NAN,HitRegion::Torso,20).damage>=1);
        CHECK(punchOutcome(4,HitRegion::Head,20,0).impulse==0&&punchOutcome(4,HitRegion::Head,20,2).impulse>punchOutcome(4,HitRegion::Head,20,1).impulse);
        CHECK(std::string(regionName(HitRegion::Neck))=="neck");}
    std::cout<<checks<<" interaction checks passed. Game / hardware / installer not exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
