// 0.8.0: Epic / Steam manifest parsing used to find GTA V Legacy automatically.
#include "install_parse.hpp"
#include <iostream>
#include <stdexcept>
using namespace app;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
int main(){try{
    // Epic Games .item manifest (JSON, escaped backslashes).
    std::string epic="{\n\t\"FormatVersion\": 0,\n\t\"DisplayName\": \"Grand Theft Auto V Legacy\",\n\t\"InstallLocation\": \"F:\\\\games for epic\\\\GTAV\\\\GTAV\",\n\t\"LaunchExecutable\": \"PlayGTAV.exe\"\n}";
    auto v=quotedValuesUtf8(epic,"InstallLocation");CHECK(v.size()==1&&v[0]=="F:\\games for epic\\GTAV\\GTAV");
    CHECK(quotedValuesUtf8(epic,"LaunchExecutable").at(0)=="PlayGTAV.exe");CHECK(quotedValuesUtf8(epic,"Missing").empty());
    // Steam libraryfolders.vdf: several libraries, tab separated.
    std::string vdf="\"libraryfolders\"\n{\n\t\"0\"\n\t{\n\t\t\"path\"\t\t\"C:\\\\Program Files (x86)\\\\Steam\"\n\t\t\"label\"\t\t\"\"\n\t}\n\t\"1\"\n\t{\n\t\t\"path\"\t\t\"D:\\\\SteamLibrary\"\n\t\t\"apps\"\n\t\t{\n\t\t\t\"271590\"\t\t\"105000000000\"\n\t\t}\n\t}\n}\n";
    auto paths=quotedValuesUtf8(vdf,"path");CHECK(paths.size()==2&&paths[0]=="C:\\Program Files (x86)\\Steam"&&paths[1]=="D:\\SteamLibrary");
    // "path" as a value (not a key) is skipped; forward slashes; unterminated input does not hang.
    CHECK(quotedValuesUtf8("{\"name\": \"path\", \"path\": \"E:/Games/GTAV\"}","path")==std::vector<std::string>{"E:/Games/GTAV"});
    CHECK(quotedValuesUtf8("\"path\": \"C:\\/x\"","path").at(0)=="C:/x");CHECK(quotedValuesUtf8("\"path\": \"unterminated","path").empty());
    CHECK(quotedValuesUtf8("","path").empty());CHECK(quotedValuesUtf8("\"path\" x \"y\"","path").empty());
    std::cout<<checks<<" install parsing checks passed (Epic manifest, Steam library folders). Windows installer UI NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
