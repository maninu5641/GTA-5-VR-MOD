// 0.13.0: hand on the gun (frames, controller-relative share), finger weights, scripted-animation data,
// Pavlov holster axes.
#include "vr_grip.hpp"
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static Rot axisAngle(Vec3 axis,float degrees){axis=unit(axis);float a=rad(degrees),c=std::cos(a),s=std::sin(a);
    auto r=[&](Vec3 v){return v*c+cross(axis,v)*s+axis*dot(axis,v)*(1-c);};return {r({1,0,0}),r({0,1,0}),r({0,0,1})};}
static bool nearRot(const Rot& a,const Rot& b,float degrees){return rotAngleDegrees(a,b)<=degrees;}
static bool nearFrame(const Frame3& a,const Frame3& b,float e=1e-4f,float deg=.05f){return near(a.pos,b.pos,e)&&nearRot(a.rot,b.rot,deg);}
static Pose poseOf(const Rot& r,Vec3 p){Pose q{};q.m[0][0]=r.x.x;q.m[1][0]=r.x.y;q.m[2][0]=r.x.z;q.m[0][1]=r.y.x;q.m[1][1]=r.y.y;q.m[2][1]=r.y.z;
    q.m[0][2]=r.z.x;q.m[1][2]=r.z.y;q.m[2][2]=r.z.z;q.m[0][3]=p.x;q.m[1][3]=p.y;q.m[2][3]=p.z;return q;}

int main(){try{
    // --- Frames
    {   Frame3 a{{1,2,3},axisAngle({.2f,1,.3f},50)},b{{-.3f,.4f,.1f},axisAngle({1,0,.5f},-70)};
        Frame3 ab=compose(a,b);CHECK(nearFrame(relativeTo(a,ab),b));CHECK(nearFrame(compose(a,inverse(a)),Frame3{}));
        CHECK(nearFrame(compose(inverse(b),compose(inverse(a),ab)),Frame3{},1e-4f,.1f));CHECK(finiteFrame(ab)&&!finiteFrame(Frame3{{NAN,0,0},{}}));}
    // --- The motion add-on and the renderer map the controller the same way (mapHand's grip).
    {   Pose head=poseOf(axisAngle({0,1,0},25),{.1f,1.6f,.2f}),hand=poseOf(axisAngle({1,.3f,-.2f},40),{.3f,1.2f,-.25f});
        Basis cam=cameraBasis({0,0,123});Vec3 cp{100,200,30};float s=1.16f;
        Frame3 c=controllerWorld(hand,head,cp,cam,s);WeaponPose m=mapHand(head,hand,cp,cam,s,0);
        CHECK(near(c.pos,m.grip,1e-3f)&&orthonormalRot(c.rot,1e-3f)&&near(c.rot.x,m.right,1e-3f));
        // The mod: the hand bone that puts the gun where GTA holds it; the renderer rebuilds it next update from
        // its own (moved) controller pose: the gun stays in the hand.
        Frame3 gun{m.grip+m.forward*.05f,{m.forward,m.right*-1.0f,m.up}},inHand{{.09f,.03f,-.02f},axisAngle({1,0,0},-80)};
        Frame3 handBone=compose(gun,inverse(inHand));CHECK(nearFrame(compose(handBone,inHand),gun,1e-4f,.1f));
        HandShare share;share.flags=RightTarget;packRight(share,relativeTo(c,handBone));Frame3 rel{};CHECK(unpackRight(share,rel));
        Pose moved=poseOf(mul(axisAngle({0,0,1},30),axisAngle({1,.3f,-.2f},40)),{.35f,1.25f,-.3f});
        Frame3 c2=controllerWorld(moved,head,cp,cam,s);Frame3 rebuilt=compose(c2,rel);
        Frame3 gun2=compose(c2,relativeTo(c,gun));CHECK(nearFrame(compose(rebuilt,inHand),gun2,1e-3f,.2f));
        HandShare none;CHECK(!unpackRight(none,rel));share.rightPos[0]=2;CHECK(!unpackRight(share,rel));
        CHECK(freshShare(HandShare{0,0,1000},1100)&&!freshShare(HandShare{0,0,1000},1300)&&!freshShare(HandShare{0,0,0},10)&&!freshShare(HandShare{0,0,1000},900));}
    // --- Quaternion round trip
    {   Rot r=axisAngle({.4f,-1,.2f},137);Quaternion q=quaternion(r.x,r.y,r.z);CHECK(nearRot(rotFromQuaternion(q.x,q.y,q.z,q.w),r,.05f));
        CHECK(nearRot(rotFromQuaternion(0,0,0,0),Rot{},.01f));}
    // --- Averaging GTA's grip measurement
    {   FrameAverage avg;Frame3 f{{.1f,.02f,0},axisAngle({0,0,1},30)};for(unsigned i=0;i<FrameAverage::Needed;++i)CHECK(avg.add(f));CHECK(avg.ready()&&nearFrame(avg.mean(),f,1e-5f,.05f));
        FrameAverage jump;jump.add(f);jump.add(f);jump.add(Frame3{{.3f,0,0},f.rot});CHECK(jump.count()==1&&!jump.ready());   // inconsistent: starts over
        CHECK(!jump.add(Frame3{{NAN,0,0},{}})&&jump.count()==1);}
    // --- Grip classes
    {   CHECK(gripClassFor(1,false,false,false,false,false)==GripPistol&&gripClassFor(2,false,false,false,false,false)==GripSmg);
        CHECK(gripClassFor(3,false,false,false,false,false)==GripRifle&&gripClassFor(5,false,false,false,false,false)==GripRifle&&gripClassFor(6,false,false,false,false,false)==GripSniper);
        CHECK(gripClassFor(0,true,false,false,false,false)==GripMelee1h&&gripClassFor(0,true,false,false,true,false)==GripMelee2h&&gripClassFor(7,false,true,false,false,false)==GripThrown);
        CHECK(gripClassFor(0,true,false,false,false,true)==GripNone&&gripClassFor(7,false,false,true,false,false)==GripNone);}
    // --- Finger weights: the grip value closes an empty hand; a held item takes its grip pose.
    {   auto w=fingerWeights(GripNone,0);CHECK(near(w.open,1)&&near(w.fist,0)&&near(w.grip,0));
        w=fingerWeights(GripNone,.25f);CHECK(near(w.open,.75f)&&near(w.fist,.25f));w=fingerWeights(GripNone,3);CHECK(near(w.fist,1));
        w=fingerWeights(GripNone,NAN);CHECK(near(w.open,1));w=fingerWeights(GripPistol,0);CHECK(near(w.grip,1)&&near(w.open,0));
        w=fingerWeights(GripFist,0);CHECK(near(w.fist,1)&&near(w.grip,0));
        SqueezeFilter f;CHECK(near(f.update(.5f,0),.5f));float v=f.update(1,.03f);CHECK(v>.7f&&v<.8f);for(int i=0;i<20;++i)f.update(1,.03f);CHECK(f.value()>.99f);
        v=f.update(0,.03f);CHECK(v>.65f&&v<.75f);CHECK(near(f.update(NAN,.25f),0,1e-6f));}
    // --- Clips: every pose has candidates, GTA's own grip clips first.
    {   ClipRef c[4];for(int g=0;g<=8;++g)CHECK(clipCandidates(GripClass(g),c)>=1);
        CHECK(clipCandidates(GripPistol,c)==2&&!std::strcmp(c[0].dict,"weapons@pistol@")&&!std::strcmp(c[0].clip,"grip"));
        CHECK(clipCandidates(GripNone,c)>=1&&!std::strcmp(c[0].dict,"anim@heists@box_carry@"));CHECK(std::string(gripName(GripRifle))=="rifle grip");}
    // --- TASK_SCRIPTED_ANIMATION data: 22 slots, string pointers (GTA 1.0.3889 scripts: .f_1 dict, .f_2 clip,
    //     .f_5 / .f_10 / .f_15 weights, .f_16 filter, .f_17 / .f_18 blend, .f_19 time -1, .f_20 flags, .f_21 IK flags).
    {   ClipRef clips[3]={{"anim@heists@box_carry@","idle"},{"weapons@melee_1h","grip_idle"},{"weapons@pistol@","grip"}};
        auto d=armBlend(clips,FingerWeights{.25f,.75f,0},std::int32_t(joaat("BONEMASK_ARMONLY_R")),FingerAnimFlags);
        const unsigned char* raw=reinterpret_cast<const unsigned char*>(&d);
        auto slotPtr=[&](int slot){const char* p;std::memcpy(&p,raw+slot*8,sizeof p);return p;};
        auto slotF=[&](int slot){float f;std::memcpy(&f,raw+slot*8,4);return f;};
        auto slotI=[&](int slot){std::int32_t v;std::memcpy(&v,raw+slot*8,4);return v;};
        CHECK(sizeof(ScriptedAnimData)==22*8&&slotI(0)==2);
        CHECK(!std::strcmp(slotPtr(1),"anim@heists@box_carry@")&&!std::strcmp(slotPtr(2),"idle")&&!std::strcmp(slotPtr(11),"weapons@pistol@")&&!std::strcmp(slotPtr(12),"grip"));
        CHECK(near(slotF(3),0)&&near(slotF(4),0)&&near(slotF(5),.25f)&&near(slotF(10),.75f)&&near(slotF(15),0));
        CHECK(slotI(16)==std::int32_t(joaat("BONEMASK_ARMONLY_R"))&&near(slotF(17),.125f)&&near(slotF(18),.125f)&&slotI(19)==-1&&slotI(20)==57&&slotI(21)==0);
        ScriptedAnimData empty;CHECK(empty.type==0&&empty.clip[0].dict&&empty.clip[0].dict[0]==0&&near(empty.clip[2].rate,1)&&near(empty.clip[1].weight,1));
        // GTA's hashes of the arm masks (as GTA's own code names them).
        CHECK(joaat("BONEMASK_ARMONLY_R")==0xE0D61CDCu&&joaat("BONEMASK_ARMONLY_L")==0x67B52A94u);
        CHECK(sameClip(clips[0],ClipRef{"anim@heists@box_carry@","idle"})&&!sameClip(clips[0],clips[1]));}
    // --- Finger check: open, then fist; a hand whose fingers do not move is reported.
    {   FingerCheck c;CHECK(!c.running());c.start();CHECK(c.running()&&!c.wantFist());
        float curl[2];bool done=false;int frames=0;
        while(!done&&frames<200){curl[0]=c.wantFist()?.06f:.05f;curl[1]=c.wantFist()?.40f:.10f;done=c.update(1/30.0f,curl);++frames;}   // left: no change
        CHECK(done&&c.stage()==FingerCheck::Stage::Done&&frames<40);
        CHECK(c.measured(0)&&c.measured(1)&&!c.closes(0)&&c.closes(1)&&near(c.openCurl(1),.10f,1e-4f)&&near(c.fistCurl(1),.40f,1e-4f));
        FingerCheck u;u.start();float none[2]={NAN,NAN};while(u.running())u.update(.05f,none);CHECK(!u.measured(0)&&u.closes(0));
        CHECK(std::abs(fingerCurl({0,0,0},{.08f,0,0},{.12f,0,0},{.15f,0,0}))<1e-4f);
        CHECK(fingerCurl({0,0,0},{.08f,0,0},{.10f,-.03f,0},{.08f,-.05f,0})>.3f&&std::isnan(fingerCurl({0,0,0},{0,0,0},{0,0,0},{0,0,0})));
        ClipRef f[4];CHECK(fistCandidates(0,f)>=2&&!std::strcmp(f[0].dict,"weapons@melee_2h")&&fistCandidates(1,f)>=2&&!std::strcmp(f[0].dict,"weapons@melee_1h"));}
    // --- 0.14.0: single-clip data and phases
    {   auto d=armSingle(ClipRef{"nm@hands","fist"},.5f,7,FingerAnimFlags);const unsigned char* raw=reinterpret_cast<const unsigned char*>(&d);
        const char* dict;std::memcpy(&dict,raw+8,sizeof dict);float phase,rate,weight;std::memcpy(&phase,raw+24,4);std::memcpy(&rate,raw+32,4);std::memcpy(&weight,raw+40,4);
        CHECK(d.type==1&&!std::strcmp(dict,"nm@hands")&&near(phase,.5f)&&near(rate,0)&&near(weight,1));
        ClipRef c3[3]={{"a","b"},{"c","d"},{"e","f"}};const float ph[3]={0,2,NAN};auto b=armBlend(c3,ph,FingerWeights{1,0,0},0,57);
        CHECK(near(b.clip[1].phase,1)&&near(b.clip[2].phase,0)&&near(b.clip[0].weight,1));}
    // --- 0.14.0: the hand check
    {   SurveyPose poses[MaxSurveyPoses];int n=surveyPoses(poses);
        CHECK(n==17&&poses[15].filter==1&&poses[16].filter==2&&poses[14].filter==0&&!std::strcmp(poses[0].clip.dict,"anim@heists@box_carry@")&&!std::strcmp(poses[1].clip.clip,"natural")&&poses[3].role==PoseRole::Fist&&poses[13].role==PoseRole::ThumbsUp);
        // Synthetic hands: what each pose does to (thumb, index, middle, ring); the left hand never changes.
        auto curlsFor=[&](int pose,int hand){FingerCurls c;
            if(hand==0){c.f[0]=.1f;c.f[1]=c.f[2]=c.f[3]=.1f;return c;}
            switch(pose){
                case 0:c.f[0]=.06f;c.f[1]=c.f[2]=c.f[3]=.10f;break;            // box carry (open)
                case 2:c.f[0]=.02f;c.f[1]=c.f[2]=c.f[3]=.04f;break;            // flat: the most open, but later in the list
                case 3:c.f[0]=.30f;c.f[1]=c.f[2]=c.f[3]=.50f;break;            // fist
                case 6:c.f[0]=.20f;c.f[1]=c.f[2]=c.f[3]=.32f;break;            // grab
                case 7:c.f[0]=.05f;c.f[1]=c.f[2]=c.f[3]=.06f;break;            // pistol grip: does nothing
                case 9:c.f[0]=.10f;c.f[1]=c.f[2]=c.f[3]=.20f;break;            // rifle grip
                case 12:c.f[0]=.25f;c.f[1]=.45f;c.f[2]=.05f;c.f[3]=.45f;break;  // middle finger
                case 13:c.f[0]=.03f;c.f[1]=c.f[2]=c.f[3]=.45f;break;           // thumbs up
                case 14:c.f[0]=.20f;c.f[1]=.40f;c.f[2]=c.f[3]=.40f;break;      // "point" that does not point
                case 15:c.f[0]=.10f;c.f[1]=c.f[2]=c.f[3]=.12f;break;           // grip filters: hardly
                case 16:c.f[0]=.30f;c.f[1]=c.f[2]=c.f[3]=.50f;break;           // no filter: closes
                default:c.f[0]=.06f;c.f[1]=c.f[2]=c.f[3]=.10f;break;
            }
            return c;};
        FingerSurvey s;s.start(n);CHECK(s.running()&&s.current()==0);int steps=0,last=0;
        while(s.running()&&steps<2000){FingerCurls c[2]={curlsFor(s.current(),0),curlsFor(s.current(),1)};last=s.update(1/30.0f,c);++steps;}
        CHECK(last==2&&!s.running()&&steps<=n*13+2);   // the filter checks do not count as gestures or grips
        CHECK(near(s.result(3,1).closed(),.5f,1e-4f)&&near(s.result(12,1).f[2],.05f,1e-4f)&&!s.result(20,1).valid());
        HandChoice right=chooseHand(poses,n,s,1),left=chooseHand(poses,n,s,0);
        CHECK(right.open==0&&right.fist==3&&right.grab==6&&right.grip[GripRifle]==9&&right.middle==12&&right.thumbs==13&&right.point<0&&right.anyChange);
        // 0.15.8: a gun whose own grip clip does nothing takes the rifle's (not the claw); grenades still the claw.
        CHECK(right.grip[GripPistol]==9&&right.borrowed[GripPistol]==GripRifle&&right.grip[GripSmg]==9&&right.grip[GripSniper]==9&&right.borrowed[GripRifle]<0);
        CHECK(right.grip[GripThrown]==6&&right.borrowed[GripThrown]<0&&right.grip[GripMelee1h]==6);
        CHECK(left.open>=0&&left.fist<0&&left.grab<0&&!left.anyChange&&left.grip[GripRifle]<0);
        CHECK(near(filterGain(poses,n,s,1,2,right.open),.40f,1e-4f)&&near(filterGain(poses,n,s,1,1,right.open),.02f,1e-4f)&&std::isnan(filterGain(poses,n,s,1,1,-1)));
        CHECK(specialPose(right,GripPistol,0)==9&&specialPose(right,GripFist,0)==6&&specialPose(right,GripNone,3)==12&&specialPose(right,GripNone,2)<0&&specialPose(right,GripRifle,3)==9);
        // 0.15.8: when the pistol's own clip works: kept (Auto), or the rifle's (PistolGrip=Rifle); no rifle clip: the SMG's.
        auto run=[&](auto curls){FingerSurvey v;v.start(n);int k=0;while(v.running()&&k<2000){FingerCurls c[2]={curls(v.current(),0),curls(v.current(),1)};v.update(1/30.0f,c);++k;}return v;};
        auto pistolWorks=[&](int pose,int hand){FingerCurls c=curlsFor(pose,hand);if(hand==1&&pose==7){c.f[0]=.2f;c.f[1]=.2f;c.f[2]=c.f[3]=.35f;}return c;};
        FingerSurvey ps=run(pistolWorks);HandChoice a=chooseHand(poses,n,ps,1),b=chooseHand(poses,n,ps,1,PistolGrip::Rifle);
        CHECK(a.grip[GripPistol]==7&&a.borrowed[GripPistol]<0&&a.grip[GripSmg]==9&&a.borrowed[GripSmg]==GripRifle);
        CHECK(b.grip[GripPistol]==9&&b.borrowed[GripPistol]==GripRifle&&b.grip[GripSmg]==9);
        auto smgOnly=[&](int pose,int hand){FingerCurls c=curlsFor(pose,hand);if(hand==1&&pose==9){c.f[0]=.06f;c.f[1]=c.f[2]=c.f[3]=.10f;}
            if(hand==1&&pose==8){c.f[0]=.1f;c.f[1]=c.f[2]=c.f[3]=.25f;}return c;};
        FingerSurvey ss=run(smgOnly);HandChoice c=chooseHand(poses,n,ss,1,PistolGrip::Rifle);
        CHECK(c.grip[GripSmg]==8&&c.grip[GripRifle]==8&&c.borrowed[GripRifle]==GripSmg&&c.grip[GripPistol]==8&&c.borrowed[GripPistol]==GripSmg);
        auto noGun=[&](int pose,int hand){FingerCurls c=curlsFor(pose,hand);if(hand==1&&pose==9){c.f[0]=.06f;c.f[1]=c.f[2]=c.f[3]=.10f;}return c;};
        FingerSurvey ns=run(noGun);HandChoice d=chooseHand(poses,n,ns,1);
        CHECK(d.grip[GripPistol]==6&&d.grip[GripRifle]==6&&d.borrowed[GripPistol]<0&&d.borrowed[GripRifle]<0);   // no gun clip at all: the claw
        FingerSurvey skip;skip.start(2);skip.skip();CHECK(skip.current()==1);skip.skip();CHECK(!skip.running());
        CHECK(near(chainBend({0,0,0},{.03f,0,0},{.06f,0,0}),0)&&chainBend({0,0,0},{.03f,0,0},{.03f,.03f,0})>.25f);}
    // --- 0.14.0: gestures settle before the hand changes
    {   GestureHold g;CHECK(g.update(1,.05f)==0&&g.update(1,.05f)==0&&g.update(1,.06f)==1);
        CHECK(g.update(3,.05f)==1&&g.update(1,.05f)==1&&g.update(3,.10f)==1&&g.update(3,.10f)==3);}
    // --- Holster axes: proper rotations; pistol barrel down with the grip backwards; long guns down across the back.
    {   Vec3 r{1,0,0},f{0,1,0},u{0,0,1};
        for(int h=0;h<5;++h){Rot a=holsterAxes(h,r,f,u);CHECK(orthonormalRot(a,1e-4f)&&near(cross(a.x,a.y),a.z,1e-4f));}
        Rot hip=holsterAxes(0,r,f,u);CHECK(near(hip.x,{0,0,-1})&&near(hip.z,{0,1,0}));   // grip (-z of the gun) points backwards
        Rot back=holsterAxes(3,r,f,u);CHECK(back.x.z<-.7f&&back.x.x<-.5f&&near(back.z,{0,-1,0},1e-4f));
        Rot left=holsterAxes(4,r,f,u);CHECK(left.x.x>.5f);CHECK(nearRot(holsterAxes(9,r,f,u),Rot{},.01f));}
    // --- 0.15.7: the weapon in the character's hand (attached to the prop bone).
    {   // The object's axes from a weapon pose and back, for any ModelYawDegrees.
        for(float yaw:{0.0f,90.0f,-90.0f,180.0f,37.5f})for(int k=0;k<12;++k){
            Rot r=axisAngle({std::sin(k*.7f),std::cos(k*1.3f),.4f+k*.1f},k*29.0f-150);WeaponPose p{{k*.1f,2-k*.05f,1+k*.02f},r.x,r.y*-1.0f,r.z};
            Frame3 o=objectFromPose(p,yaw);CHECK(orthonormalRot(o.rot,1e-4f)&&near(cross(o.rot.x,o.rot.y),o.rot.z,1e-4f));
            WeaponPose b=poseFromObject(o,yaw);CHECK(near(b.grip,p.grip)&&near(b.forward,p.forward,1e-4f)&&near(b.right,p.right,1e-4f)&&near(b.up,p.up,1e-4f));}
        // positionObject / shareRight's frame: x = barrel (yaw 0), y = the gun's left, z = its top.
        WeaponPose p{{0,0,1},{0,1,0},{1,0,0},{0,0,1}};Frame3 o=objectFromPose(p,0);CHECK(near(o.rot.x,{0,1,0})&&near(o.rot.y,{-1,0,0})&&near(o.rot.z,{0,0,1}));
        // The chain: the hand bone sent to G * T^-1 holds the attached weapon (hand * T) exactly at G.
        Frame3 T{{.09f,.01f,-.03f},axisAngle({.3f,1,.2f},-75)};   // the prop bone in the hand bone's frame
        WeaponPose wanted{{.4f,1.1f,1.2f},unit(Vec3{.2f,1,-.1f}),{},{}};wanted.right=unit(cross(wanted.forward,Vec3{0,0,1}));wanted.up=cross(wanted.right,wanted.forward);
        Frame3 G=objectFromPose(wanted,0),H=compose(G,inverse(T));
        WeaponPose seen=poseFromObject(compose(H,T),0);HoldMiss m=holdMiss(seen,wanted);CHECK(m.metres<1e-4f&&m.degrees<.05f);
        // The arm IK misses: the hand 4 cm short and turned 12 deg at the wrist -> the weapon in it shows that.
        Frame3 Hm{H.pos+wanted.forward*-.04f,mul(axisAngle(wanted.up,12),H.rot)};
        m=holdMiss(poseFromObject(compose(Hm,T),0),wanted);CHECK(m.metres>.03f&&m.metres<.08f&&near(m.degrees,12,.6f));
        CHECK(std::isnan(holdMiss(WeaponPose{{NAN,0,0},{0,1,0},{},{}},wanted).metres));
        // HoldWatch: not judged while it settles; small misses never give up; a big one for 1.5 s does; a spike does not.
        HoldWatch w;w.reset(1000);HoldMiss big{.5f,80},small{.05f,8},spin{.03f,90};
        for(std::uint64_t t=1000;t<2200;t+=33)CHECK(!w.update(big,true,t));
        w.reset(5000);bool gave=false;for(std::uint64_t t=5000;t<20000;t+=33)gave|=w.update(small,true,t);CHECK(!gave&&w.metres()<.06f);
        std::uint64_t at=0;for(std::uint64_t t=20000;t<30000&&!at;t+=33)if(w.update(big,true,t))at=t;CHECK(at>=21500&&at<=21800);
        w.reset(40000);gave=false;for(std::uint64_t t=40000;t<50000;t+=33)gave|=w.update(spin,false,t);CHECK(!gave);   // a grenade: only its place counts
        w.reset(60000);for(std::uint64_t t=60000;t<62000;t+=33)w.update(small,true,t);
        gave=false;for(int i=0;i<3;++i)gave|=w.update(big,true,62000+i*33);for(std::uint64_t t=62100;t<70000;t+=33)gave|=w.update(small,true,t);CHECK(!gave);
        CHECK(!w.update(HoldMiss{},true,80000));}
    // --- 0.15.8: the gun in the hand the way GTA holds it - GTA's rotation order 2 and the check of the attachment.
    {   CHECK(near(eulerYXZ(Rot{}),{0,0,0},1e-4f));
        for(int k=0;k<60;++k){Vec3 e{-85.0f+k*2.9f,std::fmod(k*37.0f,340.0f)-170,std::fmod(k*71.0f,350.0f)-175};
            Rot r=rotYXZ(e);CHECK(orthonormalRot(r,1e-4f));Vec3 back=eulerYXZ(r);CHECK(near(back,e,.02f));CHECK(nearRot(rotYXZ(back),r,.05f));}
        for(int k=0;k<40;++k){Rot r=axisAngle({std::sin(k*.9f),std::cos(k*.4f),.3f-k*.05f},k*17.0f-300);CHECK(nearRot(rotYXZ(eulerYXZ(r)),r,.05f));}
        // Straight up / down (gimbal): still the same rotation.
        for(float p:{90.0f,-90.0f})for(float y:{0.0f,40.0f,-120.0f}){Rot r=rotYXZ({p,0,y});CHECK(nearRot(rotYXZ(eulerYXZ(r)),r,.05f));
            Rot q=rotYXZ({p,25,y});CHECK(nearRot(rotYXZ(eulerYXZ(q)),q,.05f));}
        // The camera's convention: pitch turns the forward axis up, yaw to the left (+z), roll the right axis down.
        CHECK(near(rotYXZ({90,0,0}).y,{0,0,1},1e-5f)&&near(rotYXZ({0,0,90}).y,{-1,0,0},1e-5f)&&rotYXZ({0,30,0}).x.z<-.4f);
        // The attachment checked against GTA's grip: 8 updates after 0.5 s decide, once.
        GripMatch m;m.reset(1000);for(std::uint64_t t=1000;t<1500;t+=16)CHECK(m.update(.5f,90,t)==0);   // settling: not judged
        int r=0;std::uint64_t t=1500;for(int i=0;i<7;++i)CHECK(m.update(.01f,3,t+=16)==0);CHECK(m.update(.02f,11,t+=16)==1);
        for(int i=0;i<20;++i)CHECK(m.update(.5f,90,t+=16)==0);                                             // decided: once
        m.reset(5000);t=5600;for(int i=0;i<7;++i){CHECK(m.update(.10f,3,t+=16)==0);CHECK(m.update(.01f,3,t+=16)==0);}   // 7 out (place), 7 in
        r=m.update(.01f,40,t+=16);CHECK(r==-1);   // the 8th out (turned 40 deg): it does not match
        m.reset(9000);CHECK(m.update(NAN,0,9600)==0&&m.update(.01f,NAN,9601)==0);}
    std::cout<<checks<<" grip checks passed (frames, controller-relative hand target, grip average, grip classes, finger weights, scripted-animation data, finger check, hand check and gestures, holster axes, the weapon held in the hand, GTA's rotation order, borrowed gun grips). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
