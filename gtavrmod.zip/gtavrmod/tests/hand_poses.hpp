#pragma once
// Synthetic SteamVR-style hand skeletons for tests and preview images.
// Model space of a RIGHT hand: wrist at the origin, fingers along -Z, palm
// facing -Y, thumb on the -X side. Left hands mirror X. Real SteamVR data has
// the same bone list; only joint positions are used by the mod.
#include "hands.hpp"

namespace handvr::test {
struct Curls { float thumb,index,middle,ring,pinky; };
inline Vec3 bendDirection(float degrees){float a=rad(degrees);return {0,-std::sin(a),-std::cos(a)};}
inline HandSkeleton syntheticHand(Curls c,bool left=false,Pose root=Pose{}){
    HandSkeleton h;h.valid=true;h.trackingLevel=2;
    if(!validPose(root)){root=Pose{};root.m[0][0]=root.m[1][1]=root.m[2][2]=1;}
    h.root=root;
    auto& m=h.model;m[BoneRoot]={0,0,.03f};m[BoneWrist]={0,0,0};
    const Vec3 base[5]={{},{-.012f,0,-.02f},{0,0,-.02f},{.012f,0,-.02f},{.024f,0,-.018f}};
    const Vec3 knuckle[5]={{},{-.030f,0,-.088f},{-.008f,0,-.092f},{.013f,0,-.088f},{.031f,0,-.078f}};
    const float lengths[5][3]={{},{.043f,.025f,.022f},{.047f,.029f,.023f},{.044f,.028f,.022f},{.034f,.020f,.019f}};
    const float curls[5]={c.thumb,c.index,c.middle,c.ring,c.pinky};
    for(unsigned f=1;f<=4;++f){unsigned b=fingerBase(f);m[b]=base[f];m[b+1]=knuckle[f];
        float angle=0;const float joint[3]={85,100,70};Vec3 p=knuckle[f];
        // knuckle (b+1) -> PIP (b+2) -> DIP (b+3) -> tip (b+4)
        for(int s=0;s<3;++s){angle+=curls[f]*joint[s];p=p+bendDirection(angle)*lengths[f][s];m[b+2+s]=p;}
    }
    // Thumb: from extended (forward-outward) towards tucked across the palm.
    Vec3 extended=unit({-.55f,-.08f,-.83f}),tucked=unit({.80f,-.50f,-.33f});
    m[BoneThumb0]={-.020f,-.012f,-.022f};m[BoneThumb1]={-.040f,-.020f,-.045f};
    const float thumbLengths[2]={.035f,.030f};const float share[2]={.8f,1.0f};Vec3 p=m[BoneThumb1];
    for(int s=0;s<2;++s){float t=c.thumb*share[s];p=p+unit(extended*(1-t)+tucked*t)*thumbLengths[s];m[BoneThumb2+s]=p;}
    for(int i=0;i<5;++i)h.curl[i]=curls[i];
    if(left)for(auto& v:m)v.x=-v.x;
    return h;
}
// The five gestures from the user's photos.
inline Curls openHand(){return {0,0,0,0,0};}
inline Curls thumbsUp(){return {0,1,1,1,1};}
inline Curls fist(){return {1,1,1,1,1};}
inline Curls threeFingers(){return {1,0,0,0,1};}     // thumb holds the pinky
inline Curls middleFinger(){return {1,1,0,1,1};}
// What Oculus Touch can express: one grip value for middle/ring/pinky.
inline Curls touchPose(float thumb,float trigger,float grip){return {thumb,trigger,grip,grip,grip};}
}
