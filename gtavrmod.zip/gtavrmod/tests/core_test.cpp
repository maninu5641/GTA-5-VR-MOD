#include "core.hpp"
#include "protocol.hpp"
#include "weapons.hpp"
#include <iostream>
#include <limits>
#include <set>
#include <stdexcept>
using namespace handvr;
static int checks=0;
#define CHECK(x) do { ++checks;if(!(x)) throw std::runtime_error(std::string("Failed: ")+ #x+" at line "+std::to_string(__LINE__)); } while(0)
static bool near(float a,float b,float tolerance=0.0001f) { return std::abs(a-b)<tolerance; }
static bool near(Vec3 a,Vec3 b) { return near(a.x,b.x)&&near(a.y,b.y)&&near(a.z,b.z); }
static Pose identity(Vec3 pos={}) { Pose p;p.m[0][0]=p.m[1][1]=p.m[2][2]=1;p.m[0][3]=pos.x;p.m[1][3]=pos.y;p.m[2][3]=pos.z;return p; }
static Vec3 worldToTracking(Vec3 v) { return {v.x,v.z,-v.y}; }
static Pose headForCamera(Vec3 angles,Vec3 position) {
    auto b=cameraBasis(angles);Pose p=identity(position);
    auto x=worldToTracking(b.right),y=worldToTracking(b.up),z=worldToTracking(-b.forward);
    for(int c=0;c<3;++c) { auto v=c==0?x:c==1?y:z;p.m[0][c]=v.x;p.m[1][c]=v.y;p.m[2][c]=v.z; }
    return p;
}
static Vec3 rotate(Quaternion q,Vec3 v) { Vec3 u{q.x,q.y,q.z};return v+cross(u,v)*(2*q.w)+cross(u,cross(u,v))*2; }
int main() {
    try {
        CHECK(joaat("WEAPON_PISTOL")==0x1B06D571u);CHECK(joaat("WEAPON_UNARMED")==0xA2719263u);
        CHECK(argument(-1)==0xFFFFFFFFull);CHECK(argument(1.0f)==0x3F800000ull);CHECK(argument(false)==0);
        int sample=0;CHECK(argument(&sample)==reinterpret_cast<std::uintptr_t>(&sample));
        for(int i=0;i<8;++i) { float a=i*2*pi/8;CHECK(wheelSector(std::sin(a),std::cos(a),8)==i); }
        CHECK(wheelSector(0,0,8)==-1);CHECK(wheelSector(0,1,0)==-1);
        CHECK(wheelSector(std::numeric_limits<float>::quiet_NaN(),0,8)==-1);
        Wheel wheel;CHECK(wheel.update(true,1,0,8)==-1&&wheel.open&&wheel.hover==2);
        CHECK(wheel.update(false,1,0,8)==2&&!wheel.open);CHECK(wheel.update(false,1,0,8)==-1);
        wheel.update(true,1,0,8);CHECK(wheel.update(false,0,0,8)==-1);
        wheel.update(true,1,0,8);wheel.cancel();CHECK(wheel.update(false,1,0,8)==-1);
        FireGate trigger;CHECK(!trigger.update(1,true,false,100,200));
        CHECK(!trigger.update(0,true,false,101,200));CHECK(trigger.update(1,true,false,102,200));
        CHECK(!trigger.update(1,true,false,400,200));CHECK(!trigger.update(0,true,false,401,200));CHECK(trigger.update(1,true,false,402,200));
        CHECK(!trigger.update(1,false,false,500,200));CHECK(!trigger.update(1,true,false,800,200));
        trigger.update(0,true,true,801,100);CHECK(trigger.update(1,true,true,802,100));CHECK(!trigger.update(1,true,true,901,100));CHECK(trigger.update(1,true,true,902,100));
        // A delayed game frame produces at most one shot, never an accumulated burst.
        CHECK(trigger.update(1,true,true,5000,100));CHECK(!trigger.update(1,true,true,5000,100));
        SnapTurn turn;CHECK(turn.update(.9f,false,30)==-30);CHECK(turn.update(.9f,false,30)==0);
        turn.update(0,false,30);CHECK(turn.update(-.9f,false,30)==30);turn.update(0,true,30);CHECK(turn.update(.9f,false,30)==0);
        CHECK(near(deadzone(.1f),0));CHECK(near(deadzone(1),1));CHECK(near(deadzone(-1),-1));CHECK(near(deadzone(std::numeric_limits<float>::infinity()),0));
        CHECK(fresh(100,300));CHECK(!fresh(100,301));CHECK(!fresh(500,499));CHECK(!fresh(0,1));
        Pose head=identity({0,1.6f,0}),hand=identity({.2f,1.2f,-.5f});
        auto p=mapHand(head,hand,{100,200,30},cameraBasis({}),1,0);
        CHECK(near(p.grip,{100.2f,200.5f,29.6f}));CHECK(near(p.forward,{0,1,0}));CHECK(near(p.up,{0,0,1}));
        // Moving the SteamVR origin must not move the virtual weapon relative to the head.
        auto p2=mapHand(identity({10,5.6f,20}),identity({10.2f,5.2f,19.5f}),{100,200,30},cameraBasis({}),1,0);
        CHECK(near(p.grip,p2.grip));
        // Looking around cannot rotate a stationary tracked gun. Covers yaw/pitch/roll.
        for(int yaw=-170;yaw<=170;yaw+=17) for(int pitch=-60;pitch<=60;pitch+=20) for(int roll=-30;roll<=30;roll+=15) {
            Vec3 angles{float(pitch),float(roll),float(yaw)};
            auto pose=mapHand(headForCamera(angles,head.pos()),hand,{100,200,30},cameraBasis(angles),1,0);
            CHECK(near(pose.grip,p.grip));CHECK(near(pose.forward,p.forward));
            CHECK(near(dot(cross(pose.right,pose.forward),pose.up),1));
            auto q=quaternion(pose.forward,-pose.right,pose.up);
            CHECK(near(rotate(q,{1,0,0}),pose.forward));CHECK(near(rotate(q,{0,0,1}),pose.up));
        }
        for(Vec3 angles: {Vec3{0,0,0},Vec3{0,0,180},Vec3{90,0,0},Vec3{0,180,0},Vec3{-45,90,170}}) {
            auto b=cameraBasis(angles);auto q=quaternion(b.right,b.forward,b.up);
            CHECK(near(rotate(q,{1,0,0}),b.right));CHECK(near(rotate(q,{0,1,0}),b.forward));CHECK(near(rotate(q,{0,0,1}),b.up));
        }
        CHECK(validPose(head));auto bad=head;bad.m[0][0]=4;CHECK(!validPose(bad));bad=head;bad.m[0][3]=std::numeric_limits<float>::quiet_NaN();CHECK(!validPose(bad));
        InputFrame f;f.flags=HeadValid|RightValid|InputReady;f.timeMs=100;f.head=head;f.right=hand;CHECK(usable(f,101));
        f.flags|=DashboardOpen;CHECK(!usable(f,101));f.flags&=~DashboardOpen;CHECK(!usable(f,301));
        f.version=42;CHECK(!usable(f,101));f.version=protocolVersion;f.trigger=std::numeric_limits<float>::quiet_NaN();CHECK(!usable(f,101));
        f.trigger=0;f.right=identity({20,1.6f,0});CHECK(!usable(f,101));
        std::set<std::uint32_t> hashes;
        for(const auto& w:weapons) { CHECK(hashes.insert(w.hash).second);CHECK(w.group>=0&&w.group<8);CHECK(w.pellets>0&&w.pellets<=8); }
        std::cout<<checks<<" checks passed. Hardware / GTA runtime not exercised.\n";
        return 0;
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; }
}
