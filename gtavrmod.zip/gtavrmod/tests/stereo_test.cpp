#include "protocol.hpp"
#include <iostream>
#include <limits>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
bool near(float a,float b,float epsilon=.0002f){return std::abs(a-b)<epsilon;}
bool near(Vec3 a,Vec3 b){return length(a-b)<.0003f;}
Pose identity(Vec3 p={}){Pose t{};t.m[0][0]=t.m[1][1]=t.m[2][2]=1;t.m[0][3]=p.x;t.m[1][3]=p.y;t.m[2][3]=p.z;return t;}
template<class F> bool rejects(F f){try{f();}catch(const std::runtime_error&){return true;}return false;}
int main(){try{
    // Golden identity and asymmetric projections, including texture V direction.
    EyeTangents eyes[2]={{-1,1,-1,1},{-1,1,-1,1}};
    auto p=projection(eyes,1);CHECK(near(p.verticalFov,90));CHECK(near(p.crop[0].uMin,0));CHECK(near(p.crop[1].vMax,1));
    eyes[0]={-1.2f,.8f,-1.1f,.9f};eyes[1]={-.8f,1.2f,-1.1f,.9f};p=projection(eyes,2);
    CHECK(near(p.crop[0].uMin,.2272727f));CHECK(near(p.crop[1].uMax,.7727273f));CHECK(near(p.crop[0].vMin,0));CHECK(near(p.crop[1].vMax,.9090909f));
    CHECK(rejects([&]{projection(eyes,0);}));CHECK(rejects([&]{projection(eyes,std::numeric_limits<float>::quiet_NaN());}));
    eyes[0].top=1;CHECK(rejects([&]{projection(eyes,1);}));eyes[0].top=-10;CHECK(rejects([&]{projection(eyes,1);}));
    eyes[0].top=std::numeric_limits<float>::infinity();CHECK(rejects([&]{projection(eyes,1);}));
    // Known 64 mm IPD must generate two distinct views around one head center.
    WorldCamera head{{10,20,30},cameraBasis({})};auto left=eyeCamera(head,identity({-.032f,0,0}),1),right=eyeCamera(head,identity({.032f,0,0}),1);
    CHECK(near(left.position,{9.968f,20,30}));CHECK(near(right.position,{10.032f,20,30}));CHECK(near(length(right.position-left.position),.064f));
    head.basis=cameraBasis({0,0,90});left=eyeCamera(head,identity({-.032f,0,0}),1);right=eyeCamera(head,identity({.032f,0,0}),1);
    CHECK(near(right.position-left.position,{0,.064f,0}));
    left=eyeCamera(head,identity({-.032f,0,0}),2);right=eyeCamera(head,identity({.032f,0,0}),2);CHECK(near(length(right.position-left.position),.128f));
    // Preserve a room-space translation and clamp only excessive movement.
    auto origin=identity({0,1.6f,0});auto moved=identity({.2f,1.7f,-.3f});
    auto world=trackedCamera(moved,origin,{10,20,30},cameraBasis({}),1,.75f);
    CHECK(near(world.position,{10.2f,20.3f,30.1f}));CHECK(validBasis(world.basis));
    world=trackedCamera(identity({10,1.6f,0}),origin,{10,20,30},cameraBasis({}),1,.75f);CHECK(near(world.position,{10.75f,20,30}));
    // Recenter yaw maps current forward to game forward, without flattening pitch.
    Pose turned=identity({0,1.6f,0});turned.m[0][0]=0;turned.m[0][2]=-1;turned.m[2][0]=1;turned.m[2][2]=0;
    world=trackedCamera(turned,yawPose(turned),{1,2,3},cameraBasis({}),1,.75f);
    CHECK(near(world.basis.forward,{0,1,0}));CHECK(near(world.position,{1,2,3}));
    // ZXY camera decomposition includes heading wrapping, roll and pole cases.
    for(int pitch=-90;pitch<=90;pitch+=15)for(int yaw=-180;yaw<=180;yaw+=30)for(int roll=-90;roll<=90;roll+=30){
        auto b=cameraBasis({float(pitch),float(roll),float(yaw)});auto recovered=cameraBasis(cameraAngles(b));
        CHECK(near(b.right,recovered.right));CHECK(near(b.forward,recovered.forward));CHECK(near(b.up,recovered.up));
    }
    // No eye advances before Present. A reset requires two newly captured eyes.
    EyeSequence sequence;CHECK(sequence.next()==0&&!sequence.ready());CHECK(sequence.next()==0);
    sequence.consumed();CHECK(sequence.next()==1&&!sequence.ready());sequence.consumed();CHECK(sequence.next()==0&&sequence.ready());
    sequence.consumed();CHECK(sequence.next()==1&&sequence.ready());sequence.reset();CHECK(sequence.next()==0&&!sequence.ready());
    // The input consumer uses a single center camera, independent of alternating eyes.
    InputFrame f;f.timeMs=100;f.head=origin;f.right=identity({.2f,1.2f,-.5f});f.flags=HeadValid|RightValid|InputReady|CameraKnown;
    f.gameHead={10,20,30};f.gameBasis=cameraBasis({});CHECK(usable(f,100));
    auto weapon=mapHand(f.head,f.right,f.gameHead,f.gameBasis,1,0);CHECK(near(weapon.grip,{10.2f,20.5f,29.6f}));
    f.gameBasis.up={0,0,0};CHECK(!usable(f,100));f.gameBasis=cameraBasis({});f.gameHead.x=std::numeric_limits<float>::quiet_NaN();CHECK(!usable(f,100));
    f.flags&=~CameraKnown;CHECK(usable(f,100));
    std::cout<<checks<<" stereo math/protocol checks passed. GTA camera timing and headset output NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
