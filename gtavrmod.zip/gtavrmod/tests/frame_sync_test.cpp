// Frame-sync logic: tag codec, plan ring, camera-lag votes and an end-to-end
// simulation of a GTA-like pipeline (game update -> render queue -> Present ->
// delayed GPU readback). No D3D11, GTA or headset is involved.
#include "frame_sync.hpp"
#include <deque>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)

static std::array<TagSample,TagCells> render(const std::array<bool,TagCells>& cells,std::uint8_t white=255,std::uint8_t black=0){
    std::array<TagSample,TagCells> out{};for(unsigned i=0;i<TagCells;++i){auto v=cells[i]?white:black;out[i]={v,v,v};}return out;
}
static Pose identity(Vec3 p={}){Pose t{};t.m[0][0]=t.m[1][1]=t.m[2][2]=1;t.m[0][3]=p.x;t.m[1][3]=p.y;t.m[2][3]=p.z;return t;}

// What one game update asked GTA to render, and what actually ended up on screen.
struct GameFrame { std::uint32_t tagId=0;bool tagged=false;unsigned trueEye=0;bool hasCamera=false; };

int main(){try{
    // --- Tag codec: every id round-trips; geometry stays in the top-left strip.
    for(std::uint32_t id=0;id<5000;++id){auto decoded=decodeTag(render(encodeTag(id)));CHECK(decoded&&*decoded==(id&TagIdMask));}
    for(std::uint32_t id=0;id<=TagIdMask;++id){auto d=decodeTag(render(encodeTag(id),200,60));CHECK(d&&*d==id);}   // dimmed HUD / gamma
    CHECK(TagWidth==96&&TagHeight==6);
    for(unsigned c=0;c<TagCells;++c){auto r=tagRect(c,1920,1080);
        CHECK(std::abs(r.w*1920-6)<1e-3f&&std::abs(r.h*1080-6)<1e-3f);
        CHECK(std::abs((r.x-r.w/2)*1920-c*6.0f)<1e-3f&&std::abs((r.y-r.h/2)*1080)<1e-3f);
        CHECK(tagSampleX(c)>=c*TagCellPixels&&tagSampleX(c)<(c+1)*TagCellPixels);}
    CHECK(TagSampleY<TagHeight);
    // Rejections: missing sync, broken complement, coloured / mid-grey pixels.
    {auto cells=encodeTag(42);auto s=render(cells);s[0]={0,0,0};CHECK(!decodeTag(s));
     s=render(cells);s[3]=s[3+TagIdBits];CHECK(!decodeTag(s));
     s=render(cells);s[5]={255,40,40};CHECK(!decodeTag(s));
     s=render(cells);s[7]={128,128,128};CHECK(!decodeTag(s));
     std::array<TagSample,TagCells> flat{};for(auto& x:flat)x={255,255,255};CHECK(!decodeTag(flat));
     for(auto& x:flat)x={0,0,0};CHECK(!decodeTag(flat));}
    // Random natural-looking content almost never decodes (and is then rejected by plan lookup anyway).
    {std::mt19937 rng(7);unsigned accidental=0;
     for(int n=0;n<200000;++n){std::array<TagSample,TagCells> s{};for(auto& x:s){auto v=std::uint8_t(rng()&255);x={v,std::uint8_t(std::clamp(int(v)+int(rng()%41)-20,0,255)),v};}accidental+=bool(decodeTag(s));}
     CHECK(accidental==0);}
    // Bright sky or dark night in the corner: uniform cells never decode either.
    for(int v=0;v<256;++v){std::array<TagSample,TagCells> s{};for(auto& x:s)x={std::uint8_t(v),std::uint8_t(v),std::uint8_t(v)};CHECK(!decodeTag(s));}

    // --- Plan ring
    PlanRing ring;CHECK(ring.latestId()==0&&!ring.find(0)&&!ring.find(1));
    for(int i=1;i<=10;++i){auto& p=ring.create(identity(),{float(i),0,0},i);CHECK(p.id==std::uint32_t(i)&&p.eye==eyeForPlan(i));}
    CHECK(ring.find(10)&&ring.find(10)->eyePosition.x==10&&ring.find(1)&&!ring.find(11));
    CHECK(ring.resolveTag(10&TagIdMask,10)==std::optional<std::uint32_t>(10));
    CHECK(ring.resolveTag(8,10)==std::optional<std::uint32_t>(8));
    CHECK(!ring.resolveTag(11,10));           // would be id 11-128 <1: no such plan
    CHECK(!ring.resolveTag(5,11));            // capture cannot claim a plan newer than the ring
    ring.newSession();CHECK(!ring.find(10)&&!ring.resolveTag(10,10));
    ring.create(identity(),{},11);CHECK(ring.find(11)&&!ring.find(10)&&ring.resolveTag(11,11)==std::optional<std::uint32_t>(11));
    for(int i=0;i<300;++i)ring.create(identity(),{},0);
    CHECK(ring.find(ring.latestId())&&ring.find(ring.latestId()-TagIdMask)&&!ring.find(ring.latestId()-TagIdMask-1));
    {std::uint32_t L=ring.latestId();CHECK(!ring.resolveTag((L-TagMaxAge-1)&TagIdMask,L));CHECK(ring.resolveTag((L-TagMaxAge)&TagIdMask,L));}
    // Tag lookup with camera lag
    {PlanRing r;for(int i=1;i<=20;++i)r.create(identity(),{},0);std::uint32_t depth=0;
     auto* p=planForTaggedFrame(r,15,20,0,&depth);CHECK(p&&p->id==15&&depth==5);
     p=planForTaggedFrame(r,15,20,1,&depth);CHECK(p&&p->id==14&&p->eye==0);
     CHECK(!planForTaggedFrame(r,1,20,1));}

    {PlanRing r;auto& m=r.create(identity(),{},1,true);CHECK(m.mono);auto& n=r.create(identity(),{},2);CHECK(!n.mono);}
    // --- Camera lag estimator
    {FramePlan a{},b{};a.eyePosition={0,0,0};b.eyePosition={.064f,0,0};
     CHECK(CameraLagEstimator::classify({.064f,0,0},b,a)==CameraLagEstimator::SameFrame);
     CHECK(CameraLagEstimator::classify({0,0,0},b,a)==CameraLagEstimator::OneFrameLate);
     CHECK(CameraLagEstimator::classify({.032f,0,0},b,a)==CameraLagEstimator::None);
     b.eyePosition={.01f,0,0};CHECK(CameraLagEstimator::classify({.01f,0,0},b,a)==CameraLagEstimator::None);
     CHECK(CameraLagEstimator::classify({NAN,0,0},b,a)==CameraLagEstimator::None);
     CameraLagEstimator e;for(int i=0;i<23;++i)CHECK(!e.observe(CameraLagEstimator::OneFrameLate));CHECK(e.lag()==0);
     CHECK(e.observe(CameraLagEstimator::OneFrameLate));CHECK(e.lag()==1);
     for(int i=0;i<40;++i)e.observe(CameraLagEstimator::SameFrame);CHECK(e.lag()==1);    // 40/64 is not a 75% majority
     for(int i=0;i<10;++i)e.observe(CameraLagEstimator::SameFrame);CHECK(e.lag()==0);
     e.observe(CameraLagEstimator::None);CHECK(e.ambiguousSamples()==1);e.reset();CHECK(e.lag()==0&&e.votesFor(0)==0);}

    // --- Prediction
    CHECK(std::abs(predictionSeconds(0,90,.011f,0)-(1/90.0f+.011f))<1e-5f);
    CHECK(std::abs(predictionSeconds(1,90,0,0))<1e-6f);
    CHECK(predictionSeconds(0,0,1,10)==.06f);
    CHECK(predictionSeconds(NAN,NAN,NAN,NAN)>0);
    {LatencyFilter f;CHECK(f.seconds()==0);f.add(.02);CHECK(std::abs(f.seconds()-.02)<1e-9);f.add(5);CHECK(std::abs(f.seconds()-.02)<1e-9);f.add(.03);CHECK(std::abs(f.seconds()-.021)<1e-9);}

    // --- End-to-end pipeline simulation.
    // Each game update u: the script requests eye(u) and draws tag(u). GTA applies
    // the camera `cameraLag` updates late; the render thread presents update u
    // `queue` updates later (jittering); the tag readback completes 1-3 presents later.
    unsigned scenarios=0;
    for(unsigned cameraLag=0;cameraLag<=1;++cameraLag)for(unsigned baseQueue=0;baseQueue<=3;++baseQueue)for(int jitter=0;jitter<=1;++jitter)for(int skips=0;skips<=1;++skips){
        ++scenarios;std::mt19937 rng(baseQueue*31+cameraLag*7+jitter*3+skips);
        PlanRing plans;CameraLagEstimator lag;
        std::deque<GameFrame> renderQueue;std::deque<std::pair<GameFrame,std::uint32_t>> readback;   // (frame, latest plan at capture)
        std::vector<int> requestedEye;   // per update, -1 = no request (skipped tick)
        unsigned correct=0,wrong=0,legacyWrong=0,legacyTotal=0;
        std::vector<Vec3> requestedPos;
        for(std::uint32_t u=0;u<4000;++u){
            // Game thread: lag measurement from the last rendered camera, then a new request.
            bool skip=skips&&(rng()%17==0);
            if(!skip){
                std::uint32_t latest=plans.latestId();
                if(latest>1&&u>=1+cameraLag){
                    // Camera rendered for the previous update: the request made cameraLag updates earlier.
                    int src=int(u)-1-int(cameraLag);while(src>=0&&requestedEye[src]<0)--src;
                    if(src>=0){auto* a=plans.find(latest);auto* b=plans.find(latest-1);if(a&&b)lag.observe(CameraLagEstimator::classify(requestedPos[src],*a,*b));}
                }
                std::uint32_t next=plans.latestId()+1;Vec3 pos{eyeForPlan(next)?.032f:-.032f,float(u)*.001f,0};
                plans.create(identity(),pos,u);requestedEye.push_back(int(eyeForPlan(next)));requestedPos.push_back(pos);
            }else{requestedEye.push_back(-1);requestedPos.push_back({});}
            // What GTA renders for update u: camera from the request cameraLag updates earlier (latest non-skipped),
            // tag only if this update's tick ran.
            GameFrame frame;frame.tagged=!skip;frame.tagId=plans.latestId()&TagIdMask;
            int src=int(u)-int(cameraLag);while(src>=0&&requestedEye[src]<0)--src;
            frame.hasCamera=src>=0;frame.trueEye=frame.hasCamera?unsigned(requestedEye[src]):0;
            renderQueue.push_back(frame);
            unsigned queue=baseQueue+(jitter?unsigned(rng()%2):0);
            while(renderQueue.size()>queue){
                GameFrame shown=renderQueue.front();renderQueue.pop_front();
                std::uint32_t latestAtCapture=plans.latestId();
                // Legacy labelling: "the latest plan" (FrameOffset=0).
                if(shown.hasCamera&&latestAtCapture){auto* p=plans.find(latestAtCapture);if(p){++legacyTotal;legacyWrong+=p->eye!=shown.trueEye;}}
                readback.push_back({shown,latestAtCapture});
            }
            while(readback.size()>1+rng()%3){
                auto [shown,latestAtCapture]=readback.front();readback.pop_front();
                if(!shown.tagged)continue;   // decodeTag fails: the frame is skipped, never mislabelled
                auto decoded=decodeTag(render(encodeTag(shown.tagId)));CHECK(decoded);
                auto* plan=planForTaggedFrame(plans,*decoded,latestAtCapture,lag.lag());
                if(!plan||!shown.hasCamera)continue;
                if(u>200){if(plan->eye==shown.trueEye)++correct;else ++wrong;}   // after the lag estimate settles
            }
        }
        CHECK(lag.lag()==cameraLag);
        CHECK(wrong==0);CHECK(correct>2500);
        // The simulation must actually exercise the failure the tags fix.
        if(baseQueue%2==1&&!jitter&&!skips&&cameraLag==0)CHECK(legacyWrong*10>legacyTotal*9);
    }
    CHECK(scenarios==32);
    std::cout<<checks<<" frame-sync checks passed (tag codec, plan ring, camera-lag votes, 32 simulated GTA pipelines). D3D11 readback, GTA and headset NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
