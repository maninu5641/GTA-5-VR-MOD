// 0.7.0: view projection (zoom, mono depth, measured GTA FOV) and the FOV calibration.
#include "vr_view.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool sameCrop(const Crop& a,const Crop& b,float e=1e-5f){return near(a.uMin,b.uMin,e)&&near(a.uMax,b.uMax,e)&&near(a.vMin,b.vMin,e)&&near(a.vMax,b.vMax,e);}
// Image tangent shown at eye tangent t (horizontal) for a crop and an image half tangent.
static float imageTangentAt(const Crop& c,const EyeTangents& e,float t,float tanH){
    float u=c.uMin+(t-e.left)/(e.right-e.left)*(c.uMax-c.uMin);return (u-.5f)*2*tanH;
}
// Screen position of a point at horizontal / vertical tangent (tx, ty) for an image with half tangents (tv, th).
static void project(float tx,float ty,float tv,float th,float& x,float& y){x=.5f+tx/(2*th);y=.5f-ty/(2*tv);}

int main(){try{
    const float noShift[2]={-.032f,.032f};
    // --- Default model, zoom 1: identical to the 0.6.0 projection.
    for(float aspect:{1.0f,16.0f/9.0f,2.0f}){
        EyeTangents sets[3][2]={{{-1,1,-1,1},{-1,1,-1,1}},{{-1.2f,.8f,-1.1f,.9f},{-.8f,1.2f,-1.1f,.9f}},{{-1.39f,1.0f,-1.19175f,1.1f},{-1.0f,1.39f,-1.19175f,1.1f}}};
        for(auto& eyes:sets){auto old=projection(eyes,aspect);auto now=viewProjection(eyes,noShift,aspect,{},{});
            CHECK(near(now.requestFov,old.verticalFov,1e-3f));CHECK(sameCrop(now.crop[0],old.crop[0])&&sameCrop(now.crop[1],old.crop[1]));
            CHECK(sameCrop(now.monoCrop[0],now.crop[0])&&sameCrop(now.monoCrop[1],now.crop[1]));CHECK(!now.clamped);}}
    // Friend's headset: 100 degrees vertical on a 16:9 backbuffer.
    EyeTangents quest[2]={{-1.39f,1.0f,-1.19175f,1.19175f},{-1.0f,1.39f,-1.19175f,1.19175f}};
    float aspect=16.0f/9.0f;
    {   auto p=viewProjection(quest,noShift,aspect,{},{});CHECK(near(p.requestFov,100,.01f));CHECK(near(p.tanH,p.tanV*aspect));
        // --- GTA treating the FOV as horizontal (ratio = 1 / aspect): request the horizontal angle instead.
        GtaFovModel horizontal{1/aspect,aspect,true};auto q=viewProjection(quest,noShift,aspect,horizontal,{});
        CHECK(near(q.requestFov,2*std::atan(1.19175f*aspect)*180/pi,.01f));CHECK(q.requestFov<130&&!q.clamped);
        CHECK(sameCrop(q.crop[0],p.crop[0])&&sameCrop(q.crop[1],p.crop[1]));            // same image, so the same crops
        // --- GTA's 130 degree limit: clamp and crop the narrower image honestly.
        GtaFovModel narrow{.5f,aspect,true};auto r=viewProjection(quest,noShift,aspect,narrow,{});
        CHECK(r.clamped&&near(r.requestFov,130));CHECK(near(r.tanV,.5f*std::tan(rad(65))));CHECK(r.crop[0].vMin<0);}
    // --- Zoom: 0.9 shows an image point at 0.9 of its angle (smaller), 1.1 magnifies.
    for(float zoom:{.9f,1.1f}){
        ViewSettings s;s.zoom=zoom;auto p=viewProjection(quest,noShift,aspect,{},s);
        for(float t:{-.8f,-.3f,.4f,.9f})CHECK(near(imageTangentAt(p.crop[0],quest[0],t,p.tanH),t/zoom,1e-4f));
        CHECK(near(p.tanV,std::max(1.19175f,1.39f/aspect)/zoom,1e-4f));}
    {   ViewSettings s;s.zoom=0.1f;CHECK(near(viewProjection(quest,noShift,aspect,{},s).tanV,1.19175f/.6f,1e-3f));   // zoom clamped to 0.6
        s.zoom=NAN;CHECK(near(viewProjection(quest,noShift,aspect,{},s).requestFov,100,.01f));}
    // --- Mono depth: a centred object appears in front of each eye at the convergence distance.
    {   ViewSettings s;s.monoDepth=2;auto p=viewProjection(quest,noShift,aspect,{},s);
        float sl=.032f/2;   // left eye sees it at +ipd/2 / depth (to the right)
        CHECK(near(imageTangentAt(p.monoCrop[0],quest[0],sl,p.tanH),0,1e-5f));
        CHECK(near(imageTangentAt(p.monoCrop[1],quest[1],-sl,p.tanH),0,1e-5f));
        CHECK(p.monoCrop[0].uMin<p.crop[0].uMin&&p.monoCrop[1].uMin>p.crop[1].uMin);
        CHECK(p.monoCrop[0].uMin>=0&&p.monoCrop[1].uMax<=1);}
    // --- Invalid input
    {   EyeTangents bad[2]={{1,1,-1,1},{-1,1,-1,1}};bool threw=false;try{viewProjection(bad,noShift,aspect,{},{});}catch(const std::exception&){threw=true;}CHECK(threw);
        threw=false;try{viewProjection(quest,noShift,0,{},{});}catch(const std::exception&){threw=true;}CHECK(threw);}
    // --- Measured projection used as is.
    {   auto p=viewProjectionAt(quest,noShift,{},120,1.6f,2.8f);CHECK(near(p.requestFov,120)&&near(p.tanV,1.6f)&&!p.clamped);
        CHECK(near(p.crop[0].uMin,.5f-1.39f/(2*2.8f)));auto q=viewProjectionAt(quest,noShift,{},100,1.0f,1.2f);CHECK(q.clamped);}

    // --- FOV samples from projected probe points.
    {   float tanA=std::tan(rad(20)),tv=1.19175f,th=tv*aspect;float xl,yl,xr,yr,xu,yu,xd,yd,xc,yc;
        project(-tanA,0,tv,th,xl,yl);project(tanA,0,tv,th,xr,yr);project(0,tanA,tv,th,xu,yu);project(0,-tanA,tv,th,xd,yd);project(0,0,tv,th,xc,yc);
        FovSample s;CHECK(fovSample(tanA,xl,xr,yu,yd,xc,yc,s));CHECK(near(s.tanV,tv,1e-4f)&&near(s.tanH,th,1e-4f));
        CHECK(!fovSample(tanA,xl,xr,yu,yd,.53f,yc,s));                 // camera readback off the screen centre
        CHECK(!fovSample(tanA,xl+.05f,xr+.05f,yu,yd,xc,yc,s));          // pair not symmetric about the centre
        CHECK(!fovSample(tanA,xr,xl,yu,yd,xc,yc,s));CHECK(!fovSample(NAN,xl,xr,yu,yd,xc,yc,s));}
    // --- Calibration: GTA renders the requested angle horizontally; one correction, then consistent.
    {   FovCalibrator cal;GtaFovModel model{};auto p=viewProjection(quest,noShift,aspect,model,{});
        auto gta=[&](float request){float t=std::tan(rad(request/2));return FovSample{t/aspect,t};};   // horizontal-FOV game
        FovCalibrator::Result r;for(std::size_t i=0;i<FovCalibrator::Needed;++i)r=cal.add(gta(p.requestFov),p.requestFov,model,aspect);
        CHECK(r.ready&&r.changed&&!r.finished);CHECK(near(r.model.ratio,1/aspect,1e-3f)&&near(r.model.aspect,aspect,1e-3f));
        model=r.model;p=viewProjection(quest,noShift,aspect,model,{});CHECK(p.requestFov>129&&p.requestFov<130);
        for(std::size_t i=0;i<FovCalibrator::Needed;++i)r=cal.add(gta(p.requestFov),p.requestFov,model,aspect);
        CHECK(r.ready&&!r.changed&&r.finished&&cal.finished());
        CHECK(!cal.add(gta(p.requestFov),p.requestFov,model,aspect).ready);}   // finished: no more rounds
    // --- Calibration: a vertical-FOV game (the assumption) finishes in one round without change.
    {   FovCalibrator cal;GtaFovModel model{};auto p=viewProjection(quest,noShift,aspect,model,{});float t=std::tan(rad(p.requestFov/2));
        FovCalibrator::Result r;for(std::size_t i=0;i<FovCalibrator::Needed;++i)r=cal.add({t*(1+.004f*float(i%3)),t*aspect},p.requestFov,model,aspect);
        CHECK(r.ready&&!r.changed&&r.finished);CHECK(near(r.model.ratio,1,.01f));}
    // --- Noisy round rejected, request change restarts the round, three rounds at most.
    {   FovCalibrator cal;GtaFovModel model{};FovCalibrator::Result r;
        for(std::size_t i=0;i<FovCalibrator::Needed;++i)r=cal.add({i%2?1.0f:1.5f,1.8f},100,model,aspect);CHECK(!r.ready&&cal.roundsDone()==0);
        for(std::size_t i=0;i<FovCalibrator::Needed-1;++i)cal.add({1,1.8f},100,model,aspect);r=cal.add({1,1.8f},101,model,aspect);CHECK(!r.ready);
        float request=100;int rounds=0;
        for(int k=0;k<5&&!cal.finished();++k){for(std::size_t i=0;i<FovCalibrator::Needed;++i)r=cal.add({.7f+.1f*k,.7f*aspect+.1f*k},request,model,aspect);if(r.ready){++rounds;model=r.model;request+=5;}}
        CHECK(cal.finished()&&rounds==3);}
    // --- 0.8.0: log-only mode stops after one measurement.
    {   FovCalibrator cal;cal.stop();CHECK(cal.finished());CHECK(!cal.add({1,1.8f},100,{},1.8f).ready);cal.restart();CHECK(!cal.finished());}
    std::cout<<checks<<" view checks passed (zoom, mono depth, GTA FOV model, 130 degree clamp, FOV probe and calibration rounds). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
