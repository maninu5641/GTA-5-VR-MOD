// 0.7.0: lazy torso holsters, grab / hold / throw, locomotion filter, character switch, clip book.
#include "vr_play.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
// Head pose looking along yaw (radians, 0 = -Z, + = left) with pitch (radians, + = up).
static Pose headPose(float yaw,float pitch,Vec3 pos){
    Vec3 f{-std::sin(yaw)*std::cos(pitch),std::sin(pitch),-std::cos(yaw)*std::cos(pitch)};
    Vec3 r=unit(cross(f,{0,1,0}),{1,0,0}),u=cross(r,f);Pose p{};
    p.m[0][0]=r.x;p.m[1][0]=r.y;p.m[2][0]=r.z;p.m[0][1]=u.x;p.m[1][1]=u.y;p.m[2][1]=u.z;p.m[0][2]=-f.x;p.m[1][2]=-f.y;p.m[2][2]=-f.z;
    p.m[0][3]=pos.x;p.m[1][3]=pos.y;p.m[2][3]=pos.z;return p;
}

int main(){try{
    // --- Head yaw, including looking straight down or up.
    {   CHECK(near(headYaw(headPose(0,0,{0,1.7f,0})),0));CHECK(near(headYaw(headPose(1.2f,0,{0,1.7f,0})),1.2f,1e-3f));
        CHECK(near(headYaw(headPose(-.7f,1.5f,{0,1.7f,0})),-.7f,1e-2f));CHECK(near(headYaw(headPose(.5f,-1.55f,{0,1.7f,0})),.5f,1e-2f));
        CHECK(near(yawForward(0),{0,0,-1}));CHECK(near(yawForward(pi/2),{-1,0,0},1e-5f));CHECK(near(wrapAngle(3*pi),pi,1e-4f)||near(wrapAngle(3*pi),-pi,1e-4f));}
    // --- Torso: a glance does not move the holsters; a far turn or a long look does.
    {   TorsoYaw t;CHECK(near(t.update(.3f,0),.3f));
        for(int i=0;i<4;++i)t.update(.3f+.6f,.1f);CHECK(near(t.value(),.3f));                        // 34 deg glance for 0.4 s: body still
        t.update(.3f+1.3f,.016f);CHECK(near(t.value(),.3f+1.3f-TorsoYaw::Deadband,1e-4f));          // 75 deg turn: body pulled to 40 deg behind
        TorsoYaw g;g.update(0,0);for(int i=0;i<60;++i)g.update(.3f,.016f);CHECK(near(g.value(),0));   // 17 deg aside for 1 s: a glance, body still
        // 0.16.2: you turned (or keep looking 29 deg aside): after 0.5 s the body turns all the way, in about 0.4 s.
        TorsoYaw u;u.update(0,0);for(int i=0;i<30;++i)u.update(.5f,.016f);CHECK(near(u.value(),0));     // 0.48 s: not yet
        for(int i=0;i<90;++i)u.update(.5f,.016f);CHECK(std::abs(u.value()-.5f)<TorsoYaw::Aligned+.01f);// 1.9 s: facing where you look (was 10 deg short)
        TorsoYaw f;f.update(0,0);f.update(1.6f,.016f);for(int i=0;i<90;++i)f.update(1.6f,.016f);CHECK(std::abs(f.value()-1.6f)<.08f);   // a real 92 deg turn: within 5 deg after 1.5 s
        for(int i=0;i<40;++i)f.update(1.6f,.016f);CHECK(std::abs(f.value()-1.6f)<TorsoYaw::Aligned+.005f);
        // Walking: the body faces where you look (you walk there) within ~0.4 s; looking down at a holster it stays.
        TorsoYaw m;m.update(0,0);for(int i=0;i<25;++i)m.update(.4f,.016f,true);CHECK(std::abs(m.value()-.4f)<.05f);
        TorsoYaw d;d.update(0,0);for(int i=0;i<200;++i)d.update(.5f,.016f,false,true);CHECK(near(d.value(),0));
        d.update(1.5f,.016f,false,true);CHECK(near(d.value(),1.5f-TorsoYaw::Deadband,1e-4f));          // turning around while looking down: still pulled along
        TorsoYaw w;w.update(3.0f,0);w.update(-3.0f,.016f);CHECK(near(w.value(),3.0f));                 // across +-180: small turn, no jump
        CHECK(near(w.update(NAN,.016f),3.0f));
        TorsoYaw s;s.set(1.0f);CHECK(near(s.value(),1.0f));s.set(NAN);CHECK(near(s.value(),1.0f));s.set(4*pi+.5f);CHECK(near(s.value(),.5f,1e-4f));
        CHECK(lookingDown(headPose(0,-1.0f,{0,1.7f,0}))&&!lookingDown(headPose(0,-.5f,{0,1.7f,0}))&&!lookingDown(headPose(1,.3f,{0,1.7f,0})));}
    // --- Zones follow the torso yaw, not the head.
    {   Vec3 h{0,1.7f,0};auto z0=holsterZonesAt(h,0),z1=holsterZonesAt(h,pi/2);
        CHECK(near(z0[int(Holster::RightHip)].center,{.20f,1.0f,-.03f},1e-4f));CHECK(near(z1[int(Holster::RightHip)].center,{-.03f,1.0f,-.20f},1e-4f));
        CHECK(holsterAt(z0,{.21f,1.02f,-.02f})==Holster::RightHip);CHECK(holsterAt(z0,{0,1.32f,-.13f})==Holster::Chest);CHECK(holsterAt(z0,{0,2.5f,0})==Holster::None);
        CHECK(near(holsterZonesAt(h,0,-.1f)[int(Holster::Chest)].center.y,1.7f-.1f-.38f,1e-5f));
        // the 0.5.0 head-based zones are the same at the same yaw
        auto old=holsterZones(headPose(.4f,0,h)),now=holsterZonesAt(h,.4f);for(int i=0;i<holsterCount;++i)CHECK(near(old[i].center,now[i].center,1e-3f));
        CHECK(atPouchAt(h,0,pouchCenterAt(h,0)));CHECK(!atPouchAt(h,0,{.5f,1.0f,0}));}
    // --- Grab: hold mode. Squeeze at a holster = take it; let go = it goes back (guns) / thrown (grenades).
    {   HandGrab g;GrabInput in;in.zone=Holster::RightHip;in.zoneHasItem=true;
        in.grip=true;CHECK(!g.update(in).grabbed);                                                   // grip already squeezed: not a press
        in.grip=false;g.update(in);in.grip=true;auto e=g.update(in);CHECK(e.grabbed&&g.holding&&e.from==Holster::RightHip);
        in.zone=Holster::None;CHECK(!g.update(in).released);                                          // moving away while squeezing: still held
        in.grip=false;e=g.update(in);CHECK(e.released&&!e.inHolster&&!g.holding&&e.from==Holster::RightHip);
        in.zone=Holster::Chest;in.zoneHasItem=false;in.grip=true;e=g.update(in);CHECK(e.emptyHolster&&!g.holding);
        in.grip=false;g.update(in);in.zoneHasItem=true;in.grip=true;g.update(in);in.grip=false;e=g.update(in);CHECK(e.released&&e.inHolster);   // let go in its own holster
        in.grip=true;g.update(in);in.valid=false;e=g.update(in);CHECK(e.released&&e.inHolster&&!g.holding);}                                  // tracking lost: back in the holster
    // --- Grab: toggle mode keeps the weapon; a squeeze at any holster puts it away; grenades are always hold.
    {   HandGrab g;GrabInput in;in.mode=GripMode::Toggle;in.zone=Holster::RightShoulder;in.zoneHasItem=true;in.grip=false;g.update(in);
        in.grip=true;CHECK(g.update(in).grabbed);in.grip=false;in.zone=Holster::None;CHECK(!g.update(in).released&&g.holding);
        in.grip=true;CHECK(!g.update(in).released);in.grip=false;g.update(in);                        // squeeze away from holsters: nothing
        in.zone=Holster::LeftHip;in.grip=true;auto e=g.update(in);CHECK(e.released&&e.inHolster&&!g.holding);
        HandGrab n;GrabInput gi;gi.mode=GripMode::Toggle;gi.alwaysHold=true;gi.zone=Holster::Chest;gi.zoneHasItem=true;gi.grip=false;n.update(gi);
        gi.grip=true;CHECK(n.update(gi).grabbed);gi.zone=Holster::None;gi.grip=false;e=n.update(gi);CHECK(e.released&&!e.inHolster);}
    // --- Locomotion: touch gate, hysteresis, brake after release.
    {   MoveFilter m;auto o=m.update(0,.25f,true,true,false);CHECK(!o.moving);                       // below start
        o=m.update(0,.6f,true,true,false);CHECK(o.moving&&o.y>0&&near(o.x,0));
        o=m.update(0,.22f,true,true,false);CHECK(o.moving);                                          // between stop and start: keeps moving
        o=m.update(0,.15f,true,true,false);CHECK(!o.moving&&o.brake&&o.y==0);
        int brakes=1;for(int i=0;i<10;++i)if(m.update(0,0,true,true,false).brake)++brakes;CHECK(brakes==MoveFilter::BrakeFrames);
        o=m.update(0,.9f,true,true,false);CHECK(o.moving);o=m.update(0,.9f,true,false,false);CHECK(!o.moving&&o.brake);   // thumb off a drifting stick: stop
        MoveFilter n;CHECK(n.update(0,.9f,false,false,false).moving);                                // no touch sensor bound: position only
        CHECK(!n.update(0,.9f,false,false,true).moving);CHECK(!n.update(NAN,.9f,false,false,false).moving);
        MoveFilter f;o=f.update(1,1,false,false,false);CHECK(near(std::sqrt(o.x*o.x+o.y*o.y),1,1e-5f));}
    // --- Head-relative direction: GTA moves relative to its camera.
    {   CHECK(near(gtaHeading({0,1,0}),0));CHECK(near(gtaHeading({-1,0,0}),90));CHECK(near(gtaHeading({1,0,0}),-90));
        float x=0,y=1;stickRelativeTo(x,y,90,0);CHECK(near(x,-1,1e-5f)&&near(y,0,1e-5f));               // looking left: forward = camera left
        x=1;y=0;stickRelativeTo(x,y,90,0);CHECK(near(x,0,1e-5f)&&near(y,1,1e-5f));                      // right = camera forward
        x=.3f;y=.4f;stickRelativeTo(x,y,30,30);CHECK(near(x,.3f)&&near(y,.4f));
        x=0;y=1;stickRelativeTo(x,y,-170,170);CHECK(near(x,-std::sin(rad(20)),1e-4f)&&near(y,std::cos(rad(20)),1e-4f));}
    // --- Character switch
    {   CHECK(characterForStick(-1,0)==Character::Michael&&characterForStick(0,1)==Character::Franklin&&characterForStick(1,.1f)==Character::Trevor);
        CHECK(characterForStick(0,-1)==Character::None&&characterForStick(.2f,.2f)==Character::None&&characterForStick(NAN,1)==Character::None);
        CHECK(characterControl(Character::Michael)==166&&characterControl(Character::Franklin)==167&&characterControl(Character::Trevor)==168&&characterControl(Character::None)==0);
        SwitchSequence s;CHECK(!s.active()&&s.next().done);s.start(167);int wheel=0,select=0,steps=0;
        while(s.active()){auto st=s.next();wheel+=st.wheel;select+=st.select==167;++steps;}CHECK(steps==10&&wheel==4&&select==8);
        s.start(0);CHECK(!s.active());
        PressHold h(350);CHECK(h.update(true,0)==PressHold::None);CHECK(h.update(false,100)==PressHold::Tap);
        h.update(true,1000);CHECK(h.update(true,1349)==PressHold::None);CHECK(h.update(true,1350)==PressHold::HoldStart&&h.holding());
        CHECK(h.update(true,2000)==PressHold::None);CHECK(h.update(false,2100)==PressHold::HoldEnd&&!h.holding());}
    // --- Clip book
    {   ClipBook b;CHECK(!b.has(5)&&b.get(5,12)==12);b.set(5,7);CHECK(b.has(5)&&b.get(5,12)==7);b.set(5,-3);CHECK(b.get(5,1)==0);
        for(std::uint32_t i=100;i<200;++i)b.set(i,int(i));CHECK(b.get(199,0)==199);b.set(0,4);CHECK(!b.has(0));
        CHECK(defaultCapacity(1)==12&&defaultCapacity(5)==8);}
    std::cout<<checks<<" play checks passed (lazy torso holsters, grab / hold / toggle / throw, locomotion gate and brake, head-relative walking, character switch, clip book). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
