// 0.15.5: the buttons chosen in the VR menu, GTA's pause menu with the controllers, the VR menu (vr_menu.hpp).
#include "vr_menu.hpp"
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)

int main(){try{
    // --- 0.16.3: the Reload button (A) is GTA's action key E too (the developer: "the gun shop person says press E").
    //     args: enabled, A down, free (no add-on menu), phone, in a vehicle, a gun in the right hand, GTA's help message.
    CHECK(reloadIsActionKey(true,true,true,false,false,false,false));     // on foot, empty hand: E
    CHECK(!reloadIsActionKey(true,true,true,false,false,true,false));     // a gun in the hand, no prompt: only the magazine
    CHECK(reloadIsActionKey(true,true,true,false,false,true,true));       // a gun and "press E to browse": E as well
    CHECK(!reloadIsActionKey(true,true,true,false,true,false,false));     // in a vehicle: the handbrake only...
    CHECK(reloadIsActionKey(true,true,true,false,true,false,true));       // ...unless GTA asks for E
    CHECK(!reloadIsActionKey(true,true,true,true,false,false,true));      // the phone has A (answer / select)
    CHECK(!reloadIsActionKey(true,true,false,false,false,false,true));    // the add-on's character menu has it
    CHECK(!reloadIsActionKey(false,true,true,false,false,false,true));    // ReloadIsE=0
    CHECK(!reloadIsActionKey(true,false,true,false,false,false,true));    // A not pressed
    CHECK(std::string(functionName(ButtonFunction::Reload)).find(" E ")!=std::string::npos);
    // --- The six buttons are the six SteamVR actions, one bit each, all different.
    std::uint32_t seen=0;
    for(int i=0;i<physCount;++i){std::uint32_t b=physicalBit(PhysButton(i));CHECK(b&&!(b&seen)&&(b&physicalMask)==b);seen|=b;}
    CHECK(seen==physicalMask);
    // Function bits: the 0.15.4 functions keep their bits; the new ones are new bits; None is nothing.
    CHECK(functionBit(ButtonFunction::None)==0);
    CHECK(functionBit(ButtonFunction::Reload)==ReloadHeld&&functionBit(ButtonFunction::Vehicle)==WheelHeld&&functionBit(ButtonFunction::Jump)==JumpHeld);
    CHECK(functionBit(ButtonFunction::CharacterWheel)==ToggleHeld&&functionBit(ButtonFunction::Run)==SprintHeld&&functionBit(ButtonFunction::WheelHold)==InteractHeld);
    std::uint32_t all=0;
    for(int i=1;i<functionCount;++i){std::uint32_t b=functionBit(ButtonFunction(i));CHECK(b&&!(b&all));all|=b;
        CHECK(!(b&(SupportGrip|WeaponGrip|MoveTouched|TouchKnown)));}   // never the grips / stick touch
    // Every function has a name and an INI word that reads back as itself (any letter case).
    for(int i=0;i<functionCount;++i){ButtonFunction f=ButtonFunction(i),g=ButtonFunction::Pause;
        CHECK(std::string(functionName(f)).size()>3);
        std::string t=functionToken(f);std::wstring w(t.begin(),t.end());CHECK(parseFunction(w.c_str(),g)&&g==f);
        for(auto& c:w)c=wchar_t(std::towupper(wint_t(c)));g=ButtonFunction::Pause;CHECK(parseFunction(w.c_str(),g)&&g==f);}
    {ButtonFunction f=ButtonFunction::Jump;CHECK(parseFunction(L"  context \r",f)&&f==ButtonFunction::Context);
     CHECK(parseFunction(L"E",f)&&f==ButtonFunction::Context);CHECK(parseFunction(L"off",f)&&f==ButtonFunction::None);
     f=ButtonFunction::Jump;CHECK(!parseFunction(L"Fly",f)&&f==ButtonFunction::Jump&&!parseFunction(nullptr,f)&&!parseFunction(L"",f));}
    for(int i=0;i<physCount;++i){CHECK(std::string(buttonName(PhysButton(i))).size()>3&&std::wstring(buttonKey(PhysButton(i))).size()>5);}

    // --- Defaults = 0.15.4, except the right stick click (GTA's action key E).
    {ButtonMap m=ButtonMap::defaults();CHECK(m.isDefault());
     CHECK(m.apply(ReloadHeld)==ReloadHeld&&m.apply(WheelHeld)==WheelHeld&&m.apply(JumpHeld)==JumpHeld);
     CHECK(m.apply(ToggleHeld)==ToggleHeld&&m.apply(SprintHeld)==SprintHeld&&m.apply(InteractHeld)==ContextHeld);
     CHECK(m.apply(0)==0&&m.apply(SupportGrip|WeaponGrip)==0);   // only the six buttons go through the map
     CHECK(m.buttonFor(ButtonFunction::CharacterWheel)==int(PhysButton::Y)&&m.buttonFor(ButtonFunction::Pause)==-1);
     // Remapped: Y = pause menu, X = character wheel, B = nothing; two buttons may share a function.
     m.set(PhysButton::Y,ButtonFunction::Pause);m.set(PhysButton::X,ButtonFunction::CharacterWheel);m.set(PhysButton::B,ButtonFunction::None);
     m.set(PhysButton::A,ButtonFunction::Context);
     CHECK(!m.isDefault()&&m.apply(ToggleHeld)==PauseHeld&&m.apply(JumpHeld)==ToggleHeld&&m.apply(WheelHeld)==0);
     CHECK(m.apply(ReloadHeld|InteractHeld)==ContextHeld&&m.apply(physicalMask)==(PauseHeld|ToggleHeld|ContextHeld|SprintHeld));}

    // --- Stick as arrow keys: one step, again after 0.4 s, then every 0.11 s; hysteresis; direction changes.
    {StickRepeat r;CHECK(r.update(0,0,0)==StickDir::None&&r.update(.5f,0,0)==StickDir::None);   // under 0.6: nothing
     CHECK(r.update(0,.9f,1000)==StickDir::Up);CHECK(r.update(0,.9f,1001)==StickDir::None&&r.update(0,.9f,1399)==StickDir::None);
     CHECK(r.update(0,.9f,1400)==StickDir::Up&&r.update(0,.9f,1509)==StickDir::None&&r.update(0,.9f,1510)==StickDir::Up);
     CHECK(r.update(0,.4f,1600)==StickDir::None&&r.holding()==StickDir::Up);   // still held at 0.4 (hysteresis) ...
     CHECK(r.update(0,.4f,1620)==StickDir::Up);                                // ... and repeating
     CHECK(r.update(0,.2f,1700)==StickDir::None&&r.holding()==StickDir::None); // let go
     CHECK(r.update(-.95f,.1f,2000)==StickDir::Left);
     CHECK(r.update(.2f,-.9f,2100)==StickDir::Down);                           // another direction takes over at once
     CHECK(r.update(.7f,.65f,2200)==StickDir::Right);                          // diagonal: the larger axis
     CHECK(StickRepeat::direction(NAN,1,.5f)==StickDir::None&&StickRepeat::direction(0,-1,.5f)==StickDir::Down);
     CHECK(arrowScan(StickDir::Up)==scan::Up&&arrowScan(StickDir::Left)==scan::Left&&arrowScan(StickDir::None)==0);}

    // --- Key taps: down once, up after 60 ms; a second tap of a held key makes it longer; release all.
    {KeyTaps k;std::string ups;auto up=[&](const KeyTap& t){ups+=std::to_string(t.code)+",";};
     CHECK(k.press(scan::Enter,false,100)&&k.isDown(scan::Enter)&&k.held()==1);
     CHECK(!k.press(scan::Enter,false,130));                                    // already down: longer
     CHECK(k.press(scan::Up,true,140));
     CHECK(k.release(159,up)==0&&k.release(189,up)==0);                         // Enter until 190 now
     CHECK(k.release(190,up)==1&&ups=="28,");
     CHECK(k.release(200,up)==1&&ups=="28,72,"&&k.held()==0);
     for(int i=0;i<8;++i)CHECK(k.press(std::uint16_t(10+i),false,0));
     CHECK(!k.press(99,false,0)&&k.held()==8);                                  // full: no more
     CHECK(k.release(1,up,true)==8&&k.held()==0);}

    // --- The VR menu: open, move, change, reset, close.
    {VrMenu menu;MenuSettings s;
     CHECK(!menu.opened()&&menu.input(StickDir::Down,false,false,s).result==VrMenu::Result::None);   // closed: nothing
     menu.open();CHECK(menu.opened()&&menu.selected()==MenuItem::ButtonY);
     CHECK(menuValue(MenuItem::ButtonY,s)=="GTA's character wheel"&&menuValue(MenuItem::RightClick,s)=="GTA's action key (E)");
     auto o=menu.input(StickDir::Up,false,false,s);CHECK(o.result==VrMenu::Result::Moved&&menu.selected()==MenuItem::Close);   // wraps round
     o=menu.input(StickDir::Down,false,false,s);CHECK(menu.selected()==MenuItem::ButtonY);
     o=menu.input(StickDir::Right,false,false,s);CHECK(o.result==VrMenu::Result::Changed&&o.item==MenuItem::ButtonY);
     CHECK(s.buttons.of(PhysButton::Y)==ButtonFunction::Run);
     o=menu.input(StickDir::Left,false,false,s);o=menu.input(StickDir::Left,false,false,s);CHECK(s.buttons.of(PhysButton::Y)==ButtonFunction::Jump);
     for(int i=0;i<functionCount;++i)menu.input(StickDir::None,true,false,s);   // A: forward; a full round comes back
     CHECK(s.buttons.of(PhysButton::Y)==ButtonFunction::Jump);
     CHECK(menu.input(StickDir::None,false,false,s).result==VrMenu::Result::None);
     // Snap turn: off, 15 .. 90.
     while(menu.selected()!=MenuItem::SnapTurn)menu.input(StickDir::Down,false,false,s);
     CHECK(menuValue(MenuItem::SnapTurn,s)=="snap 30 degrees");
     menu.input(StickDir::Right,false,false,s);CHECK(s.snapOn&&s.snapDegrees==45);
     menu.input(StickDir::Left,false,false,s);menu.input(StickDir::Left,false,false,s);menu.input(StickDir::Left,false,false,s);
     CHECK(!s.snapOn&&menuValue(MenuItem::SnapTurn,s)=="off");
     menu.input(StickDir::Left,false,false,s);CHECK(s.snapOn&&s.snapDegrees==90);
     menu.input(StickDir::Down,false,false,s);CHECK(menu.selected()==MenuItem::GtaAim&&s.gtaAim);
     menu.input(StickDir::None,true,false,s);CHECK(!s.gtaAim&&menuValue(MenuItem::GtaAim,s)=="off");
     menu.input(StickDir::Down,false,false,s);menu.input(StickDir::Right,false,false,s);CHECK(!s.pauseOnDashboard);
     menu.input(StickDir::Down,false,false,s);menu.input(StickDir::Left,false,false,s);CHECK(!s.wheelFlat&&menuValue(MenuItem::WheelView,s)=="VR");
     menu.input(StickDir::Down,false,false,s);CHECK(menu.selected()==MenuItem::ResetButtons);
     CHECK(menu.input(StickDir::Right,false,false,s).result==VrMenu::Result::None&&!s.buttons.isDefault());   // the action needs A
     o=menu.input(StickDir::None,true,false,s);CHECK(o.result==VrMenu::Result::Reset&&s.buttons.isDefault());
     CHECK(!s.gtaAim&&!s.pauseOnDashboard&&!s.wheelFlat);                       // only the buttons go back
     menu.input(StickDir::Down,false,false,s);CHECK(menu.selected()==MenuItem::Close);
     o=menu.input(StickDir::None,true,false,s);CHECK(o.result==VrMenu::Result::Close&&!menu.opened());
     menu.open();o=menu.input(StickDir::Down,false,true,s);CHECK(o.result==VrMenu::Result::Close&&!menu.opened());   // B closes anywhere
     for(int i=0;i<menuItemCount;++i)CHECK(std::string(menuLabel(MenuItem(i))).size()>3);}

    // --- Random input never leaves the menu in a bad state.
    {std::mt19937 rng(155);VrMenu menu;MenuSettings s;unsigned closes=0;
     for(int n=0;n<20000;++n){if(!menu.opened())menu.open();
        StickDir d=StickDir(rng()%5);bool a=rng()%7==0,b=rng()%41==0;
        auto o=menu.input(d,a,b,s);if(o.result==VrMenu::Result::Close)++closes;
        CHECK(int(menu.selected())>=0&&int(menu.selected())<menuItemCount);
        for(int i=0;i<physCount;++i){int f=int(s.buttons.of(PhysButton(i)));CHECK(f>=0&&f<functionCount);}
        CHECK(!s.snapOn||(s.snapDegrees>=15&&s.snapDegrees<=90));}
     CHECK(closes>0);}
    std::cout<<checks<<" VR menu / button map / menu key checks passed (vr_menu.hpp). GTA NOT exercised.\n";
    return 0;
}catch(const std::exception& e){std::cerr<<"FAILED: "<<e.what()<<"\n";return 1;}}
