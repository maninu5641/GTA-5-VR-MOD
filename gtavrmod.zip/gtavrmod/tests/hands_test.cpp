// Hands / arms (0.4.0): geometry, IK, button gesture, gesture names, overlay camera.
// No D3D11, SteamVR or GTA involved.
#include "hand_poses.hpp"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

using namespace handvr;using namespace handvr::test;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static Pose at(Vec3 p,float yawDegrees=0){Pose t{};float c=std::cos(rad(yawDegrees)),s=std::sin(rad(yawDegrees));
    // yaw about +Y (OpenVR): columns = right, up, back
    t.m[0][0]=c;t.m[0][2]=s;t.m[1][1]=1;t.m[2][0]=-s;t.m[2][2]=c;t.m[0][3]=p.x;t.m[1][3]=p.y;t.m[2][3]=p.z;return t;}

int main(){try{
    // --- Synthetic hands are plausible; corrupted ones are rejected.
    auto open=syntheticHand(openHand());CHECK(plausible(open));
    auto bad=open;bad.model[5].x=std::numeric_limits<float>::quiet_NaN();CHECK(!plausible(bad));
    bad=open;bad.model[12]={0,0,-2};CHECK(!plausible(bad));
    bad=open;bad.valid=false;CHECK(!plausible(bad));
    bad=open;bad.root.m[0][0]=5;CHECK(!plausible(bad));
    // Finger segments keep their lengths when curled.
    auto closed=syntheticHand(fist());
    for(unsigned f=1;f<=4;++f){unsigned b=fingerBase(f);for(unsigned k=2;k<5;++k)CHECK(near(length(open.model[b+k]-open.model[b+k-1]),length(closed.model[b+k]-closed.model[b+k-1])));}
    // Curled fingertips end up near the palm, below it (palm faces -Y).
    CHECK(length(closed.model[BoneIndex4]-closed.model[BoneWrist])<length(open.model[BoneIndex4]-open.model[BoneWrist])-.05f);
    CHECK(closed.model[BoneMiddle4].y<-.02f);

    // --- Capsules: thumb 3 + fingers 12 + palm 9 + arm 2.
    HandColors colors{srgb(200,160,130),srgb(60,60,60),{}};ArmSettings arm;
    Pose head=at({0,1.7f,0});
    Pose hand=at({.2f,1.2f,-.35f});
    auto right=syntheticHand(openHand(),false,hand);
    std::vector<Capsule> caps;handCapsules(right,head,1,arm,colors,caps);CHECK(caps.size()==26);
    for(auto& c:caps){CHECK(finite(c.a)&&finite(c.b));CHECK(c.ra>.005f&&c.rb>.005f&&c.ra<.06f&&c.rb<.06f);}
    CHECK(near(caps[24].a,right.world(BoneWrist)));                                           // forearm starts at the wrist
    CHECK(near(caps[24].color,colors.skin)&&near(caps[25].color,colors.sleeve));               // upper arm = sleeve
    caps.clear();arm.arms=false;handCapsules(right,head,1,arm,colors,caps);CHECK(caps.size()==24);arm.arms=true;
    caps.clear();handCapsules(bad,head,1,arm,colors,caps);CHECK(caps.empty());
    // Root pose places the hand in tracking space.
    CHECK(near(right.world(BoneWrist),hand.pos()));
    CHECK(near(right.world(BoneMiddle1),hand.pos()+Vec3{-.008f,0,-.092f}));

    // --- Arm IK
    for(float side:{-1.0f,1.0f}){
        Vec3 wrist{side*.25f,1.25f,-.30f};
        auto j=solveArm(head,wrist,{0,0,-1},side,arm);
        CHECK(near(length(j.elbow-j.shoulder),arm.upperArm,1e-3f));
        CHECK(near(length(j.wrist-j.elbow),arm.forearm,1e-3f));
        CHECK(j.shoulder.x*side>0);                              // shoulder on the hand's side
        CHECK(near(j.shoulder.y,1.7f-arm.shoulderDrop));
        // Relaxed arm: elbow lower than the straight shoulder-wrist line midpoint.
        CHECK(j.elbow.y<(j.shoulder.y+j.wrist.y)*.5f);
    }
    {   // Mirror symmetry
        auto l=solveArm(head,{-.25f,1.25f,-.3f},{0,0,-1},-1,arm),r=solveArm(head,{.25f,1.25f,-.3f},{0,0,-1},1,arm);
        CHECK(near(l.elbow,{-r.elbow.x,r.elbow.y,r.elbow.z},1e-4f));}
    {   // Out of reach: arm fully straight towards the hand.
        Vec3 wrist{.2f,1.5f,-1.5f};auto j=solveArm(head,wrist,{0,0,-1},1,arm);
        Vec3 d1=unit(j.elbow-j.shoulder),d2=unit(wrist-j.shoulder);CHECK(dot(d1,d2)>.9999f);
        CHECK(near(length(j.elbow-j.shoulder),arm.upperArm,2e-3f));}
    {   // Shoulders follow head yaw (turned 90 degrees left, right shoulder moves to -Z).
        Pose turned=at({0,1.7f,0},90);CHECK(shoulderPosition(turned,1,arm).z< -.1f);}
    {   // Arm length scale
        ArmSettings longer=arm;longer.lengthScale=1.2f;auto j=solveArm(head,{.25f,1.25f,-.3f},{0,0,-1},1,longer);
        CHECK(near(length(j.elbow-j.shoulder),arm.upperArm*1.2f,1e-3f));}

    // --- Gestures from the user's photos (hand tracking = full skeleton).
    CHECK(classifyGesture(syntheticHand(openHand()).curl)==Gesture::Open);
    CHECK(classifyGesture(syntheticHand(thumbsUp()).curl)==Gesture::ThumbsUp);
    CHECK(classifyGesture(syntheticHand(fist()).curl)==Gesture::Fist);
    CHECK(classifyGesture(syntheticHand(threeFingers()).curl)==Gesture::Three);
    CHECK(classifyGesture(syntheticHand(middleFinger()).curl)==Gesture::MiddleFinger);
    CHECK(classifyGesture(syntheticHand({1,0,1,1,1}).curl)==Gesture::Point);
    CHECK(classifyGesture(syntheticHand({0,0,1,1,1}).curl)==Gesture::Gun);
    CHECK(std::string(gestureName(Gesture::MiddleFinger))=="middle finger");
    // Oculus Touch (one grip value for middle/ring/pinky) can never show the middle finger alone...
    for(float t=0;t<=1;t+=.25f)for(float i=0;i<=1;i+=.25f)for(float g=0;g<=1;g+=.25f)
        CHECK(classifyGesture(syntheticHand(touchPose(t,i,g)).curl)!=Gesture::MiddleFinger);
    // ...so the button combo straightens it: a fist becomes the middle finger.
    {   auto h=syntheticHand(fist());auto original=h;straightenFinger(h,2,1);
        CHECK(classifyGesture(h.curl)==Gesture::MiddleFinger);
        unsigned b=fingerBase(2);Vec3 dir=unit(original.model[b+1]-original.model[b]);
        for(unsigned k=2;k<5;++k){CHECK(near(length(h.model[b+k]-h.model[b+k-1]),length(original.model[b+k]-original.model[b+k-1])));
            CHECK(dot(unit(h.model[b+k]-h.model[b+k-1]),dir)>.9999f);}
        for(unsigned i=0;i<HandBoneCount;++i)if(i<b||i>b+4)CHECK(near(h.model[i],original.model[i],0));   // other bones untouched
        // The raised finger points along the hand, like the photo (close to the open-hand middle finger).
        auto openH=syntheticHand(openHand());CHECK(length(h.model[BoneMiddle4]-openH.model[BoneMiddle4])<.012f);
        auto none=syntheticHand(fist());straightenFinger(none,2,0);CHECK(near(none.model[BoneMiddle4],original.model[BoneMiddle4],0));
        auto half=syntheticHand(fist());straightenFinger(half,2,.5f);
        CHECK(near(half.model[BoneMiddle4],(original.model[BoneMiddle4]+h.model[BoneMiddle4])*.5f));}
    {   // Combo: grip + trigger + stick click; click hidden while latched; blocked in vehicles.
        GestureCombo c;
        CHECK(!c.update(1,1,false,true,.016f));CHECK(c.blend()==0);
        CHECK(!c.update(.5f,1,true,true,.016f));                      // no fist: normal click passes through
        CHECK(!c.update(1,1,false,true,.016f));
        CHECK(c.update(1,1,true,true,.016f));CHECK(c.blend()>0&&c.blend()<1);
        for(int i=0;i<6;++i)c.update(1,1,true,true,.016f);CHECK(c.blend()==1);
        CHECK(c.update(.2f,.1f,true,true,.016f));                      // releasing grip first keeps the click hidden
        CHECK(!c.update(.2f,.1f,false,true,.016f));                    // stick released: done
        for(int i=0;i<6;++i)c.update(0,0,false,true,.016f);CHECK(c.blend()==0);
        CHECK(!c.update(1,1,true,false,.016f));CHECK(c.blend()==0);   // in a vehicle / disabled
        CHECK(c.update(1,1,true,true,std::numeric_limits<float>::quiet_NaN())&&c.blend()==0);}
    CHECK(std::string(trackingLevelName(1)).find("Touch")!=std::string::npos);

    // --- Overlay camera matches GTA's symmetric eye frustum.
    {   Pose eye=at({.03f,1.7f,0});Mat4 vp=multiply(perspective(90,16.0f/9,.02f,30),viewMatrix(eye));
        auto c=transformPoint(vp,{.03f,1.7f,-1});CHECK(near(c[0]/c[3],0)&&near(c[1]/c[3],0));CHECK(c[2]/c[3]>0&&c[2]/c[3]<1);
        auto top=transformPoint(vp,{.03f,2.7f,-1});CHECK(near(top[1]/top[3],1));             // tan(45) = 1 m up at 1 m
        auto edge=transformPoint(vp,{.03f+16.0f/9,1.7f,-1});CHECK(near(edge[0]/edge[3],1));
        auto behind=transformPoint(vp,{.03f,1.7f,1});CHECK(behind[3]<0);
        auto nearPlane=transformPoint(vp,{.03f,1.7f,-.02f});CHECK(near(nearPlane[2]/nearPlane[3],0,1e-4f));
        auto farPlane=transformPoint(vp,{.03f,1.7f,-30});CHECK(near(farPlane[2]/farPlane[3],1,1e-4f));
        // Turned eye: a point to its own front is centred.
        Pose yawed=at({0,1.7f,0},90);Mat4 vp2=multiply(perspective(90,1,.02f,30),viewMatrix(yawed));
        auto f=transformPoint(vp2,Vec3{0,1.7f,0}-yawed.col(2));CHECK(near(f[0]/f[3],0)&&near(f[1]/f[3],0)&&f[3]>0);}
    {   Pose h=at({1,2,3},30);Pose offset=at({-.032f,0,0});Pose e=compose(h,offset);
        CHECK(near(e.pos(),h.pos()+h.col(0)*-.032f));CHECK(near(e.col(2),h.col(2)));}

    // --- Mesh and colours
    {   std::vector<CapsuleVertex> v;std::vector<std::uint16_t> idx;capsuleMesh(v,idx,6,14);
        CHECK(v.size()==2*7*14);CHECK(idx.size()==(2*7-1)*14*6);
        for(auto i:idx)CHECK(i<v.size());
        for(auto& x:v){CHECK(near(x.n[0]*x.n[0]+x.n[1]*x.n[1]+x.n[2]*x.n[2],1,1e-4f));CHECK(x.end==0?x.n[1]<=1e-6f:x.n[1]>=-1e-6f);}}
    CHECK(daylightFactor(12)==1&&daylightFactor(2)<.5f&&daylightFactor(6)>daylightFactor(5)&&daylightFactor(19)<1&&daylightFactor(-1)==1);
    CHECK(!near(defaultSkin(0x9B22DBAFu),defaultSkin(0x0D7114C9u),.01f));
    CHECK(near(srgb(255,255,255),{1,1,1})&&near(srgb(0,0,0),{0,0,0}));
    std::cout<<checks<<" hand/arm checks passed (geometry, IK, Touch middle-finger combo, gestures, overlay camera). D3D11 drawing, SteamVR skeleton data and GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
