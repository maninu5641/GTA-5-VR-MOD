// 0.4.1 camera stabilisation: level horizon, body-anchored eye, stereo gate.
#include "camera_anchor.hpp"
#include "stereo.hpp"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static Pose identityAt(Vec3 p){Pose t{};t.m[0][0]=t.m[1][1]=t.m[2][2]=1;t.m[0][3]=p.x;t.m[1][3]=p.y;t.m[2][3]=p.z;return t;}

int main(){try{
    // --- Heading frame matches GTA's camera yaw convention (cameraBasis).
    for(float h=-180;h<=180;h+=15){CHECK(near(headingForward(h),cameraBasis({0,0,h}).forward));CHECK(near(headingRight(h),cameraBasis({0,0,h}).right));
        Vec3 v{1.5f,-.4f,.7f};CHECK(near(fromPedLocal(toPedLocal(v,h),h),v));}
    // --- Level horizon: a game camera looking 30 degrees down with roll no longer tilts the VR view.
    {   Vec3 tilted{-30,8,75};Basis level=cameraBasis(levelRotation(tilted));
        CHECK(near(level.up,{0,0,1}));CHECK(near(level.forward.z,0));CHECK(near(level.forward,cameraBasis({0,0,75}).forward));
        Pose head=identityAt({0,1.7f,0});
        auto before=trackedCamera(head,yawPose(head),{0,0,1.6f},cameraBasis(tilted),1,.75f);
        auto after=trackedCamera(head,yawPose(head),{0,0,1.6f},level,1,.75f);
        CHECK(before.basis.forward.z<-.4f);                       // 0.4.0: looking straight ahead in the headset showed the ground
        CHECK(near(after.basis.forward.z,0)&&near(after.basis.up,{0,0,1}));}
    // --- Eye anchor: calibrates from the game camera, then ignores head bob.
    {   EyeAnchor a;Vec3 ped{100,200,30};float heading=40;Vec3 eye=fromPedLocal({0,.1f,.65f},heading);
        std::uint64_t t=1000;
        for(int i=0;i<19;++i){Vec3 bob{0,0,.04f*std::sin(i*.9f)};Vec3 out=a.update(ped,heading,ped+eye+bob,t+=16);CHECK(near(out,ped+eye+bob));}
        CHECK(!a.ready());a.update(ped,heading,ped+eye,t+=16);CHECK(a.ready());
        CHECK(near(a.localOffset(),{0,.1f,.65f},.02f));
        // Walking: body moves smoothly, game camera bobs 4 cm; the anchored eye does not bob.
        float maxBob=0;
        for(int i=0;i<60;++i){Vec3 p=ped+Vec3{0,.02f*i,0};Vec3 bob{0,0,.04f*std::sin(i*.9f)};Vec3 out=a.update(p,heading,p+eye+bob,t+=16);
            maxBob=std::max(maxBob,std::abs(out.z-(p+eye).z));}
        CHECK(maxBob<.02f);
        // Turning the body rotates the offset with it.
        Vec3 turned=a.update(ped,heading+90,ped+fromPedLocal({0,.1f,.65f},heading+90),t+=16);
        CHECK(near(turned,ped+fromPedLocal(a.localOffset(),heading+90)));
        // Crouch: eye 40 cm lower for more than 0.4 s -> re-measured.
        Vec3 crouch=fromPedLocal({0,.15f,.25f},heading);unsigned before=a.recalibrations;
        for(int i=0;i<40;++i)a.update(ped,heading,ped+crouch,t+=16);
        CHECK(a.recalibrations==before+1);for(int i=0;i<25;++i)a.update(ped,heading,ped+crouch,t+=16);
        CHECK(a.ready()&&near(a.localOffset(),{0,.15f,.25f},.01f));
        // A short spike (one animation frame) does not re-measure.
        before=a.recalibrations;a.update(ped,heading,ped+eye,t+=16);a.update(ped,heading,ped+crouch,t+=16);CHECK(a.recalibrations==before);
        // A game camera far from the body (cinematic / frozen) is ignored.
        Vec3 out=a.update(ped,heading,ped+Vec3{30,0,0},t+=16);CHECK(near(out,ped+fromPedLocal(a.localOffset(),heading)));
        // Invalid body data falls back to the game camera.
        Vec3 nanPed{std::numeric_limits<float>::quiet_NaN(),0,0};CHECK(near(a.update(nanPed,heading,{1,2,3},t+=16),{1,2,3}));
        // In a vehicle the eye follows the vehicle exactly (no lag at speed).
        EyeAnchor car;Vec3 seat=fromPedLocal({-.35f,.05f,.45f},0);
        for(int i=0;i<20;++i)car.update({0,0,0},0,seat,t+=16);
        for(int i=0;i<30;++i){Vec3 p{0,30.0f*i*.016f,0};CHECK(near(car.update(p,0,p+seat,t+=16),p+seat,.01f));}}
    // --- 0.16.2: the view's own heading on foot; snap turns from the add-on's running total; the body's heading.
    {   ViewYaw v;CHECK(!v.on());CHECK(v.snapTotal(500)==0);                     // first value read: the start
        v.start(120,30);CHECK(v.on()&&near(v.value(),90));                         // you look 30 deg left of the origin: view = character
        v.turn(-20);CHECK(near(v.value(),70));
        CHECK(near(v.snapTotal(530),30)&&near(v.value(),100));                    // a 30 deg snap turn left
        CHECK(near(v.snapTotal(500),-30)&&near(v.value(),70));                    // and right
        CHECK(v.snapTotal(500)==0);
        CHECK(near(v.snapTotal(10),-490)&&near(v.value(),-60));                    // a big jump of the total is still a turn (wrapped)
        ViewYaw w;w.snapTotal(10);w.start(0,0);
        CHECK(near(w.snapTotal(65526),-20)&&near(w.value(),-20));                 // across the 16-bit wrap: 10 -> -10
        CHECK(near(w.snapTotal(20),30)&&near(w.value(),10));                      // and back over it
        w.stop();CHECK(w.snapTotal(50)==0&&near(w.value(),10));                   // off (a vehicle): not turned, still followed
        w.start(0,0);CHECK(near(w.snapTotal(80),30));
        v.start(NAN,0);CHECK(!v.on());v.start(170,-30);CHECK(near(v.value(),-160)); // wraps at +-180
        v.unsync();CHECK(v.snapTotal(9000)==0);
        CHECK(near(bodyHeading(90,.5f,.5f),90));CHECK(near(bodyHeading(90,pi/2,0),180)||near(bodyHeading(90,pi/2,0),-180));
        CHECK(near(bodyHeading(-170,-pi/6,0),160));}
    // --- 0.16.2: on foot the eye stays on the body (the developer's 0.16.1 log: measured 0.37-0.48 m in front of it).
    {   std::uint64_t t=5000;Vec3 ped{10,20,30};float heading=-30;
        Vec3 upright{.01f,.08f,.68f},bent{.03f,.48f,.41f},aside{-.10f,.14f,.70f};
        CHECK(uprightEye(upright)&&!uprightEye(bent)&&!uprightEye(aside));
        CHECK(near(onFootEye(bent),{.03f,.14f,.45f}));CHECK(near(onFootEye(upright),upright));
        // Bent over (GTA's camera pitched down after the SteamVR menu) while it measures: skipped, the view stays on the
        // body (the last offset), then the first upright moments are measured.
        EyeAnchor a;
        for(int i=0;i<60;++i){Vec3 out=a.update(ped,heading,ped+fromPedLocal(bent,heading),t+=16,false,true);
            CHECK(near(out,ped+fromPedLocal({0,.08f,.62f},heading)));}
        CHECK(!a.ready()&&a.leaningSkipped==60);
        for(int i=0;i<20;++i)a.update(ped,heading,ped+fromPedLocal(upright,heading),t+=16,false,true);
        CHECK(a.ready()&&near(a.localOffset(),upright,.005f));
        // A lean that lasts (GTA's aim pose, looking down): no re-measure, the eye stays where it was.
        for(int i=0;i<150;++i){Vec3 out=a.update(ped,heading,ped+fromPedLocal(bent,heading),t+=16,false,true);CHECK(near(out,ped+fromPedLocal(upright,heading),.005f));}
        CHECK(a.recalibrations==0);
        // Head turned aside by GTA (its camera far from the body's heading): limited to 4 cm.
        EyeAnchor s;for(int i=0;i<25;++i)s.update(ped,heading,ped+fromPedLocal({-.07f,.12f,.70f},heading),t+=16,false,true);
        CHECK(s.ready()&&near(s.localOffset(),{-.04f,.12f,.70f},.005f));
        // Never upright for 2.5 s: measured as ready with the last offset (no endless wait).
        EyeAnchor n;for(int i=0;i<170;++i)n.update(ped,heading,ped+fromPedLocal(bent,heading),t+=16,false,true);
        CHECK(n.ready()&&near(n.localOffset(),{0,.08f,.62f}));
        // An offset measured off foot (a seat, cover) is limited once on foot again.
        EyeAnchor c;for(int i=0;i<20;++i)c.update(ped,heading,ped+fromPedLocal({-.30f,.20f,.40f},heading),t+=16);
        CHECK(near(c.update(ped,heading,ped+fromPedLocal(upright,heading),t+=16,false,true),ped+fromPedLocal({-.04f,.14f,.45f},heading)));}
    // --- Stereo gate
    {   StereoGate g;std::uint64_t t=0;
        CHECK(!g.update(false,true,t));                         // soft stop never starts stereo
        CHECK(g.update(false,false,t+=16));
        CHECK(g.update(false,true,t+=16));CHECK(g.update(false,true,t+=200));   // brief control loss: stay in VR
        CHECK(!g.update(false,true,t+=150));                    // > 300 ms: cinema
        CHECK(!g.update(false,true,t+=16));
        CHECK(g.update(false,false,t+=16));
        CHECK(!g.update(true,false,t+=16));                     // cutscene / pause: immediate
        CHECK(!g.update(false,true,t+=16));
        CHECK(g.update(false,false,t+=16));
        CHECK(g.update(false,true,t+=100));CHECK(g.update(false,false,t+=16));CHECK(g.update(false,true,t+=250));   // timer restarts
        g.reset();CHECK(!g.update(false,true,t+=16));}
    // --- Yaw stabiliser: animation wobble removed, deliberate turns kept.
    {   YawStabilizer y;float dt=1/60.0f;float out=y.update(90,dt);CHECK(out==90);
        float worst=0;for(int i=1;i<600;++i){float raw=90+1.2f*std::sin(i*.35f);out=y.update(raw,dt);if(i>60)worst=std::max(worst,std::abs(out-90));}
        CHECK(worst<.35f);                                                   // +/-1.2 deg wobble -> < 0.35 deg
        CHECK(near(y.update(120,dt),120));                                  // 30 deg snap turn: immediate
        float v=0;for(int i=0;i<120;++i)v=y.update(120+i*1.5f,dt);       // 90 deg/s stick turn
        CHECK(std::abs(wrapDegrees(v-(120+119*1.5f)))<8);                    // follows with a small lag
        YawStabilizer w;w.update(179,dt);CHECK(std::abs(wrapDegrees(w.update(-179,dt)-179))<2.1f);   // wraps at +/-180
        CHECK(near(wrapDegrees(540),180)||near(wrapDegrees(540),-180));CHECK(wrapDegrees(NAN)==0);
        YawStabilizer z;z.update(10,dt);CHECK(z.update(NAN,dt)==10);CHECK(z.update(50,.5f)==50);}   // long gap re-primes
    // --- Wall limiter: drops at once, recovers smoothly, never flickers.
    {   OffsetLimiter l;float dt=1/60.0f;CHECK(l.update(1,dt)==1);
        CHECK(near(l.update(.5f,dt),.35f));                                 // stop 15% before the wall
        float a=l.update(1,dt);CHECK(a>.35f&&a<.5f);                          // eases back
        for(int i=0;i<30;++i)a=l.update(1,dt);CHECK(a==1);
        // Probe alternating hit / clear every frame (the 0.4.0 flicker case): output stays near the low value.
        float lo=1,hi=0;for(int i=0;i<60;++i){float v=l.update(i%2?1.0f:.2f,dt);if(i>10){lo=std::min(lo,v);hi=std::max(hi,v);}}
        CHECK(hi-lo<.08f);
        CHECK(l.update(NAN,dt)>0);l.reset();CHECK(l.update(1,dt)==1);}
    std::cout<<checks<<" camera stabilisation checks passed (level horizon, body anchor without head bob, re-measure on crouch/seat, stereo gate). GTA camera behaviour NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
