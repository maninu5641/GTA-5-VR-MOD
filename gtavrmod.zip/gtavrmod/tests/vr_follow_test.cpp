// 0.10.0: room-scale follow, offset consumption, body turn, crouch detection.
#include "vr_follow.hpp"
#include "stereo.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}

int main(){try{
    // --- Headings
    {   CHECK(near(headingDifference(10,350),20));CHECK(near(headingDifference(350,10),-20));CHECK(near(headingDifference(90,90),0));
        CHECK(near(std::abs(headingDifference(180,0)),180));CHECK(near(headingDifference(NAN,3),0));
        CHECK(near(stepHeading(10,100,90,.25f),32.5f));CHECK(near(stepHeading(350,20,200,.25f),20));CHECK(near(stepHeading(5,330,120,.25f),335));CHECK(near(stepHeading(10,12,90,1),12));CHECK(near(stepHeading(10,100,90,1),32.5f));}   // one step covers at most 0.25 s
    // --- Room follow: a real step walks the character under the head; small leans do not.
    {   RoomFollow f;auto o=f.update({.25f,0,.3f},true,.016f);CHECK(!o.walk&&!f.active());                 // lean: below 30 cm (height ignored)
        o=f.update({.4f,0,0},true,.016f);CHECK(o.walk&&near(o.direction,{1,0,0})&&near(o.speed,.45f));
        o=f.update({.8f,.2f,0},true,.016f);CHECK(o.walk&&o.speed>.7f);
        o=f.update({.2f,0,0},true,.016f);CHECK(o.walk);                                                    // keeps going below the start distance
        o=f.update({.05f,0,0},true,.016f);CHECK(!o.walk&&!f.active());                                     // arrived
        o=f.update({.5f,0,0},false,.016f);CHECK(!o.walk);                                                  // stick / menu in use
        // Against a wall: no progress for 1.5 s -> stop, and stay stopped until the offset changes.
        RoomFollow w;w.update({.5f,0,0},true,.016f);int steps=0;while(w.update({.5f,0,0},true,.1f).walk&&steps<100)++steps;
        CHECK(steps>=14&&steps<=16&&w.blocked());CHECK(!w.update({.5f,0,0},true,.1f).walk);
        CHECK(w.update({0,-.5f,0},true,.1f).walk&&!w.blocked());                                          // the player moved elsewhere
        RoomFollow n;CHECK(!n.update({NAN,0,0},true,.1f).walk);}
    // --- Offset consumption: only the part of the movement toward the head, never past it.
    {   CHECK(near(consumeOffset({.5f,0,0},{.1f,0,0}),{.1f,0,0}));CHECK(near(consumeOffset({.5f,0,0},{.1f,.1f,0}),{.1f,0,0}));
        CHECK(near(consumeOffset({.5f,0,0},{-.1f,0,0}),{0,0,0}));CHECK(near(consumeOffset({.05f,0,0},{.3f,0,0}),{.05f,0,0}));
        CHECK(near(consumeOffset({.5f,0,0},{5,0,0}),{0,0,0}));CHECK(near(consumeOffset({.01f,0,0},{.01f,0,0}),{0,0,0}));
        CHECK(near(consumeOffset({0,.4f,.9f},{0,.1f,-.5f}),{0,.1f,0}));CHECK(near(consumeOffset({NAN,0,0},{.1f,0,0}),{0,0,0}));}
    // --- Body turn: a glance does nothing; facing elsewhere for 0.5 s turns the character.
    {   BodyTurn t;CHECK(!t.update(0,30,true,1));CHECK(!t.update(0,60,true,.3f));CHECK(t.update(0,60,true,.3f)&&near(t.target(),60));
        CHECK(t.update(30,62,true,.1f)&&near(t.target(),62));CHECK(!t.update(55,62,true,.1f));                 // within 10 degrees: done
        BodyTurn m;m.update(0,90,true,.4f);CHECK(!m.update(0,90,false,.4f)&&!m.active());                 // walking: no turn
        BodyTurn w;CHECK(!w.update(350,40,true,.3f));CHECK(w.update(350,40,true,.3f));                   // across north
        CHECK(!w.update(NAN,40,true,.1f));}
    // --- Crouch: 30 % lower for 0.3 s = crouch; back above 86 % = stand.
    {   CrouchDetector c;CHECK(c.update(1.6f,1.6f,.78f,.86f,.1f,true)==0&&!c.crouched());
        CHECK(c.update(1.1f,1.6f,.78f,.86f,.2f,true)==0);CHECK(c.update(1.1f,1.6f,.78f,.86f,.2f,true)==1&&c.crouched());
        CHECK(c.update(1.3f,1.6f,.78f,.86f,.5f,true)==0&&c.crouched());                                    // between thresholds: stays down
        CHECK(c.update(1.5f,1.6f,.78f,.86f,.2f,true)==0);CHECK(c.update(1.5f,1.6f,.78f,.86f,.2f,true)==-1&&!c.crouched());
        CHECK(c.update(1.0f,1.6f,.78f,.86f,.1f,true)==0);CHECK(c.update(1.6f,1.6f,.78f,.86f,.1f,true)==0);    // a quick dip does nothing
        c.update(1.0f,1.6f,.78f,.86f,.2f,true);c.update(1.0f,1.6f,.78f,.86f,.2f,true);CHECK(c.crouched());CHECK(c.update(1.0f,1.6f,.78f,.86f,.1f,false)==-1&&!c.crouched());   // not allowed (vehicle): stand
        CHECK(c.update(1.0f,0,.78f,.86f,1,true)==0&&c.update(NAN,1.6f,.78f,.86f,1,true)==0&&c.update(1.0f,1.6f,.9f,.8f,1,true)==0);}
    // --- The renderer's origin shift: world offset <-> tracking space round trip (yawed origin, scaled world).
    {   Pose head{};head.m[0][0]=head.m[1][1]=head.m[2][2]=1;head.m[0][3]=.4f;head.m[1][3]=1.6f;head.m[2][3]=-.3f;
        float yaw=.7f;Pose origin{};origin.m[0][0]=std::cos(yaw);origin.m[0][2]=std::sin(yaw);origin.m[1][1]=1;origin.m[2][0]=-std::sin(yaw);origin.m[2][2]=std::cos(yaw);origin.m[1][3]=1.6f;
        Basis base=cameraBasis({0,0,35});Vec3 w=trackedOffset(head,origin,base,1.2f);
        CHECK(near(length(w),1.2f*std::sqrt(.4f*.4f+.3f*.3f),1e-4f)&&std::abs(w.z)<1e-4f);                 // horizontal head move stays horizontal
        Vec3 back=worldToTracking(w,origin,base,1.2f);CHECK(near(back,head.pos()-origin.pos(),1e-4f));
        Vec3 used=consumeOffset(w,w*.5f);Vec3 t=worldToTracking(used,origin,base,1.2f);
        Pose moved=origin;moved.m[0][3]+=t.x;moved.m[2][3]+=t.z;CHECK(near(trackedOffset(head,moved,base,1.2f),w*.5f,1e-4f));}   // half the walk used up = half the offset left
    std::cout<<checks<<" follow checks passed (room-scale follow, offset consumption, body turn, crouch). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
