// 0.7.0: GTA model arms follow the real hands. 0.11.0: closed-loop reach, target readback, hand rotation learned from play.
#include "vr_arms.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static bool nearRot(const Rot& a,const Rot& b,float degrees=.5f){return rotAngleDegrees(a,b)<=degrees;}
static Rot axisAngle(Vec3 axis,float degrees){axis=unit(axis);float a=rad(degrees),c=std::cos(a),s=std::sin(a);
    auto r=[&](Vec3 v){return v*c+cross(axis,v)*s+axis*dot(axis,v)*(1-c);};return {r({1,0,0}),r({0,1,0}),r({0,0,1})};}

int main(){try{
    // --- Rotation helpers
    {   Rot i{};CHECK(nearRot(mul(i,i),i,1e-3f));Rot a=axisAngle({0,0,1},90);CHECK(near(apply(a,{1,0,0}),{0,1,0}));
        CHECK(near(rotAngleDegrees(i,a),90,1e-2f));CHECK(nearRot(mul(a,transpose(a)),i,.1f));CHECK(near(applyT(a,apply(a,{.3f,-.2f,.7f})),{.3f,-.2f,.7f}));
        Rot b=mul(axisAngle({1,2,3},37),axisAngle({-2,.5f,1},71));CHECK(orthonormalRot(b));
        RotAverage avg;avg.add(b);CHECK(nearRot(avg.mean(),b,.1f));                                   // quaternion round trip
        RotAverage two;two.add(axisAngle({0,0,1},10));two.add(axisAngle({0,0,1},30));CHECK(nearRot(two.mean(),axisAngle({0,0,1},20),.2f));
        Rot bad{{1,0,0},{1,0,0},{0,0,1}};CHECK(!orthonormalRot(bad));}
    // --- Bone frame from offset probes
    {   Rot r=axisAngle({.3f,1,.2f},50);Vec3 o{100,200,30};float s=.1f;Rot f;
        CHECK(boneFrame(o,o+r.x*s,o+r.y*s,o+r.z*s,s,f)&&nearRot(f,r,.1f));
        CHECK(!boneFrame(o,o,o,o,s,f));CHECK(!boneFrame(o,o+r.x*s,o+r.x*s,o+r.z*s,s,f));}
    // --- Anatomical frame: right hand palm down, fingers forward (+Y), index on the left.
    {   Rot a;CHECK(anatomicalFrame({0,0,0},{-.025f,.085f,0},{0,.09f,0},{.03f,.075f,0},a));
        CHECK(near(a.y,{0,1,0},1e-3f)&&near(a.x,{-1,0,0},1e-3f)&&near(a.z,{0,0,-1},1e-3f));CHECK(orthonormalRot(a));
        CHECK(!anatomicalFrame({0,0,0},{0,0,0},{0,0,0},{0,0,0},a));CHECK(!anatomicalFrame({0,0,0},{-.025f,.5f,0},{0,.5f,0},{.03f,.5f,0},a));}
    // --- Rig calibration: bone frame and anatomy differ by a fixed rotation M.
    {   Rot m=axisAngle({1,.4f,-.3f},73);RigCalibration rig;
        for(unsigned k=0;k<RigCalibration::Needed;++k){Rot bone=axisAngle({float(k%3)-1,1,.5f},float(k)*9);rig.add(bone,mul(bone,m));}
        CHECK(rig.ready()&&nearRot(rig.value(),m,.1f));
        Rot desired=axisAngle({0,1,1},33);CHECK(nearRot(mul(rig.boneFor(desired),m),desired,.1f));
        RigCalibration noisy;noisy.add(Rot{},m);noisy.add(Rot{},axisAngle({0,0,1},40));CHECK(!noisy.ready());}   // inconsistent sample restarts
    // --- Reach clamp
    {   Vec3 s{0,0,1.4f};CHECK(near(clampReach({0,1,1.4f},s,.6f),{0,.6f*.97f,1.4f},1e-4f));CHECK(near(clampReach({0,.3f,1.4f},s,.6f),{0,.3f,1.4f}));
        CHECK(near(clampReach({0,.02f,1.4f},s,.6f),{0,.10f,1.4f},1e-4f));CHECK(near(clampReach({0,1,1.4f},s,0),{0,1,1.4f}));}
    // --- 0.12.0: the renderer's open-loop rotation chain with simulated GTA bones. The knuckles are fixed in
    // the hand bone's local axes (rigid hand); bone axes come from offset points (GET_PED_BONE_COORDS offsets),
    // the knuckle frame from positions; any animated pose calibrates M; a bone turned to boneFor(desired)
    // puts the knuckle frame exactly on the desired frame - for a right and a mirrored left hand.
    {   for(int side=0;side<2;++side){float mx=side?-1.0f:1.0f;
            Vec3 index{.025f*mx,.09f,.01f},middle{.0f*mx,.095f,.012f},pinky{-.04f*mx,.08f,.005f};   // bone-local knuckles
            auto pose=[&](const Rot& b,Vec3 o,Rot& axes,Rot& knuckles){const float s=.1f;
                bool ok=boneFrame(o,o+apply(b,{s,0,0}),o+apply(b,{0,s,0}),o+apply(b,{0,0,s}),s,axes);
                return ok&&anatomicalFrame(o,o+apply(b,index),o+apply(b,middle),o+apply(b,pinky),knuckles);};
            RigCalibration rig;Vec3 o{1,2,3};
            for(unsigned k=0;k<RigCalibration::Needed;++k){Rot b=axisAngle({.2f,1,.3f*mx},10.0f+float(k)),axes{},kn{};CHECK(pose(b,o,axes,kn));rig.add(axes,kn);}
            CHECK(rig.ready());
            for(float deg:{0.0f,45.0f,120.0f,-160.0f}){Rot desired=axisAngle({1,-.5f,.2f*mx},deg);Rot want=rig.boneFor(desired),axes{},kn{};
                CHECK(orthonormalRot(want,1e-3f)&&pose(want,o,axes,kn)&&nearRot(kn,desired,.2f));}}}
    // --- 0.11.0: rotation blend, body frame from a GTA heading
    {   Rot z90=axisAngle({0,0,1},90);CHECK(nearRot(blendRot(Rot{},z90,.5f),axisAngle({0,0,1},45),.2f));
        CHECK(nearRot(blendRot(Rot{},z90,0),Rot{},.01f)&&nearRot(blendRot(Rot{},z90,1),z90,.05f)&&nearRot(blendRot(Rot{},z90,NAN),Rot{},.01f));
        Rot far=axisAngle({1,1,0},170),near170=axisAngle({1,1,0},-170);CHECK(nearRot(blendRot(far,near170,.5f),axisAngle({1,1,0},180),.3f));   // the short way round
        CHECK(nearRot(headingRot(0),Rot{},1e-3f));Rot w=headingRot(90);CHECK(near(w.x,{0,1,0},1e-5f)&&near(w.y,{-1,0,0},1e-5f)&&near(w.z,{0,0,1}));}
    // --- 0.11.0: closed-loop reach. Simulated GTA arm IK that carries out only part of each request
    // (k), from the animation's hand position, one or two updates late.
    {   const float dt=1.0f/36;Vec3 pose{0,0,0},goal{.3f,0,0};
        auto run=[&](float k,int lag,float seconds,float& worst){ReachLoop loop;Vec3 queue[4]{pose,pose,pose,pose};Vec3 hand=pose;worst=0;
            for(int i=0;i<int(seconds/dt);++i){Vec3 cmd=loop.update(goal,hand,dt);
                for(int j=3;j>0;--j)queue[j]=queue[j-1];queue[0]=cmd;
                Vec3 sent=queue[lag-1];hand=pose+(sent-pose)*k;worst=std::max(worst,hand.x);}
            return std::make_pair(hand,loop.correction());};
        float worst=0;auto r=run(.5f,1,4,worst);CHECK(near(r.first,goal,.01f)&&near(r.second,{.3f,0,0},.012f)&&worst<goal.x+.02f);   // half strength: twice as far
        r=run(.6f,2,4,worst);CHECK(near(r.first,goal,.01f)&&worst<goal.x+.02f);                                               // two updates late: no overshoot
        r=run(1,1,4,worst);CHECK(near(r.first,goal,.002f)&&length(r.second)<.003f);                                           // GTA does it all: nothing added
        // Fast moves are lag, not error: nothing integrated while the controller moves faster than FastHand.
        {ReachLoop l;Vec3 g{0,0,0};for(int i=0;i<36;++i){g.x+=2.0f*dt;l.update(g,{0,0,0},dt);}CHECK(length(l.correction())<1e-4f);
            for(int i=0;i<36;++i)l.update(g,g-Vec3{.1f,0,0},dt);CHECK(l.correction().x>.05f);}
        // GTA ignores the request: the correction stops at its limit, the miss is reported; after GiveUpSeconds
        // at the limit with no progress the loop switches itself off and the correction fades.
        {ReachLoop l;Vec3 g{.6f,0,0};for(int i=0;i<int(3/dt);++i)l.update(g,{.05f,0,0},dt);
            CHECK(near(length(l.correction()),ReachLoop::MaxCorrection,1e-3f)&&l.saturatedSeconds()>1.5f&&near(l.steadyMiss(),.55f,.01f)&&near(l.startMiss(),.55f,.01f)&&!l.unresponsive());
            for(int i=0;i<int(2/dt);++i)l.update(g,{.05f,0,0},dt);CHECK(l.unresponsive());
            for(int i=0;i<int(4/dt);++i)l.update(g,{.05f,0,0},dt);CHECK(length(l.correction())<.05f&&l.unresponsive());
            l.reset();CHECK(!l.unresponsive()&&std::isnan(l.startMiss()));
            // A weak IK (35 %) far from the controller: the correction saturates but the hand came much closer: stays on.
            ReachLoop k;Vec3 hand{0,0,0},far{.6f,0,0};for(int i=0;i<int(8/dt);++i){Vec3 c=k.update(far,hand,dt);hand=c*.35f;}
            CHECK(!k.unresponsive()&&k.saturatedSeconds()>ReachLoop::GiveUpSeconds&&k.steadyMiss()<k.startMiss()*ReachLoop::Helped);
            // No measurement (hand bone unknown): the correction fades; too far off (another place): not integrated.
            ReachLoop m;for(int i=0;i<int(2/dt);++i)m.update(g,{.05f,0,0},dt);
            for(int i=0;i<int(4/dt);++i)m.update(g,{NAN,0,0},dt);CHECK(length(m.correction())<.05f&&m.saturatedSeconds()==0);
            ReachLoop f;for(int i=0;i<36;++i)f.update(g,{-.5f,0,0},dt);CHECK(length(f.correction())<1e-4f&&std::isnan(f.steadyMiss()));}
        // The caller limits the target (reach): the correction follows what was sent.
        {ReachLoop l;l.update(goal,pose,dt);l.update(goal,pose,dt);l.sent(goal,goal+Vec3{0,.05f,0});CHECK(near(l.correction(),{0,.05f,0}));
            CHECK(near(l.update({NAN,0,0},pose,dt).x,NAN)||std::isnan(l.update({NAN,0,0},pose,dt).x));}}
    // --- 0.11.0: target readback (quaternion convention)
    {   Rot r=axisAngle({.2f,1,.4f},70),want=axisAngle({1,0,.3f},40);
        TargetReadback a;bool done=false;for(int i=0;i<20&&!done;++i)done=a.observe(r,r);CHECK(done&&a.state()==TargetReadback::State::Direct&&nearRot(a.command(want),want,1e-3f));
        TargetReadback b;done=false;for(int i=0;i<20&&!done;++i)done=b.observe(r,transpose(r));CHECK(done&&b.state()==TargetReadback::State::Transposed&&nearRot(b.command(want),transpose(want),1e-3f));
        TargetReadback c;done=false;for(int i=0;i<40&&!done;++i)done=c.observe(r,Rot{});CHECK(done&&c.state()==TargetReadback::State::Stuck);
        TargetReadback d;for(int i=0;i<50;++i)d.observe(axisAngle({0,0,1},5),Rot{});CHECK(d.state()==TargetReadback::State::Unknown);   // nearly symmetric: proves nothing
        Rot bad{{1,0,0},{1,0,0},{0,0,1}};for(int i=0;i<50;++i)d.observe(r,bad);CHECK(d.state()==TargetReadback::State::Unknown&&nearRot(d.command(want),want,1e-3f));}
    // --- 0.11.0: hand rotation learned from the player's own movements. Simulated GTA: with working flags
    // the hand = target * D, one update late; otherwise the animation keeps the hand's frame (relative to the body).
    {   const float dt=1.0f/36;Rot d=axisAngle({.3f,1,-.2f},55),anim=axisAngle({0,1,0},20);
        // The player's hand (relative to the body) turns slowly back and forth up to 70 degrees.
        auto desiredAt=[&](int i){return axisAngle({1,.2f,.3f},70*std::sin(float(i)*dt*.6f));};
        struct Result { HandTurn::State state;int flags;Rot hand;Rot desired; };
        auto run=[&](HandTurn& turn,int workingFlags,float seconds,float headingRate,bool withBody,float partial=1){
            Rot prev{};int prevFlags=0;bool have=false;Rot hand{},desired{};
            for(int i=0;i<int(seconds/dt);++i){Rot body=headingRot(headingRate*float(i)*dt);
                desired=withBody?mul(body,desiredAt(i)):mul(body,axisAngle({1,.2f,.3f},10));
                if(have){bool works=prevFlags==workingFlags;Rot follow=mul(prev,d),still=mul(body,anim);
                    hand=works?(partial<1?blendRot(still,follow,partial):follow):still;turn.observe(prev,hand,body,true,dt);}
                prev=turn.target(desired);prevFlags=turn.flags();have=true;}
            return Result{turn.state(),turn.flags(),hand,desired};};
        HandTurn a;CHECK(a.state()==HandTurn::State::Settling&&a.flags()==65&&a.active());
        auto r=run(a,65,12,0,true);CHECK(r.state==HandTurn::State::Working&&a.working()&&r.flags==65);
        CHECK(nearRot(a.response(),d,2)&&nearRot(r.hand,r.desired,4));                                    // the hand turns like yours
        HandTurn b;r=run(b,68,30,0,true);CHECK(r.state==HandTurn::State::Working&&r.flags==68&&b.candidate()==1);   // 65 ignored, 68 works
        HandTurn c;r=run(c,-1,40,0,true);CHECK(r.state==HandTurn::State::Ignored&&!c.active());          // neither: position only
        // Turning on the spot (body and hand together) proves nothing: never accepted, never rejected.
        HandTurn e;r=run(e,-1,40,30,false);CHECK(r.state==HandTurn::State::Judging&&e.candidate()==0&&e.turnedDegrees()<5);
        // Half-followed rotation is not accepted as working.
        HandTurn h;r=run(h,65,10,0,true,.5f);CHECK(r.state!=HandTurn::State::Working);
        // Working, then the hand stops following (another animation): measured again.
        {HandTurn w;run(w,65,12,0,true);CHECK(w.working());Rot prev=w.target(desiredAt(0));bool relearn=false;
            Rot other=axisAngle({0,0,1},120);int steps=0;
            for(int i=1;i<int(8/dt)&&!relearn;++i,++steps){relearn=w.observe(prev,other,Rot{},true,dt)&&w.state()==HandTurn::State::Settling;prev=w.target(desiredAt(i));}
            CHECK(relearn&&w.candidate()==0&&float(steps)*dt>HandTurn::RelearnSeconds&&float(steps)*dt<HandTurn::RelearnSeconds+1.5f);}
        // Not steady (fast turns): nothing learned.
        HandTurn n;for(int i=0;i<500;++i)n.observe(desiredAt(i),mul(desiredAt(i),d),Rot{},false,dt);CHECK(n.state()==HandTurn::State::Settling);
        CHECK(nearRot(n.target(anim),anim,1e-3f));}
    // --- 0.9.0: controller-only hand frame (no skeleton): fingers ahead, knuckles across = up.
    {   Pose aim{};aim.m[0][0]=1;aim.m[1][1]=1;aim.m[2][2]=1;Rot r=controllerAnatomy(aim);CHECK(near(r.x,{0,1,0})&&near(r.y,{0,0,-1})&&orthonormalRot(r));}
    std::cout<<checks<<" arm checks passed (bone / anatomical frames, rig calibration, open-loop rotation chain, reach clamp, closed-loop reach, target readback, hand rotation learning). GTA IK NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
