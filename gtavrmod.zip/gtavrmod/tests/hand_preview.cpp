// Dumps hand/arm capsules for the gesture preview images (tools/render_hand_preview.py).
#include "hand_poses.hpp"
#include <cstdio>
using namespace handvr;using namespace handvr::test;
int main(){
    // Right hand, palm towards the viewer, fingers up, 35 cm in front of the eyes.
    Pose root{};root.m[0][0]=-1;root.m[1][2]=-1;root.m[2][1]=-1;root.m[0][3]=.05f;root.m[1][3]=1.42f;root.m[2][3]=-.33f;
    Pose head{};head.m[0][0]=head.m[1][1]=head.m[2][2]=1;head.m[1][3]=1.6f;
    struct Item{const char* name;Curls c;bool combo;};
    Item items[]={{"Mao aberta",openHand(),false},{"Joinha",thumbsUp(),false},{"Punho",fist(),false},
        {"Tres dedos (hand tracking)",threeFingers(),false},{"Dedo do meio (hand tracking)",middleFinger(),false},{"Dedo do meio (Touch: combo)",fist(),true}};
    HandColors colors{defaultSkin(0x9B810FA2u),defaultSkin(0x9B810FA2u),{}};ArmSettings arm;
    std::printf("[\n");
    for(unsigned n=0;n<6;++n){auto h=syntheticHand(items[n].c,false,root);if(items[n].combo)straightenFinger(h,2,1);
        std::vector<Capsule> caps;handCapsules(h,head,1,arm,colors,caps);
        std::printf("{\"name\":\"%s\",\"gesture\":\"%s\",\"capsules\":[",items[n].name,gestureName(classifyGesture(h.curl)));
        for(size_t i=0;i<caps.size();++i){auto& c=caps[i];std::printf("%s[%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f]",i?",":"",c.a.x,c.a.y,c.a.z,c.ra,c.b.x,c.b.y,c.b.z,c.rb,c.color.x,c.color.y,c.color.z);}
        std::printf("]}%s\n",n<5?",":"");}
    std::printf("]\n");
}
