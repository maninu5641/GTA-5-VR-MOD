// 0.6.0: eye from head bone, tracking->world, auto stereo, Y tap/hold, controller driving.
#include "vr_body.hpp"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
static bool near(float a,float b,float e=1e-4f){return std::abs(a-b)<=e;}
static bool near(Vec3 a,Vec3 b,float e=1e-4f){return length(a-b)<=e;}
static float valueOf(const DriveControls& c,int control){for(int i=0;i<c.count;++i)if(c.items[i].control==control)return c.items[i].value;return std::numeric_limits<float>::quiet_NaN();}
static bool has(const DriveControls& c,int control){for(int i=0;i<c.count;++i)if(c.items[i].control==control)return true;return false;}

int main(){try{
    // --- Eye from the head bone: in front of and above it, along the character's heading.
    {   Vec3 head{100,200,31.6f};auto e=eyeFromHeadBone(head,0,false);CHECK(near(e,{100,200.09f,31.67f}));
        auto turned=eyeFromHeadBone(head,90,false);CHECK(near(turned,{99.91f,200,31.67f},1e-3f));     // heading 90 = facing west (-X)
        auto dog=eyeFromHeadBone(head,0,true);CHECK(dog.y>e.y&&dog.z<e.z);
        Vec3 root{100,200,31};CHECK(headBoneUsable(head,root));CHECK(!headBoneUsable({0,0,0},root));
        CHECK(!headBoneUsable(root,root));CHECK(!headBoneUsable({100,200,40},root));CHECK(!headBoneUsable({NAN,0,0},root));}
    // --- Eye bones: midpoint of both eyes, rejected when missing (root / zeros) or implausible.
    {   Vec3 head{100,200,31.6f},l{99.968f,200.09f,31.69f},r{100.032f,200.09f,31.69f};
        CHECK(eyeBonesUsable(l,r,head));CHECK(near(eyeFromEyeBones(l,r,0),{100,200.1f,31.69f}));
        CHECK(near(eyeFromEyeBones(l,r,90),{99.99f,200.09f,31.69f},1e-3f));
        CHECK(!eyeBonesUsable(head,head,head));CHECK(!eyeBonesUsable({0,0,0},{0,0,0},head));       // missing bones
        CHECK(!eyeBonesUsable({100,200,31},{100,200,31},head));                                     // both at the root
        CHECK(!eyeBonesUsable({99.8f,200.09f,31.69f},{100.2f,200.09f,31.69f},head));               // 40 cm apart
        CHECK(!eyeBonesUsable({NAN,0,0},r,head));}
    // --- Tracking -> world (identity head, world camera facing north).
    {   Pose head{};head.m[0][0]=head.m[1][1]=head.m[2][2]=1;head.m[1][3]=1.7f;
        Basis north=cameraBasis({0,0,0});Vec3 cam{10,20,31.7f};
        CHECK(near(trackingToWorld({0,1.7f,-.5f},head,cam,north,1),{10,20.5f,31.7f}));   // 0.5 m in front
        CHECK(near(trackingToWorld({.3f,1.2f,0},head,cam,north,1),{10.3f,20,31.2f}));     // right and down
        CHECK(near(trackingToWorld({0,1.7f,-.5f},head,cam,north,2),{10,21,31.7f}));       // world scale
        Basis west=cameraBasis({0,0,90});CHECK(near(trackingToWorld({0,1.7f,-.5f},head,cam,west,1),{9.5f,20,31.7f}));}
    // --- Auto stereo (0.7.0 thresholds 30 / 40): 24 fps -> mono after 3 s; 50 fps -> 3D after 5 s; noise does not flip it.
    {   StereoAuto a;std::uint64_t t=0;
        int updates=0;while(!a.monoSelected()&&updates<10){a.update(24,1,t+=1000);++updates;}
        CHECK(a.monoSelected()&&updates>=3&&updates<=5);CHECK(near(float(a.framesPerSecond()),24,1));      // ~3 s of low fps
        bool changed=false;for(int i=0;i<4;++i)changed|=a.update(50,1,t+=1000);CHECK(!changed&&a.monoSelected());
        for(int i=0;i<4;++i)changed|=a.update(50,1,t+=1000);CHECK(changed&&!a.monoSelected());
        StereoAuto b;std::uint64_t u=0;for(int i=0;i<20;++i)b.update(i%2?32:38,1,u+=1000);CHECK(!b.monoSelected());   // hovering near 35: stays 3D
        StereoAuto d;std::uint64_t w=0;for(int i=0;i<20;++i)d.update(36,1,w+=1000);CHECK(!d.monoSelected());          // the friend's 36 fps: 3D
        StereoAuto e(50,62);std::uint64_t x=0;for(int i=0;i<6;++i)e.update(36,1,x+=1000);CHECK(e.monoSelected());      // 0.6.0 thresholds still selectable
        StereoAuto c;CHECK(!c.update(36,0,1000));CHECK(!c.update(36,10,2000));CHECK(c.framesPerSecond()==0);
        // 0.16.1: the range follows the headset's refresh rate (the developer's 120 Hz headset with GTA at 60 fps).
        // 0.16.2: 3D only with 40+ images per eye and GTA at about the headset's rate (the developer's 72 Hz: juddery 3D).
        auto r90=StereoAuto::rangeFor(90),r120=StereoAuto::rangeFor(120),r72=StereoAuto::rangeFor(72),r80=StereoAuto::rangeFor(80),bad=StereoAuto::rangeFor(NAN);
        CHECK(std::abs(r90.first-72)<.01&&std::abs(r90.second-81)<.01&&std::abs(r120.first-96)<.01&&std::abs(r120.second-108)<.01);
        CHECK(std::abs(r72.second-80)<.01&&r72.first<=r72.second-6&&std::abs(bad.first-72)<.01);
        CHECK(StereoAuto::monoOnly(72)&&!StereoAuto::monoOnly(80)&&!StereoAuto::monoOnly(90)&&!StereoAuto::monoOnly(120)&&!StereoAuto::monoOnly(NAN));
        CHECK(r80.second/2>=40&&r90.second/2>=40);                                                                    // 40+ images per eye
        StereoAuto f(50,62);f.setRange(r120.first,r120.second);CHECK(f.lowFps()==r120.first&&f.highFps()==r120.second);
        std::uint64_t y=0;for(int i=0;i<6;++i)f.update(60,1,y+=1000);CHECK(f.monoSelected());                       // 60 fps on 120 Hz: mono
        for(int i=0;i<10;++i)f.update(85,1,y+=1000);CHECK(f.monoSelected());                                         // 85 on 120 Hz: still mono (42 per eye, far below the rate)
        for(int i=0;i<10;++i)f.update(115,1,y+=1000);CHECK(!f.monoSelected());                                       // 115 on 120 Hz: 3D
        // The developer's 0.16.1 session at 72 Hz: 45 fps, then 72 fps - mono all the time (it was 3D).
        StereoAuto h(50,62);h.setRange(r72.first,r72.second);h.startMono(StereoAuto::monoOnly(72));std::uint64_t k=0;
        for(int i=0;i<20;++i)h.update(45,1,k+=1000);CHECK(h.monoSelected());for(int i=0;i<30;++i)h.update(72,1,k+=1000);CHECK(h.monoSelected());
        // 90 Hz: starts mono; GTA at 90 fps for 5 s -> 3D (45 per eye); a slow stretch (65 fps) -> mono after 3 s.
        StereoAuto g(50,62);g.setRange(r90.first,r90.second);g.startMono(true);std::uint64_t z=0;
        for(int i=0;i<3;++i)g.update(90,1,z+=1000);CHECK(g.monoSelected());for(int i=0;i<4;++i)g.update(90,1,z+=1000);CHECK(!g.monoSelected());
        for(int i=0;i<10;++i)g.update(76,1,z+=1000);CHECK(!g.monoSelected());                                         // in between: stays
        for(int i=0;i<6;++i)g.update(65,1,z+=1000);CHECK(g.monoSelected());
        g.setRange(NAN,1);CHECK(g.lowFps()==r90.first);}
    // --- Y: tap enters/exits a vehicle, hold toggles motion controls (once).
    {   TapHold y;std::uint64_t t=0;
        CHECK(y.update(true,t)==TapHold::None);CHECK(y.update(true,t+=200)==TapHold::None);CHECK(y.update(false,t+=50)==TapHold::Tap);
        CHECK(y.update(false,t+=50)==TapHold::None);
        y.update(true,t+=100);CHECK(y.update(true,t+=900)==TapHold::Hold);CHECK(y.update(true,t+=500)==TapHold::None);CHECK(y.update(false,t+=50)==TapHold::None);
        y.reset();CHECK(y.update(false,t+=50)==TapHold::None);}
    // --- Driving
    CHECK(vehicleKind(0)==VehicleKind::Car&&vehicleKind(8)==VehicleKind::Bike&&vehicleKind(13)==VehicleKind::Bicycle);
    CHECK(vehicleKind(14)==VehicleKind::Boat&&vehicleKind(15)==VehicleKind::Heli&&vehicleKind(16)==VehicleKind::Plane&&vehicleKind(21)==VehicleKind::Other);
    {   DriveInput in;in.throttle=.8f;in.stickX=-1;in.handbrake=true;auto c=driveControls(VehicleKind::Car,in);
        CHECK(near(valueOf(c,71),.8f));CHECK(near(valueOf(c,59),-1));CHECK(valueOf(c,76)==1);CHECK(!has(c,72));
        in=DriveInput{};in.brake=1;c=driveControls(VehicleKind::Car,in);CHECK(near(valueOf(c,72),1)&&!has(c,71)&&!has(c,59));   // brake / reverse
        in=DriveInput{};in.stickX=.1f;in.stickY=.1f;CHECK(driveControls(VehicleKind::Car,in).count==0);                          // deadzone
        in=DriveInput{};in.stickY=1;c=driveControls(VehicleKind::Bike,in);CHECK(near(valueOf(c,60),-1));                     // lean forward
        CHECK(!has(driveControls(VehicleKind::Car,in),60));
        in=DriveInput{};in.handbrake=true;CHECK(!has(driveControls(VehicleKind::Boat,in),76));
        in=DriveInput{};in.throttle=1;in.brake=.5f;in.stickX=.6f;in.stickY=1;in.rightX=-1;c=driveControls(VehicleKind::Heli,in);
        CHECK(near(valueOf(c,87),1)&&near(valueOf(c,88),.5f));CHECK(valueOf(c,107)>0&&near(valueOf(c,108),-1));CHECK(near(valueOf(c,89),1)&&!has(c,90));
        CHECK(!has(c,71)&&!has(c,59));
        in.rightX=.5f;c=driveControls(VehicleKind::Plane,in);CHECK(has(c,90)&&!has(c,89));
        CHECK(driveControls(VehicleKind::Other,in).count==0);
        in=DriveInput{};in.throttle=NAN;in.stickX=NAN;CHECK(driveControls(VehicleKind::Car,in).count==0);
        CHECK(near(driveDeadzone(1),1)&&near(driveDeadzone(-.575f),-.5f)&&driveDeadzone(.1f)==0);}
    std::cout<<checks<<" body / vehicle / stereo-mode checks passed (eye from head bone, tracking->world, auto mono, Y tap/hold, controller driving). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
