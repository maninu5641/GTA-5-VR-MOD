// 0.15.7: the phone on the right stick, the prologue's cover at the crates, health back for a kill (vr_assist.hpp).
// 0.15.8: the grip that holds a weapon, a squeeze right after it slipped out, a moment of lost tracking, why the input
// was not usable (protocol.hpp).
#include "vr_assist.hpp"
#include "protocol.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace handvr;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x))throw std::runtime_error("Line "+std::to_string(__LINE__)+": " #x);}while(0)
using Act=PhoneStickUp::Act;
using CoverAct=AutoCover::Act;

int main(){try{
    // --- The phone: a flick up from the centre takes it out; held up with the phone up puts it away.
    {   PhoneStickUp s;std::uint64_t t=1000;
        CHECK(s.update(0,1,false,true,t)==Act::None);                 // pushed before the centre was seen: nothing
        CHECK(s.update(0,0,false,true,t+=16)==Act::None);
        CHECK(s.update(.1f,.9f,false,true,t+=16)==Act::TakeOut);      // the flick
        for(int i=0;i<100;++i)CHECK(s.update(.1f,.9f,i>5,true,t+=16)==Act::None);   // held on: the phone came up, no put-away from the same push
        CHECK(s.update(0,0,true,true,t+=16)==Act::None);
        CHECK(s.update(0,.95f,true,true,t+=16)==Act::None);           // phone up: a push is its own arrow (not here)
        bool away=false;std::uint64_t start=t;while(t<start+2000&&!away)away=s.update(0,.95f,true,true,t+=16)==Act::PutAway;
        CHECK(away&&t>=start+PhoneStickUp::HoldMs&&t<start+PhoneStickUp::HoldMs+40);
        for(int i=0;i<60;++i)CHECK(s.update(0,.95f,true,true,t+=16)==Act::None);    // once per hold
        // Short pushes with the phone up: never put away.
        CHECK(s.update(0,0,true,true,t+=16)==Act::None);
        for(int k=0;k<10;++k){for(int i=0;i<20;++i)CHECK(s.update(0,.9f,true,true,t+=16)==Act::None);CHECK(s.update(0,0,true,true,t+=16)==Act::None);}
        // A slight dip below the line keeps the hold; sideways and diagonal pushes are not "up" (snap turn).
        CHECK(s.update(0,.9f,true,true,t+=16)==Act::None);for(int i=0;i<30;++i)CHECK(s.update(0,i%3?.9f:.6f,true,true,t+=16)==Act::None);   // 0.5 s
        int puts=0;for(int i=0;i<30;++i)if(s.update(0,.9f,true,true,t+=16)==Act::PutAway)++puts;CHECK(puts==1);
        s.reset();CHECK(s.update(0,0,false,true,t+=16)==Act::None);CHECK(s.update(.9f,.2f,false,true,t+=16)==Act::None);CHECK(s.update(.7f,.8f,false,true,t+=16)==Act::None);
        CHECK(!PhoneStickUp::up(.7f,.8f)&&PhoneStickUp::up(.2f,.8f)&&!PhoneStickUp::up(0,-.9f)&&!PhoneStickUp::up(NAN,1));
        // Not allowed (a wheel or menu uses the stick): nothing, and the centre must be seen again.
        s.reset();CHECK(s.update(0,0,false,true,t+=16)==Act::None);CHECK(s.update(0,.9f,false,false,t+=16)==Act::None);
        CHECK(s.update(0,.9f,false,true,t+=16)==Act::None);CHECK(s.update(0,0,false,true,t+=16)==Act::None);CHECK(s.update(0,.9f,false,true,t+=16)==Act::TakeOut);
        CHECK(s.update(NAN,0,false,true,t+=16)==Act::None);}

    // --- The prologue's cover spots: the nearest within reach.
    {   CHECK(prologueCoverCount==5);
        CHECK(nearestCover({5333,-5186,83.6f},prologueCover,prologueCoverCount,12)==0);
        CHECK(nearestCover({5326,-5192,83.6f},prologueCover,prologueCoverCount,12)==3);
        CHECK(nearestCover({5338,-5194,83.8f},prologueCover,prologueCoverCount,12)==4);
        CHECK(nearestCover({5345,-5188,83.6f},prologueCover,prologueCoverCount,12)==4);    // 13.0 m from the first, 9.8 m from the last
        CHECK(nearestCover({5345,-5188,83.6f},prologueCover,prologueCoverCount,9)==-1);
        CHECK(nearestCover({5300,-5188,83.6f},prologueCover,prologueCoverCount,12)==-1);   // in the vault, far away
        CHECK(nearestCover({5332,-5185,95},prologueCover,prologueCoverCount,12)==-1);       // another floor
        CHECK(nearestCover({NAN,0,0},prologueCover,prologueCoverCount,12)==-1&&nearestCover({5332,-5185,82},nullptr,5,12)==-1);}

    // --- AutoCover: into cover once per stage, out with the stick pulled back, never against the player.
    {   AutoCover c;std::uint64_t t=1000;
        CHECK(c.update(false,true,false,false,false,t)==CoverAct::None&&!c.stageActive());
        CHECK(c.update(true,false,false,false,false,t+=100)==CoverAct::None&&c.stageActive());   // the stage, but far from the crates
        CHECK(c.update(true,true,false,false,false,t+=100)==CoverAct::Enter&&c.attempts()==1);
        CHECK(c.update(true,true,false,true,false,t+=100)==CoverAct::None);                       // going into cover
        for(int i=0;i<50;++i)CHECK(c.update(true,true,true,false,false,t+=100)==CoverAct::None);  // in cover
        CHECK(c.wasInCover()&&!c.finished());
        CHECK(c.update(true,true,true,false,true,t+=100)==CoverAct::None);                        // stick back...
        CHECK(c.update(true,true,true,false,true,t+=200)==CoverAct::None);
        CHECK(c.update(true,true,true,false,true,t+=250)==CoverAct::Leave);                       // ...0.4 s: leave
        CHECK(c.update(true,true,true,false,true,t+=100)==CoverAct::None);                        // once
        for(int i=0;i<100;++i)CHECK(c.update(true,true,false,false,false,t+=100)==CoverAct::None); // out: not put back
        CHECK(c.finished());
        // The stage ends and starts again (a checkpoint restart): once more.
        CHECK(c.update(false,true,false,false,false,t+=100)==CoverAct::None&&!c.stageActive());
        CHECK(c.update(true,true,false,false,false,t+=100)==CoverAct::Enter);
        // GTA did not take it: up to 3 tries, 4 s apart.
        int enters=1;for(int i=0;i<400;++i)if(c.update(true,true,false,false,false,t+=100)==CoverAct::Enter)++enters;
        CHECK(enters==AutoCover::MaxTries);
        // Out of cover by GTA's cover key or by the mission (no stick): left alone as well.
        AutoCover d;t=50000;CHECK(d.update(true,true,false,false,false,t)==CoverAct::Enter);
        for(int i=0;i<10;++i)d.update(true,true,true,false,false,t+=100);
        for(int i=0;i<100;++i)CHECK(d.update(true,true,false,false,false,t+=100)==CoverAct::None);
        // A short pull back is not a way out (walking along the cover).
        AutoCover e;t=90000;e.update(true,true,false,false,false,t);e.update(true,true,true,false,false,t+=100);
        for(int k=0;k<5;++k){CHECK(e.update(true,true,true,false,true,t+=100)==CoverAct::None);CHECK(e.update(true,true,true,false,true,t+=200)==CoverAct::None);
            CHECK(e.update(true,true,true,false,false,t+=100)==CoverAct::None);}}

    // --- Health back for a kill.
    {   CHECK(healAfterKill(150,200,15)==165&&healAfterKill(195,200,15)==200&&healAfterKill(200,200,15)==200);
        CHECK(healAfterKill(100,200,15)==100&&healAfterKill(90,200,15)==90);   // dead / dying: nothing
        CHECK(healAfterKill(150,200,0)==150&&healAfterKill(150,100,15)==150&&healAfterKill(120,200,45)==165);}
    // --- 0.15.8: the grip holds - taken past 0.65, let go below 0.35 for 0.1 s.
    {   GripLatch g;std::uint64_t t=1000;
        CHECK(!g.update(.5f,t)&&!g.update(.65f,t+=11));                  // not past 0.65 yet
        CHECK(g.update(.66f,t+=11)&&g.held());
        for(int i=0;i<300;++i)CHECK(g.update(i%2?.64f:.4f,t+=11));     // a relaxed hand / a reading around 0.65: still held
        CHECK(g.update(.2f,t+=11)&&g.update(.1f,t+=50)&&g.update(.3f,t+=40));   // 90 ms below 0.35: still held
        CHECK(g.update(.5f,t+=11));                                       // back above: the 0.1 s starts again
        CHECK(g.update(.1f,t+=11)&&g.update(.1f,t+=60)&&!g.update(.1f,t+=40)&&!g.held());   // 100 ms below: let go
        CHECK(!g.update(.6f,t+=11)&&g.update(.9f,t+=11));                // a new squeeze needs 0.65 again
        CHECK(g.update(NAN,t+=11)&&!g.update(NAN,t+=100));               // no reading = let go (after 0.1 s)
        g.update(.9f,t+=11);g.reset();CHECK(!g.held()&&!g.update(.5f,t+=11));}
    // --- 0.15.8: a squeeze within 0.8 s after the weapon slipped out takes it back, once.
    {   RegrabWindow r;CHECK(!r.pending(100)&&r.take(100)<0);constexpr std::uint64_t W=RegrabWindow::WindowMs;CHECK(W==800);
        r.dropped(7,1000);CHECK(r.pending(1000)&&r.pending(1000+W)&&!r.pending(1001+W)&&!r.pending(999));
        CHECK(r.take(1300)==7&&r.take(1310)<0&&!r.pending(1310));       // one use
        r.dropped(3,2000);CHECK(r.take(2001+W)<0);                        // too late
        r.dropped(4,3000);r.reset();CHECK(r.take(3100)<0);}
    // --- 0.15.8: a hand losing tracking counts as there for 1.5 s.
    {   TrackingGrace g;CHECK(!g.update(false,500));                       // never seen: not there
        CHECK(g.update(true,1000)&&g.update(false,1100)&&g.update(false,2499)&&!g.update(false,2500));
        CHECK(g.update(true,3000)&&g.update(false,3001));g.reset();CHECK(!g.update(false,3002));}
    // --- 0.15.8: why the input was not usable (the log), in usable()'s order.
    {   InputFrame f;f.timeMs=10000;f.flags=HeadValid|RightValid|InputReady;
        for(int i=0;i<3;++i){f.head.m[i][i]=1;f.right.m[i][i]=1;}f.head.m[1][3]=1.7f;f.right.m[0][3]=.3f;f.right.m[1][3]=1.2f;f.right.m[2][3]=-.3f;
        CHECK(usable(f,10050)&&!*inputProblem(f,10050));
        CHECK(!usable(f,10250)&&std::string(inputProblem(f,10250)).find("late")!=std::string::npos);
        InputFrame g=f;g.magic=0;CHECK(std::string(inputProblem(g,10050)).find("no input")!=std::string::npos);
        g=f;g.flags|=DashboardOpen;CHECK(!usable(g,10050)&&std::string(inputProblem(g,10050)).find("dashboard")!=std::string::npos);
        g=f;g.flags&=~RightValid;CHECK(!usable(g,10050)&&std::string(inputProblem(g,10050)).find("right controller's tracking")!=std::string::npos);
        g=f;g.right.m[0][3]=3;CHECK(!usable(g,10050)&&std::string(inputProblem(g,10050)).find("2.5 m")!=std::string::npos);
        g=f;g.flags&=~HeadValid;CHECK(std::string(inputProblem(g,10050)).find("headset")!=std::string::npos);
        g=f;g.rightGrip=NAN;CHECK(!usable(g,10050)&&std::string(inputProblem(g,10050)).find("grip")!=std::string::npos);
        g=f;g.flags&=~InputReady;CHECK(!usable(g,10050)&&std::string(inputProblem(g,10050)).find("bindings")!=std::string::npos);
        g=f;g.flags|=CameraKnown;g.gameHead={NAN,0,0};CHECK(!usable(g,10050)&&std::string(inputProblem(g,10050)).find("camera")!=std::string::npos);}
    std::cout<<checks<<" assist checks passed (the phone on the right stick, the prologue's cover at the crates, health for a kill, the grip latch, the regrab window, tracking grace, why input was not usable). GTA NOT exercised.\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
