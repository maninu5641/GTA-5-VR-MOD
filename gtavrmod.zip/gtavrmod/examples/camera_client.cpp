// Integration helper for another ASI, not a second camera driver.
// Call from normal plugin code, never from DllMain. Use one tracking writer.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "camera_api.h"
#include <cstring>

class Gta5VrCameraClient {
    decltype(&GTA5VR_SubmitHeadPose) submitPose=nullptr;
    decltype(&GTA5VR_ClearHeadPose) clearPose=nullptr;
    decltype(&GTA5VR_ReadCamera) readCamera=nullptr;
    decltype(&GTA5VR_RequestRecenter) recenterCamera=nullptr;
    uint64_t sequence=0;
public:
    bool connect(){
        auto module=GetModuleHandleW(L"GTA5VRRenderer.asi");if(!module)return false;
        auto version=reinterpret_cast<decltype(&GTA5VR_GetCameraApiVersion)>(GetProcAddress(module,"GTA5VR_GetCameraApiVersion"));
        if(!version||version()!=GTA5VR_CAMERA_API_VERSION)return false;
        submitPose=reinterpret_cast<decltype(submitPose)>(GetProcAddress(module,"GTA5VR_SubmitHeadPose"));
        clearPose=reinterpret_cast<decltype(clearPose)>(GetProcAddress(module,"GTA5VR_ClearHeadPose"));
        readCamera=reinterpret_cast<decltype(readCamera)>(GetProcAddress(module,"GTA5VR_ReadCamera"));
        recenterCamera=reinterpret_cast<decltype(recenterCamera)>(GetProcAddress(module,"GTA5VR_RequestRecenter"));
        return submitPose&&clearPose&&readCamera&&recenterCamera;
    }
    int update(const float (&standingPose)[3][4],uint64_t sampleTimeMs){
        if(!submitPose)return GTA5VR_CAMERA_UNAVAILABLE;
        Gta5VrHeadPose p{};p.structSize=sizeof(p);p.version=GTA5VR_CAMERA_API_VERSION;
        p.sequence=++sequence;p.sampleTimeMs=sampleTimeMs;
        std::memcpy(p.headToStanding,standingPose,sizeof(standingPose));
        return submitPose(&p,sizeof(p));
    }
    int read(Gta5VrCameraSnapshot& out){return readCamera?readCamera(&out,sizeof(out)):GTA5VR_CAMERA_UNAVAILABLE;}
    int recenter(){return recenterCamera?recenterCamera():GTA5VR_CAMERA_UNAVAILABLE;}
    int release(){if(!clearPose)return GTA5VR_CAMERA_UNAVAILABLE;auto result=clearPose();if(result==GTA5VR_CAMERA_OK)sequence=0;return result;}
};
