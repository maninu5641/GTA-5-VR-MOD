# Third-party notices and provenance

## Valve OpenVR

The included `third_party/openvr/openvr_capi.h` and `dist/GTAHandVR/openvr_api.dll` are from Valve's [OpenVR repository](https://github.com/ValveSoftware/openvr), commit `0924064316de3effbcd1acf1e309182a2deb1c05`. OpenVR uses the BSD 3-Clause license, reproduced in `third_party/openvr/LICENSE` and beside the runtime DLL as `OpenVR-LICENSE.txt`.

SteamVR itself is an external prerequisite. This project is not affiliated with or endorsed by Valve or Meta.

## Script Hook V

Script Hook V is developed by Alexander Blade: https://www.dev-c.com/gtav/scripthookv/ . Its runtime and ASI loader are **not included**. Users obtain the appropriate version directly from its publisher.

`native.hpp`, `ScriptHookV.def` and the renderer's Present callback declarations use public API signatures and exported names for interoperability. The import library used during the build is generated locally from those names; it is not the proprietary runtime. Export names, including `presentCallbackRegister` and `presentCallbackUnregister`, were cross-checked against the SDK header/import table available in the SanguShellz compatibility patcher's SDK directory, used only as a development reference.

GTA native names, identifiers and signatures were checked against the community [GTA native database](https://github.com/alloc8or/gta5-nativedb-data). Only the interface identifiers used by this add-on are included. Its database snapshot digest is recorded in `DEPENDENCIES.json`; the database itself is not distributed here.

## Build runtime

The 0.3.3 Windows binaries were compiled with llvm-mingw 20240619 (clang/LLVM 18.1.8 with the mingw-w64 UCRT runtime), which statically links LLVM libc++, libc++abi, libunwind and mingw-w64 runtime/support code. Earlier builds used Zig 0.13.0, which `build.py --zig` still supports. Relevant LLVM libc++, libc++abi, libunwind, MinGW and Zig notices are reproduced under `third_party/licenses/`. The compiler itself is not part of the downloadable mod.

## Build-time shader validation

The hand overlay HLSL (0.4.0) is compiled on the player's PC by Windows' own `d3dcompiler_47.dll`. Microsoft's [DirectX Shader Compiler](https://github.com/microsoft/DirectXShaderCompiler) v1.8.2407 is used only on the build host to validate that text; it is not included in the package.

## Weapon identifiers

The factual weapon names, numeric identifiers, categories and magazine-component identifiers used to build the 113-entry catalog were checked against [DurtyFree/gta-v-data-dumps](https://github.com/DurtyFree/gta-v-data-dumps/blob/master/weapons.json) on 2026-10-09. The source dump, descriptions, translations and game assets are not redistributed. Reload/interaction adapters are original code and are not supplied by that database.

## MinHook

Original upstream [MinHook v1.3.4](https://github.com/TsudaKageyu/minhook/tree/v1.3.4) sources under `third_party/minhook/` are retained from version 0.3. They are not compiled or linked into the renderer since version 0.3.1, which switched to Script Hook V's Present callback. The upstream BSD 2-Clause license and HDE notices remain preserved in source and `MinHook-LICENSE.txt` in the installer. File digests are recorded in `DEPENDENCIES.json`.

## GTA V

GTA V and its game content belong to their respective owners. No game content or proprietary game executable is included.
