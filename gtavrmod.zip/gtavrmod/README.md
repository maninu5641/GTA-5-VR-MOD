# GTA 5 VR — 0.16.3

**0.16.3 — o A é o E do GTA, novos nomes dos arquivos:**
- O botão A também aperta o E do GTA: a pé com a mão direita sem arma de fogo, e sempre que o GTA mostra "aperte E" (a loja de armas, falar com alguém). `[Controls] ReloadIsE=0` desliga.
- O menu da loja funciona com os controles: analógico = setas, A = Enter, B = Backspace, X = Espaço.
- O instalador se chama `gta5vrmod setup.exe` e o pacote `gtavrmod.zip`. Detalhes em `docs/PATCH_NOTES_0.16.3.md`.

**0.16.2 — o corpo vira com você de verdade, a visão fica no corpo, imagem suave:**
- A visão não fica mais solta na frente do corpo: a posição dos olhos só é medida com o personagem em pé e reto, e fica sempre em cima do corpo. As mãos voltam a alcançar as armas.
- O personagem vira para onde o seu corpo está virado: na hora quando você vira mais de 40°, todo depois de 0,5 s olhando para o lado, e para onde você anda. A visão tem a própria direção (só a sua cabeça e o giro a mudam); a câmera do GTA não mexe mais nela.
- O modo automático começa em Mono e só usa 3D quando cada olho recebe 40+ imagens por segundo: a 72 Hz, sempre Mono (suave). Shift+F10 troca. Detalhes em `docs/PATCH_NOTES_0.16.2.md`.

**0.16.1 — o corpo vira com você, sem painel de números, imagem mais suave:**
- Virando o corpo de verdade (parado), o personagem agora vira junto; antes a visão ficava de frente para as costas dele.
- O painel de números (FPS etc.) não aparece mais sozinho; só com Shift+End.
- O modo automático 3D / Mono leva em conta a taxa do óculos: com o GTA lento para o óculos (60 FPS num óculos de 120 Hz, por exemplo), usa Mono, que é mais suave. Desligue o VSync do GTA. Testado no GTA V do app Xbox: funciona. Detalhes em `docs/PATCH_NOTES_0.16.1.md`.

**0.16.0 — pronto para lançar: instalador e launcher mais simples:**
- O launcher (`GTA5 VR.exe`) agora tem só quatro opções — **primeira pessoa**, **recarga física do carregador**, **segunda mão nas armas pesadas** e **laser de mira** — e um botão grande **PLAY GTA 5 IN VR**. As opções são salvas na hora, e um quadro no topo diz em palavras simples se falta alguma coisa (Script Hook V, ASI Loader, SteamVR, arquivos do mod).
- O instalador mostra três passos (pasta do GTA V, o que tem nela, instalar) e não tem mais avisos de "experimental".
- A versão do **app Xbox (PC Game Pass)** do GTA V Legacy agora é aceita pelo instalador (a 0.15.8 recusava a pasta `C:\XboxGames\...\Content`), com um aviso: ela ainda não foi testada com o GTA 5 VR e depende do Script Hook V funcionar nela.
- Saíram as opções de renderizador externo (R.E.A.L.), OpenXR e direção física. O GTA 5 VR usa só o próprio renderizador OpenVR / SteamVR; nos carros, gatilhos e analógicos dirigem. Os arquivos dessas partes (o companion de entrada e a layer OpenXR) não são mais instalados, e o Setup os remove de uma instalação antiga (com backup). Detalhes em `docs/PATCH_NOTES_0.16.0.md`.

**0.15.8 — a arma não some mais da mão e fica na mão do jeito que o GTA segura:**
- Um instante sem rastreamento do controle, um quadro lento do jogo ou uma queda não mandam mais a arma para o coldre: por até 1,5 s as mãos ficam com o que seguram. O grip pega acima de 65% e só solta abaixo de 35%; se a arma escapar, apertar de novo em até 0,8 s traz ela de volta.
- Cada arma fica na mão do jeito que o próprio GTA segura aquela arma (lido da cópia invisível do personagem na primeira vez que você pega cada arma). `[Weapons] GtaGrip=0` volta como na 0.15.7.
- Dedos: uma arma cuja pose própria não fecha a mão usa a pose do rifle (a mão no cabo, o indicador no gatilho), não mais a garra. `[Hands] PistolGrip=Rifle` força isso na pistola. Detalhes em `docs/PATCH_NOTES_0.15.8.md`.


**0.15.7 — a arma na mão de verdade, o celular no analógico direito, cobertura no prólogo, vida por abate:**
- A arma (e a granada, e o detonador da C4) agora fica presa na mão do personagem, no ponto da palma que o próprio GTA usa para segurar armas e objetos. O braço leva a mão para onde o controle aponta; o tiro sai da arma que você vê. `[Weapons] HandHold=0` volta como na 0.15.6.
- Analógico direito para cima: o celular do GTA aparece, em todo lugar (a pé e em veículos). Com o celular na mão, o analógico anda nele, A escolhe, B volta; segurar para cima guarda. Para baixo troca para a próxima arma.
- Prólogo, tiroteio na sala das caixas: o personagem entra sozinho em cobertura atrás da caixa mais próxima (só nessa parte). Analógico esquerdo para trás sai da cobertura.
- Cada pessoa morta pelo jogador devolve um pouco de vida (`[Gameplay] HealOnKill=15`). Detalhes em `docs/PATCH_NOTES_0.15.7.md`.


**0.15.6 — a roda de personagens do próprio GTA:**
- O Y continua apertando o Alt esquerdo (a tecla da roda do GTA), mas o mod não escreve mais a lista de nomes por cima: só a roda do GTA, com as fotos.
- O bloqueio do F8 (que leva ao GTA Online) e os bloqueios de combate agora desligam só as próprias teclas. Antes desligavam também os controles "parecidos", e o suspeito é que isso desligava as teclas de troca de personagem (e o Q de cobertura).
- O log diz, a cada atualização, se a tecla da roda do GTA chegava desligada ou se foi o mod. Detalhes em `docs/PATCH_NOTES_0.15.6.md`.


**0.15.5 — botões escolhidos dentro do jogo, menu de pausa com os controles, pessoas reagem à arma:**
- Menu de VR dentro do jogo (Y com o menu de pausa do GTA aberto): o que cada botão faz (Y, X, A, B, cliques dos analógicos), o giro, a mira do GTA, a pausa pelo botão do SteamVR. Salva na hora no `GTAHandVR.ini` (`[Controls]`). Padrão novo: clique do analógico direito = tecla de ação E do GTA.
- O botão de menu do SteamVR pausa o GTA; o menu de pausa do GTA anda com os controles (analógico = setas, A = Enter, B = voltar, grips = abas).
- Enquanto a arma de VR aponta para uma pessoa, o personagem mira no GTA também (a câmera do GTA vira para ela, a imagem do óculos não): as pessoas e as missões reagem (reféns do prólogo, lojas, polícia). `[Weapons] GtaAim=0` desliga.
- O VR não sai mais quando uma missão só carrega a próxima cena; um aviso diz por que a imagem ficou plana. Celular: o analógico direito anda nos apps. Prólogo: se a roda do GTA não abrir, a tecla do personagem (F7) é tocada sozinha.

Detalhes em `docs/PATCH_NOTES_0.15.5.md`.



**0.15.4 — a mão esquerda não fica mais colada no rifle:**
- O próprio GTA coloca a mão esquerda do personagem na frente de qualquer arma de duas mãos que ele segura — também na cópia invisível que faz o som dos tiros (0.15.0). Agora o personagem só segura essa cópia enquanto você atira (dedo no gatilho e 0,8 s depois do último tiro; o primeiro tiro espera até 0,3 s por ela). No resto do tempo a mão esquerda segue o controle. `[Weapons] GunHold=Always` volta ao jeito da 0.15.3.

Detalhes em `docs/PATCH_NOTES_0.15.4.md`.


**0.15.3 — a roda de personagens do próprio GTA, a arma não fica mais grudada na mão:**
- Y abre a roda de personagens do próprio GTA (não é mais o menu do mod). A imagem vira a tela plana do GTA no óculos, o mod segura o Alt esquerdo do GTA como um teclado e a roda do jogo abre. O analógico aponta o personagem (F5 / F6 / F7 seguradas junto) e Y / A / gatilho troca; B fecha. Funciona também no carro. `[Motion] CharacterMenu=Mod` volta o menu da 0.15.2.
- A arma do GTA que faz o som (a cópia invisível da 0.15.0) não aparece mais nem fica presa na mão: fica escondida o tempo todo, é guardada na hora em que a mão solta, e a medição da pegada é feita nela sem mostrar a arma do GTA.

Detalhes em `docs/PATCH_NOTES_0.15.3.md`.


**0.15.2 — a troca de personagem troca de verdade, a arma atira depois do pente:**
- A tecla do GTA para trocar de personagem (F5 / F6 / F7) agora fica apertada 0,65 s. O GTA só troca se a roda dele ficar aberta 0,3 s, e a 0.15.1 soltava em 0,2 s, por isso nunca trocava. `[Motion] CharacterKeyHold`.
- O pente novo já coloca bala na câmara de novo: a arma atira logo depois da recarga. Para puxar o ferrolho igual no Pavlov: `[Weapons] RackSlide=1`.

Detalhes em `docs/PATCH_NOTES_0.15.2.md`.


**0.15.1 — B só para o carro, menu novo para trocar de personagem:**
- B entra / rouba / sai do carro, na hora. Segurar B não abre mais o menu de armas (o analógico já troca a arma na mão). Só com uma arma especial do GTA na mão (galão, ferramenta de missão) o B segurado ainda abre o menu. `[Weapons] WeaponWheel=1` volta o menu.
- Y abre o menu CHANGE CHARACTER do mod (Michael esquerda, Franklin em cima, Trevor direita): aponte um analógico e aperte Y / A / gatilho. Quem troca é o GTA, pela tecla dele (F5 / F6 / F7), apertada como num teclado. `[Motion] CharacterKeys=0` volta ao menu do GTA.

Detalhes em `docs/PATCH_NOTES_0.15.1.md`.


**0.15.0 — botão de VR, som dos tiros, recarga igual Pavlov:**
- Botão para sair e entrar no VR: clique os dois analógicos e segure 1 segundo. VR desligado = a imagem normal do GTA numa tela no óculos (e no monitor), com teclado / controle. O mesmo botão (ou F11) volta para o VR.
- Som dos tiros: o personagem segura a mesma arma no GTA, invisível, e o GTA dispara ela. Assim toca o som de verdade de cada arma. Se o GTA não disparar, o log diz por quê ("Gun sound").
- Recarga igual Pavlov: o pente sai da arma quando cai e volta quando você coloca outro; perto da arma ele se alinha e entra. Arma vazia: depois do pente novo, puxe o ferrolho com a mão esquerda ou aperte A. Sniper Rifle com ferrolho manual depois de cada tiro. Gatilho com a arma vazia dá um "clique" no controle.

Detalhes em `docs/PATCH_NOTES_0.15.0.md`.


**0.14.0 — dedos de novo, andar sem correr, botões novos, recarga igual Pavlov:**
- Teste das mãos no começo (uns 7 s): o mod lê os ossos dos dedos e usa só as poses que funcionam (poses de mão do próprio GTA: aberta, punho, segurar; gestos joinha, apontar, dedo do meio).
- O analógico anda; clique para correr, segure o clique para disparar.
- B entra / rouba / sai do carro (segurar B a pé = roda de armas); Y = menu de personagens do GTA numa tela no VR; A / B atendem e desligam o celular; motion controls já ligados.
- Recarga: o pente da arma aparece no cinto e na mão (sem bolas azuis) e a arma já atira depois do pente novo. Analógico direito para cima troca para outra arma do mesmo coldre.

Detalhes em `docs/PATCH_NOTES_0.14.0.md`.


**0.13.0 — igual Pavlov: a mão encaixa na arma, os dedos mexem, as armas ficam no corpo:**
- Modo Pavlov é o novo padrão: pistola no quadril direito, faca no esquerdo, granadas no peito, fuzil e escopeta por cima do ombro direito, sniper por cima do esquerdo. A própria arma aparece no coldre (não é mais a bola amarela).
- A mão do personagem segura a arma do jeito que o GTA segura. Na primeira vez que você pega cada arma, o GTA segura ela por meio segundo e o mod mede onde ela fica na mão.
- Os dedos mexem: a mão vazia fecha com o grip; segurando algo, a mão faz a pose do GTA para aquela arma. No começo o mod confere se a mão fecha mesmo.
- O modo antigo continua: `[Weapons] Mode=GTA4VR`.

Detalhes em `docs/PATCH_NOTES_0.13.0.md`.


**0.12.0 — a mão vai direto no controle e gira junto:**
- O vídeo da 0.11.0 mostrou que o IK do GTA mexe os braços, mas o GTA passa para os mods a posição dos ossos da animação, antes do IK. A correção da 0.11.0 usava essa medida e empurrava a mão para longe do controle.
- Sem correção: o alvo do IK é o seu pulso, direto (como na 0.8.0).
- A mão gira junto com a sua desde o começo: o mod mede os eixos do osso da mão e manda o alvo virado igual à sua mão.
- Um marcador invisível preso no osso da mão testa se dá para ver a mão de verdade depois do IK (log "Arm IK check").

Detalhes em `docs/PATCH_NOTES_0.12.0.md`.


**0.11.0 — braços e mãos refeitos:**
- O IK dos braços entra com força total na hora (antes entrava aos poucos e a mão parava no meio do caminho, a 22-31 cm do controle).
- O IK de primeira pessoa do próprio GTA fica desligado enquanto as suas mãos mexem os braços.
- O mod mede onde a mão do personagem foi parar e corrige o próximo pedido até a mão ficar no controle.
- A rotação da mão é aprendida enquanto você joga (sem o teste que torcia a mão); o painel diz "WORKS" ou "GTA ignores it".
- A câmera do GTA fica nivelada a pé, então o personagem não se curva mais olhando para o chão.
- A pose padrão das mãos voltou a ser a de digitar (a de punho fechado não existe no modo história).

Detalhes em `docs/PATCH_NOTES_0.11.0.md`.


**0.10.0 — o corpo inteiro segue você:**
- Cabeça: o headset. Um passo de verdade faz o personagem andar até ficar embaixo da sua cabeça.
- Braços: os controles. O corpo gira com você, então os braços não dão mais a volta no corpo.
- Mãos: punhos fechados com o polegar para cima, e o mod testa 8 jeitos de o GTA girar a mão junto com o controle.
- Pernas: andar, virar e agachar de verdade usam as animações do GTA; o IK das pernas do GTA fica ligado.
- Painel de diagnóstico no headset (15 s no início, Shift+End).

Detalhes em `docs/PATCH_NOTES_0.10.0.md`.


**0.9.0:**
- Calibração de altura: em pé, braços em T, segure os dois gatilhos por 2 s. O corpo do personagem passa a bater com o seu (chão, alcance dos braços).
- Mãos: pose nova com as palmas para baixo, e o mod testa sozinho se o GTA consegue girar a mão do personagem junto com a sua (aparece um texto no headset).
- Roda de personagens do GTA: o analógico agora também vai como mouse, que é o que o GTA usa no PC sem controle de Xbox; F5/F6/F7 se ele não trocar.
- Mapa: o minimapa do GTA no pulso esquerdo (a pé) e no painel (no carro).
- Armas como no GTA4VR: a arma fica na mão, analógico direito para cima/baixo troca, grip direito solta o pente, pente novo por cima do ombro, escopeta pump a cada tiro.

Detalhes em `docs/PATCH_NOTES_0.9.0.md`.


**0.8.0:**
- O personagem não sai mais correndo sozinho. O Y só usa o "entrar no carro" do próprio GTA, com um carro a até 4 m.
- Os braços não balançam mais ao andar ou correr, e o mod acha sozinho o jeito de o IK do GTA mover a mão.
- Segurar o clique do analógico direito abre a roda de personagens do próprio GTA.
- O renderer voltou a ser o da 0.6.0.
- Setup novo, que acha o GTA sozinho e verifica a pasta antes de instalar.
- Botão de desinstalar no menu e no Setup.

Detalhes em `docs/PATCH_NOTES_0.8.0.md`.

**0.7.0:**
- Mãos e braços do próprio modelo do Franklin, Michael e Trevor seguindo as suas mãos, sem animações de arma do GTA.
- Coldres no corpo: segure o grip para pegar a arma, solte para guardar.
- Granada: pegue no peito e solte para jogar.
- O personagem para de andar quando o polegar sai do analógico.
- Segurar o clique do analógico direito troca de personagem.
- 3D volta a ser o padrão, com verificação do FOV contra o zoom.

No instalador, deixe marcado "Reset GTAHandVR.ini". Detalhes em `docs/PATCH_NOTES_0.7.0.md`.

**0.6.0:**
- Corpo real do Franklin, Michael e Trevor, com os braços indo até os controles.
- Chop em primeira pessoa.
- Arma apontando igual ao laser do controle.
- Carros: Y entra e sai, e se dirige com os gatilhos e o analógico, em primeira pessoa.
- `StereoMode=Auto`: Mono quando o FPS está baixo.

Detalhes em `docs/PATCH_NOTES_0.6.0.md`.

**0.5.0 reformula as armas.**
- **Holsters no corpo:** pistola no quadril, fuzil atrás do ombro, granada no peito. Pegue com a mão direita + grip.
- **Tiro mais realista:** recuo, cano subindo em rajada, clarão, cápsula e vibração por arma. Armas longas atiram com uma mão.
- **Recarga física:** A solta o pente, a mão esquerda pega outro no cinto, encosta na arma e puxa o ferrolho se a câmara estiver vazia.

Detalhes em `docs/PATCH_NOTES_0.5.0.md`.

**0.4.1 estabiliza a câmera e reduz o tremor.** O horizonte não herda mais a inclinação da câmera do GTA e o olho segue o corpo do personagem sem o balanço de andar. A oscilação da direção da câmera do jogo é suavizada e a câmera não pisca mais perto de paredes. **Shift+F10** liga um modo estável (Mono), sem o tremido da renderização alternada. Pular, cair ou perder o controle por um instante não troca mais para a tela de cinema. Detalhes em `docs/PATCH_NOTES_0.4.1.md`.

**0.4.0 adiciona braços e mãos com dedos no VR e soco com hitbox.** As mãos seguem o esqueleto de mão do SteamVR (31 ossos). Com controles Touch, médio, anelar e mindinho se movem juntos, e o combo grip + gatilho + clique no analógico faz o dedo do meio. Com hand tracking do Quest cada dedo se move sozinho. O soco acerta a parte do corpo que a mão tocou, com dano e reação por região. Detalhes e imagem em `docs/PATCH_NOTES_0.4.0.md`.

**0.3.4 corrigiu o motivo de nada aparecer no headset na 0.3.3:** o SteamVR recusava as imagens com `Submit error 106`, porque o DirectX 11 do GTA V Legacy é criado com DXGI 1.0. Agora um dispositivo-ponte DXGI 1.1 na mesma GPU recebe as capturas por textura compartilhada e as entrega ao SteamVR (`SubmitDevice=Auto`). O Diagnostics também inclui os logs do SteamVR. Detalhes em `docs/PATCH_NOTES_0.3.4.md`.

A versão 0.3.3 adicionou **sincronização de quadros**: cada imagem capturada passa a ser identificada pelo marcador da atualização do jogo que a produziu, então cada olho recebe a câmera que o GTA realmente usou para aquela imagem. Também mede se o GTA aplica a câmera de script com uma atualização de atraso e move `WaitGetPoses` para o render thread, sem bloquear o Present. Detalhes em `docs/PATCH_NOTES_0.3.3.md`.

A versão 0.3.2 integrou a **interface de câmera e tracking 6DOF ao renderizador principal**, com leitura das propriedades nativas depois de aplicar posição, rotação e FOV. Inclui o instalador `gta5vrmod setup.exe` e o menu `GTA5 VR.exe`. Não há modo de teste separado: a integração é usada automaticamente no gameplay com o renderizador integrado. O código foi compilado para Windows x64, mas **não foi executado no Windows, no GTA ou em um headset**. O funcionamento e a estabilidade ainda precisam ser confirmados no jogo.

SteamVR continua fornecendo o tracking normalmente. Uma interface adicional permite que outros plugins enviem poses e consultem a câmera sem executar funções do GTA fora do script principal. Dados inválidos, antigos ou fora de ordem são rejeitados. Detalhes para desenvolvedores em `docs/CAMERA_API.md`; essa interface não precisa ser configurada para jogar.

O log da versão 0.3 parava em "Waiting for the game swapchain". A versão 0.3.1 recebe a imagem pelo callback de vídeo do Script Hook V, substituindo a busca baseada em uma janela temporária do DirectX. O novo log registra a chegada da imagem, a conexão com SteamVR, o tracking e o primeiro envio de texturas aceito. O log anterior, sozinho, não permite concluir qual dessas etapas estava bloqueada.

O novo renderizador captura duas posições de câmera diferentes em quadros alternados do GTA, usando a distância entre os olhos e projeções fornecidas pelo headset. Desde a 0.3.3, um marcador preto/branco de 96×6 px no canto superior esquerdo (coberto nas imagens do headset, visível no monitor) diz a qual atualização cada imagem pertence. Cada olho recebe uma imagem nova a cada dois quadros. Isso pode gerar duplicação, desconforto e artefatos em movimento.

## Instalar e iniciar

1. Use **GTA V Legacy (DirectX 11)** no Windows x64, com **Script Hook V** e o **ASI Loader** (o `dinput8.dll` que vem com o Script Hook V). GTA V Enhanced não é suportado.
2. Feche o GTA e execute `gta5vrmod setup.exe`. Ele acha a pasta do GTA V (Epic, Steam ou Rockstar), mostra o que tem e o que falta nela, e instala. Deixe marcado "Start with the default settings".
3. Abra o launcher: `GTA5 VR.exe` na pasta do GTA V (ou **Open launcher** no Setup). Escolha as opções; elas são salvas na hora.
4. Inicie o SteamVR com o headset e os controles ligados, feche o dashboard e aperte **PLAY GTA 5 IN VR** — ou abra o GTA V pela biblioteca da Epic / Steam / Rockstar (na Epic, use a biblioteca da Epic se o Play pedir o launcher da loja). Entre no **Story Mode**. O VR começa quando o Script Hook V inicia os scripts; a abertura do jogo pode aparecer só no monitor.
5. No jogo: **F10** recentraliza a visão; segurar os **dois analógicos por 1 s** (ou **F11**) desliga / liga o VR; ficar em **T-pose e segurar os dois gatilhos por 2 s** ajusta o corpo ao seu tamanho. Os controles de movimento já começam ligados (**F8** desliga / liga).

O Setup faz backup dos arquivos substituídos (pasta `GTA5VR-Backups`). Nenhum arquivo do jogo, Script Hook V, ASI Loader ou SteamVR é distribuído. Não deixe o `RealVR.asi` (outro mod de VR) na pasta do GTA V: dois mods de VR não funcionam juntos, e o launcher avisa.

## Renderizador e primeira pessoa

- `GTA5VRRenderer.asi` recebe o swapchain DirectX 11 pelo callback Present do Script Hook V; copia a imagem do GTA para texturas compartilhadas, que um dispositivo-ponte DXGI 1.1 na mesma GPU entrega ao compositor SteamVR (0.3.4). Não aplica IA ou geração de quadros.
- O script usa câmeras diferentes para os olhos esquerdo/direito, tracking de cabeça, IPD do headset e recorte assimétrico de projeção. A imagem anterior do outro olho é mantida com sua pose de captura. Não há renderização simultânea dos dois olhos nem depth buffer para reprojeção posicional.
- O personagem usa a câmera nativa de primeira pessoa como referência. Movimento físico da cabeça é limitado a 0,75 m na escala padrão e possui um teste simples contra paredes.
- O corpo do jogador fica oculto para evitar que a câmera veja dentro da cabeça. A arma de movimento continua independente. Os braços e as mãos com dedos são desenhados pelo renderizador a partir do tracking do SteamVR (0.4.0, seção `[Hands]`). `HideBody=0` permite experimentar o corpo visível.
- Em cutscenes, pausa, ragdoll, perda de tracking ou controle do personagem, o script devolve a câmera ao jogo e usa uma **tela plana de cinema**. Não são cutscenes estéreo. Sem tracking válido, a tela só é posicionada depois da primeira pose válida.
- **Sincronização (0.3.3):** cada atualização em estéreo recebe um número, desenhado como marcador com `DRAW_RECT`. O Present copia a imagem e lê o marcador de forma assíncrona; a imagem só vira o olho esquerdo/direito depois que o número é lido. Quadros sem marcador são descartados. `GET_FINAL_RENDERED_CAM_COORD` mede se a câmera foi aplicada na mesma atualização ou uma depois (`CameraLag=Auto`). Se o marcador nunca aparecer, o log avisa e volta ao modo sem marcador (`FrameOffset`).
- Os controles de armas recebem a câmera central da cabeça, evitando que a alternância de olho mova o ponto de referência das mãos.
- O mod consulta `GET_CAM_COORD`, `GET_CAM_ROT` e `GET_CAM_FOV` depois de aplicar a câmera. O log informa se os valores conferem. Isso verifica propriedades da câmera; não comprova que ela produziu o quadro capturado ou que os olhos estão sincronizados.

**Ainda não validado:** que o marcador aparece e é lido no jogo real (o log `Frame sync:` mostra isso), atualização da câmera nativa enquanto uma câmera de script está ativa, convenção vertical do FOV do GTA, espelhamento/orientação das texturas, HUD, mudanças de personagem/veículo, missões que controlam câmeras, compatibilidade com outros mods e desempenho. Veja `docs/RENDERER.md` e `docs/VERIFICATION.md`. Esses pontos podem impedir o uso confortável ou correto do protótipo.

Referências dos projetos: [Script Hook V](https://www.dev-c.com/gtav/scripthookv/), [OpenVR](https://github.com/ValveSoftware/openvr).

## Mãos e soco (0.4.0)

- Mão, dedos, antebraço e braço são desenhados por cima da imagem de cada olho. As cores e o tamanho ficam em `[Hands]` no `GTAHandVR.ini`. Os braços são estimados por IK a partir do ombro.
- Com controles Touch funcionam mão aberta, joinha, punho e apontar. O dedo do meio sai pelo combo de botões. Com hand tracking cada dedo se move sozinho.
- No SteamVR, use o binding **padrão** do app: bindings personalizados antigos não têm as ações de esqueleto.
- Soco desarmado (modo de movimento ligado):
  - O mod descobre a região atingida (cabeça, pescoço, tronco, braço ou perna), aplica o dano daquela região e empurra a pessoa a partir do osso atingido.
  - Soco forte na cabeça derruba. Pedestres comuns revidam.
  - Opções em `[Punch]`.

## Interações existentes

As interações da versão 0.2 foram preservadas: catálogo de 113 entradas reconhecidas quando possuídas, 34 adaptações genéricas de carregador, 74 armas com disparo genérico, 20 entradas de corpo a corpo, 10 arremessáveis e 9 ferramentas/especiais que usam controles normais. Esses números descrevem caminhos de código, não armas testadas no jogo; veja `docs/WEAPON_COVERAGE.md`. Pistolas e rifles de assalto permitem uma mão; apoio para outras armas é configurável. Direção física continua opcional e incompleta.

A IA, dano e progressão são do jogo original. A geração de disparos por natives não garante que todos os scripts de missão reconheçam o gesto como uma ação normal do personagem. Campanha completa com controles VR e cutscenes sem bugs **não está estabelecida**.

## Controles Touch

| Controle | Ação |
|---|---|
| F8 / segurar Y esquerdo (0,8 s) | Ativar/desativar interações |
| Segurar clique do analógico direito + empurrar (esq./cima/dir.) + soltar | Roda de personagens do GTA: Michael / Franklin / Trevor |
| Shift+PageUp / Shift+PageDown / Shift+Home | Zoom da imagem no VR (1,00 = exato) |
| Toque no Y esquerdo | Entrar / sair do veículo (o clique no analógico direito também entra) |
| No veículo: gatilho direito / esquerdo, analógico esquerdo, A | Acelerar / frear-ré, volante, freio de mão |
| F9 | Recarregar configurações de movimento |
| F10 | Recentralizar headset e tela de cinema |
| Shift+F10 | Alternar 3D (olhos alternados) / Mono estável |
| F11 | Alternar gameplay estéreo / cinema plano (renderizador integrado) |
| Shift+F11 | Alternar `CameraLag` Auto → 0 → 1 (comparar olhos no headset) |
| B segurado + analógico direito | Categoria da roda de armas |
| Analógico esquerdo com roda aberta | Arma anterior/próxima dentro da categoria |
| Soltar B | Equipar; analógico direito centralizado cancela |
| Gatilho direito | Atirar; preparar arremessável; usar detonador |
| A | Soltar o pente / recarga temporizada; freio de mão ao dirigir |
| Grip direito no quadril / peito / atrás do ombro | Sacar a arma daquele holster; no holster da arma atual, guardar |
| Grip esquerdo | Apoiar arma, pegar carregador, manipular ferrolho ou segurar volante |
| Grip direito | Pegar arremessável; soltar depois de preparar para arremessar |
| Analógico esquerdo / clique | Andar / correr |
| Grip + gatilho + clique no analógico (mesma mão) | Dedo do meio (não entra em veículo / não corre enquanto segura) |
| Analógico direito | Giro por etapas fora da roda |
| Clique no analógico direito | Entrar/sair de veículo |
| X esquerdo | Pular |

**Recarga com carregador:** aperte A; aperte grip esquerdo perto do quadril esquerdo; leve o carregador para baixo da arma; solte; pegue o ferrolho/slide com grip esquerdo; puxe aproximadamente 6,5 cm para trás e solte. Marcadores indicam os pontos de interação. Armas sem carregador destacável usam o botão A e um temporizador. Não há inserção individual de cartuchos, recarga física de tambor ou pump action físico nesta versão.

**Arremessáveis:** solte grip e gatilho antes de começar; aperte grip direito para segurar; aperte gatilho para preparar; solte o grip durante o movimento. Para C4, depois do lançamento solte o gatilho e aperte novamente para detonar. O prop de detonador é solicitado ao próprio jogo; se indisponível, aparece um marcador. Esses comportamentos ainda não foram confirmados no jogo.

**Direção:** gatilho direito acelera, gatilho esquerdo freia, o analógico esquerdo vira; os gatilhos precisam ser soltos antes de assumir o controle ao entrar. Helicópteros e aviões: gatilho direito acelera, esquerdo desce, analógico esquerdo inclina, direito gira. (A direção física, com as mãos no volante, saiu na 0.16.0.)

## Se não funcionar

Primeiro veja o quadro no topo do launcher: ele diz o que falta. Depois envie os logs da pasta do GTA V: `GTAHandVR.log` e `GTA5VRRenderer.log` (e, para erros do SteamVR, `vrclient_GTA5.txt` da pasta `logs` do Steam). Nenhum log é enviado automaticamente.

- Sem `GTA5VRRenderer.log`: confira ASI loader, Script Hook V, versão Legacy e pasta de instalação.
- Log ainda mostrando versão 0.3 e "hooks installed": a atualização não foi carregada; confira se o Setup apontou para a mesma pasta usada pela Epic e reinicie GTA.
- `Submit error 106`: o SteamVR recusou as texturas. Confirme `SubmitDevice=Auto` ou `Bridge` no `GTAHandVR.ini` e a linha `Submit device: bridge`. Se o erro continuar com a ponte, envie os logs e o `vrclient_GTA5.txt` do SteamVR.
- Versão 0.3.4 parada em "waiting for a game frame": confirme Legacy / DirectX 11 e Script Hook V compatível. Envie o log completo, incluindo a última etapa `Capture:` ou `OpenVR:`. O aviso de 15 segundos só pode aparecer enquanto o script do jogo continua executando.
- `Frame sync: frame tag found` confirma que o marcador foi lido e que os olhos seguem a imagem real. `Frame sync: no frame tag ... cell samples` mostra as cores lidas no canto quando o marcador não aparece; envie essa linha. `Falling back to untagged` indica o modo antigo, sem verificação dos olhos.
- Profundidade invertida ou visão "errada" com marcador funcionando: aperte Shift+F11 e compare 0 e 1; informe qual ficou certo e o valor medido no log (`measured scripted-camera application`).
- `Camera API v1 loaded` confirma a inicialização da interface. `Camera native readback` mostra que o script aplicou e leu a câmera. Mensagens `Camera paused` explicam situações como perda de tracking, dashboard ou primeira pessoa desativada. Nenhuma dessas mensagens, sozinha, confirma a imagem correta no headset.
- Erro de inicialização: confira SteamVR, headset, GPU e arquivos do pacote. Reinicie GTA depois de corrigir; o renderer não reinicializa no meio de uma sessão.
- Tela plana: veja se First-person está marcado e se F11, cutscene, menu ou perda de tracking está mantendo o modo cinema.
- Visão duplicada, tremida ou distorcida: F11 + F8 retorna ao controle convencional em cinema; envie os logs. Ajustar WorldScale não corrige erro de sincronização de câmera.
- Sem mãos/arma: confirme tracking, bindings Touch e F8. Atualize todos os arquivos juntos pelo Setup.

## Remover ou restaurar

Use **Uninstall** no `gta5vrmod setup.exe` (o GTA V, o Script Hook V e o ASI Loader ficam). Para fazer à mão: feche o GTA e consulte `GTAHandVR/Installed-files.txt`. Remova somente entradas CREATED; restaure REPLACED pelo backup indicado; preserve PRESERVED. Não remova arquivos originais do GTA ou dependências separadas. Não descarregue os ASIs enquanto GTA está em execução.

## Código e verificação

O código original é MIT. Dependências e seus hashes estão em `THIRD_PARTY_NOTICES.md` e `DEPENDENCIES.json`. A 0.3.3 foi compilada com [llvm-mingw 20240619](https://github.com/mstorsjo/llvm-mingw/releases/tag/20240619) (clang 18.1.8, UCRT); Zig 0.13.0 continua suportado:

```sh
python build.py --llvm-mingw /caminho/para/llvm-mingw --test   # usado na 0.3.3
python build.py --zig /caminho/para/zig --test                 # alternativa
python tests/check_package.py
```

Os testes locais cobrem marcador de quadro, correspondência de olhos em 32 pipelines simulados (atraso de render, atraso de câmera, ticks perdidos), matemática de câmera/projeção, protocolo, gestos, validade/expiração das poses, e leitura da câmera entre threads. A inspeção do instalador compara recursos incorporados byte a byte e verifica os exports da interface de câmera. Não substituem a execução no Windows/GTA/headset.
