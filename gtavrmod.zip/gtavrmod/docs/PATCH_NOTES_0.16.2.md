# 0.16.2: o corpo vira com você de verdade, a visão fica no corpo, imagem suave

Tudo da 0.16.1 continua. Mudou isto, depois do segundo teste no PC do desenvolvedor (GTA V do app Xbox, RTX 4070 SUPER, óculos a 72 Hz).

## O que o teste mostrou

- "Tá muito travado e a cabeça não vira junto com o tronco do personagem."
- **A visão ficava na frente do corpo.** Depois do menu do SteamVR, a câmera do GTA ficava inclinada para o chão (-70°) e o personagem ficava curvado. O mod mediu a posição dos olhos nessa hora e guardou: os olhos ficaram 37 a 48 cm na frente do corpo pelo resto da partida (o normal é 8 cm). Por isso a visão parecia solta do corpo, e as mãos do personagem não alcançavam os controles: três vezes a arma ficou flutuando ("the character's hand did not bring the Pistol...").
- **O corpo quase nunca virava.** O mod só virava o personagem com o seu corpo uns 90° virado e parado. Andando, nunca. O log mostrou o personagem 42° a 85° virado em relação à câmera do GTA.
- **O 3D travava.** No começo o jogo rodava a 45 FPS e depois a 72 FPS. Mas no 3D cada olho recebe metade dos quadros: 22 e depois 36 imagens por segundo, num óculos de 72 Hz.

## A visão fica no corpo

- A posição dos olhos agora só é medida com o personagem em pé e reto. Se o GTA inclinar o personagem (olhando para o chão, mirando), a medida espera.
- A pé, os olhos ficam sempre em cima do corpo: no máximo 4 cm para o lado e 14 cm para a frente.
- Enquanto mede, a visão fica no corpo (antes ela seguia a cabeça animada do GTA).

## O corpo vira com você

- **A visão tem a própria direção.** Só a sua cabeça e o giro do analógico direito viram a visão. A câmera do GTA não mexe mais nela.
- **O personagem vira para onde o seu corpo está virado:**
  - quando você vira a cabeça mais de 40°, o corpo vem junto na hora;
  - quando você fica 0,5 s olhando 20° ou mais para o lado, o corpo vira todo para lá (em uns 0,4 s);
  - andando, o corpo fica de frente para onde você anda;
  - olhando para baixo (para um coldre, um carregador), o corpo não se mexe.
- Antes o mod virava a câmera do GTA e depois virava a visão de volta, quando o GTA mostrava a virada. Às vezes isso chegava atrasado, ou nunca ("GTA's camera did not take the body turn"). Isso acabou.
- Os coldres ficam no corpo do personagem: o mod de movimento usa a mesma direção do corpo.
- `[Body] TurnBody=0` volta como na 0.16.1 (sem virar o corpo).

## Imagem mais suave

- **O modo automático começa em Mono** (a mesma imagem nos dois olhos, todo quadro) e só passa para o 3D quando cada olho recebe 40 imagens por segundo ou mais, com o GTA rodando quase na taxa do óculos:
  - **72 Hz:** sempre Mono (no 3D cada olho receberia 36 por segundo, no máximo);
  - **90 Hz:** 3D acima de 81 FPS, Mono abaixo de 72;
  - **120 Hz:** 3D acima de 108 FPS, Mono abaixo de 96.
- Shift+F10 continua trocando na hora entre 3D e Mono. `[Renderer] StereoMode=Alternating` força o 3D.
- Para ter 3D suave: óculos a 90 Hz e o GTA rodando a 90 FPS (gráficos mais baixos, VSync desligado).

## Para o próximo teste (no log)

A cada 10 s o `GTA5VRRenderer.log` tem uma linha "Frame timing" com:
- quantos quadros do GTA vieram no tempo certo e quantos atrasaram;
- o tempo de GPU;
- quanto a renderização esperou pelo mod;
- quantos quadros o SteamVR mostrou, perdeu ou reprojetou;
- se o personagem acompanha o seu corpo ("body: off_avg/max_deg").

Mande os dois logs depois de jogar.
