# 0.3.2 — integração de câmera na versão principal

A integração faz parte de `GTA5VRRenderer.asi`, instalado pelo mesmo Setup e configurado pelo mesmo menu. Não há modo de teste separado.

- A câmera recebe o tracking pelo caminho principal do Script Hook V.
- Após aplicar posição, rotação e FOV, o mod lê as propriedades nativas e registra diferenças no diagnóstico.
- Uma interface C para outros plugins aceita poses de cabeça e fornece a câmera atual sem executar natives fora do script do jogo. SteamVR continua sendo a fonte padrão.
- A interface rejeita dados inválidos, antigos ou fora de ordem; perda de dados do provedor externo suspende a câmera até receber uma pose válida ou devolver o controle ao SteamVR.
- O mod recria sua câmera quando o handle deixa de existir, reiniciando a preparação das imagens dos dois olhos.

Instalação: feche GTA e o menu; rode `GTA5_VR_Setup.exe` na pasta do GTA V Legacy da Epic. No menu, salve Built-in OpenVR renderer, OpenVR / SteamVR e First-person gameplay. Inicie SteamVR e depois GTA pela biblioteca da Epic, em Story Mode. F10 recentraliza; F8 ativa as interações depois de confirmar a imagem no headset.

Os controles de armas e demais interações anteriores continuam presentes. OpenXR ainda exige renderizador externo. A confirmação das propriedades da câmera não prova a sincronização dos olhos com a imagem capturada. Esta atualização permanece sem execução validada no GTA/headset.

Se não funcionar, abra Diagnostics e envie o novo arquivo. Confira `0.3.2` no início do log. As linhas `Camera API v1 loaded` e `Camera native readback` ajudam a distinguir inicialização da interface de aplicação efetiva da câmera.
