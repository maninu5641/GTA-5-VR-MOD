# 0.15.8: a arma não some mais da mão, e fica na mão do jeito que o GTA segura

Tudo da 0.15.7 continua. Mudou isto.

## O que vocês mandaram

- Vídeo da 0.15.7: "arrume a posição da mão, ela não deveria fazer um punho na arma; e a arma está sumindo das minhas mãos mesmo fora de casa".
- No vídeo: a pistola some da mão de um quadro para o outro; a mão abre por um instante e logo depois fecha em punho, vazia. Com a pistola na mão, os dedos ficam como uma garra e a pistola fica deitada ao longo dos dedos, com o cabo perto do pulso.

## A arma sumindo da mão

### O que estava errado

- Qualquer atualização sem leitura válida do controle soltava tudo. Bastava um instante sem rastreamento do controle direito (no Quest isso acontece quando o controle passa perto do rosto ou sai da vista das câmeras) ou um único quadro lento do jogo (a leitura do controle chegando com mais de 0,2 s). A arma voltava para o coldre, mesmo com você apertando o grip. Uma queda ou o personagem caindo no chão (ragdoll) fazia o mesmo.
- O grip tinha um limite só, 65%. Se a mão relaxava um pouco, ou se a leitura ficava oscilando perto de 65%, a arma voltava para o coldre.

### O que mudou

- **Até 1,5 s sem leitura do controle, e durante quedas, as mãos ficam com o que estão segurando.** Só depois de 1,5 s sem leitura a arma volta para o coldre, como antes.
- **O grip pega a arma acima de 65% e só solta abaixo de 35%** (por 0,1 s). Mão relaxada não derruba mais a arma.
- Se a arma escapar longe de um coldre, **aperte o grip de novo em até 0,8 s e a mesma arma volta para a mão.**
- Granadas: saem voando quando o grip fica abaixo de 35% (antes era 65%).
- O log agora diz por que cada arma saiu da mão (linhas "Hand: the ... left the right hand - ...") e quanto tempo o controle ficou sem leitura, e por quê (linhas "Input: ...").

## A mão na arma

### O que estava errado

- Na 0.15.7 a arma ficava presa num ponto fixo da palma (o "PH_R_Hand" do GTA), sem ajuste. Só que o GTA não segura as armas exatamente ali: cada arma tem o cabo num lugar diferente. Por isso a pistola ficava deitada ao longo dos dedos, com o cabo perto do pulso.
- Os dedos: no começo do jogo o mod faz um teste de mãos e vê quais poses do GTA fecham os dedos do personagem. Quando a pose de pistola do GTA não passava nesse teste, a pistola ficava com a pose de "garra". É essa garra/punho que aparece na pistola. Os rifles usavam a pose de rifle, que funcionava.

### O que mudou

- **Cada arma agora fica na mão do jeito que o próprio GTA segura aquela arma.** Na primeira vez que você pega cada arma, o mod lê, por até 1,5 s, como o GTA segura ela (na cópia invisível que o personagem já segura para o som dos tiros) e prende a arma de VR na mão nessa mesma posição. Nessa primeira vez a arma pode dar um pequeno pulo na mão quando a leitura termina.
- Durante essa leitura (até 1,5 s, só na primeira vez de cada arma), o GTA pode colocar a mão esquerda do personagem na frente de um rifle. Depois ela fica livre de novo.
- O mod confere se a arma ficou mesmo do jeito do GTA. Se não ficou, volta a usar o ponto da palma da 0.15.7 para aquela arma, e o log avisa.
- **Os dedos: uma arma cuja pose de segurar não fecha a mão agora usa a pose de outra arma que fecha.** Primeiro a do rifle: a mão em volta do cabo, o indicador no gatilho. Não usa mais a garra.
- Se o jogo não tocar as poses por dedo (aí o mod usa poses da mão inteira), uma arma agora usa a pose de rifle do GTA em vez da garra.

## No instalador

Deixe marcado "Reset GTAHandVR.ini" (as opções novas entram; o arquivo antigo fica no backup).

## Se algo ficar errado (no `GTAHandVR.ini`)

- A arma presa do jeito do GTA atrapalhando: `[Weapons] GtaGrip=0` volta como na 0.15.7.
- A pistola ainda com a mão estranha: `[Hands] PistolGrip=Rifle` faz a pistola usar sempre a pose do rifle.
- O resto continua como na 0.15.7 (`HandHold`, `PhoneStick`, `PrologueCover`, `HealOnKill`).

## Limites

**Nada disso rodou no GTA ainda.**

- Ainda não chegou nenhum log de vocês. Com os dois logs eu vejo exatamente o que aconteceu, em vez de adivinhar pelo vídeo. O vídeo mostra que a arma sumiu, mas não mostra por quê.
- A leitura do jeito que o GTA segura a arma precisa do som dos tiros ligado (`[Weapons] GunSound=Game`, o padrão) e de munição na arma.

## Mande depois de testar

1. **Os dois logs**, da pasta do GTA: `GTAHandVR.log` e `GTA5VRRenderer.log`. Mesmo que tudo funcione. As linhas importantes começam com "Hand:", "Input:" e "Fingers:".
2. **Um vídeo com o painel ligado** (Shift+End no teclado, antes de colocar o óculos) mostrando:
   - pegar a pistola, olhar para a mão, girar o pulso e atirar;
   - o mesmo com um rifle;
   - andar alguns minutos com a arma na mão fora de casa, como no último vídeo, para ver se ela ainda some;
   - se ela sumir, anotar o minuto do vídeo em que sumiu.
