# 0.4.0 — braços, mãos com dedos e soco com hitbox

![Gestos desenhados pela geometria do mod](hand_preview.png)

*A imagem foi gerada fora do jogo com a mesma geometria e iluminação que o mod usa, a partir de esqueletos de mão sintéticos. Ela não é uma captura do headset.*

## Braços e mãos no VR

- O renderizador lê o **esqueleto da mão do SteamVR** (31 ossos por mão, ações `left_skeleton` / `right_skeleton` novas nos manifestos) e desenha **mão, dedos, antebraço e braço** por cima da imagem de cada olho, no dispositivo-ponte da 0.3.4.
- Cada dedo segue o tracking: mão aberta, joinha, punho e apontar funcionam com os controles Touch. Com **hand tracking do Quest** (por exemplo pelo Virtual Desktop, que envia todos os dedos ao SteamVR), cada dedo se move sozinho, inclusive "três dedos" e dedo do meio.
- **Controles Touch: dedo do meio por botões.** O Touch tem um sensor só (o grip) para médio, anelar e mindinho, então esses dedos sempre se movem juntos. Como em outros jogos de VR, existe um combo: **feche a mão (grip + gatilho) e clique no analógico da mesma mão**. Enquanto o combo está ativo, esse clique não entra em veículo nem faz correr. O combo fica desligado dentro de veículos. Para desligar: `MiddleFingerCombo=0`.
- Os braços usam IK de dois ossos, do ombro (estimado a partir da cabeça) até o pulso rastreado. A direção do cotovelo segue a orientação da mão.
- A cor da pele muda por personagem (Michael, Franklin, Trevor), e o brilho acompanha a hora do jogo (mão mais escura à noite). Tudo é configurável em `[Hands]`.
- Quando as mãos são desenhadas, os marcadores azuis de mão do modo de movimento somem.
- O log mostra o nível de tracking dos dedos de cada mão ("partial" para Touch, "full" para hand tracking) e o gesto reconhecido (por exemplo `Hands: right gesture middle finger`).

## Soco com hitbox

- O soco agora testa os **limites de ragdoll** do corpo (`START_SHAPE_TEST_CAPSULE` com flags 12) e procura o **osso mais próximo do ponto de contato**: cabeça, pescoço, tronco, braço ou perna.
- **O dano depende da região e da velocidade do soco.** Na mesma força, a cabeça recebe 2,2×, o pescoço 1,7×, o tronco 1×, a perna 0,7× e o braço 0,55×.
- Reações:
  - Soco forte na cabeça ou no pescoço (a partir de 2,3 m/s) derruba.
  - Soco muito forte no tronco (a partir de 3,2 m/s) derruba.
  - Socos médios em qualquer lugar fazem a pessoa cambalear.
  - Nos três casos o mod empurra a pessoa a partir do osso atingido (`APPLY_FORCE_TO_ENTITY` com o índice do osso).
- Pedestres comuns revidam (`Provoke=1`). Personagens de missão mantêm o comportamento do script.
- Armas brancas usam o mesmo sistema, com o dano base da arma.
- Opções em `[Punch]`: `Localized`, `Force`, `Provoke`.

## Como testar

1. Instale com o Setup da 0.4.0 na pasta do GTA (as configurações antigas são preservadas; as novas opções têm padrão).
2. No SteamVR, em **Controller Bindings** do "GTA 5 VR - built-in renderer", escolha o binding **padrão (Default)**. Um binding personalizado antigo não tem as ações de esqueleto, e aí os dedos não aparecem.
3. No jogo, olhe para as mãos e abra e feche os dedos. Faça o combo do dedo do meio.
4. Ative o modo de movimento (F8 / Y esquerdo), fique desarmado e dê socos em um pedestre: cabeça, barriga e braço.
5. Mande o Diagnostics. Linhas importantes:
   - `Hands: overlay ready`: os shaders compilaram.
   - `Hands: right hand finger tracking ...`: o nível de tracking dos dedos.
   - `Hands: right gesture ...`: o gesto reconhecido.
   - `hands_drawn=` na linha `Frame sync:`: quantas imagens receberam mãos.

## Limites

- **Nada disso rodou no Windows, no GTA ou no headset.** Os shaders são compilados no seu PC pelo `d3dcompiler_47.dll` do Windows. O texto deles foi validado aqui com o DXC.
- **As mãos ficam sempre por cima da imagem**, porque o mod não tem a profundidade do jogo: uma mão "atrás" de uma parede continua visível.
- Não há antialiasing nas mãos.
- **O braço e o ombro são estimados**, não rastreados.
- **O empurrão e a queda dependem do ragdoll do GTA.** A força ainda precisa ser calibrada no jogo (`Force`).
