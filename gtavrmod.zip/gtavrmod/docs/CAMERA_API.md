# Camera API v1 — integrated into GTA5VRRenderer.asi

The normal built-in renderer uses this camera path automatically. There is no separate test mode, extra camera ASI to install, or new player setting. SteamVR supplies tracking by default. This API additionally lets one cooperating in-process plugin submit headset poses and read camera properties without calling GTA natives from its own worker/render thread.

This is development code, compiled but not executed in GTA or on VR hardware. A camera-property readback is not a rendering or comfort certification.

## Public interface

Include `src/camera_api.h`. Use `GetModuleHandleW(L"GTA5VRRenderer.asi")` and `GetProcAddress` to resolve these undecorated exports. An example client is in `examples/camera_client.cpp`; it is compiled as an object to check the interface but is not installed as another camera mod.

| Export | Behavior |
|---|---|
| `GTA5VR_GetCameraApiVersion` | Returns 1. |
| `GTA5VR_SubmitHeadPose` | Validates and queues a pose. Success means accepted input, not that the game has applied or rendered it. |
| `GTA5VR_ClearHeadPose` | Releases the external provider, returns to SteamVR tracking and schedules recentering. |
| `GTA5VR_RequestRecenter` | Queues recentering for the next available camera tick. F10 remains available. |
| `GTA5VR_ReadCamera` | Copies the latest timestamped native camera snapshot. The call itself performs no GTA native calls. |

The contract is Windows x64, C linkage, default struct packing/alignment. Version-1 packets are exactly 72 bytes; snapshots are 152 bytes. Pointer buffers must be valid for the supplied structure size throughout the call. Do not invoke these exports from DllMain. ASI hot unloading is unsupported. Only one external tracking writer is supported; simultaneous writers are not arbitrated.

Input returns one of the results in the header: OK, BAD_ARGUMENT, UNAVAILABLE, STALE_POSE or OUT_OF_ORDER. Exceptions are caught at the DLL API boundary. Built-in mode and First-person must be enabled for pose submission; external renderer mode does not accept camera overrides. Snapshot reads remain available while starting, suspended or disabled.

## Tracking coordinates and lifetime

`headToStanding` is a row-major 3x4 rigid head-to-world transform in **the same OpenVR standing tracking space** as the current HMD/controller poses: metres, +Y up and -Z forward. GTA world coordinates, local-eye transforms, OpenXR poses without a calibrated space conversion, or a different room origin cannot be passed directly. This interface does not implement that calibration. A connected, tracked SteamVR HMD is still required, and SteamVR still owns the compositor session and controller actions.

Set `sampleTimeMs` to the sample's Windows `GetTickCount64()` timestamp. Do not use Unix time, a predicted display timestamp, or repeatedly timestamp old data as new. Packets older than 150 ms or in the future are rejected. Sequence numbers must be nonzero and strictly increase until ClearHeadPose; sample times cannot go backwards. NaN, infinite, non-orthonormal, reflected and excessively distant transforms are rejected without replacing the last accepted sample.

Once an external provider is active, its pose expiring suspends tracked gameplay through the existing cinema/native-camera fallback. It does not silently resume with a different tracking source. Supply a fresh, increasing sample to resume, or call ClearHeadPose before shutting down your provider. Entering/leaving a provider queues recentering and invalidates the two-eye warmup. Head displacement is still bounded by the existing world-scale/room-translation guard. Pause, cutscenes, tracking loss and the built-in camera toggle continue to govern camera ownership.

The public functions exchange POD data through a mutex-protected mailbox. Only the registered Script Hook V script fiber calls GTA natives; the Present callback handles textures only. Public calls never take the render-state mutex, preventing worker callers from waiting on the VR frame loop while holding native state.

## Native camera application and readback

Every active camera plan applies `SET_CAM_COORD`, `SET_CAM_ROT` (rotation order 2) and `SET_CAM_FOV`, then obtains `GET_CAM_COORD`, `GET_CAM_ROT`, `GET_CAM_FOV` and `IS_CAM_ACTIVE`. These getters expose position, Euler rotation and FOV; they are not themselves full matrix functions. The API constructs matrices from the returned values using the project's ZXY basis conversion. A missing camera handle is recreated before choosing the next eye.

Snapshot matrices map camera-local **right, forward, up** axes to GTA world space. Translation is stored at indices 3, 7 and 11. `requestedCamera` describes the selected eye, including headset IPD; `nativeCamera` is read back from the scripted camera. It is not the center-head matrix used for hand mapping. `frame` counts camera applications, not presented frames. Inactive snapshots clear the camera handle, matrices and flags. Check state and timestamp before using a snapshot: script pauses or blocked runtime calls may leave an older snapshot available.

The native-active flag reflects IS_CAM_ACTIVE. The readback-matches flag checks position within 0.02 GTA world units, orientation within 0.5 degrees and FOV within 0.1 degree. Rotation comparison uses bases so wrapped Euler angles are equivalent. Flags are independent: matching properties do not imply the camera is active.

`GTA5VRRenderer.log` reports the native readback on flag changes and at most once every five seconds while flags stay unchanged. Even exact matching properties do not prove that this camera produced the captured backbuffer, that the correct eye was submitted, that the game's FOV convention is correct, or that mission cameras are compatible. Those remain game/headset validation requirements described in RENDERER.md.
