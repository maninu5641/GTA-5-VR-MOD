# 0.16.1: o corpo vira com você, sem painel de números, imagem mais suave

Tudo da 0.16.0 continua. Mudou isto, depois do teste no PC do desenvolvedor (GTA V do app Xbox, RTX 4070 SUPER, óculos a 120 Hz).

## O que o teste mostrou

- **O GTA V do app Xbox funciona.** O Script Hook V reconheceu o jogo (VER_1_0_3889_0) e carregou o GTA 5 VR. O VR só começa depois que o Modo História termina de carregar; antes disso o GTA aparece só no monitor.
- "Quando eu me viro na vida real, o personagem não vira, e a cabeça fica de frente para as costas."
- "Fica travado e a visão parece distorcida." O log mostrou o GTA a 60 FPS o tempo todo, com o óculos a 120 Hz, no modo 3D.
- "Tira o menuzinho com números em cima da cabeça, porque vou lançar o mod."

## O corpo vira com você

- Quando você virava o corpo de verdade e ficava parado, o mod girava a câmera do GTA, mas o GTA não girava o personagem parado junto com ela. A visão ficava virada para as costas do personagem.
- **Agora o personagem vira junto**: depois de meio segundo virado mais de 45°, ele fica de frente para onde o seu corpo está virado, e a visão não se mexe. O log mostra cada virada ("Body: you turned ... - the character turned with you").

## Sem painel de números

- O painel com FPS e números aparecia sozinho por 15 s toda vez que o VR voltava (depois de uma cena, do menu, do pause). **Agora ele não aparece mais sozinho.** Só aparece com Shift+End no teclado, para quem quiser ver os números.

## Imagem mais suave (menos travada e distorcida)

- No modo 3D cada olho recebe metade dos quadros do GTA. Com 60 FPS, cada olho via só 30 imagens por segundo num óculos de 120 Hz, e como cada olho mostra um momento diferente, a imagem ficava distorcida quando você se mexia.
- **O modo automático agora leva em conta a taxa do óculos**: abaixo de 55% dela o mod usa Mono (a mesma imagem nos dois olhos, mais suave); acima de 65% volta para o 3D. A 120 Hz: Mono abaixo de 66 FPS, 3D acima de 78. A 90 Hz: Mono abaixo de 50, 3D acima de 59 (quase igual a antes).
- Shift+F10 continua trocando entre 3D e Mono na hora.

## Para ficar mais fluido

- No GTA, desligue a **sincronização vertical (VSync)**: ela prendia o jogo em 60 FPS.
- No app que liga o óculos ao PC, use **90 Hz ou 72 Hz** em vez de 120 Hz.
- Se a imagem ainda parecer "derretendo" quando você se mexe, desligue o **Motion Smoothing** do SteamVR (ou o ASW / SSW do app do Quest).

## No launcher e no instalador

- O launcher e o instalador agora dizem que o VR começa quando o Modo História termina de carregar.
- A pasta do app Xbox aparece em verde no instalador: "Xbox app (Game Pass) version: start GTA V from the Xbox app".
