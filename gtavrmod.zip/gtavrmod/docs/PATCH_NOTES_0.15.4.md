# 0.15.4: a mão esquerda não fica mais colada no rifle

Tudo da 0.15.3 continua (a roda de personagens do GTA no Y, a arma do GTA escondida). Mudou só isto.

## O que vocês mandaram

- O vídeo: com o rifle e com a escopeta, a mão esquerda do personagem fica colada na frente da arma, mesmo quando a sua mão de verdade está em outro lugar. Sem arma, as duas mãos ficam livres.

## O que estava errado

- Desde a 0.15.0, para o tiro ter o som de verdade, o personagem segura no GTA a mesma arma, invisível.
- Quando o personagem segura uma arma de duas mãos (rifle, escopeta, metralhadora), o próprio GTA coloca a mão esquerda dele na frente da arma. O mod mandava o GTA não fazer isso, mas o GTA não obedece a esse pedido. Por isso a mão ficava colada o tempo todo.

## O que mudou

- Agora o personagem só segura a arma invisível na hora de atirar: a partir do momento em que o dedo começa a apertar o gatilho, e até 0,8 segundo depois do último tiro.
- No resto do tempo a mão esquerda segue a sua mão: dá para tirar a mão da arma, pegar um pente novo e bombear a escopeta.
- Enquanto você atira, a mão esquerda ainda vai para a frente da arma, porque é o próprio GTA que faz isso. É o preço do som de verdade.
- O primeiro tiro pode sair até 0,3 segundo depois de apertar o gatilho, enquanto o GTA pega a arma. Normalmente é bem menos.
- Sem munição, com o pente fora ou na hora de bombear a escopeta, a arma do GTA sai da mão mais rápido, para a mão esquerda ficar livre.
- O som dos tiros continua o mesmo.

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica no backup.

## Se algo ficar errado (no `GTAHandVR.ini`)

- Para a mão esquerda nunca ir para a arma, nem atirando: `[Weapons] GunSound=Off`. Só que aí os tiros ficam sem som, como na 0.14.0.
- Se o primeiro tiro atrasar demais ou ficar sem som: `[Weapons] GunHold=Always` volta ao jeito da 0.15.3 (com a mão colada na arma o tempo todo).

## Limites

**Nada disso rodou no GTA ainda.**

- Se o primeiro tiro de vez em quando sair sem som, me avisem: é o GTA demorando para pegar a arma.

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`. As linhas "Gun sound" mostram quanto o primeiro tiro esperou.
2. **Um vídeo com som** mostrando:
   - o rifle na mão direita, a mão esquerda longe da arma, depois atirando e recarregando;
   - a roda de personagens no Y, se ainda não testaram a 0.15.3.
