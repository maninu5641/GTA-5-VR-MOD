# 0.15.0: botão de VR, som dos tiros e recarga igual Pavlov

## O que vocês pediram

- Um botão para entrar e sair do modo VR.
- As armas não faziam som nenhum ao atirar.
- Pegar e recarregar as armas igual no vídeo do Pavlov.

## O que mudou

1. **Botão de VR.** Clique os dois analógicos ao mesmo tempo e segure 1 segundo.
   - VR desligado: o GTA aparece normal numa tela grande no óculos (e no monitor). Os motion controls param; teclado ou controle de Xbox funcionam.
   - Para voltar ao VR: o mesmo botão (os dois analógicos, 1 segundo) ou F11.
   - Enquanto você segura, aparece "Keep holding both sticks" com uma porcentagem. Quando troca, o controle direito vibra.
   - Segurar os dois analógicos não faz o personagem correr nem abre o menu de personagens.

2. **Som dos tiros.**
   - Antes o mod criava a bala sozinho, e o GTA não toca som para essas balas.
   - Agora, quando a sua mão pega uma arma, o personagem também segura a mesma arma no GTA, invisível (você só vê a arma do VR). Cada tiro pede para o GTA disparar essa arma no ponto para onde o cano aponta. Assim toca o som de verdade de cada arma, com eco, e os pedestres e a polícia reagem ao tiro.
   - A mira do GTA (o pontinho no meio da tela) e o ícone da arma ficam escondidos.
   - Se o GTA não disparar, o mod atira sozinho como na 0.14.0 (sem som) e o log explica o motivo ("Gun sound: GTA did not fire ...").

3. **Recarga igual Pavlov.**
   - A tira o pente: ele cai de dentro da arma, e a arma fica sem pente até você colocar outro.
   - O pente novo continua no cinto (frente, lado esquerdo). Perto da arma ele se alinha sozinho e entra.
   - Arma vazia (atirou até acabar): depois do pente novo o ferrolho fica para trás. Puxe o ferrolho com a mão esquerda (bolinha laranja em cima da arma) ou aperte A. Se ainda tinha bala na arma, não precisa.
   - Sniper Rifle: depois de cada tiro, aperte o grip esquerdo no ferrolho (lado direito, logo atrás da luneta), puxe para trás e empurre para frente.
   - Puxar o gatilho com a arma vazia dá um "clique" (uma vibração curta) no controle.

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica no backup.

## Se algo ficar errado (no `GTAHandVR.ini`)

- O personagem ficar estranho com a arma, ou o som piorar alguma coisa: `[Weapons] GunSound=Off` (volta a ser a 0.14.0).
- Quer a recarga automática, sem puxar o ferrolho: `[Weapons] RackSlide=0`.
- Sniper sem ferrolho: `[Weapons] BoltAction=0`.
- Pente sempre na arma: `[Weapons] MagazineModels=0`.
- Desligar o botão dos dois analógicos: `[Renderer] VrButton=Off` (fica só o F11). O tempo para segurar é `VrButtonHold`.

## Limites

**Nada disso rodou no GTA ainda.**

- O som depende do GTA aceitar disparar a arma invisível. Se ele não aceitar, o log mostra o motivo e eu mudo na próxima versão.
- Se o pente não sair de alguma arma, o log diz que o modelo dela não tem o pente separado.
- Os logs da 0.13.0 / 0.14.0 ainda não chegaram. Sem eles não sei se os dedos já fecham.

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`. O `GTAHandVR.log` tem uma linha "Gun sound" para cada arma.
2. **Um vídeo com som** mostrando:
   - tiros com a pistola e com um fuzil;
   - uma recarga com a arma vazia (pente sai, pente novo, ferrolho ou A);
   - o Sniper Rifle (ferrolho depois do tiro);
   - o botão de VR (desligar e ligar de novo).
