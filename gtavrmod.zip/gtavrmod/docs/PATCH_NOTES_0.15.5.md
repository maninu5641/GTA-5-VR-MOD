# 0.15.5: botões escolhidos dentro do jogo, menu de pausa com os controles, pessoas reagem à arma

Tudo da 0.15.4 continua (a mão esquerda livre do rifle, a roda de personagens do GTA no Y). Mudou isto.

## O que vocês mandaram

- "Faça os bindings de VR e coloque nas configurações do jogo, e deixe o menu usável: toda vez que entro no menu não consigo fazer nada." E: "faça todas as missões compatíveis com o VR".
- Na primeira missão (o prólogo), na hora de trocar para o Trevor, aparece o aviso de trocar de personagem e não funciona.
- Às vezes o jogo sai do modo VR.
- Mirando em alguém, a pessoa não reage: em vez de ficar com medo, não se mexe (os reféns da primeira missão).
- Três vídeos e os logs.

## O que mudou

### Menu de VR dentro do jogo (os botões)

- Novo: um menu de VR, desenhado no jogo, na tela plana do óculos. **Para abrir: com o menu de pausa do GTA aberto, aperte Y.**
- Nele vocês escolhem o que cada botão faz: Y, X, A, B, clique do analógico esquerdo e clique do analógico direito. As opções: roda de personagens do GTA, pular, pente / recarregar, veículo, correr, **tecla de ação E do GTA**, cobertura (Q), celular, habilidade especial, menu de pausa do GTA, o próprio menu de VR, ou nada.
- Também no menu: o giro do analógico direito (desligado, 15, 30, 45, 60 ou 90 graus), as pessoas reagirem à arma (liga / desliga), o botão de menu do SteamVR pausar o GTA (liga / desliga), a visão da roda de personagens (tela plana ou VR) e "voltar os botões ao padrão".
- Analógico para cima / para baixo escolhe a linha; para os lados (ou A) muda o valor; B fecha. Cada mudança é salva na hora no `GTAHandVR.ini`.
- No menu de VR e no menu de pausa, A e B sempre funcionam do mesmo jeito, não importa o que foi colocado nos botões.
- **Mudança no padrão:** o clique do analógico direito agora é a tecla de ação **E** do GTA (portas, conversar, os "aperte E" das missões). Antes, segurá-lo abria a roda de personagens, mas o Y já faz isso. Dá para voltar como era no menu de VR.
- Não dá para colocar opções dentro do menu de Configurações do próprio GTA (o jogo não deixa), por isso o menu de VR é do mod e abre pelo menu de pausa.

### O menu de pausa do GTA com os controles

- O botão de menu do controle esquerdo (o que abre o menu do SteamVR) agora **pausa o GTA** também. Fechando o menu do SteamVR, o menu de pausa do GTA está lá.
- No menu de pausa: analógico = setas, **A = Enter**, **B = voltar** (no começo do menu, volta ao jogo), X = Espaço, grips = Q / E (abas), gatilhos = Page Down / Page Up (zoom do mapa), **Y = menu de VR**.
- Se o GTA parar o mod enquanto está pausado, os controles do menu passam por outro caminho do mod e funcionam igual.

### As pessoas reagem à arma (a mira do próprio GTA)

- O GTA só faz as pessoas e as missões reagirem à mira dele, e a arma de VR não era a mira do GTA.
- Agora, enquanto o cano da arma de VR aponta para uma pessoa (até 40 m), o personagem mira no GTA também: a cópia invisível da arma na mão, a mira do GTA apertada, e a câmera do GTA virada para a pessoa. A imagem do óculos **não** gira junto.
- As pessoas reagem como no jogo normal: mãos para cima, fogem ou brigam. A polícia também: mirar num policial dá estrela de procurado, como no GTA normal.
- As missões veem a mira: no prólogo os reféns se levantam e vão para o armário; nas lojas o caixa entrega o dinheiro.
- O corpo do personagem vira para a pessoa (é o GTA que faz isso). A posição dos seus olhos fica onde estava.
- Enquanto mira numa pessoa, a mão esquerda do personagem vai para a frente de uma arma de duas mãos, igual a quando atira (é o próprio GTA).
- Não funciona com rifles de precisão nem com lança-foguetes (a mira deles cobre a tela).

### O prólogo: trocar para o Trevor

- O log da 0.15.4 mostra que o GTA recebeu o Alt esquerdo, mas a roda dele não abriu nessa cena.
- Agora, se a roda do GTA não abrir: ao soltar o Y apontando para o Trevor, o mod aperta sozinho a tecla do Trevor (**F7**) um instante depois. Nas missões, o GTA troca com um toque rápido dessa tecla.
- O log agora diz se o GTA viu o Alt como tecla dele ou só como tecla bloqueada, e se a troca aconteceu.

### "O jogo sai do modo VR"

- Achei uma causa: quando uma missão só carrega a próxima cena (antes de ela começar), o mod achava que a cena já estava passando e mostrava a tela plana. Foi o que aconteceu no "Go to the guard" do vídeo, com o personagem andando. Agora a tela plana é só enquanto a cena realmente passa.
- Quando a imagem fica plana por causa do jogo (cena, personagem sem controle, janela do GTA fora de foco), aparece um aviso em cima dizendo o motivo por alguns segundos. O VR volta sozinho.
- O menu do SteamVR continua deixando a imagem plana enquanto está aberto: isso é do SteamVR.

### O celular

- Com o celular na mão, o analógico direito anda pelos apps e pelos contatos (as missões pedem ligações). A e B funcionam como antes.
- Pelo menu de VR, um botão pode ser "Phone": tira o celular e guarda.

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica no backup.

## Se algo ficar errado (no `GTAHandVR.ini`)

- A mira do GTA atrapalhando: `[Weapons] GtaAim=0` volta como na 0.15.4 (também dá no menu de VR).
- O botão do SteamVR não deve pausar o GTA: `[Menu] PauseOnDashboard=0`.
- Os controles no menu de pausa atrapalhando: `[Menu] Controllers=0`.
- Os botões ficam na seção `[Controls]` (ou no menu de VR).

## Limites

**Nada disso rodou no GTA ainda.**

- "Todas as missões": não consigo testar as missões daqui. Esta versão traz o que as missões mais pedem: mirar nas pessoas, a tecla E, o celular, a troca de personagem, o menu de pausa, e o VR não sair quando a missão carrega uma cena. Partes em que a missão usa a própria câmera ou tira o controle do personagem continuam na tela plana. Quando uma missão travar, me mandem qual é e o momento.
- A troca do prólogo: não tenho certeza de que vai funcionar. O GTA pode estar bloqueando a troca nessa cena por outro motivo. O log vai dizer.
- A mira do GTA: pode ser que a câmera do GTA não "pegue" a pessoa. O log diz em cada pessoa se o GTA mirou nela ("GTA aims at him: YES / no").

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`.
2. **Um vídeo com som** mostrando:
   - a arma apontada para uma pessoa (no prólogo, os reféns; na rua, um pedestre);
   - o botão de menu do controle esquerdo: o menu do SteamVR, depois o menu de pausa do GTA com os controles (andar nas abas, entrar, voltar ao jogo com B);
   - o menu de VR (Y no menu de pausa) trocando o que um botão faz;
   - a troca para o Trevor no prólogo (apontar para a direita e soltar o Y).
3. Na cena da troca do prólogo, testem também **no teclado**: segurar o Alt esquerdo e apertar F7. Se pelo teclado trocar e pelo VR não, me avisem.
