# Weapon coverage — 0.3.4 development build (interaction adapters unchanged)

All entries are untested in GTA / VR hardware. The wheel only offers valid, already-owned entries. No weapon is granted by this add-on.

| Weapon | Identifier | Interaction | Reload |
|---|---|---|---|
| Unarmed | `WEAPON_UNARMED` | Tracked swing / NPC collision | Not applicable |
| Knife | `WEAPON_KNIFE` | Tracked swing / NPC collision | Not applicable |
| Nightstick | `WEAPON_NIGHTSTICK` | Tracked swing / NPC collision | Not applicable |
| Hammer | `WEAPON_HAMMER` | Tracked swing / NPC collision | Not applicable |
| Baseball Bat | `WEAPON_BAT` | Tracked swing / NPC collision | Not applicable |
| Golf Club | `WEAPON_GOLFCLUB` | Tracked swing / NPC collision | Not applicable |
| Crowbar | `WEAPON_CROWBAR` | Tracked swing / NPC collision | Not applicable |
| Pistol | `WEAPON_PISTOL` | Tracked native projectile | Generic physical magazine |
| Combat Pistol | `WEAPON_COMBATPISTOL` | Tracked native projectile | Generic physical magazine |
| AP Pistol | `WEAPON_APPISTOL` | Tracked native projectile | Generic physical magazine |
| Pistol .50 | `WEAPON_PISTOL50` | Tracked native projectile | Generic physical magazine |
| Micro SMG | `WEAPON_MICROSMG` | Tracked native projectile | Generic physical magazine |
| SMG | `WEAPON_SMG` | Tracked native projectile | Generic physical magazine |
| Assault SMG | `WEAPON_ASSAULTSMG` | Tracked native projectile | Generic physical magazine |
| Assault Rifle | `WEAPON_ASSAULTRIFLE` | Tracked native projectile | Generic physical magazine |
| Carbine Rifle | `WEAPON_CARBINERIFLE` | Tracked native projectile | Generic physical magazine |
| Advanced Rifle | `WEAPON_ADVANCEDRIFLE` | Tracked native projectile | Generic physical magazine |
| MG | `WEAPON_MG` | Tracked native projectile | Timed A button |
| Combat MG | `WEAPON_COMBATMG` | Tracked native projectile | Timed A button |
| Pump Shotgun | `WEAPON_PUMPSHOTGUN` | Tracked native projectile | Timed A button |
| Sawed-Off Shotgun | `WEAPON_SAWNOFFSHOTGUN` | Tracked native projectile | Timed A button |
| Assault Shotgun | `WEAPON_ASSAULTSHOTGUN` | Tracked native projectile | Timed A button |
| Bullpup Shotgun | `WEAPON_BULLPUPSHOTGUN` | Tracked native projectile | Timed A button |
| Stun Gun | `WEAPON_STUNGUN` | Tracked native projectile | Timed A button |
| Sniper Rifle | `WEAPON_SNIPERRIFLE` | Tracked native projectile | Timed A button |
| Heavy Sniper | `WEAPON_HEAVYSNIPER` | Tracked native projectile | Timed A button |
| Grenade Launcher | `WEAPON_GRENADELAUNCHER` | Tracked native projectile | Timed A button |
| Tear Gas Launcher | `WEAPON_GRENADELAUNCHER_SMOKE` | Tracked native projectile | Timed A button |
| RPG | `WEAPON_RPG` | Tracked native projectile | Timed A button |
| Minigun | `WEAPON_MINIGUN` | Tracked native projectile | Timed A button |
| Grenade | `WEAPON_GRENADE` | Grip / prime / release | Not applicable |
| Sticky Bomb | `WEAPON_STICKYBOMB` | Grip / prime / release | Not applicable |
| Tear Gas | `WEAPON_SMOKEGRENADE` | Grip / prime / release | Not applicable |
| BZ Gas | `WEAPON_BZGAS` | Grip / prime / release | Not applicable |
| Molotov | `WEAPON_MOLOTOV` | Grip / prime / release | Not applicable |
| Fire Extinguisher | `WEAPON_FIREEXTINGUISHER` | Normal game combat controls | Native controls |
| Jerry Can | `WEAPON_PETROLCAN` | Normal game combat controls | Native controls |
| Ball | `WEAPON_BALL` | Grip / prime / release | Not applicable |
| Flare | `WEAPON_FLARE` | Grip / prime / release | Not applicable |
| Bottle | `WEAPON_BOTTLE` | Tracked swing / NPC collision | Not applicable |
| SNS Pistol | `WEAPON_SNSPISTOL` | Tracked native projectile | Generic physical magazine |
| Heavy Pistol | `WEAPON_HEAVYPISTOL` | Tracked native projectile | Generic physical magazine |
| Bullpup Rifle | `WEAPON_BULLPUPRIFLE` | Tracked native projectile | Generic physical magazine |
| Special Carbine | `WEAPON_SPECIALCARBINE` | Tracked native projectile | Generic physical magazine |
| SNS Pistol Mk II | `WEAPON_SNSPISTOL_MK2` | Tracked native projectile | Generic physical magazine |
| Marksman Rifle Mk II | `WEAPON_MARKSMANRIFLE_MK2` | Tracked native projectile | Timed A button |
| Pump Shotgun Mk II | `WEAPON_PUMPSHOTGUN_MK2` | Tracked native projectile | Timed A button |
| Bullpup Rifle Mk II | `WEAPON_BULLPUPRIFLE_MK2` | Tracked native projectile | Generic physical magazine |
| Special Carbine Mk II | `WEAPON_SPECIALCARBINE_MK2` | Tracked native projectile | Generic physical magazine |
| Acid Package | `WEAPON_ACIDPACKAGE` | Normal game combat controls | Native controls |
| Candy Cane | `WEAPON_CANDYCANE` | Tracked swing / NPC collision | Not applicable |
| Railgun | `WEAPON_RAILGUNXM3` | Tracked native projectile | Timed A button |
| WM 29 Pistol | `WEAPON_PISTOLXM3` | Tracked native projectile | Generic physical magazine |
| Up-n-Atomizer | `WEAPON_RAYPISTOL` | Normal game combat controls | Native controls |
| Unholy Hellbringer | `WEAPON_RAYCARBINE` | Tracked native projectile | Timed A button |
| Widowmaker | `WEAPON_RAYMINIGUN` | Tracked native projectile | Timed A button |
| Double-Action Revolver | `WEAPON_DOUBLEACTION` | Tracked native projectile | Timed A button |
| Snowball | `WEAPON_SNOWBALL` | Grip / prime / release | Not applicable |
| Proximity Mine | `WEAPON_PROXMINE` | Grip / prime / release | Not applicable |
| Homing Launcher | `WEAPON_HOMINGLAUNCHER` | Normal game combat controls | Native controls |
| Heavy Revolver Mk II | `WEAPON_REVOLVER_MK2` | Tracked native projectile | Timed A button |
| Gusenberg Sweeper | `WEAPON_GUSENBERG` | Tracked native projectile | Timed A button |
| Antique Cavalry Dagger | `WEAPON_DAGGER` | Tracked swing / NPC collision | Not applicable |
| Vintage Pistol | `WEAPON_VINTAGEPISTOL` | Tracked native projectile | Generic physical magazine |
| Musket | `WEAPON_MUSKET` | Tracked native projectile | Timed A button |
| Firework Launcher | `WEAPON_FIREWORK` | Tracked native projectile | Timed A button |
| Hatchet | `WEAPON_HATCHET` | Tracked swing / NPC collision | Not applicable |
| Railgun | `WEAPON_RAILGUN` | Tracked native projectile | Timed A button |
| Heavy Shotgun | `WEAPON_HEAVYSHOTGUN` | Tracked native projectile | Timed A button |
| Marksman Rifle | `WEAPON_MARKSMANRIFLE` | Tracked native projectile | Timed A button |
| Ceramic Pistol | `WEAPON_CERAMICPISTOL` | Tracked native projectile | Generic physical magazine |
| Military Rifle | `WEAPON_MILITARYRIFLE` | Tracked native projectile | Generic physical magazine |
| Combat Shotgun | `WEAPON_COMBATSHOTGUN` | Tracked native projectile | Timed A button |
| Hazardous Jerry Can | `WEAPON_HAZARDCAN` | Normal game combat controls | Native controls |
| Flare Gun | `WEAPON_FLAREGUN` | Tracked native projectile | Timed A button |
| Perico Pistol | `WEAPON_GADGETPISTOL` | Tracked native projectile | Timed A button |
| Navy Revolver | `WEAPON_NAVYREVOLVER` | Tracked native projectile | Timed A button |
| Knuckle Duster | `WEAPON_KNUCKLE` | Tracked swing / NPC collision | Not applicable |
| Combat PDW | `WEAPON_COMBATPDW` | Tracked native projectile | Generic physical magazine |
| Marksman Pistol | `WEAPON_MARKSMANPISTOL` | Tracked native projectile | Timed A button |
| Double Barrel Shotgun | `WEAPON_DBSHOTGUN` | Tracked native projectile | Timed A button |
| Machete | `WEAPON_MACHETE` | Tracked swing / NPC collision | Not applicable |
| Machine Pistol | `WEAPON_MACHINEPISTOL` | Tracked native projectile | Generic physical magazine |
| Compact Rifle | `WEAPON_COMPACTRIFLE` | Tracked native projectile | Generic physical magazine |
| Flashlight | `WEAPON_FLASHLIGHT` | Tracked swing / NPC collision | Not applicable |
| Switchblade | `WEAPON_SWITCHBLADE` | Tracked swing / NPC collision | Not applicable |
| Heavy Revolver | `WEAPON_REVOLVER` | Tracked native projectile | Timed A button |
| Compact Grenade Launcher | `WEAPON_COMPACTLAUNCHER` | Tracked native projectile | Timed A button |
| Mini SMG | `WEAPON_MINISMG` | Tracked native projectile | Generic physical magazine |
| Pipe Wrench | `WEAPON_WRENCH` | Tracked swing / NPC collision | Not applicable |
| Sweeper Shotgun | `WEAPON_AUTOSHOTGUN` | Tracked native projectile | Timed A button |
| Pool Cue | `WEAPON_POOLCUE` | Tracked swing / NPC collision | Not applicable |
| Battle Axe | `WEAPON_BATTLEAXE` | Tracked swing / NPC collision | Not applicable |
| Pipe Bomb | `WEAPON_PIPEBOMB` | Grip / prime / release | Not applicable |
| Carbine Rifle Mk II | `WEAPON_CARBINERIFLE_MK2` | Tracked native projectile | Generic physical magazine |
| Combat MG Mk II | `WEAPON_COMBATMG_MK2` | Tracked native projectile | Timed A button |
| SMG Mk II | `WEAPON_SMG_MK2` | Tracked native projectile | Generic physical magazine |
| Assault Rifle Mk II | `WEAPON_ASSAULTRIFLE_MK2` | Tracked native projectile | Generic physical magazine |
| Heavy Sniper Mk II | `WEAPON_HEAVYSNIPER_MK2` | Tracked native projectile | Timed A button |
| Pistol Mk II | `WEAPON_PISTOL_MK2` | Tracked native projectile | Generic physical magazine |
| Stone Hatchet | `WEAPON_STONE_HATCHET` | Tracked swing / NPC collision | Not applicable |
| Service Carbine | `WEAPON_TACTICALRIFLE` | Tracked native projectile | Generic physical magazine |
| Precision Rifle | `WEAPON_PRECISIONRIFLE` | Tracked native projectile | Timed A button |
| Heavy Rifle | `WEAPON_HEAVYRIFLE` | Tracked native projectile | Generic physical magazine |
| Fertilizer Can | `WEAPON_FERTILIZERCAN` | Normal game combat controls | Native controls |
| Compact EMP Launcher | `WEAPON_EMPLAUNCHER` | Tracked native projectile | Timed A button |
| Stun Gun | `WEAPON_STUNGUN_MP` | Tracked native projectile | Timed A button |
| Tactical SMG | `WEAPON_TECPISTOL` | Tracked native projectile | Generic physical magazine |
| Snowball Launcher | `WEAPON_SNOWLAUNCHER` | Normal game combat controls | Native controls |
| Battle Rifle | `WEAPON_BATTLERIFLE` | Tracked native projectile | Generic physical magazine |
| Hacking Device | `WEAPON_HACKINGDEVICE` | Normal game combat controls | Native controls |
| The Shocker | `WEAPON_STUNROD` | Tracked swing / NPC collision | Not applicable |
| El Strickler | `WEAPON_STRICKLER` | Tracked native projectile | Generic physical magazine |
