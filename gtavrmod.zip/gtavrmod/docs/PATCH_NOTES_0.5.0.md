# 0.5.0 — armas reformuladas: holsters, tiro realista e recarga física

Pedido do seu amigo: trocar de arma no corpo, tiro mais realista, e recarga do jeito real (pegar o pente, colocar na arma, puxar o ferrolho para pôr a bala na câmara e atirar).

## Holsters no corpo (mão direita + grip)

| Onde | Arma |
|---|---|
| Quadril direito | Pistola |
| Quadril esquerdo | Arma branca (faca, taco...) |
| Peito | Granadas e arremessáveis |
| Atrás do ombro direito | Fuzil, escopeta, SMG ou metralhadora (a última que você usou) |
| Atrás do ombro esquerdo | Sniper ou arma pesada |

- Leve a mão direita até o lugar e aperte o **grip**: a arma sai dali.
- Faça o mesmo no holster da arma que está na mão: você guarda a arma e fica desarmado.
- Quando a mão entra num holster, o controle vibra de leve e aparece um marcador pequeno.
- A roda do botão **B** continua funcionando. Ela escolhe qual arma fica em cada holster (por exemplo, qual pistola vai no quadril).
- As posições são relativas à sua cabeça, então funcionam em pé ou sentado.

## Tiro mais realista

- **Recuo:**
  - A arma sobe e volta para trás a cada tiro.
  - Em rajada, o cano sobe aos poucos e você precisa segurar a mira.
  - Escopeta e sniper dão um coice forte.
  - **Com as duas mãos o recuo cai bastante.** Com uma mão só, armas longas chutam mais.
- **Clarão na ponta do cano e cápsula saindo da arma.** São os efeitos originais do GTA (`muz_pistol`, `muz_assault_rifle`, `muz_shotgun`, `eject_pistol`, `eject_auto`...).
- **Vibração por tipo de arma:** forte na escopeta e na sniper, curta na SMG. A recarga também vibra: pegar o pente, encaixar, puxar o ferrolho.
- **Fuzil e escopeta atiram com uma mão** (com mais recuo). Para voltar a exigir as duas: `RequireSupportGrip=1`, ou marque "Support grip" no menu.

## Recarga física (armas com pente)

1. **A**: o pente vazio cai da arma (com física, no chão).
2. **Mão esquerda no cinto** (quadril esquerdo, na frente) ou no peito, e aperte o **grip**: você pega um pente novo e ele aparece na mão.
3. **Encoste o pente embaixo da arma**, no lugar do pente. Ele encaixa sozinho, não precisa soltar o grip.
4. **Se a arma estava vazia**, a câmara está sem bala: segure o ferrolho ou slide com a mão esquerda (em cima da arma) e **puxe uns 5 cm para trás**. Pronto, pode atirar.

- **Recarga tática:** se você troca o pente com balas sobrando, a bala da câmara fica, então não precisa puxar o ferrolho. Dá até para dar esse último tiro com o pente fora.
- Atirou até zerar: o slide trava e o texto mostra `EMPTY | A: drop the magazine`.
- Um marcador pequeno mostra o próximo passo (cinto, lugar do pente, ferrolho).
- Se você soltar o pente longe da arma, ele cai e você precisa pegar outro.
- Armas sem pente (escopeta pump, revólveres) continuam com a recarga no botão A.

## Configuração (`[Weapons]` no `GTAHandVR.ini`)

`Holsters`, `ShowHolsterZones`, `Recoil` (multiplicador, 0 desliga), `MuzzleFlash`, `ShellEject`. Em `[Motion]`: `ManualReload`, `RequireSupportGrip`.

Setup preserva o seu INI antigo. Opções novas usam o padrão. Uma instalação antiga ainda tem `RequireSupportGrip=1`: desmarque no menu se quiser atirar com uma mão.

## Limites

- **Nada disso rodou no GTA ainda.**
- **As posições do lugar do pente e do ferrolho são genéricas** por tipo de arma (pistola, fuzil, sniper), não por modelo.
- **A direção do clarão e da cápsula depende da orientação do modelo da arma no GTA.** Se aparecerem tortos, desligue com `MuzzleFlash=0` / `ShellEject=0` e me avise.
- **Não há pump físico na escopeta nem recarga bala a bala.**
