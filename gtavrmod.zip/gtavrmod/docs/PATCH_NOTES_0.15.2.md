# 0.15.2: a troca de personagem troca de verdade e a arma atira depois do pente

Tudo da 0.15.0 e da 0.15.1 continua. Mudaram só estas duas coisas.

## O que vocês mandaram

- O menu de personagem abre, mas não entra no personagem escolhido.
- A arma não atira depois de recarregar.

## O que estava errado e o que mudou

1. **Troca de personagem.**
   - No vídeo, o menu abriu, o Michael foi escolhido e depois apareceu "GTA did not switch to Michael".
   - O motivo: o mod apertava a tecla do GTA (F5, F6 ou F7) por só 0,2 segundo. O GTA só troca se a tecla ficar apertada até a roda dele abrir por completo, e isso leva 0,3 segundo. Como o mod soltava antes, o GTA nunca trocava. Descobri isso lendo o código do próprio GTA que cuida da troca.
   - Agora a tecla fica apertada 0,65 segundo. Por um instante aparece a roda do próprio GTA, e então ele troca de personagem.
   - O log diz se o GTA recebeu a tecla ("GTA saw it held") e, se mesmo assim não trocar, o motivo provável.

2. **A arma atira depois de recarregar.**
   - Na 0.15.0 e na 0.15.1, se a arma fosse esvaziada, ela só voltava a atirar depois de puxar o ferrolho ou apertar A, igual no Pavlov. Pelo jeito isso fazia parecer que a arma não atirava.
   - Agora o pente novo já coloca bala na câmara: entrou o pente, a arma atira.
   - Quem quiser puxar o ferrolho igual no Pavlov: `[Weapons] RackSlide=1`.

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica no backup.

## Se algo ficar errado (no `GTAHandVR.ini`)

- Se a troca ainda falhar, aumente o tempo da tecla: `[Motion] CharacterKeyHold=1.0`.
- Puxar o ferrolho igual no Pavlov: `[Weapons] RackSlide=1`.

## Limites

**Nada disso rodou no GTA ainda.**

- O GTA não deixa trocar de personagem em algumas missões, com estrela de polícia, no ar ou na água. Também não troca para um personagem que ainda não apareceu na história (no começo do jogo só dá para jogar com o Franklin).

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`. As linhas "Character menu" mostram se o GTA recebeu a tecla.
2. **Um vídeo com som** mostrando a troca de personagem e uma recarga com a arma vazia, atirando logo depois.
