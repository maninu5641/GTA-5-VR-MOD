# 0.16.0: instalador e launcher simples, pronto para lançar

Tudo da 0.15.8 continua. Mudou o que aparece fora do jogo, e algumas partes saíram.

## O launcher (`GTA5 VR.exe`)

- **Só quatro opções**, salvas na hora em que você marca ou desmarca (não existe mais "Save settings"):
  - **First-person gameplay**: você vê pelos olhos do personagem. Desligado, o GTA aparece numa tela grande dentro do VR.
  - **Physical magazine reload**: você tira o carregador, pega outro no ombro ou no cinto e encaixa na arma.
  - **Support grip for heavier weapons**: rifles e escopetas precisam da outra mão neles para atirar.
  - **Show aiming laser**: um laser sai do cano e mostra para onde vão os tiros.
- Com o GTA aberto, as opções de arma mudam na hora. A primeira pessoa muda quando o GTA abrir de novo.
- **Um botão grande: PLAY GTA 5 IN VR.** Também dá para abrir o GTA V pela Epic, Steam ou Rockstar, e o VR começa junto.
- **Um quadro no topo diz se está tudo pronto** ("Ready to play") **ou o que falta** ("Not ready yet"): o Script Hook V, o ASI Loader, outro mod de VR na pasta, algum arquivo do mod faltando ou estragado, ou o SteamVR. Ele confere de novo sempre que você volta para a janela.
- Embaixo ficam as dicas do jogo: F10 recentraliza a visão; os dois analógicos segurados por 1 s desligam e ligam o VR; T-pose com os dois gatilhos segurados por 2 s ajusta o corpo ao seu tamanho.
- **Saíram:** a escolha do renderizador (R.E.A.L.), a escolha do runtime (OpenXR), a direção física, a caixa de texto técnica e os botões Save settings, Diagnostics, Game folder, Script Hook V source, notas de compatibilidade, Refresh checks e Uninstall. Para desinstalar, use o Setup.

## O instalador (`GTA5_VR_Setup.exe`)

- **Três passos numerados:** 1. escolha a pasta do GTA V Legacy (ele acha sozinho as pastas da Epic, Steam e Rockstar); 2. veja o que tem nela; 3. instale.
- Textos mais simples. O botão **Get Script Hook V** só aparece quando falta o Script Hook V ou o ASI Loader.
- **Open launcher** abre o launcher.
- Saíram o aviso "Experimental mod: not tested..." e o "development build". No lugar: "Story Mode only - GTA Online is not supported."
- Numa atualização, o Setup apaga os arquivos das partes que saíram (o companion do R.E.A.L., a layer OpenXR e as configurações do launcher antigo). Antes de apagar, ele guarda uma cópia na pasta `GTA5VR-Backups`.

## GTA V do app Xbox (PC Game Pass)

- O Setup da 0.15.8 recusava a pasta do app Xbox (`C:\XboxGames\Grand Theft Auto V Legacy\Content`) com a mensagem "Select the GTA V Legacy installation folder... Enhanced is not supported". A lista ficava verde, mas o Install falhava: o instalador lia o `GTA5.exe` inteiro para conferir que era o GTA V Legacy de 64 bits, e essa leitura falhou na pasta do app Xbox (o app protege os arquivos do jogo).
- Agora o instalador lê só o começo do `GTA5.exe`. A pasta do app Xbox (com o `MicrosoftGame.config`, ou dentro de `XboxGames`) é aceita, e o Setup também a procura sozinho em todos os discos.
- Nessa versão aparece um aviso amarelo: **"Xbox app (Game Pass) version: not tested with GTA 5 VR yet"**. O mod só foi testado na versão da Epic, e ele depende do Script Hook V funcionar na versão do app Xbox.
- No launcher, na versão do app Xbox, o PLAY abre a página do GTA V Legacy na Microsoft Store, onde fica o botão Jogar. Se o jogo abrir sem VR, o Script Hook V não funciona nessa versão.

## O que saiu do mod

- **O renderizador externo (R.E.A.L.) e o OpenXR.** O GTA 5 VR usa só o próprio renderizador OpenVR / SteamVR, e os arquivos deles (`GTAHandVR-Bridge.exe` e a pasta `OpenXR`) não são mais instalados.
- **A direção física** (as mãos no volante). Nos veículos: gatilho direito acelera, gatilho esquerdo freia e o analógico esquerdo vira.
- Se um `GTAHandVR.ini` antigo ainda tiver essas opções, elas são ignoradas.
- O log agora começa com "GTA 5 VR 0.16.0 loaded", sem "development build" nem "Experimental".

## Continua igual

- Tudo da 0.15.8: a arma presa na mão do jeito que o GTA segura, o grip que não solta a arma sozinho, os dedos da pistola.
- As outras configurações continuam no `GTAHandVR.ini` e no menu de VR dentro do jogo.
