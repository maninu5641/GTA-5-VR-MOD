# 0.15.6: a roda de personagens do próprio GTA

Tudo da 0.15.5 continua. Mudou só isto.

## O que vocês mandaram

- O vídeo do prólogo: apertando o Y aparece um texto com os nomes (Michael, Franklin, Trevor) em vez da roda do GTA, e a troca não funciona. "Usem a roda do próprio GTA, a que tem as fotos dos personagens, não a de vocês."

## O que estava errado

- O Y não abre um menu do mod: desde a 0.15.3 ele aperta o Alt esquerdo, que é a tecla da roda do próprio GTA. O texto com os nomes era só uma ajuda escrita por cima. Como a roda do GTA nunca abria, só sobrava o texto.
- No vídeo aparece, no canto de baixo à direita, o ícone com o rosto do Trevor. Esse ícone é do próprio GTA e mostra que a troca está liberada nessa cena. Ou seja: o GTA deixava trocar, mas não aceitava a tecla.
- Achei uma causa provável dentro do próprio mod. Desde a 0.7.0 o mod bloqueia o F8, porque no GTA o F8 leva para o GTA Online. Ele bloqueava o F8 com uma opção do GTA que bloqueia também os controles "parecidos" com ele. Isso pode estar desligando também as teclas de troca de personagem (Alt, F5, F6 e F7). Outro bloqueio do mesmo tipo desligava o Q (cobertura).

## O que mudou

- O mod agora bloqueia só as teclas de que precisa, sem os controles "parecidos".
- Enquanto a roda está em uso, o mod libera as teclas de troca do GTA no fim de cada atualização.
- **O mod não escreve mais nada por cima da roda do GTA** (acabou a lista de nomes). Se a roda do GTA não abrir, aparece só "GTA's character wheel did not open here" por 3 segundos.
- Como usar (igual antes):
  - segure o Y: a imagem fica plana e a roda do GTA aparece, com as fotos;
  - aponte um analógico (esquerda Michael, cima Franklin, direita Trevor): a roda do GTA marca o personagem;
  - solte o Y: o GTA troca.
  - Ou dê um toque no Y: a roda fica aberta; Y de novo (ou A, ou o gatilho) troca, e B fecha.
- O log agora diz, a cada atualização, se a tecla da roda do GTA já chegava desligada ou se foi o mod que a desligou. Isso mostra de vez quem bloqueia.

## No instalador

Pode deixar marcado "Reset GTAHandVR.ini" (os botões escolhidos no menu de VR voltam ao padrão; o arquivo antigo fica no backup).

## Limites

**Nada disso rodou no GTA ainda.** A causa é provável, mas não confirmada.

## Mande depois de testar

1. **O `GTAHandVR.log`** (e o `GTA5VRRenderer.log`). Desta vez o log é o mais importante: as linhas "Character wheel" dizem se a roda do GTA abriu e, se não abriu, quem desligou a tecla.
2. Um vídeo da troca para o Trevor no prólogo.
3. Se a roda ainda não abrir: na mesma cena, segurem o Alt esquerdo no teclado. Se pelo teclado ela abrir e pelo Y não, me avisem.
