# 0.8.0: correr sozinho, braços sem animação, roda de personagem do GTA, renderer antigo, setup e desinstalar

Feito a partir do vídeo da 0.7.0.

## O personagem corria sozinho

**A causa:** desde a 0.6.0, o toque no Y ou um clique sem querer no analógico direito (comum ao virar) procurava um carro num raio de 6 m. Se o GTA não entrava sozinho, o mod mandava o personagem andar ou correr até esse carro, e o analógico não cancelava isso. Saindo de casa sempre tem um carro estacionado perto, então ele saía correndo para o carro.

**Agora:**
- **Toque no Y usa só o "entrar no veículo" do próprio GTA**, igual ao Y do controle de Xbox. O personagem só vai até o carro se o GTA mandar, e mexer o analógico cancela, como no jogo normal.
- **O Y só funciona com um carro a até 4 m.** Longe de carro, o Y não faz nada.
- **O clique do analógico direito não entra mais em carro;** ele agora só abre a roda de personagens.
- Para voltar ao comportamento antigo: `EnterVehicleTask=1`.

## Mãos sem animação de andar e correr

- **No vídeo, os braços ficavam no quadril** enquanto a arma flutuava no controle: a animação de andar e parado do GTA ganhava do IK.
- **Agora os braços ficam numa pose parada à frente do corpo,** a de "carregar caixa" do próprio GTA, só da cintura para cima. As pernas andam e correm normalmente, mas os braços não balançam mais; quem move as mãos é o IK.
- A pose sai sozinha ao entrar em carro, nadar, escalar, ficar na cobertura, cair ou virar ragdoll.
- `ArmPose=0` volta ao normal.
- **O mod testa sozinho cada jeito de chamar o IK do GTA** (orientação, posição e três pontos da mão) e fica com o que realmente leva a mão até o controle. O log diz qual funcionou ("Arm IK ... moves the hand to the controller"). Se nenhum chegar, ele avisa, mantém o mais próximo e a pose parada continua.

## Trocar de personagem com a roda do GTA

- **Segurar o clique do analógico direito abre a roda de personagens do próprio GTA,** como segurar o direcional para baixo no controle.
- Empurre o analógico na direção do personagem: esquerda = Michael, cima = Franklin, direita = Trevor. Solte o clique e o GTA troca.
- O analógico direito controla a roda do GTA. O painel próprio do mod foi removido.
- Se o GTA não começar a troca em 1 s, o mod aperta F5, F6 ou F7 do personagem escolhido.

## Renderer antigo

O renderer voltou a ficar igual ao da 0.6.0:

- **`StereoMode=Auto`:** abaixo de ~50 FPS a imagem é igual nos dois olhos e fica mais lisa; acima de ~62 FPS vira 3D.
- **Shift+F10** alterna entre os dois na hora.
- **Mono no infinito** (`MonoDepth=0`), como antes.
- **A verificação de FOV agora só mede e escreve no log,** sem mudar a imagem (`FovCheck=Log`). Se a imagem estiver estreita demais, `FovCheck=Fix` liga a correção da 0.7.0.
- O zoom manual continua: Shift+PageUp e Shift+PageDown, e Shift+Home volta ao normal.

## Setup novo

- **Acha o GTA V Legacy sozinho:** Epic (pelos manifestos), Steam (todas as bibliotecas) e Rockstar (pelo registro). Se tiver mais de um, dá para escolher na lista.
- **Lista de verificação colorida antes de instalar:**
  - se a pasta é do GTA V Legacy (e avisa se for o Enhanced);
  - Script Hook V;
  - ASI Loader (dinput8.dll);
  - SteamVR;
  - outro renderer VR (RealVR.asi);
  - versão do GTA 5 VR já instalada.
- O botão vira **Update** quando já existe uma instalação.
- **Botões:** Install/Update, **Uninstall**, Open GTA 5 VR e "Script Hook V page".
- A opção de resetar o `GTAHandVR.ini` continua marcada por padrão.

## Desinstalar pelo menu do VR

- No menu **GTA 5 VR** (o launcher) há o botão **"Uninstall GTA 5 VR"**.
- **Remove:** o renderer, o mod de movimento, a pasta GTAHandVR, as configurações, os logs e o próprio menu, que se apaga ao fechar. A pasta de backups só sai se você quiser.
- **Não mexe** no GTA V, no Script Hook V nem no ASI Loader.
- O Setup também tem o botão Uninstall.

## Limites

**Nada disso rodou no GTA ainda.**

- O IK do GTA pode não mover a mão de nenhum jeito; o log vai dizer. Nesse caso os braços ficam na pose parada à frente do corpo.
- Não dá para saber, sem testar, se a roda do GTA aceita o analógico injetado pelo mod. Se não aceitar, o F5/F6/F7 resolve a troca.
- O Setup e o Uninstall foram compilados, mas não foram executados no Windows.
