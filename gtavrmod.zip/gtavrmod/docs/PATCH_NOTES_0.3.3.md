# 0.3.3 — sincronização de quadros (olho certo na imagem certa)

A 0.3.2 dava a cada imagem capturada o olho da **última** câmera pedida pelo script. Se o GTA mostrar a imagem de um quadro anterior (o render thread costuma ficar 1–2 quadros atrás do jogo), os olhos ficam trocados ou misturados — o bloqueio principal listado em `docs/RENDERER.md`. A 0.3.3 resolve isso medindo, em vez de supor.

## O que mudou

- **Marcador de quadro (frame tag).** A cada atualização em estéreo o script desenha, com `DRAW_RECT`, uma faixa de 96×6 px preta/branca no canto superior esquerdo com o número daquela atualização. O renderizador lê essa faixa de volta da imagem capturada (cópia assíncrona de 96×6 px, sem travar a GPU) e usa a câmera/pose **daquela** atualização. Quadros sem marcador legível são descartados em vez de receberem o olho errado. A faixa é coberta nas imagens do headset; ela continua aparecendo no monitor.
- **Atraso de aplicação da câmera.** Antes de definir a nova câmera, o script lê `GET_FINAL_RENDERED_CAM_COORD` e compara com as posições pedidas nas duas atualizações anteriores. Assim mede se o GTA aplica a câmera de script na mesma atualização ou uma depois, e corrige a correspondência automaticamente (`CameraLag=Auto`).
- **WaitGetPoses no render thread.** Antes, o script do jogo chamava `WaitGetPoses` segurando a trava compartilhada, o que podia bloquear o Present do GTA por até um quadro do headset. Agora `Submit` → `WaitGetPoses` rodam no render thread sem a trava, e o script usa uma pose prevista sem bloqueio (`GetDeviceToAbsoluteTrackingPose`), com a previsão ajustada pelo atraso medido.
- **Telas de carregamento no cinema.** A pose do render thread posiciona a tela de cinema mesmo antes do primeiro tick do script, então o carregamento pode aparecer no headset em vez de só preto.
- **Fallback seguro.** Se o marcador não for encontrado em 180 quadros seguidos (ou 900 depois de já ter funcionado), o log explica e volta à captura sem marcador da 0.3.2 (`FrameOffset`).
- **Novas opções** em `[Renderer]` do `GTAHandVR.ini` (instalações antigas usam os padrões automaticamente):
  - `FrameTag=1` — marcador ligado (padrão).
  - `FrameOffset=0` — só para o modo sem marcador.
  - `CameraLag=Auto` — ou `0` / `1` para forçar.
- **Shift+F11** alterna `CameraLag` entre Auto → 0 → 1 durante o jogo, para comparar no headset sem reiniciar.
- **Log**: linhas `Frame sync:` a cada 10 s com quadros marcados/descartados, profundidade do pipeline, atraso da câmera medido e latência plano→envio.

## Como testar

1. Instale com o `GTA5_VR_Setup.exe` desta versão (mesma pasta do GTA V Legacy).
2. No menu, mantenha **Built-in OpenVR renderer + OpenVR / SteamVR + First-person**. Salve.
3. Entre no Story Mode, recentralize com F10 e fique uns 20 segundos olhando ao redor.
4. Feche o GTA e envie o **Diagnostics**. As linhas que interessam:
   - `Frame sync: frame tag found` — o marcador funcionou.
   - `Frame sync: measured scripted-camera application ...` — o atraso medido.
   - `Frame sync: mode=tagged tagged=... untagged=...` — estatísticas.
   - `no frame tag ... cell samples` — o marcador não apareceu; as cores lidas ajudam a corrigir.
5. Teste rápido de olhos: feche um olho, depois o outro, olhando um poste próximo. Se a profundidade parecer invertida, aperte **Shift+F11** e compare; anote qual opção ficou certa.

## Limites

Continua sendo renderização alternada (cada olho recebe imagem nova a cada dois quadros) e **não foi executado no Windows, no GTA ou em um headset**. O marcador assume que os desenhos de script (`DRAW_RECT`) saem no mesmo quadro que o mundo; isso é o comportamento normal do GTA, mas precisa ser confirmado pelo log. Os binários desta versão foram compilados com llvm-mingw (clang 18.1.8) porque o Zig 0.13.0 não estava disponível no ambiente de build; o código continua compilando com Zig pelo mesmo `build.py`.
