# 0.15.3: a roda de personagens do próprio GTA e a arma que não fica mais grudada

Tudo da 0.15.0 até a 0.15.2 continua. Mudaram só estas duas coisas.

## O que vocês mandaram

- O menu de personagens ainda não troca. É para usar o menu que já vem no jogo, e não um feito pelo mod.
- A arma fica colada na mão.

## O que mudou

1. **Troca de personagem pela roda do próprio GTA.**
   - O menu CHANGE CHARACTER do mod saiu. Agora o Y abre a roda de personagens do próprio GTA, a mesma do jogo normal.
   - Quando você aperta Y, a imagem vira a tela plana do GTA dentro do óculos (a câmera e o HUD do jogo). Aí o mod segura a tecla do GTA para a roda, o Alt esquerdo, como se fosse um teclado de verdade. A roda do GTA abre e aparece nessa tela.
   - Aponte um analógico para o personagem: Michael à esquerda, Franklin em cima, Trevor à direita. O mod segura junto a tecla daquele personagem (F5, F6 ou F7), e a roda do GTA marca ele.
   - Toque rápido no Y: a roda fica aberta. Y de novo, A ou o gatilho troca. B (ou 15 segundos) fecha sem trocar.
   - Segurar o Y também funciona: segure, aponte e solte.
   - Quem troca é o próprio GTA. Se um personagem ainda não foi liberado na história, a própria roda do GTA mostra ele bloqueado. O mesmo vale numa missão ou com estrela de polícia.
   - Se a roda do GTA não abrir, aparece na tela o motivo que o mod conseguiu ver (missão, estrela de polícia, celular na mão...). O `GTAHandVR.log` também anota cada passo nas linhas "Character wheel".
   - Agora também funciona dentro do carro (a tela plana aparece no carro também).

2. **A arma não fica mais colada na mão.**
   - Desde a 0.15.0, para a arma fazer o som de verdade, o personagem segura a mesma arma no GTA, invisível. Três coisas faziam essa arma do GTA aparecer ou ficar presa na mão:
     - Ao soltar a arma, a arma do GTA voltava a ficar visível na hora, enquanto o GTA ainda guardava ela.
     - O GTA podia deixar a arma na mão do personagem por até 1,5 segundo depois que você soltava.
     - Na primeira vez que você pegava cada arma, o GTA mostrava a arma dele na mão do personagem por até 2 segundos, e a arma do VR sumia.
   - Agora:
     - A arma do GTA fica escondida o tempo todo.
     - Quando você solta a arma, o mod manda o GTA guardar ela na hora e repete até o GTA guardar. Ela continua escondida durante esse tempo.
     - A medição de como o GTA segura cada arma é feita na arma invisível. Nada aparece e a arma do VR não some mais.
   - Quando a roda de personagens está na tela plana, a arma do VR fica escondida, para não ficar flutuando na frente da câmera.
   - O som dos tiros continua igual.

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica no backup.

## Se algo ficar errado (no `GTAHandVR.ini`)

- Quer o menu do mod de volta (o da 0.15.2): `[Motion] CharacterMenu=Mod`.
- Se a arma ainda grudar na mão: `[Weapons] GunSound=Off`. O personagem para de segurar a arma no GTA, mas os tiros ficam sem som, como na 0.14.0.

## Limites

**Nada disso rodou no GTA ainda.**

- A janela do GTA precisa estar na frente, porque é ela que recebe as teclas. Se não estiver, aparece um aviso na tela.
- A troca usa o Alt esquerdo e as teclas F5, F6 e F7. Se alguém mudou essas teclas nas configurações do GTA, a troca não funciona.
- No começo da história só dá para jogar com o Franklin. Aí a roda do GTA não abre ou mostra os outros bloqueados. Isso é do próprio jogo.
- Ainda não sei com certeza o que vocês quiseram dizer com "a arma colada na mão". Corrigi o que encontrei. Se for outra coisa, mandem um vídeo curto mostrando.

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`. As linhas "Character wheel" e "Gun" mostram o que o GTA fez.
2. **Um vídeo com som** mostrando:
   - o Y abrindo a roda do GTA e a troca de personagem;
   - pegar uma arma, atirar e soltar a arma (como ela fica na mão e depois que você solta).
