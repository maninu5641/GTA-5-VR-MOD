# 0.13.0: a mão encaixa na arma, os dedos mexem e as armas ficam no corpo (igual Pavlov)

## O que você pediu

- Os dedos do personagem não mexiam.
- A mão precisa encaixar na arma, igual no Pavlov.
- Pegar a arma igual no Pavlov: a arma aparece no corpo, em vez da bola amarela.

## O que mudou

1. **Modo Pavlov (é o novo padrão).** As armas ficam no corpo:
   - quadril direito = pistola;
   - quadril esquerdo = faca, taco e outras armas brancas;
   - peito = granadas;
   - por cima do ombro direito = fuzil, escopeta, submetralhadora;
   - por cima do ombro esquerdo = sniper e armas pesadas.

   A própria arma aparece no coldre, não é mais a bola amarela. Leve a mão até ela e aperte o grip. Soltou o grip, a arma volta para o lugar dela.
   Pente, escopeta pump e cartuchos continuam iguais.
   O modo antigo (arma sempre na mão, troca com o analógico) ainda existe: `[Weapons] Mode=GTA4VR`.

2. **A mão encaixa na arma.** O personagem segura a arma do jeito que o próprio GTA segura.
   - Na primeira vez que você pega cada arma, o GTA segura essa arma por meio segundo. Nesse tempo o mod mede onde a arma fica na mão do personagem. Depois disso a mão pega a arma exatamente assim.
   - Com as duas mãos na arma, a mão direita gira junto com a arma, igual no Pavlov.
   - No log aparece "Hand on the gun: GTA holds the Pistol ...".

3. **Os dedos mexem.**
   - Mão vazia: o grip fecha a mão aos poucos, do jeito que você aperta.
   - Segurando uma arma: a mão faz a pose que o próprio GTA usa para aquela arma (pistola, fuzil, faca, granada...).
   - A mão esquerda fecha quando segura a frente da arma, um pente ou uma granada.
   - No começo, o mod confere se a mão fecha mesmo: as mãos abrem e fecham uma vez sozinhas. No log aparece "Fingers: ... Check OK".

## Painel (Shift+End)

- Braço direito: `target = the gun (GTA's grip)` quando a mão está na arma.
- Linha nova dos dedos: `Fingers: L 40% closed | R pistol grip`.

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica salvo no backup.

## Se algo ficar errado

- Os braços ficarem esquisitos: `[Hands] FingerFilter=Hand` no `GTAHandVR.ini`.
- Os dedos atrapalharem: `[Hands] Fingers=Off` volta para a pose da 0.12.0.
- A arma ficar torta na mão: `[Weapons] MeasureGrip=0`. Se continuar torta, `HandOnGun=0` volta para a 0.12.0.
- Quer a bola amarela de volta: `[Weapons] HolsterModels=0`.

## Limites

**Nada disso rodou no GTA ainda.**

- Os dedos usam as animações de "grip" das armas do próprio GTA. Se o GTA não tocar essa animação, o mod troca sozinho para poses inteiras (mão aberta, punho, pose da arma) e avisa no log.
- O dedo indicador não segue o gatilho sozinho. A mão inteira segue o grip.
- As armas das costas ficam atrás de você. Olhando para frente você não vê elas, igual no Pavlov.

## Mande depois de testar

1. **Um vídeo com o painel (Shift+End).** Mostre:
   - pegar a pistola no quadril e soltar;
   - pegar o fuzil por cima do ombro e segurar com as duas mãos;
   - abrir e fechar a mão vazia;
   - olhar para baixo para ver as armas no corpo.
2. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`.
3. **Como ficou:** a mão encaixa na arma? Os dedos fecham? As armas aparecem no corpo no lugar certo?
