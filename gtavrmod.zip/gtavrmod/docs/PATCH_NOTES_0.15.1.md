# 0.15.1: B só para o carro e um menu novo para trocar de personagem

Tudo da 0.15.0 continua (botão de VR, som dos tiros, recarga igual Pavlov). Mudaram só estas duas coisas.

## O que você pediu

- O menu de armas no B não precisa: com uma arma na mão, o analógico já troca para a próxima arma.
- Não dava para trocar de personagem.

## O que mudou

1. **B só para o carro.**
   - B entra ou rouba o carro perto (até uns 4 m) na hora, sem esperar. Dentro do carro, B sai.
   - Segurar B não abre mais o menu de armas.
   - Exceção: quando o GTA coloca uma arma especial na sua mão (galão de gasolina, extintor, ferramenta de missão), o analógico não consegue trocar. Aí segurar B ainda abre o menu, para voltar para as suas armas.
   - No celular continua igual: A atende, B desliga.

2. **Trocar de personagem.**
   - Aperte Y: abre o menu **CHANGE CHARACTER** no meio da tela, com Michael (esquerda), Franklin (em cima) e Trevor (direita).
   - Aponte um analógico para o personagem e aperte Y de novo (ou A, ou o gatilho). B fecha sem trocar. Também dá para segurar Y, apontar e soltar.
   - Antes, o mod tentava abrir o menu do próprio GTA, e pelo jeito isso não funcionava. Agora o menu é do mod, e quem troca é o próprio GTA: o mod aperta a tecla do GTA para aquele personagem (F5, F6 ou F7), igual a um teclado.
   - O GTA não deixa trocar em algumas missões, com estrela de polícia, no ar ou na água, ou antes do personagem aparecer na história. Nesses casos aparece "GTA did not switch to ..." na tela e no log.

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica no backup.

## Se algo ficar errado (no `GTAHandVR.ini`)

- Quer o menu de armas no B de volta: `[Weapons] WeaponWheel=1`.
- Quer o jeito antigo de trocar de personagem (o menu do GTA): `[Motion] CharacterKeys=0`.

## Limites

**Nada disso rodou no GTA ainda.**

- A troca usa as teclas F5, F6 e F7 do GTA. Se alguém mudou essas teclas nas configurações do GTA, a troca não funciona.
- A janela do GTA precisa estar na frente (é ela que recebe a tecla). Se não estiver, o log avisa.

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`. As linhas "Character menu" mostram o que aconteceu na troca.
2. **Um vídeo com som** mostrando: a troca de personagem (Y, apontar, Y), o B num carro, os tiros, uma recarga e o botão de VR (os dois analógicos).
