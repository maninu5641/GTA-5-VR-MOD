# 0.14.0: dedos de novo, andar sem correr, botões novos e recarga igual Pavlov

## O que vocês pediram

- A mão ficava parada, sem gestos.
- Andando normal, o personagem corria.
- Granada: pegar com a mão esquerda ou com a direita.
- B para entrar ou roubar o carro.
- Y para trocar de personagem, com o menu do GTA na tela, escolhendo com o analógico.
- No celular: A atende, B desliga.
- Motion controls já ligados quando o jogo abre, sem F8.
- Depois de recarregar, a arma não atirava. Recarga igual Pavlov.
- O círculo azul da munição vira o pente da arma.
- Com uma arma na mão, analógico direito para cima troca de arma (pistolas e armas das costas).

## O que mudou

1. **Dedos (teste das mãos).**
   - No vídeo da 0.13.0 as mãos ficaram abertas com todas as poses. Então agora o mod testa antes de usar.
   - Quando o jogo começa, as duas mãos fazem várias poses sozinhas por uns 7 segundos. É o teste das mãos.
   - O mod lê os ossos dos dedos em cada pose e só usa as poses que dobram os dedos de verdade.
   - Poses novas: as do próprio GTA para as mãos (mão aberta, punho, segurar). Depois as de cada arma.
   - Mão vazia: o grip fecha a mão. Segurando arma: a mão fica fechada na arma.
   - Gestos (se o teste aprovar): joinha, apontar e o dedo do meio.
   - Se nenhuma pose funcionar desse jeito, o mod tenta outro jeito sozinho e avisa no log.

2. **Andar.** O analógico esquerdo agora anda. Para correr, clique o analógico esquerdo (corre até soltar o analógico). Segurando o clique, o personagem dispara. Andando de verdade no quarto, ele sempre anda.

3. **Botões.**
   - **B:** entra ou rouba o carro perto (até uns 4 m). Dentro do carro, B sai. Segurar B a pé abre a roda de armas.
   - **Y:** abre o menu de personagens do GTA, numa tela no VR. Aponte um analógico para o personagem (esquerda Michael, cima Franklin, direita Trevor) e aperte Y de novo (ou A, ou o gatilho). B fecha sem trocar. Também dá para segurar Y, apontar e soltar.
   - **Celular:** quando toca ou está na mão, A atende e B desliga.
   - **Motion controls:** já vêm ligados. F8 desliga e liga.

4. **Recarga igual Pavlov.**
   - A solta o pente.
   - O próximo pente aparece no cinto, na frente à esquerda. Pegue com a mão esquerda.
   - Encoste o pente na arma: ela já está pronta para atirar. Não precisa mais puxar o ferrolho. Com `RackSlide=1` volta a precisar.
   - Sem bolas azuis: o pente da própria arma aparece no cinto e na mão.
   - Se você puxar o gatilho e a arma não atirar, o log diz o motivo ("did not fire: ...").

5. **Troca de arma no analógico.** Com uma arma na mão direita, analógico direito para cima ou para baixo troca para a próxima arma do mesmo coldre. Por exemplo: outra pistola, ou outra arma das costas.

6. **Granada.** A área do peito ficou maior (18 cm). As duas mãos pegam granada no peito. A mão direita precisa estar vazia. A esquerda não pega enquanto você estiver pegando um pente. O log mostra "Grenade: taken with the left hand".

## No instalador

Deixe marcado "Reset GTAHandVR.ini". O arquivo antigo fica no backup.

## Se algo ficar errado (no `GTAHandVR.ini`)

- Dedos atrapalhando: `[Hands] Fingers=Off`.
- Quer correr com o analógico como antes: `[Motion] StickSpeed=Run`.
- Menu de personagens dentro do 3D em vez da tela: `[Motion] CharacterWheelView=VR`.
- Motion controls desligados no começo: `[Motion] StartEnabled=0`.
- Puxar o ferrolho depois do pente: `[Weapons] RackSlide=1`.

## Limites

**Nada disso rodou no GTA ainda.**

- O teste das mãos acontece uma vez por sessão, a pé. Se ele for interrompido (carro, celular), recomeça depois.
- Os gestos dependem do que o SteamVR manda dos dedos do controle do Quest.
- Granada: não achei um erro no código. Aumentei a área e coloquei avisos no log para ver o que acontece.

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`. O teste das mãos escreve uma tabela no `GTA5VRRenderer.log` ("Fingers: hand check done"). É ela que mostra quais poses funcionam.
2. **Um vídeo com o painel (Shift+End)** mostrando:
   - o começo, com as mãos fazendo as poses;
   - abrir e fechar a mão;
   - segurar uma arma;
   - andar e correr;
   - uma recarga;
   - pegar uma granada com cada mão.
