# 0.3.1 — captura e início pela Epic com SteamVR

Esta atualização experimental trata o caminho de captura que aparecia parado em "Waiting for the game swapchain" no log da versão 0.3. O resultado no PC/headset ainda não foi confirmado.

- O renderizador recebe o swapchain pelo callback Present do Script Hook V. Foram removidos a janela temporária de DirectX, os detours e o filtro de seleção de janela.
- O log identifica as etapas de captura, inicialização do SteamVR, bindings, primeiro tracking e envio de texturas. Um aviso de etapa parada pode aparecer após 15 segundos se o script do jogo continuar executando; isso não cancela chamadas bloqueadas.
- As texturas são recriadas se o tamanho, formato, amostragem ou swapchain mudar. Uma troca de dispositivo gráfico desativa o renderizador e exige reiniciar GTA.
- O menu e as instruções explicam como salvar Built-in / OpenVR e iniciar GTA V Legacy diretamente pela biblioteca da Epic com SteamVR aberto.
- Os controles, recargas e demais interações anteriores foram preservados. OpenXR continua exigindo um renderizador externo.

Feche o jogo e o menu antes de instalar. O Setup preserva as configurações existentes; abra `GTA5 VR.exe`, selecione Built-in OpenVR renderer / OpenVR e First-person gameplay, e salve. Inicie SteamVR e depois GTA V Legacy pela Epic, em Story Mode.

Se continuar sem imagem no headset, abra Diagnostics no menu e envie o novo arquivo. Confira se o início de `GTA5VRRenderer.log` identifica 0.3.1. O primeiro envio aceito pelo SteamVR pode ser a tela preta de preparação ou o fundo de cinema, e não comprova que a visão estéreo está correta.
