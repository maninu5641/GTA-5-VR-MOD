# 0.4.1 — câmera estável (sem tremer, horizonte reto, sem balanço)

Seu amigo relatou "câmera bugada" e depois "fica tremendo a tela". Revisando o código, achei estes problemas:

1. **Horizonte torto.** A câmera VR herdava a inclinação (pitch) e o giro lateral (roll) da câmera de primeira pessoa do GTA. Se a câmera do jogo estava olhando para baixo ou inclinava ao correr ou mirar, o mundo inteiro ficava torto no headset. O teste novo mostra o problema: com a câmera do jogo 30° para baixo, olhar reto no headset mostrava o chão. **Agora só a direção (heading) do jogo gira a visão.** Inclinação e giro vêm apenas da sua cabeça (`LevelHorizon=1`).
2. **A visão balançava ao andar.** A posição vinha da câmera de primeira pessoa do GTA, que sobe e desce com a animação de andar. **Agora o olho fica preso ao corpo do personagem:** a altura do olho é medida da câmera do jogo (média de 20 quadros) e depois segue o corpo, sem o balanço (`StableCamera=1`). Ela é medida de novo sozinha quando a altura real muda por mais de 0,4 s (agachar, cobertura, escalar), ao entrar ou sair de veículo, ao trocar de personagem e com F10. Em veículo, o olho acompanha o carro exatamente.
3. **Trocas para a tela de cinema.** Antes, pular ou cair e qualquer perda rápida de controle trocava o VR pela tela plana e voltava. **Agora pular e cair continuam em VR.** Perda de controle ou ragdoll só troca para cinema se durar mais de 0,3 s. Cutscene, pausa, tela preta e morte continuam trocando na hora.

4. **A tela tremia com o personagem parado ou andando.** A direção da câmera de primeira pessoa do GTA oscila um pouco com a animação de respirar e andar. A imagem era feita com essa direção, mas o SteamVR só conhece o movimento da sua cabeça. Resultado: toda oscilação sacudia o mundo inteiro. **Agora pequenas oscilações são suavizadas**, enquanto giros de verdade (snap turn, analógico rápido) passam na hora (`StabilizeTurn=1`). No teste, uma oscilação de ±1,2° cai para menos de 0,35°.
5. **Tremia perto de paredes.** Quando a cabeça chegava perto de uma parede, a câmera pulava de volta para o corpo, e no quadro seguinte voltava para a cabeça, alternando sem parar. **Agora ela para um pouco antes da parede e volta suavemente.**
6. **A previsão de movimento da cabeça podia ir até 150 ms à frente**, o que amplifica o ruído do tracking. **Agora o limite é 60 ms.**
7. **Novo modo estável (Mono), com Shift+F10.** Os dois olhos recebem a mesma imagem do centro a cada quadro. O mundo perde a profundidade 3D, mas some o tremido próprio da renderização alternada. As mãos continuam aparecendo. Serve também de teste: **se a tremedeira some no Mono, o problema é a renderização alternada; se continua, é outra coisa** (e o log ajuda a achar). Para deixar fixo: `StereoMode=Mono`.

O log `Frame sync:` agora mostra a inclinação do jogo que foi ignorada (`game_cam_pitch_roll_ignored`), o deslocamento medido do olho (`anchor_offset`), o quanto a câmera do jogo se afasta do olho estável (`anchor_drift_m`) e quantas vezes a altura foi medida de novo (`anchor_remeasured`).

## Se ainda parecer bugado

- **Imagem dupla ou tremida ao andar no modo 3D** vem da renderização alternada: cada olho recebe imagem nova a cada dois quadros do GTA. Teste o **Shift+F10 (Mono)**. No 3D, ajuda deixar o GTA no máximo de FPS possível (gráficos mais baixos) e usar 72 ou 80 Hz no Virtual Desktop.
- Profundidade estranha: compare com **Shift+F11**.
- Para comparar com o comportamento antigo: `LevelHorizon=0` e/ou `StableCamera=0` em `[Renderer]`.
- Mande um vídeo e o Diagnostics, dizendo o que acontece: treme, inclina, duplica, fica parada ou pisca.

Continua sem execução confirmada no GTA/headset.
