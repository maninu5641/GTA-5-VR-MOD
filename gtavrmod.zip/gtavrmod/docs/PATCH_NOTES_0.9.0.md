# 0.9.0: calibração de altura, mãos, roda de personagens, mapa e armas como no GTA4VR

Feito a partir do vídeo da 0.8.0 e dos pedidos do seu amigo.

## Instalar

- No Setup, deixe marcado **"Reset GTAHandVR.ini"** (vem marcado).
- Depois de instalar, faça a **calibração de altura** uma vez (abaixo). Reinstalar com o reset apaga a calibração; é só fazer de novo.

## Calibração do corpo (altura)

1. No jogo, a pé (fora do carro), fique em pé e olhe para frente.
2. Abra os braços em **T**: retos para os lados, na altura dos ombros.
3. Aperte e segure **os dois gatilhos** por 2 segundos.

Aparece no headset: "Height calibrated: your eyes 1,xx m -> body scale x,xx".

- **O que ela faz:** o mod mede a altura dos seus olhos e a dos olhos do personagem e ajusta a escala do mundo. O chão do jogo fica no seu chão de verdade, e o braço do personagem estica quando o seu estica.
- **Enquanto você está em T, os gatilhos não atiram.**
- Fica salva no `GTAHandVR.ini`, em `[Body] PlayerEyeHeight`. Para refazer, repita o T. Para desligar, `PlayerEyeHeight=0`.
- Se aparecer "failed", confira o chão no SteamVR (Room Setup).

## Mãos

- **No vídeo, as mãos ficavam com a palma para cima.** Era a pose de "carregar caixa" da 0.8.0: o IK do GTA movia a mão, mas não girava.
- **Pose nova:** mãos na frente, palmas para baixo, paradas (pose de digitar do próprio GTA). `ArmPose=Box` volta à pose da 0.8.0.
- **O mod agora testa se o GTA consegue girar a mão do personagem.** Quando a sua mão fica parada por meio segundo, ele gira a mão do personagem para um lado e para o outro, menos de 1 segundo por teste, e mede. Se algum jeito funcionar, a mão do personagem passa a girar junto com a sua.
- **Aparece um texto curto no headset** dizendo o que está acontecendo:
  - "Hands: measuring..." enquanto testa;
  - "now turns with yours" quando funcionou;
  - "ignores the hand rotation - position only" quando o GTA não deixa girar. Nesse caso a mão segue só a posição, com as palmas para baixo.
- Se der, grave esse texto no vídeo.

## Roda de personagens do GTA

- **Segurar o clique do analógico direito continua abrindo a roda do próprio GTA.** Empurre o analógico para o personagem e solte o clique.
- **O que mudou:** o analógico agora também vai como mouse. No PC sem controle de Xbox, a roda do GTA segue o mouse; na 0.8.0 o analógico só ia como controle de Xbox, o que provavelmente era o problema. Ele também vai para os dois "controles" que o GTA lê.
- Enquanto segura o clique, aparece embaixo "CHARACTER WHEEL ... -> Franklin", mostrando para quem o analógico aponta.
- Se você soltou apontando para um personagem e o GTA não trocou, o mod aperta F5, F6 ou F7 sozinho.
- **Se a roda não aparecer no 3D:** `CharacterWheelView=Flat` mostra a tela normal do GTA (tela plana) enquanto você segura o clique.

## Mapa

- **A pé:** o minimapa do GTA aparece no **pulso esquerdo**, como um relógio. Vire o lado de fora do pulso para o rosto para ver.
- **No carro:** o minimapa aparece no **painel**, à sua frente, um pouco para a direita e para baixo.
- Em cima do mapa aparecem o relógio do jogo e as estrelas de procurado. A vida e o colete são as barras do próprio GTA, embaixo do mapa.
- **Por que antes não aparecia:** o GTA desenha o minimapa no canto da imagem, e o headset nunca mostrava esse canto. Agora o mod copia esse canto para o pulso e para o painel.
- **Ajustes em `[Map]`:** `Wrist=Left`, `Right` ou `Off`, `Dashboard=0` desliga o do painel, e dá para mudar tamanho e posição.

## Armas como no GTA4VR

| Ação | Como |
|---|---|
| Atirar | Gatilho direito |
| Próxima / anterior arma | Analógico direito para cima / para baixo |
| Escolher uma arma | B (roda de armas) |
| Soltar o pente | Grip direito (apertar até o fim) ou A |
| Pegar pente novo | Grip esquerdo por cima do ombro (ou no cinto) |
| Colocar o pente | Encostar o pente na arma |
| Puxar o ferrolho | Grip esquerdo no ferrolho e puxar (só com a câmara vazia) |
| Segurar com as duas mãos | Grip esquerdo na frente da arma |
| Escopeta pump | Depois de cada tiro, mão esquerda no guarda-mão: puxar para trás e empurrar para frente |
| Cartuchos da escopeta | Grip esquerdo por cima do ombro, depois segurar a mão embaixo da arma; entra um por vez |
| Granada | Grip no peito (qualquer mão); soltar para jogar |

- **A arma fica sempre na mão direita.** Não precisa segurar o grip.
- **As balas que sobram no pente que você solta se perdem**, como no GTA4VR. `DiscardMagazineAmmo=0` guarda essas balas.
- **Escopetas pump:** Pump, Pump Mk II, Cano Serrado (Sawed-Off), Bullpup e Combat. `PumpAction=0` desliga o pump.
- O analógico direito só gira (snap turn) para os lados; para cima e para baixo ele troca de arma.
- **Para voltar aos coldres da 0.7.0 / 0.8.0:** `Style=Holsters`.

## Limites

**Nada disso rodou no GTA ainda.**

- O GTA pode não deixar girar a mão de nenhum jeito. O log e o texto no headset vão dizer.
- Não dá para saber sem testar se a roda de personagens aceita o analógico. Se não aceitar, o F5/F6/F7 troca mesmo assim, ou use `CharacterWheelView=Flat`.
- O mapa depende de o GTA desenhar o minimapa com a câmera do VR. Se o pulso ficar vazio ou preto, mande o log (linhas "Map").
- Os dedos do personagem não se mexem; o GTA não deixa.
- A mira com luneta ampliada do GTA4VR não foi feita.

## Mande depois de testar

- **Os dois logs da pasta do GTA:** `GTA5VRRenderer.log` e `GTAHandVR.log`.
- **Um vídeo mostrando:** a calibração em T, as mãos paradas por uns segundos, a roda de personagens, o mapa no pulso e no carro, e uma recarga.
