# 0.3.4 — correção do "Submit error 106" (nada aparecia no headset)

## O que aconteceu na 0.3.3

O log enviado mostrou que tudo iniciou: o Script Hook V entregou a imagem do jogo (1914×1052), o SteamVR conectou (headset 120 Hz) e a primeira pose chegou. Mas o SteamVR recusou todas as imagens com **`Submit error 106` (`SharedTexturesNotSupported`)**, e o renderizador se desligou 0,5 s depois. No headset só aparecia o SteamVR esperando o app; o GTA ficava visível apenas como janela do desktop no dashboard.

Esse erro ocorre quando o dispositivo DirectX 11 do jogo foi criado por uma fábrica **DXGI 1.0**. O SteamVR precisa criar uma textura de sincronização compartilhada (com keyed mutex, recurso do DXGI 1.1) no dispositivo que envia as imagens, e isso falha no dispositivo do GTA V Legacy. Referência: [discussão com a Valve sobre esse erro](https://steamcommunity.com/app/358720/discussions/0/405692224241830277/).

## A correção

- **Dispositivo-ponte (bridge).** O mod cria um segundo dispositivo D3D11, por `CreateDXGIFactory1`, na **mesma GPU** do GTA (identificada pelo LUID). As capturas do GTA ficam em texturas compartilhadas (`D3D11_RESOURCE_MISC_SHARED`, o tipo de compartilhamento que o DXGI 1.0 suporta), abertas no dispositivo-ponte com `OpenSharedResource`. As texturas dos olhos, do cinema e o fundo preto pertencem ao dispositivo-ponte, e só elas são entregues ao SteamVR.
- **Ordem segura entre os dois dispositivos.** O dispositivo-ponte só lê uma captura depois que a leitura assíncrona do marcador de quadro (0.3.3) termina — isso prova que a GPU já acabou de copiar aquela imagem. A tela de cinema agora passa pelo mesmo anel de capturas.
- **Nova opção** `[Renderer] SubmitDevice=Auto` (padrão). `Bridge` exige o dispositivo-ponte; `Game` volta ao comportamento antigo. Em `Auto`, se a ponte não puder ser criada, o log explica e usa o dispositivo do GTA.
- **Log mais claro.** Mostra qual dispositivo envia as imagens, o formato do backbuffer e, se o erro 106 voltar, uma mensagem específica.
- **Diagnostics** agora inclui o final dos logs do próprio SteamVR (`vrclient_GTA5.txt`, `vrcompositor.txt`, `vrserver.txt` da pasta `Steam\logs`), que explicam recusas do compositor.

## Como testar

1. Feche o GTA e rode o `GTA5_VR_Setup.exe` da 0.3.4 na mesma pasta.
2. Inicie o SteamVR (pelo Virtual Desktop ou Link, como antes) e **feche o dashboard** depois que o GTA carregar.
3. No Story Mode, olhe para frente e aperte F10.
4. Depois envie o Diagnostics. Linhas importantes:
   - `Submit device: bridge D3D11 device (DXGI 1.1) on <sua GPU>` — a ponte foi criada.
   - `Capture: first eye textures accepted by SteamVR` — o SteamVR aceitou as imagens. Na 0.3.3 essa linha nunca apareceu.
   - `Frame sync: frame tag found` — o marcador de quadro funcionou.

## Limites

Continua **sem execução confirmada** no Windows/GTA/headset. A Microsoft recomenda não misturar fábricas DXGI 1.0 e 1.1 no mesmo processo. Ferramentas de captura como o OBS usam esse mesmo método de textura compartilhada com jogos DX11, mas um driver específico ainda pode recusar. Se a ponte falhar, o log e os logs do SteamVR incluídos no Diagnostics mostram onde.
