# 0.11.0: braços e mãos refeitos

Seu amigo disse que o braço continuava igual. Os logs da 0.10.0 mostraram por quê.

## O que os logs mostraram

- **A mão não chegava no controle.** Em todos os jeitos de chamar o IK do GTA, a mão do personagem ficava em média a 22 a 31 cm do controle.
- **O teste de girar a mão falhou nos 8 jeitos.** A mão girava só uma parte do que devia.
- **A câmera do próprio GTA ficou olhando para o chão (-70°)** depois que o painel do SteamVR abriu. A visão do VR não usa essa câmera, mas o GTA dobra a cabeça e o corpo do personagem para onde ela olha.
- **A pose de punho fechado não carregou.** Ela é uma animação do online e não existe no modo história. Ficou a pose de digitar.

## O que mudou nos braços

1. **O IK entra com força total na hora.** Antes, o mod pedia ao GTA para ligar o IK aos poucos (100 ms), e repetia o pedido a cada quadro. O mais provável é que o IK nunca chegasse na força total, e por isso a mão parava no meio do caminho. Agora ele entra na hora.
2. **O IK de primeira pessoa do próprio GTA fica desligado** enquanto as suas mãos mexem os braços. Ele puxa os braços de volta para a pose do GTA.
3. **O mod confere onde a mão foi parar.** A cada quadro ele mede a distância entre a mão do personagem e o controle. Essa diferença entra no próximo pedido ao GTA, até a mão ficar em cima do controle. Isso funciona mesmo que o GTA faça só parte do movimento.
   - Se a mão não chegar mais perto nem com essa correção, o mod desliga a correção daquele braço sozinho, para não empurrar a mão para longe do controle. O log explica o que aconteceu.
4. **A rotação da mão é aprendida enquanto você joga.** O teste que torcia a mão acabou.
   - O mod primeiro confere se o alvo invisível da mão gira do jeito certo. No log aparece "quaternion check OK".
   - Depois ele mede como o GTA gira a mão do personagem.
   - Quando você vira a mão uns 45°, ele decide sozinho: **WORKS** (a mão gira com a sua) ou **GTA ignores it** (a mão fica só na posição).

## Corpo

- **A câmera do GTA fica nivelada quando você está a pé.** Assim o personagem fica em pé, reto, e os braços saem dos ombros no lugar certo.
- A pose padrão das mãos voltou a ser a de digitar (palmas para baixo), que carrega no modo história.
  - O seu `GTAHandVR.ini` ainda deve ter `ArmPose=Grip`. Não precisa mudar: depois de 4 s o mod troca sozinho para a de digitar. Se quiser evitar essa espera, troque para `ArmPose=Typing`.

## O painel (Shift+End) e o log

- Para cada braço, o painel mostra quantos cm a mão fica do controle e quanto o mod está corrigindo.
- A rotação da mão mostra um destes:
  - "measuring": medindo;
  - "checking: turn your hand (X of 45 deg)": gire a mão devagar;
  - "WORKS": a mão gira com a sua;
  - "GTA ignores it": só posição.
- No log `GTA5VRRenderer.log` aparece a cada 15 s uma linha "Arm IK" para cada braço com esses números.

## Para comparar ou desligar (GTAHandVR.ini)

- `[Hands] IkBlendIn=100`: volta o IK a entrar aos poucos, como na 0.10.0.
- `[Hands] GameFpsArmIk=On`: deixa o IK de primeira pessoa do GTA ligado.
- `[Hands] ArmIk=Position`: só posição, a mão não gira.
- `[Body] LevelGameCamera=0`: deixa a câmera do GTA solta, como antes.

## Limites

**Nada disso rodou no GTA ainda.**

- Se o GTA não girar a mão nem assim, ela segue o controle só na posição.
- Os dedos do personagem continuam sem mexer.

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`.
2. Antes de fechar o jogo, a pé:
   - fique uns segundos com as mãos paradas em lugares diferentes (na frente do peito, do lado do corpo, para cima);
   - gire as mãos devagar, para um lado e para o outro.
3. **Um vídeo com o painel** (Shift+End) ajuda muito.
4. **Como ficou o braço:** a mão chega no controle? O cotovelo fica estranho? A mão gira junto?
