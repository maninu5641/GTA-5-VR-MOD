# 0.7.0: mãos do personagem, armas, movimento, granada, troca de personagem, zoom

## Instalar

- No instalador, deixe marcado **"Reset GTAHandVR.ini to this version's settings"** (vem marcado). O arquivo antigo vai para a pasta de backup.
- Até a 0.6.0, o instalador mantinha o `GTAHandVR.ini` antigo. Por isso várias configurações novas nunca chegavam ao PC do seu amigo. Exemplo: a recarga exigia segurar com a mão esquerda.
- No SteamVR, use o **controle padrão (binding padrão)** do app. Há uma ação nova: o toque no analógico esquerdo.

## Zoom no renderizador

**A causa mais provável é o modo Mono.** A 0.6.0 ligava o Mono abaixo de 50 FPS, e o PC do seu amigo roda a ~36. No Mono, os dois olhos veem a mesma imagem: o mundo fica chapado e parece gigante, com zoom.

- **3D voltou a ser o padrão** (`StereoMode=Alternating`).
- O modo Auto só usa Mono abaixo de ~30 FPS.
- **Shift+F10** continua alternando entre os dois.
- **Verificação do FOV (nova):** o mod mede no próprio jogo o ângulo que o GTA realmente desenhou. Se a imagem do GTA for mais estreita que a do headset, ele corrige sozinho. O log mostra linhas "FOV check".
- **Zoom manual:** Shift+PageUp e Shift+PageDown mudam de 2 em 2 %, e Shift+Home volta para 1,00 (escala exata). O valor fica salvo no INI.
- **Mono com profundidade:** se escolher Mono, a imagem aparece a 2,5 m (`MonoDepth`) em vez de no infinito. Assim ela parece menos gigante.

## Mãos do Franklin, Michael e Trevor

- **Sem mãos desenhadas por cima.** Com `Body=Character`, você vê só as mãos reais do modelo do jogo. As mãos de cápsulas só aparecem com `Body=Hidden` ou `Overlay=On`.
- **Sem animações de arma.** O personagem não segura mais nenhuma arma do GTA, então o GTA não toca animações de pistola ou fuzil nos braços. A arma está na sua mão de VR e aponta igual ao controle.
- **A mão do personagem gira como a sua.** O mod mede no jogo como os ossos da mão do GTA estão orientados e como o IK do GTA responde, e corrige sozinho. O log mostra linhas "Arm IK".
  - Se o GTA não obedecer à rotação, o mod volta para "só posição", como na 0.6.0.
  - O braço nunca é esticado além do comprimento real do braço do personagem. Isso era parte do "quebrado".
- **No carro**, as mãos ficam no volante.

## Pegar armas (revamp)

**Coldres no corpo.** Coloque a mão direita no lugar e aperte o **grip**:

| Lugar | Arma |
|---|---|
| Quadril direito | Pistola |
| Quadril esquerdo | Arma branca |
| Peito | Granadas |
| Ombro direito | Fuzil, escopeta ou SMG |
| Ombro esquerdo | Sniper ou arma pesada |

- **O coldre fica no seu corpo, não na sua cabeça.** Olhar para o lado não move mais os coldres; o corpo só gira quando você vira muito ou por um tempo.
- Ao chegar num coldre, o controle vibra, aparece um marcador e o nome da arma.
- **Modo Hold (padrão):** a arma fica na mão enquanto o grip estiver apertado; soltou, ela volta para o coldre.
- **Modo Toggle:** a arma fica na mão até você apertar o grip num coldre de novo. Use `GripMode=Toggle`.
- **Armas dadas pelo GTA vão para o coldre.** Se o GTA colocar uma arma na mão do personagem (a roda de armas do GTA ou uma missão), o mod guarda no coldre certo.
- **O botão B** escolhe qual arma cada coldre entrega.
- **O carregador** é contado pelo próprio mod. A recarga física continua igual.
- **Ajuste de altura:** se os coldres estiverem altos ou baixos demais, mude `HolsterHeight` (em metros).

## Granada

- **É só pegar e jogar.** Aperte o grip no peito para pegar e solte o grip para jogar. A granada sai com a velocidade e a direção da sua mão. Não precisa mais do gatilho.
- **Funciona com a mão esquerda também**, mesmo com uma arma na direita.
- **Para guardar**, solte a granada no próprio peito.
- **C4:** depois de jogar, a mão direita vazia vira o detonador e o gatilho explode.

## Movimento (o personagem andava sozinho)

- **Tirou o polegar do analógico, o personagem para.** Funciona pelo sensor de toque do analógico. O analógico do Quest às vezes não volta ao centro, e o resto de inclinação mantinha o personagem andando.
- **Zona morta maior com histerese:** começa a andar acima de 28 % e para abaixo de 18 %.
- **Freio:** ao soltar, o personagem para na hora, sem deslizar.
- **Para frente é para onde você olha**, como na maioria dos jogos de VR (`MoveDirection=Head`). `Body` volta ao jeito antigo.
- **F8** não aciona mais o "ir para o GTA Online" do jogo.

## Trocar de personagem

1. Segure o clique do analógico direito.
2. Empurre o analógico: esquerda = Michael, cima = Franklin, direita = Trevor.
3. Solte. Se soltar antes de escolher, ainda dá para empurrar o analógico por 3 segundos.

- A roda de personagens do próprio GTA aparece enquanto você escolhe.
- Um clique rápido no analógico continua sendo "entrar no carro".

## Carros

- **Gatilho direito acelera, gatilho esquerdo freia e dá ré.** Analógico esquerdo vira, A é o freio de mão, toque no Y sai.
- O gatilho é liberado ao soltar os gatilhos ou depois de 1 s no carro.
- O log agora registra o que os controles mandaram para o carro. Se não andar, mande o `GTAHandVR.log`.

## Limites

**Nada disso rodou no GTA ainda.**

- A rotação das mãos depende de o IK do GTA aceitar a orientação. Se não aceitar, o log diz e fica só a posição.
- Os dedos do modelo do GTA não se mexem; o dedo do meio e os gestos só aparecem com `Overlay=On`.
- A troca de personagem usa as teclas do próprio GTA (F5, F6 e F7). Ela não funciona onde o jogo não deixa trocar, como em algumas missões.
