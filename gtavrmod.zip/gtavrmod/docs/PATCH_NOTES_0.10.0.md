# 0.10.0: o corpo inteiro segue você

Pedido do seu amigo:

- Cabeça: rastreamento do headset.
- Braços: rastreamento dos dois controles.
- Mãos: orientação dos controles.
- Pernas: animação calculada por IK a partir dos movimentos do corpo.

## O que estava errado

- **O corpo ficava para trás.** No primeiro pessoa do GTA, o personagem olha para onde a câmera do GTA aponta. Essa câmera não girava quando você virava o corpo de verdade. Resultado: o corpo ficava virado para o lado antigo, e os braços tinham que dar a volta no corpo para chegar nos controles. Era isso que deixava os braços "quebrados".
- **Andar de verdade não movia o personagem.** A câmera saía do corpo (até 75 cm) e as pernas não mexiam.

## Cabeça: headset

- A câmera continua sendo o headset.
- **Agora o corpo vem atrás:** se você der um passo de verdade (mais de 30 cm), o personagem anda até ficar embaixo da sua cabeça. A câmera fica exatamente onde a sua cabeça está.
- Se tiver uma parede no caminho, ele para.

## Braços: os dois controles

- O IK do GTA continua levando as mãos até os controles.
- **O corpo agora gira junto com você.** Parado, se o seu corpo ficar virado mais de 45° para outro lado por meio segundo, o personagem gira para lá com a animação do próprio GTA. A sua visão não mexe.
- Olhar rapidamente para o lado não gira o corpo; só virar de verdade.

## Mãos: orientação dos controles

- **Pose nova das mãos: punhos fechados com o polegar para cima**, como quem segura os controles. Antes era palma para cima (0.8.0) e palma para baixo (0.9.0).
- O mod continua testando sozinho se o GTA deixa girar a mão do personagem. Agora testa 8 jeitos em vez de 4.
- Se algum jeito funcionar, a mão gira igual ao controle.
- **Se nenhum funcionar, o GTA não deixa girar a mão desse personagem.** A mão segue o controle na posição, com o punho fechado.

## Pernas: animação a partir do corpo

- **Passo de verdade:** o personagem anda com a animação do GTA (as pernas mexem).
- **Virar de verdade:** o personagem gira no lugar com a animação do GTA.
- **Agachar de verdade:** o personagem agacha. Volta a ficar em pé quando você levanta. Funciona melhor depois da calibração em T.
- **IK das pernas do GTA ligado:** os pés acompanham rampa e escada.

## Painel de diagnóstico

- **Aparece por 15 segundos quando o VR 3D começa.** Shift+End liga e desliga.
- Mostra:
  - a versão, os FPS e a calibração;
  - para cada braço, como o IK está funcionando e se a mão gira ("WORKS" ou "GTA ignores it");
  - a pose das mãos, se você está agachado, quantos passos e giros o corpo fez, e o mapa.
- **Grave um vídeo com esse painel aparecendo.** Assim eu vejo o que aconteceu no seu PC, mesmo sem os logs.

## Para desligar alguma coisa (GTAHandVR.ini, seção [Body])

- `RoomScale=0`: o corpo não anda atrás dos passos.
- `TurnBody=0`: o corpo não gira com você.
- `PhysicalCrouch=0`: agachar de verdade não agacha o personagem. `CrouchHeight=0.78` é quanto abaixar para contar como agachado.
- `LegIk=0`: tira o IK das pernas.
- `[Hands] ArmPose=Typing` ou `Box` volta às poses antigas.

## Limites

**Nada disso rodou no GTA ainda.**

- **Girar a mão depende do GTA.** O GTA só deixa mexer nos braços pelo IK dele. Se ele ignorar a rotação, a mão não gira, e o painel mostra "GTA ignores it". Nesse caso, para girar a mão seria preciso mexer direto na memória do jogo. Isso eu não consigo fazer com segurança sem testar no PC.
- Os dedos do personagem não se mexem.
- Se o GTA não girar o corpo pela câmera, o log diz "GTA's camera did not take the body turn"; `TurnBody=0` desliga.

## Mande depois de testar

- **Um vídeo com o painel de diagnóstico** (os primeiros 15 segundos do VR, ou aperte Shift+End): fique parado uns segundos com as mãos paradas, vire o corpo, dê um passo e agache.
- **Os logs da pasta do GTA:** `GTA5VRRenderer.log` e `GTAHandVR.log`.
- **Qual é o bug que continua.** Se não for o das mãos ou dos braços, me diga qual.
