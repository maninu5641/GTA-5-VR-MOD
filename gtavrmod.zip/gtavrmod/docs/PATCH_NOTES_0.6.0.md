# 0.6.0 — corpo do personagem, carros pelo controle, Chop, mira do controle

O log da 0.5.0 no PC do seu amigo mostrou que o VR funciona: o SteamVR aceitou as imagens pelo dispositivo-ponte, os olhos foram identificados em todos os quadros, as mãos foram desenhadas e os holsters foram usados. Esta versão atende os novos pedidos e corrige o que o log revelou.

## Corpo real do personagem

- **Franklin, Michael e Trevor** aparecem com o próprio corpo, roupa e braços. Trocar de personagem troca o corpo.
- A cabeça fica escondida (`CPED_RESET_FLAG_MakeHeadInvisible`), porque a câmera está dentro dela.
- **Os braços do personagem vão até os controles**, pelo IK de braço do próprio GTA (`SET_IK_TARGET`, braço esquerdo = 3, direito = 4).
- Dentro do carro o IK fica desligado: as mãos do personagem continuam no volante (ou no guidão).
- Os dedos rastreados continuam sendo desenhados por cima das mãos, para os gestos (joinha, dedo do meio...). Com `[Hands] Show=0` ficam só as mãos do GTA.
- Para voltar ao visual antigo: `[Hands] Body=Hidden`.

## Chop em primeira pessoa

- Jogando com o **Chop** (ou qualquer animal), a câmera fica na cabeça do cachorro, em primeira pessoa, olhando à frente do focinho.
- Sem mãos, sem armas, sem holsters: só andar e virar.

## Arma apontando igual ao controle

- A arma usa a orientação do **"tip" do controle no SteamVR**, a mesma direção do laser do menu do SteamVR. O cano aponta exatamente para onde o controle aponta.
- A posição continua na empunhadura.
- Ações novas `left_aim` e `right_aim`: no SteamVR, use o **binding padrão** do app.

## Carros

- **Entrar e sair:** toque rápido no **Y**, como o Y do gamepad. O clique no analógico direito também entra, mas não sai: no helicóptero e no avião esse analógico é a guinada, e um clique sem querer não pode jogar você para fora.
  - O mod aperta o "entrar" do próprio GTA, então carjacking e escolha de assento continuam funcionando.
  - Se nada acontecer em 0,7 s, ele manda o personagem entrar no carro para o qual você está olhando, ou no mais próximo.
  - Perto de um carro aparece a dica "Y or right stick click: enter vehicle".
- **Ligar e desligar o modo de movimento:** agora é **segurar o Y por 0,8 s** (ou F8).
- **Dirigir pelo controle (padrão):**

| Controle | Carro, moto, bicicleta, barco | Helicóptero, avião |
|---|---|---|
| Gatilho direito | Acelerar | Subir / acelerar |
| Gatilho esquerdo | Frear / ré | Descer / reduzir |
| Analógico esquerdo | Volante (moto: inclinar) | Rolagem / arfagem |
| Analógico direito | — | Guinada |
| A | Freio de mão | — |
| Y | Sair | Sair |

  - O volante físico continua opcional (`PhysicalDriving=1`).
- **Primeira pessoa no carro:**
  - O olho é calculado pelos ossos dos olhos do personagem, ou pelo osso da cabeça se o modelo não tiver ossos de olho. Não vem mais da câmera do GTA, que no carro pode ser de terceira pessoa.
  - Todas as visões do GTA (a pé, carro, moto, barco, avião, helicóptero) são colocadas em primeira pessoa.
  - Dentro do veículo, a visão fica presa à direção do veículo: você olha em volta com a cabeça.

## Renderizador

- **O GTA estava rodando a ~36 FPS no PC do seu amigo** (GTX 980 Ti). Com olhos alternados, cada olho recebia ~18 imagens por segundo, e isso deixa tudo travado.
- **`StereoMode=Auto` (novo padrão):** abaixo de ~50 FPS os dois olhos recebem a mesma imagem a cada quadro (Mono, sem profundidade 3D no cenário). Acima de ~62 FPS volta ao 3D.
- **Shift+F10** continua forçando um ou outro.
- **Para ganhar FPS:** gráficos e resolução do GTA mais baixos, e 72 ou 80 Hz no Virtual Desktop.
- **O olho ficava até 40 cm à frente do corpo.** Ele vinha da câmera do GTA, que estava inclinada −60°. Agora vem dos olhos do personagem. O log diz qual fonte foi usada ("eye position from the character's eye bones").
- O log de leitura da câmera agora sai a cada 30 s em vez de 5 s.

## Limites

**Nada disso rodou no GTA ainda.**

- **IK do braço:** o `SET_IK_TARGET` foi feito para um alvo por atualização. As animações de arma do GTA podem brigar com ele. Se os braços ficarem estranhos, use `[Hands] Body=Hidden`.
- **Mãos e dedos:** a rotação da mão do personagem não segue o controle, só a posição. Os dedos do GTA não se mexem; os dedos rastreados são desenhados por cima.
- **Entrar no carro:** a entrada por tarefa escolhe o banco do motorista.
