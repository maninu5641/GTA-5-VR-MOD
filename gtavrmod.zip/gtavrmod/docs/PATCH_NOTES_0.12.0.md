# 0.12.0: a mão vai direto no controle e gira junto

## O que o vídeo da 0.11.0 mostrou

- O painel dizia que as mãos estavam a 20–60 cm dos controles, com a correção no máximo (40 cm).
- **Mas no vídeo as mãos se mexem para todo lado.** Então o IK do GTA funciona: ele mexe os braços.
- **O problema era a medida.** O GTA passa para os mods a posição dos ossos do braço como ela está na animação, antes do IK. O mod lia essa posição achando que era onde a mão estava de verdade.
- Por isso a correção da 0.11.0 ficava empurrando o alvo, e a mão ia parar até 40 cm além do controle. Ficou pior.
- Isso também explica por que o teste de girar a mão nunca funcionou desde a 0.9.0: ele media a mão da animação, que nunca gira.

## O que mudou

1. **Acabou a correção.** O alvo do IK é o seu pulso, direto. Era assim que a mão seguia o controle na 0.8.0.
2. **A mão gira junto com a sua desde o começo.**
   - No primeiro segundo, o mod mede os eixos do osso da mão do personagem. Isso dá para medir mesmo com a medida da animação, porque a mão é rígida.
   - Depois ele manda o alvo da mão virado igual à sua mão.
   - O mod confere se o alvo invisível gira do jeito certo. No log aparece "quaternion check OK".
3. **Continua da 0.11.0:** o IK entra com força total na hora, o IK de primeira pessoa do GTA fica desligado, e a câmera do GTA fica nivelada a pé.
4. **Teste novo:** um marcador invisível preso no osso da mão do personagem.
   - O log ("Arm IK check") diz se o marcador mostra onde a mão está de verdade depois do IK.
   - Se mostrar, a próxima versão consegue conferir a mão com números reais.

## Painel (Shift+End)

Cada braço mostra uma linha assim:

`target = controller | rotation: ON (flags 65) | marker 3.1 cm 8 deg | anim 25.0 cm`

- **rotation:** "measuring the hand bone" no primeiro segundo; depois "ON".
- **marker:** a distância e o giro entre o marcador da mão e o alvo.
- **anim:** onde a animação deixaria a mão, só para comparar.

## Se a mão ficar torta

- `[Hands] ArmIk=Position` no `GTAHandVR.ini`: a mão segue só a posição, sem girar.

## Limites

**Nada disso rodou no GTA ainda.**

- Se o GTA aplicar a rotação de um jeito diferente do esperado, a mão vai ficar virada num ângulo errado, mas sempre o mesmo. Nesse caso, mande o vídeo que eu corrijo o ângulo.
- Os dedos do personagem continuam sem mexer.

## Mande depois de testar

1. **Um vídeo igual a esse, com o painel.** Mostre:
   - as mãos paradas na frente do corpo;
   - as mãos viradas com a palma para cima, para baixo e de lado;
   - os braços esticados e dobrados.
2. **Os dois logs** da pasta do GTA: `GTA5VRRenderer.log` e `GTAHandVR.log`.
3. **Como ficou:** a mão fica no controle? Ela gira junto com a sua? O pulso ou o cotovelo ficam tortos?
