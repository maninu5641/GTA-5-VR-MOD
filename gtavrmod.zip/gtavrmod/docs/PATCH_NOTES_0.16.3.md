# 0.16.3: o A é o E do GTA, novos nomes dos arquivos

Tudo da 0.16.2 continua (o corpo vira com você, a visão fica no corpo, a imagem suave). Mudou isto, a pedido do desenvolvedor.

## O botão A é o E do GTA

- "Quando você chega perto de alguém, como o vendedor da loja de armas, e o jogo diz para apertar E, faz funcionar com o botão A em vez do E do teclado."
- **Agora o A também aperta o E do GTA:**
  - a pé, com a mão direita sem arma de fogo (vazia, com uma arma branca ou uma granada);
  - sempre que o GTA mostra uma mensagem de ajuda no canto da tela ("Aperte E para ver as armas"). Com uma arma de fogo na mão, o carregador também sai, como antes. Dentro de um veículo, o A também puxa o freio de mão, como antes.
- Segurando o A, o E fica segurado (para o "segure E"), por até 3 s.
- O mod aperta o E de verdade, como o teclado (com a janela do GTA na frente), e também avisa o GTA pelo controle dele.
- Com o celular na mão, o A continua sendo o "atender / escolher" do celular.
- O clique do analógico direito continua sendo o E também.
- `[Controls] ReloadIsE=0` desliga isso (o A fica só com o carregador).

## O menu da loja com os controles

- Depois do E, a loja abre o menu dela e o GTA tira o controle do personagem. Antes os controles ficavam parados nessa hora.
- **Agora o menu funciona com os controles, como o teclado:**
  - analógico = setas;
  - A = Enter (escolher, comprar);
  - B = Backspace (voltar, sair);
  - X = Espaço.
- O botão que já estava apertado quando o menu abriu (o A que abriu a loja) só conta depois de solto.
- `[Menu] Controllers=0` desliga isso (e o do menu de pausa).

## No launcher

- A dica embaixo agora diz: "In game: A is GTA's E key (shops, people)."

## Novos nomes dos arquivos

- O instalador agora se chama **`gta5vrmod setup.exe`** (era `GTA5_VR_Setup.exe`).
- O pacote agora se chama **`gtavrmod.zip`** (era `GTA5_VR_<versão>.zip`), e a pasta dentro dele se chama `gtavrmod`.
- A versão continua escrita no instalador, no launcher e nos logs.
