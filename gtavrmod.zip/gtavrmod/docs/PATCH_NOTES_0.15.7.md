# 0.15.7: a arma na mão de verdade, o celular no analógico direito, cobertura no prólogo, vida por abate

Tudo da 0.15.6 continua. Mudou isto.

## O que vocês mandaram

- Três vídeos: "a posição da mão nas armas de fogo e nas granadas está bugada". No vídeo do Trevor, as armas ficam flutuando atrás do punho e a granada fica atrás do pulso.
- O prólogo, na parte das caixas: "faça o personagem se proteger do lado das caixas, só nessa missão".
- "Nessa parte você tem que pegar o celular: faça o analógico direito para cima tirar o celular, e funcionar no jogo todo."
- E: "quando matar uma pessoa, o personagem ganha um pouco de vida".

## A arma na mão

### O que estava errado

- Até a 0.15.6 a arma de VR ficava presa ao controle, e o mod mandava a mão do personagem ir até ela. A mão nunca segurava a arma de fato: se a mão do personagem não chegasse exatamente lá, a arma ficava flutuando perto dela (atrás do punho, no pulso).

### O que mudou

- **A arma agora fica presa na mão do personagem**, no ponto da palma que o próprio GTA usa para segurar objetos e armas (o osso "PH_R_Hand"). É o mesmo jeito que os scripts do GTA prendem objetos na mão: os tacos de golfe e a C4 do prólogo vão nesse ponto, sem ajuste nenhum.
- O braço continua levando a mão para onde o seu controle aponta a arma. O mod mede esse ponto da mão a cada atualização, então a arma termina onde o controle aponta.
- **O que atira é a arma que você vê na mão**: o tiro sai do cano dela, na direção dela. O pente, a bomba da escopeta e o golpe corpo a corpo também usam a arma da mão.
- Granadas: a granada fica na palma da mão (direita ou esquerda), e a mão continua sendo a sua mão. O detonador da C4 também fica na mão.
- Se por algum motivo o braço não conseguir levar a arma para onde o controle aponta (por 1,5 s), a arma volta a flutuar no controle por 10 s, como na 0.15.6, e o log diz isso ("Hand:"). Na terceira vez ela fica no controle até fechar o jogo.

## O celular no analógico direito

- **Analógico direito para cima: o celular do GTA aparece.** Funciona em todo lugar: a pé, com ou sem arma na mão, e dentro de veículos.
- Com o celular na mão: o analógico direito anda nos apps e contatos (para cima, para baixo, para os lados), A escolhe / atende, B volta / desliga.
- **Para guardar o celular: segure o analógico direito para cima por meio segundo** (ou aperte B até ele sumir).
- Mudança: antes, o analógico para cima e para baixo trocava de arma. Agora **para baixo troca para a próxima arma** e para cima é o celular.

## O prólogo: cobertura nas caixas

- No tiroteio do prólogo, na sala com as caixas (logo depois do cofre), a missão pede para se proteger atrás das caixas e espera o Trevor protegido lá, com o rifle (Carbine Rifle) na mão.
- Agora, quando o personagem chega perto das caixas nessa parte, **ele entra sozinho em cobertura atrás da caixa mais próxima**. Só nessa parte dessa missão.
- Enquanto está protegido, o personagem segura o rifle no GTA também (a missão confere isso).
- **Para sair da cobertura: puxe o analógico esquerdo para trás.** Depois que você sai, o mod não coloca o personagem de volta (só se a missão recomeçar do checkpoint).

## Vida por abate

- Cada pessoa que você mata devolve **15 de vida** ao personagem (no GTA o personagem vai de 100, morto, a 200, cheio). Vale para tiro, granada, soco e faca, e atropelamento.

## No instalador

Deixe marcado "Reset GTAHandVR.ini" (as opções novas entram; o arquivo antigo fica no backup).

## Se algo ficar errado (no `GTAHandVR.ini`)

- A arma presa na mão atrapalhando: `[Weapons] HandHold=0` volta como na 0.15.6.
- O celular no analógico atrapalhando: `[Motion] PhoneStick=0` (o analógico para cima volta a trocar de arma).
- A cobertura automática do prólogo: `[Missions] PrologueCover=0`.
- A vida por abate: `[Gameplay] HealOnKill=0` desliga; outro número muda quanto devolve.

## Limites

**Nada disso rodou no GTA ainda.**

- A arma na mão depende do braço do personagem seguir a sua mão (o padrão, `[Hands] ArmIk=Auto`). O log diz, para cada arma, a quantos centímetros e graus ela ficou de onde o controle aponta ("Hand: the ... sits ...").
- O celular: o mod aperta a tecla de celular do próprio GTA. Se o GTA não abrir o celular por ela, o log mostra "Phone: right stick up" mesmo assim; me avisem.
- O prólogo: depois de entrar em cobertura, a missão ainda pode pedir para matar os policiais para continuar. Isso é da missão.

## Mande depois de testar

1. **Os dois logs** da pasta do GTA: `GTAHandVR.log` e `GTA5VRRenderer.log`. As linhas "Hand:" dizem como ficou a arma na mão.
2. **Um vídeo** mostrando:
   - uma pistola, um rifle e uma granada na mão (olhando para a mão, girando o pulso);
   - um tiro com o rifle;
   - o analógico direito para cima (o celular aparece), andar no celular, e segurar para cima para guardar;
   - a parte das caixas no prólogo (o personagem entrando em cobertura e saindo com o analógico esquerdo para trás);
   - matar alguém e a vida subindo.
